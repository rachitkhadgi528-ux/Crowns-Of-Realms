# Crown of Realms: Pixel Ascendance

A pixel-art kingdom and PvP browser game. Made in Nepal by Rachit Production.

## Play

Open `index.html` in any modern browser. No build step, no dependencies.
(The title font loads from Google Fonts, so an internet connection is needed for it.)

### Play online with GitHub Pages

1. Push this repo to GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Your game will be live at `https://<your-username>.github.io/<repo-name>/`.

## Project structure

```
index.html        # page markup; loads the files below
css/              # stylesheets, loaded in numeric order
js/               # game scripts, loaded in numeric order
```

**Load order matters.** The scripts in `js/` are plain (non-module) scripts and
share globals, so `index.html` loads them in the same order as the numbers in
the file names. Later files extend or override earlier ones (e.g. `03-game-core.js`
is the engine, and the later numbered files add features and patches on top).
If you add a file, keep its `<script>` tag in the right place in `index.html`.

## Credits

A Rachit Production · Made in Nepal
