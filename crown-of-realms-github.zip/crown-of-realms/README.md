# Crown of Realms: Pixel Ascendance

A pixel-art kingdom and PvP browser game in a single HTML file. Made in Nepal by Rachit Production.

## Play

Open `index.html` in any modern browser. No build step, no dependencies.

### Play online with GitHub Pages

1. Push this repo to GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Your game will be live at `https://<your-username>.github.io/<repo-name>/`.

## Project structure

```
index.html   # the entire game (HTML, CSS, JS)
README.md
.gitignore
```

## Credits

A Rachit Production · Made in Nepal
