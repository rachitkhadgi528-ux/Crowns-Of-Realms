/* v25: auto-quality governor: lowers detail when fps drops, restores it when fps recovers */
(function(){window.__Q=0;let f=0,t0=performance.now(),lo=0,hi=0;const NM=['High','Balanced','Fast','Max speed'];
const note=()=>{try{toast('⚙ Auto-quality: '+NM[window.__Q])}catch(e){}};
function tick(t){requestAnimationFrame(tick);f++;if(t-t0<1000)return;const fps=f*1000/(t-t0);f=0;t0=t;
 let ig=0;try{ig=typeof inGame!='undefined'&&inGame&&!document.hidden}catch(e){}
 if(!ig){lo=hi=0;return}
 if(fps<30){lo++;hi=0}else if(fps>52){hi++;lo=0}else{lo=hi=0}
 if(lo>=2&&window.__Q<3){window.__Q++;lo=0;note()}else if(hi>=6&&window.__Q>0){window.__Q--;hi=0;note()}}
requestAnimationFrame(tick);
const xn=window.xNight;if(xn)window.xNight=function(){if(window.__Q>=2)return;return xn.apply(this,arguments)}})();
