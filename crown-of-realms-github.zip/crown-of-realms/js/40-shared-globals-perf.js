/* ===== v22: shared globals, big-war performance, night lights, Hell difficulty ===== */
(function(){try{
window.KG=KG;
window.getPB=function(){try{return PB}catch(e){return null}};
window.NPCDM=1;setInterval(()=>{try{window.NPCDM=[.9,1,1.15,1.35][LI|0]||1}catch(e){}},2000);
window.sgQ=function(list,x,y,R){let g=list.__g;const f=window.__fr|0;if(!g||g.f!==f){g={f,m:new Map()};for(let i=0;i<list.length;i++){const e=list[i];if(e.dead)continue;const k=((e.x/128)|0)*4096+((e.y/128)|0);let a=g.m.get(k);if(!a){a=[];g.m.set(k,a)}a.push(e)}try{Object.defineProperty(list,'__g',{value:g,writable:true,configurable:true,enumerable:false})}catch(e){list.__g=g}}
 const x0=((x-R)/128)|0,x1=((x+R)/128)|0,y0=((y-R)/128)|0,y1=((y+R)/128)|0;let b2=R*R,bb=null;
 for(let cx=x0;cx<=x1;cx++)for(let cy=y0;cy<=y1;cy++){const a=g.m.get(cx*4096+cy);if(!a)continue;for(let i=0;i<a.length;i++){const e=a[i],ex=e.x-x,ey=e.y-y,dd=ex*ex+ey*ey;if(dd<b2){b2=dd;bb=e}}}
 return bb?{e:bb,d:b2}:null};
window.lodDraw=function(u,x,y){const n=window.__lodN||0,Q=window.__Q|0;if(n<[240,150,90,50][Q])return false;const d=UT[u.type];if(!d||(d.big&&d.big>1)||u.type=='lord'||u.type=='messenger'||u.type=='queen'||u.type=='ram'||u.type=='treb'||u.type=='wolf'||u.std)return false;
 const pb=getPB()||{c1:'#2a5aa8'},col=u.kg?u.kg.c1:(u.team?'#8a2a2a':pb.c1);
 if(Q>=2){c.fillStyle=col;c.fillRect(x-1,y-6,3,6);return true}
 c.fillStyle='#1a1410';c.fillRect(x-2,y-8,5,9);c.fillStyle=col;c.fillRect(x-2,y-7,4,6);c.fillStyle='#e8c8a0';c.fillRect(x-1,y-10,3,3);
 if(n<520){c.fillStyle='#cfcfd8';c.fillRect(u.face>0?x+2:x-3,y-9,1,6)}return true};
const _xn2=window.xNight;window.xNight=function(lt,cx,cy){if(_xn2)_xn2(lt,cx,cy);let n=0;const fl=1+Math.sin(now()*13)*.06,vis=(x,y)=>x>cx-100&&x<cx+VW+100&&y>cy-80&&y<cy+VH+120;
 try{(window.decList?decList():[]).forEach(d=>{if(n>28||!vis(d.x,d.y))return;if(d.t=='lamp'){lt(d.x-cx,d.y-cy-16,96*fl,.95);n++}else if(d.t=='fountain'||d.t=='stall'||d.t=='well'||d.t=='statue'){lt(d.x-cx,d.y-cy-10,40,.4);n++}})}catch(e){}
 try{SLOTS.forEach(q=>{if(n>44||!q.built||!vis(q.x,q.y))return;if(q.k=='tower'||q.k=='keep')lt(q.x-cx,q.y-cy-24,70*fl,.8);else if(q.k=='home'||q.k=='farm')lt(q.x-cx,q.y-cy-10,32,.45);n++})}catch(e){}
 try{KG.forEach(k=>{if(k.cast&&vis(k.cast.x,k.cast.y))lt(k.cast.x-cx,k.cast.y-cy-24,90*fl,.85)})}catch(e){}
 try{const st=Math.max(1,ARM.length/10|0);for(let i=0;i<ARM.length;i+=st){const u=ARM[i];if(vis(u.x,u.y))lt(u.x-cx,u.y-cy-8,34,.5)}}catch(e){}};
}catch(e){console.error('v22 patch',e)}})();
