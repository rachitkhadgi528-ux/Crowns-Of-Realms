/* ===== v14: Queens, captured lords (prisoners + spectating), lord-unit unlocks, medieval barracks, performance governor ===== */
(function(){
const R=Math.random,TAU=6.2832,hyp=Math.hypot;
const ok=u=>u&&!u.dead&&u.hp>0;
const hsI=i=>(window.HS&&window.HS[((i|0)%window.HS.length+window.HS.length)%window.HS.length])||null;

/* ---------- medieval building sprites (44x36): stone footing, timber frame, tiled roof ---------- */
/* ---------- Queen ---------- */
ZMS.queen=Object.assign({},ZMS.villager||{a:'cloth',h:'hood2'},{h:'hair'});
const QC={gold:150,food:30,stone:20},QMAX=12,QNAMES=['Eleanor','Isolde','Matilda','Guinevere','Adela','Margaret','Rosamund'];
const QN={u:null,has:0,rt:0,gt:0,nm:QNAMES[R()*QNAMES.length|0]};
const home=()=>({x:PC.x,y:PC.y+44});
function fixG(u,hx,hy){u.gd=1;u.hold=1;u.rl=0;u.hx=u.sx=hx;u.hy=u.sy=hy;u.std=0}
function spawnQ(){const p=home(),u=mku(0,'queen',p.x,p.y);fixG(u,p.x,p.y);u.qn=1;u.nm='Queen '+QN.nm;QN.u=u;QN.has=1;return u}
function spawnG(){const p=home(),a=R()*TAU,ty=(R()<.55)?'cguard':'bguard',u=mku(0,ty,p.x,p.y);fixG(u,PC.x+Math.cos(a)*(70+R()*40),PC.y+55+Math.sin(a)*(40+R()*22));u.qg=1;sfx('recruit',u.x,u.y);return u}
function qTick(){if(!inGame||paused||typeof PC=='undefined')return;const t=now();
 if(!QN.u){const q=ARM.find(u=>u.type=='queen'&&ok(u));if(q){QN.u=q;QN.has=1;q.qn=1}}
 ARM.forEach(u=>{if(u.type=='queen'&&u!==QN.u&&ok(u)){u.dead=t;ARM.splice(ARM.indexOf(u),1)}});
 if(QN.u&&!ok(QN.u)){QN.u=null;QN.rt=t+75;toast('👑 The Queen has fallen! She will return in 75s');feed('The Queen has fallen!')}
 if(!QN.u&&QN.has&&QN.rt&&t>=QN.rt&&PC.hp>0){QN.rt=0;spawnQ();toast('👑 Queen '+QN.nm+' returns to the castle');sfx('win')}
 if(QN.u){fixG(QN.u,QN.u.hx,QN.u.hy);
  const gs=ARM.filter(u=>u.qg&&ok(u));gs.forEach(u=>{if(!u.gd||!u.hold)fixG(u,u.hx,u.hy)});
  const away=hyp(H.x-PC.x,H.y-PC.y)>260;
  if(t>QN.gt&&gs.length<QMAX&&ARM.length<LIM()){QN.gt=t+(away?9:22);spawnG();if(!QN.told){QN.told=1;toast('👑 The Queen trains a castle guard')}}}}
setInterval(()=>{try{qTick()}catch(e){console.error(e)}},1000);
window.qnBuy=function(){if(QN.has)return qnUI('You already have a queen.');
 if(hyp(H.x-PC.x,H.y-PC.y)>260){sfx('no');return qnUI('Return to your castle to crown a queen.')}
 if(!Object.entries(QC).every(([k,v])=>H[k]>=v)){sfx('no');return qnUI('Needs '+Object.entries(QC).map(([k,v])=>v+' '+k).join(', '))}
 for(const k in QC)H[k]-=QC[k];spawnQ();QN.gt=now()+4;sfx('win');hud();qnUI('Queen '+QN.nm+' is crowned! She will recruit guards by herself.')};
function qnUI(msg){const e=$('ov');paused=1;e.style.display='flex';const gs=ARM.filter(u=>u.qg&&ok(u)).length;
 let h='<div style="max-height:90vh;overflow:auto;width:min(94vw,460px)"><h3>👑 The Queen</h3>'+(msg?'<p style="margin:2px;color:#e8b94a">'+msg+'</p>':'');
 if(!QN.has)h+='<p>Crown one queen in your castle. She recruits castle guards on her own and defends the keep while you march to war. If she is killed she returns.</p><p><button class="g" onclick="qnBuy()">Crown a Queen</button> <small>'+Object.entries(QC).map(([k,v])=>v+' '+k).join(', ')+'</small></p>';
 else if(QN.u&&ok(QN.u))h+='<p>Queen '+QN.nm+' guards your keep.</p><p>Castle guards: '+gs+'/'+QMAX+'</p><p><small>A new guard every ~22s, every ~9s while you are away.</small></p>';
 else h+='<p>The Queen has fallen. She returns in '+Math.max(0,Math.ceil(QN.rt-now()))+'s.</p>';
 e.innerHTML=h+'<button onclick="ovx()">Close</button></div>'}
(function(){const b=document.createElement('button');b.className='b';b.id='qnb';b.textContent='👑 Queen';b.addEventListener('pointerdown',e=>{e.preventDefault();if(inGame&&!won)qnUI()});const br=$('brow');if(br)br.appendChild(b)})();
/* AI kingdoms (solo) crown a queen too; she trains home guards so the lord can march to war */
function aiQueens(){if(!inGame||paused||PV.live||typeof KG=='undefined')return;const t=now();
 KG.forEach(k=>{if(k.owned||!k.hs)return;let q=k.qn;if(q&&!ok(q)){k.qn=null;k.qrt=t+120;q=null}
  if(!q&&(!k.qrt||t>k.qrt)){q=mku(1,'queen',k.x,k.y+16,{kg:k});q.hx=q.sx=k.x;q.hy=q.sy=k.y+20;q.ex=1;q.std=0;q.nm='Queen';k.qn=q;k.qrt=0}
  if(q&&t>(k.qgt||0)){k.qgt=t+70;const n=US.filter(u=>u.kg===k&&u.qg&&!u.dead).length;
   if(n<2+Math.min(3,(k.lv|0)>>1)){const a=R()*TAU,u=mku(1,R()<.5?'cguard':'bguard',k.x,k.y+16,{kg:k});u.hx=u.sx=k.x+Math.cos(a)*(70+R()*30);u.hy=u.sy=k.y+25+Math.sin(a)*(40+R()*20);u.ex=1;u.qg=1}}})}
setInterval(()=>{try{aiQueens()}catch(e){console.error(e)}},1000);
const _du=drawU;drawU=function(u,x,y){_du(u,x,y);if(u.type!=='queen'||u.dead)return;
 const col=u.kg?u.kg.c1:(u.team?'#8a2a6a':PB.c1),sw=Math.round(Math.sin((u.ph||0))*1),f=u.face||1;
 c.fillStyle=col;c.fillRect(x-4,y-14,9,3);c.fillRect(x-5,y-11,11,3);c.fillRect(x-6+sw,y-8,13,4);c.fillRect(x-7+sw,y-4,15,4);
 c.fillStyle='#e8c040';c.fillRect(x-7+sw,y-1,15,1);c.fillRect(x-4,y-14,9,1);
 c.fillStyle='#e8c040';c.fillRect(x-3,y-34,7,2);c.fillRect(x-3,y-36,1,2);c.fillRect(x,y-37,1,3);c.fillRect(x+3,y-36,1,2);c.fillStyle='#d03040';c.fillRect(x,y-34,1,1);
 pname(x,y-45,'Queen',null,col)};

/* ---------- Prisoners: captured lords are chained and dragged by their captor ---------- */
const PR=[];window.PRIS=PR;let SELF=null;window.SPEC=0;
function addPris(o){if(PR.some(p=>p.id===o.id))return;Object.assign(o,{x:0,y:0,f:1,ph:R()*6,init:0,lie:0,seed:R()*6,v:0,lx:0,ly:0,lf:1,lm:0,dt:0});PR.push(o);if(o.id==='self')SELF=o;return o}
function resolveCap(cid){
 if(cid==='me'){if(window.SPEC)return null;return{x:H.x,y:H.y,f:H.face||1,m:!!H.m}}
 if(typeof cid=='string'&&cid[0]=='k'&&cid[1]==':'){const k=KG[+cid.slice(2)];if(!k||k.owned)return null;const L=k.lord;
  if(L&&ok(L))return{x:L.x,y:L.y,f:L.face||1,m:true};const u=USK(k)[0];if(u)return{x:u.x,y:u.y,f:u.face||1,m:false};return{x:k.x,y:k.y+34,f:1,m:false}}
 const P=MP.peers.get(cid);if(!P||P.out)return null;return{x:P.x,y:P.y,f:P.f||1,m:!!P.m}}
function updPris(dt){const tail={};
 for(let i=0;i<PR.length;i++){const p=PR[i];let cp=resolveCap(p.cid);
  if(!cp){if(p.cid!=='me'&&!window.SPEC)p.cid='me';else if(p.lastc)cp=p.lastc;else continue}
  if(!cp)continue;p.lastc=cp;
  const ld=tail[p.cid]||cp,Lr=tail[p.cid]?15:22;
  if(!p.init){p.x=ld.x-(ld.f||1)*Lr;p.y=ld.y+3;p.init=1}
  const dx=ld.x-p.x,dy=ld.y-p.y,d=hyp(dx,dy)||1,ox=p.x,oy=p.y;
  if(d>Lr){const s=Math.min(d-Lr,(46+d*2.4)*dt);p.x+=dx/d*s;p.y+=dy/d*s;if(d-s>Lr*1.7){const k=(Lr*1.7)/(d-s);p.x=ld.x-(ld.x-p.x)*k;p.y=ld.y-(ld.y-p.y)*k}}
  const mv=hyp(p.x-ox,p.y-oy);
  const v=mv/Math.max(dt,.001);p.v+=(v-p.v)*Math.min(1,dt*10);p.ph+=mv*.5;if(Math.abs(dx)>2)p.f=dx>0?1:-1;
  p.lx=ld.x;p.ly=ld.y;p.lf=ld.f||1;p.lm=cp.m&&!tail[p.cid]?1:0;
  const lyT=(cp.m&&p.v>62)?1:0;p.lie+=(lyT-p.lie)*Math.min(1,dt*6);
  if(p.lie>.5&&p.v>40){p.dt-=dt;if(p.dt<=0){p.dt=.07;PS.push({x:p.x+(R()-.5)*8,y:p.y,vx:(R()-.5)*30,vy:-R()*26,l:.5,c:R()<.5?'#b8a070':'#8a7a58'})}}
  tail[p.cid]={x:p.x,y:p.y,f:p.f}}}
let _pt=performance.now();setInterval(()=>{try{const n=performance.now(),dt=Math.min(.1,(n-_pt)/1000);_pt=n;if(!inGame||paused||!PR.length)return;updPris(dt)}catch(e){console.error(e)}},33);
window.PRL=function(L,cx,cy){for(let i=0;i<PR.length;i++){const p=PR[i];if(!p.init)continue;if(p.x>cx-40&&p.x<cx+VW+40&&p.y>cy&&p.y<cy+VH+50)L.push({k:'pris',p,x:p.x,y:p.y})}};
window.drawPris=function(p,x,y,t){
 const lx=x+(p.lx-p.x),ly=y+(p.ly-p.y),hx=lx+p.lf*5,hy=ly-(p.lm?25:14),wx=x+p.f*3,wy=y-13+p.lie*10,d=hyp(hx-wx,hy-wy),sag=Math.max(2,(26-d)*.7);
 c.strokeStyle='#7a5a30';c.lineWidth=1;c.beginPath();c.moveTo(hx,hy);c.quadraticCurveTo((hx+wx)/2,(hy+wy)/2+sag,wx,wy);c.stroke();c.fillStyle='#4a3418';c.fillRect(Math.round(hx)-1,Math.round(hy)-1,2,2);
 if(GQ=='hd')shd(x,y,p.lie>.5?20:12);else{c.fillStyle='rgba(0,0,0,.3)';c.fillRect(x-6,y-1,p.lie>.5?22:12,3)}
 const walk=p.v>6,hi=p.hi|0,hh=hsI(hi)||{c1:p.c1,c2:p.c2},tq=Math.floor(t*3)%3,pq=walk?Math.floor(((p.ph%TAU+TAU)%TAU)/TAU*8):0,ph=pq/8*TAU,f=p.f;
 const stumble=walk&&p.lie<.5?Math.sin(t*7+p.seed)*.07:0,lean=walk?.2+stumble:.05+Math.sin(t*1.4+p.seed)*.02;
 const ang=p.lie*(1.4*f)+(1-p.lie)*lean*f;
 c.save();c.translate(x,y+p.lie*3);c.rotate(ang);
 Zspr(['PR',hi,p.c1,p.c2,f,walk?1:0,pq,tq].join('|'),(ox,oy)=>Zman({x:ox,y:oy,f,sc:1.12,t:tq/3,sd:hi*5+2,mv:walk,ph,fl:0,col:p.c1,acc:p.c2,st:Object.assign({},ZHERO[hi]||ZHERO[0],{sh:0,cape:0}),up:0,atk:-1,wep:null,jp:0,wv:null,ride:0,hb:0,cape:null,wp:-1,hs:1.05}),0,0,tq);
 c.fillStyle='#6a4a2a';c.fillRect(f*2-1,-14,4,2);c.restore();
 if(p.lie<.5){pname(x,y-44,'⛓ '+p.name,'Prisoner',p.c1)}};

/* ---------- captures ---------- */
const UNL=new Set();
window.UNLK=function(){const out=[];if(typeof KG!='undefined'&&!PV.live)KG.forEach(k=>{if(k.owned&&k.hs)k.hs.u.forEach(t=>out.push(t))});UNL.forEach(i=>{const h=hsI(i);if(h)h.u.forEach(t=>out.push(t))});return out};
function unlockMsg(h){const n=h.u.map(t=>UT[t]?UT[t].n:t).join(' & ');toast('⛓ Lord '+(h.ln||h.n)+' captured! Barracks now trains: '+n);feed('Lord '+(h.ln||h.n)+' is your prisoner');say('The lord is in chains, my liege. His elite troops will now serve you.',1)}
const _cq=conquer;conquer=function(k){const was=k.owned;_cq(k);try{if(was||!k.hs||PV.live)return;const i=KG.indexOf(k),hi=window.HS.indexOf(k.hs);
 addPris({id:'k'+i,name:k.hs.ln||k.hs.n,c1:k.hs.c1,c2:k.hs.c2,hi,cid:'me'});unlockMsg(k.hs)}catch(e){console.error(e)}};
function nearestAlivePeer(x,y,skip){let b=null,bd=1e9;MP.peers.forEach(Q=>{if(Q===skip||Q.out)return;const d=hyp(Q.x-x,Q.y-y);if(d<bd){bd=d;b=Q}});return b?{id:b.id,d:bd}:null}
const _po=pOut;pOut=function(P,why){const was=P.out;_po(P,why);try{if(was||String(why).indexOf('eliminated')<0)return;
 let cid=null;const by=P.by;if(by===MP.id&&!SELF)cid='me';else if(by&&by!==P.id){const Q=MP.peers.get(by);if(Q&&!Q.out)cid=by}
 if(!cid){const q=nearestAlivePeer(P.lx,P.ly,P),dm=(PC.hp>0&&!SELF)?hyp(H.x-P.lx,H.y-P.ly):1e9;cid=(dm<(q?q.d:1e9))?'me':(q?q.id:(SELF?null:'me'))}
 if(!cid)return;PR.forEach(p=>{if(p.cid===P.id)p.cid=cid});
 const hi=((P.hi!=null?P.hi:P.s)|0)%window.HS.length;addPris({id:P.id,name:P.n,c1:P.c1,c2:P.c2,hi,cid});
 if(cid==='me'){UNL.add(hi);unlockMsg(window.HS[hi])}else{toast(P.n+' is dragged away in chains')}}catch(e){console.error(e)}};
function captorFor(){
 if(PV.live){let cid=null;const a=window.LAT,Q=a&&MP.peers.get(a);if(Q&&!Q.out)cid=a;else{const q=nearestAlivePeer(CX,CX,null);if(q)cid=q.id}return cid}
 if(typeof KG=='undefined')return null;let k=window.LK&&!window.LK.owned?window.LK:null;
 if(!k)k=KG.find(x=>!x.owned&&x.rel<0)||KG.find(x=>!x.owned);return k?'k:'+KG.indexOf(k):null}
const _ov=over;over=function(){if(won||SELF)return;_ov();try{const cid=captorFor();window.SPEC=1;
 PR.forEach(p=>{if(p.cid==='me'&&cid)p.cid=cid});
 if(cid){addPris({id:'self',name:RULER||'You',c1:PB.c1,c2:PB.c2,hi:window.HI|0,cid});SELF.init=0}
 let who='a rival lord';if(cid&&cid[0]=='k'&&cid[1]==':'){const k=KG[+cid.slice(2)];who=(k.known||k.owned||window.NOFOG)?('Lord '+((k.hs&&(k.hs.ln||k.hs.n))||'')+' of '+k.name):'an unknown lord'}else if(cid){const Q=MP.peers.get(cid);if(Q)who=Q.n}
 ARM.slice().forEach(u=>{u.dead=now();const i=ARM.indexOf(u);if(i>=0)ARM.splice(i,1)});
 $('ov').innerHTML=PV.live?'<div><h3>⛓ Your castle has fallen</h3><p>'+who+' takes you prisoner and drags you in chains. You can still watch the war through them.</p><button onclick="ovx()">Spectate</button> <button onclick="mpLeave()">Leave</button></div>':'<div><h3>⛓ Captured!</h3><p>Your castle has fallen. '+who+' drags you away in chains. You can still watch the realm through them.</p><button class="g" onclick="ovx()">Spectate</button> <button onclick="reloadToMenu()">New Reign</button></div>';$('ov').style.display='flex'}catch(e){console.error(e)}};
window.__PRS={PR,resolveCap,get:()=>SELF,clr:()=>{SELF=null}};
window.SPECT=function(){if(!SELF)return null;const cp=resolveCap(SELF.cid);if(cp)SELF.lastc=cp;return SELF.lastc||null};
setInterval(()=>{try{if(!SELF||!inGame)return;if(!PV.live){const cp=SPECT();if(cp){H.x=Math.max(30,Math.min(WD-30,cp.x+380));H.y=Math.max(30,Math.min(WD-30,cp.y+260));H.hp=H.mhp;PC.hp=0}}
 if(SELF&&!resolveCap(SELF.cid)){const q=nearestAlivePeer(CX,CX,null);if(PV.live&&q)SELF.cid=q.id}}catch(e){}},100);

/* ---------- performance governor: steps resolution/effects down if the frame rate stays low ---------- */
(function(){let last=performance.now(),ema=16,slow=0;window.PERF=0;
 (function loop(){requestAnimationFrame(loop);const n=performance.now(),d=n-last;last=n;if(d>250||!inGame||paused){slow=0;return}
  ema+=(d-ema)*.06;if(ema>27)slow+=d;else slow=Math.max(0,slow-d);
  if(slow>(CR?900:1800)&&window.PERF<2){window.PERF++;slow=0;ema=16;if(window.PERF>=2&&GQ=='hd')GQ='retro';size();toast('⚡ Performance mode '+window.PERF)}})()})();
})();
