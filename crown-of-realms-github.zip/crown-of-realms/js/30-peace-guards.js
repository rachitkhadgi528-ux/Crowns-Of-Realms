/* ===== peace guards + bot targeting of the general ===== */
(function(){
const pk=()=>!!(window.peaceOn&&peaceOn());
const _hp=hurt;hurt=function(tg,dmg,from){if(!PV.on&&!MPI&&!window.GENM&&tg&&tg.kg&&tg.team&&!tg.kg.owned&&from&&(from===H||from.team===0)&&pk())return;_hp(tg,dmg,from)};
const _hc=hitCastle;hitCastle=function(n,o){if(!window.GENM&&o&&!o.pl&&o.kg&&pk())return;_hc(n,o)};
const _be=botEnts;botEnts=function(b){const L=_be(b);try{if(window.GENM&&won&&ME.tm!==b.tm&&H.hp>0)L.push({x:H.x,y:H.y,k:'h',i:0,host:1})}catch(e){}return L};
})();
