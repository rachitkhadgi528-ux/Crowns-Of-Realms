/* ===== v13: zoom out + auto-fit army so whole formations are visible ===== */
(function(){
const MODES=[1,1.6,2.4,3.4,'auto'],LB=['1x','1.6x','2.4x','3.4x','Auto'];let mi=0,tgt=216,asp=1,man=null,pd=0,pv=216;
try{const v=localStorage.getItem('cor_zoom2');if(v!==null)mi=Math.max(0,Math.min(4,+v|0))}catch(e){}
const b=document.createElement('button');b.id='zmb';
b.style.cssText='position:fixed;left:8px;bottom:285px;z-index:20;padding:8px 10px;font:bold 13px monospace;color:#f3e9d2;background:#4a3a7a;border:3px solid #1a1030;border-radius:4px;display:none;touch-action:manipulation';
function lab(){b.textContent='🔍 '+LB[mi]}lab();
b.onclick=()=>{man=null;mi=(mi+1)%MODES.length;try{localStorage.setItem('cor_zoom2',mi)}catch(e){}lab();toast('Zoom: '+LB[mi]+(mi==4?' (fits your whole army)':''))};
document.body.appendChild(b);
addEventListener('wheel',e=>{if(!inGame||paused)return;if(e.target&&e.target.closest&&e.target.closest('#ov,#pz,#pgm'))return;mi=e.deltaY>0?Math.min(3,mi==4?3:mi+1):Math.max(0,mi==4?2:mi-1);lab()},{passive:true});
const dist=t=>Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY),cvT=t=>t.target&&t.target.tagName=='CANVAS';
addEventListener('touchstart',e=>{if(e.touches.length==2&&inGame&&cvT(e.touches[0])&&cvT(e.touches[1])){pd=dist(e.touches);pv=VH}else pd=0},{passive:true});
addEventListener('touchmove',e=>{if(pd&&e.touches.length==2){e.preventDefault();man=Math.max(216,Math.min(1000,pv*pd/Math.max(20,dist(e.touches))));b.textContent='🔍 '+(216/man>0?(man/216).toFixed(1)+'x':'')}},{passive:false});
addEventListener('touchend',e=>{if(e.touches.length<2)pd=0},{passive:true});
function want(){if(man!==null)return man;const m=MODES[mi];if(m!=='auto')return 216*m;
 let mx=0,my=0;ARM.forEach(u=>{if(u.dead)return;mx=Math.max(mx,Math.abs(u.x-H.x));my=Math.max(my,Math.abs(u.y-H.y))});
 asp=innerWidth/innerHeight;return Math.max(216,Math.min(1000,Math.max(2*my*1.3+150,(2*mx+170)/asp)))}
let sm=VH,fv=VH;
(function zl(){requestAnimationFrame(zl);try{b.style.display=(inGame&&!won)?'block':'none';if(!inGame)return;
 const raw=Math.min(1000,want()*(man===null?1+.22*(window.CINK||0):1));
 /* auto mode: ignore small army jitter (dead band) then ease slowly; manual: follow quickly */
 if(man===null&&MODES[mi]==='auto'){if(Math.abs(raw-sm)>sm*.07)sm+=(raw-sm)*.06}else sm+=(raw-sm)*.3;
 fv+=(sm-fv)*.2;const nv=Math.round(fv);if(nv===(window.__pvh||VH))return;
 window.__pvh=nv;
}catch(e){}})();
})();
