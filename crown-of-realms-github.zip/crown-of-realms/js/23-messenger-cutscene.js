/* ===== v15-5-9: messenger-slain cutscene (same sprite engine as the intro) ===== */
(function(){
const W=560,H=266;let SC=1.5;try{SC=((window.devicePixelRatio||1)>1.5&&Math.min(innerWidth,innerHeight)>600)?2:1.5}catch(e){}
let box=null,cv,g,sk,subE,sp,sg,raf=0,T0=0,spec=null,cb=null,fin=0,cur=-1,parts=[],flashA=0,fired={},last=0,pp=0,SCN=[];
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),ease=q=>q*q*(3-2*q),lerp=(a,b,q)=>a+(b-a)*q;
const cc=document.createElement('canvas').getContext('2d');
const hex=c=>{try{cc.fillStyle='#000';cc.fillStyle=c;const v=cc.fillStyle;return v[0]=='#'?v:'#888888'}catch(e){return '#888888'}};
function build(){if(box)return;box=document.createElement('div');box.id='cut';box.innerHTML='<canvas></canvas><div class="bar bt"></div><div class="bar bb"></div><div class="sub"></div><button class="sk">Skip ▸</button>';document.body.appendChild(box);
 cv=box.querySelector('canvas');cv.width=W*SC;cv.height=H*SC;g=cv.getContext('2d');subE=box.querySelector('.sub');sk=box.querySelector('.sk');sk.addEventListener('click',e=>{e.stopPropagation();end()});
 sp=document.createElement('canvas');sp.width=sp.height=64;sg=sp.getContext('2d')}
function sub(t,d){subE.classList.remove('on');void subE.offsetWidth;subE.textContent=t;subE.style.setProperty('--d',d+'s');subE.classList.add('on')}
function nar(t){try{say(t,1)}catch(e){}}
function cam(z,px,py){g.translate(W/2+px,H/2+py);g.scale(z,z);g.translate(-W/2,-H/2)}
function sky(a,b,h){const gr=g.createLinearGradient(0,0,0,h||H*.75);gr.addColorStop(0,a);gr.addColorStop(1,b);g.fillStyle=gr;g.fillRect(-20,-20,W+40,H+40)}
function ridge(col,base,amp,seed,off,step){g.fillStyle=col;g.beginPath();g.moveTo(-20,H+20);const o=((off%step)+step)%step,k0=Math.floor(off/step);for(let i=-1;i*step-o<=W+step;i++){g.lineTo(i*step-o,base-amp*(.3+.7*hs(k0+i,seed)))}g.lineTo(W+step+20,H+20);g.closePath();g.fill()}
function banner(x,y,c1,c2,t,s){s=s||1;g.fillStyle='#d8b060';g.fillRect(x-2*s,y-4*s,30*s,3*s);for(let i=0;i<26;i++){const wy=Math.sin(t*3+i*.45)*1.6*(i/26),bl=(50-(13-Math.abs(i-13))*.9)*s;g.fillStyle=c1;g.fillRect(x+i*s,y+wy,Math.ceil(s),bl);g.fillStyle=c2;g.fillRect(x+i*s,y+wy+bl*.35,Math.ceil(s),5*s)}}
function man(x,y,bs,u,t,o){const mv=o.mv?1:0,ph=o.ph||0,f=o.f;sg.clearRect(0,0,64,64);const prev=Z;Z=sg;
 try{if(u.horse)Zhorse(32,54,f,ph,0,mv,u.coat||'#6a4326',u.col);
  Zman({x:32-(u.horse?f:0),y:54,f:f,sc:u.sc||1,t:t,sd:u.sd|0,mv:mv,ph:ph,fl:o.fl||0,col:u.col,acc:u.acc,st:u.st,up:0,atk:o.atk===undefined?-1:o.atk,wep:u.wep,wv:u.wv,jp:!!u.jp,ride:u.horse?12:0,hb:u.horse&&mv?-Math.round(Math.abs(Math.sin(ph))*1.4):0,cape:u.acc,wp:-1,hs:u.hs||1})}catch(e){}finally{Z=prev}
 g.imageSmoothingEnabled=false;
 if(o.rot){g.save();g.translate(x,y);g.rotate(o.rot);g.globalAlpha=o.al===undefined?1:o.al;g.drawImage(sp,0,0,64,64,-32*bs,-54*bs,64*bs,64*bs);g.restore()}
 else{if(o.sh!==0){g.fillStyle='rgba(0,0,0,.4)';g.beginPath();g.ellipse(x,y,(u.horse?15:7)*bs,2.2*bs,0,0,6.3);g.fill()}g.globalAlpha=o.al===undefined?1:o.al;g.drawImage(sp,0,0,64,64,Math.round(x-32*bs),Math.round(y-54*bs),64*bs,64*bs);g.globalAlpha=1}}
function lordU(c1,c2,hi){return{st:ZHERO[hi]||ZHERO[0],wep:'sword',wv:ZHW[hi],jp:hi==1,horse:1,coat:hi==0?'#e2e2e8':'#5a3a22',col:c1,acc:c2,sd:hi*5+2,sc:1.12,hs:1.05}}
function msgU(){return{st:ZMS.messenger||ZMS.sword,wep:'none',wv:null,jp:false,horse:1,coat:'#7a5230',col:PB.c1,acc:PB.c2,sd:4,sc:1}}
function sol(c1,c2,k,ty){return{st:ZMS[ty||'sword']||ZMS.sword,wep:ty=='bow'?'bow':'sword',wv:null,jp:false,horse:0,col:c1,acc:c2,sd:k*3+1}}
function spark(x,y,n){for(let i=0;i<n;i++){const a=Math.random()*6.28,v=20+Math.random()*50;parts.push({x:x,y:y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-25,l:.35+Math.random()*.3,c:Math.random()<.5?'#fff2b0':'#ffb040'})}}
function bgRoad(sc){sky('#2a1a4a','#f09458',H*.72);
 let gr=g.createRadialGradient(430,118,4,430,118,95);gr.addColorStop(0,'rgba(255,214,140,.95)');gr.addColorStop(1,'rgba(255,150,60,0)');g.fillStyle=gr;g.fillRect(320,10,230,200);
 g.fillStyle='#ffd48a';g.beginPath();g.arc(430,118,22,0,6.3);g.fill();
 ridge('#6a3a5a',150,52,2,sc*.08,28);ridge('#43284a',172,36,4,sc*.18,22);
 for(let i=-1;i<9;i++){const tx=((i*88-sc*.5)%(W+90)+W+90)%(W+90)-40,ty=190;g.fillStyle='#1f2f22';for(let k=0;k<3;k++){g.beginPath();g.moveTo(tx,ty-60+k*12);g.lineTo(tx-14-k*2,ty-30+k*12);g.lineTo(tx+14+k*2,ty-30+k*12);g.fill()}g.fillStyle='#2a1a10';g.fillRect(tx-2,ty-12,4,12)}
 g.fillStyle='#35502a';g.fillRect(-20,190,W+40,90);g.fillStyle='#8a6a44';g.fillRect(-20,208,W+40,38);g.fillStyle='#6e5234';for(let i=0;i<40;i++){const x=((hs(i,1)*W*2-sc*1.4)%W+W)%W;g.fillRect(x,212+hs(i,2)*30,7,2)}
 g.fillStyle='#4a6a38';for(let i=0;i<50;i++){const x=((hs(i,3)*W*2-sc*1.4)%W+W)%W;g.fillRect(x,192+hs(i,4)*14,3,2)}}
function sRide(lt){cam(1.02+.05*lt/3.2,0,0);bgRoad(lt*70);
 const E=Math.min(spec.esc|0,4);
 for(let i=0;i<E;i++)man(150-i*26,238+(i%2)*4,3.0,sol(spec.pc1,spec.pc2,i,i%4==3?'bow':'sword'),lt,{f:1,mv:1,ph:lt*8+i*1.3});
 man(232,236,4.2,msgU(),lt,{f:1,mv:1,ph:lt*10});
 for(let i=0;i<8;i++){const u=(lt*1.4+i*.125)%1;g.fillStyle='rgba(200,170,120,'+(.5*(1-u))+')';g.fillRect(200-u*60,240-u*6-i%3,3,2)}}
function sAmb(lt){const sh=lt>1.85&&lt<2.6?(1-(lt-1.85)/.75)*2.2:0;cam(1.03,(Math.random()-.5)*sh,(Math.random()-.5)*sh);
 const dt=Math.min(.05,Math.max(0,lt-last));last=lt;
 bgRoad(200+ease(clamp(lt/1.2,0,1))*40);
 const E=Math.min(spec.esc|0,8),big=E>=8,lx=lerp(660,296,ease(clamp(lt/1.5,0,1))),lw=lt<1.5,at=lt>=1.6&&lt<2.4?(lt-1.6)/.8:-1;
 // escort
 for(let i=0;i<Math.min(E,6);i++){const x=196-(i%3)*22,y=232+(i/3|0)*10,dieT=2.3+i*.22,fl=!big&&lt>dieT,tf=clamp((lt-dieT)/.6,0,1);
  if(fl)man(x,y,3.0,sol(spec.pc1,spec.pc2,i,'sword'),lt,{f:1,mv:0,rot:-ease(tf)*1.45,al:1-clamp((lt-3.3)/.7,0,1)*.7});
  else man(x,y,3.0,sol(spec.pc1,spec.pc2,i,i%4==3?'bow':'sword'),lt,{f:1,mv:lt<1.2,ph:lt*8+i,atk:lt>1.9?((lt*1.6+i*.3)%1):-1})}
 // lord's riders
 man(lx+54,226,2.9,sol(spec.c1,spec.c2,1,'sword'),lt,{f:-1,mv:lw,ph:lt*9,atk:lt>2?((lt*1.5+.2)%1):-1});
 man(lx+84,240,2.9,sol(spec.c1,spec.c2,2,'sword'),lt,{f:-1,mv:lw,ph:lt*9+1,atk:lt>2?((lt*1.5+.6)%1):-1});
 // messenger
 const tf=clamp((lt-1.95)/.7,0,1);
 man(236,236+ease(tf)*8,4.2,msgU(),lt,{f:1,mv:lt<1.1,ph:lt*10,rot:tf>0?-ease(tf)*1.45:0,al:1-clamp((lt-3.4)/.6,0,1)*.75});
 // lord
 man(lx,238,4.6,lordU(spec.c1,spec.c2,spec.hi),lt,{f:-1,mv:lw,ph:lt*10,atk:at});
 parts=parts.filter(p=>(p.l-=dt)>0);parts.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=90*dt;g.fillStyle=p.c;g.fillRect(p.x,p.y,2,2)})}
function sWar(lt){const dt=Math.min(.05,Math.max(0,lt-last));last=lt;cam(1+.04*lt/3.4,0,0);sky('#14040a','#8a1a14',H*.8);
 g.save();g.translate(280,120);g.rotate(lt*.12);for(let i=0;i<10;i++){g.rotate(Math.PI/5);g.fillStyle='rgba(255,70,40,.07)';g.beginPath();g.moveTo(0,0);g.lineTo(-22,-420);g.lineTo(22,-420);g.fill()}g.restore();
 ridge('#2a0a10',196,46,4,lt*2,26);ridge('#12050a',214,28,8,lt*3,18);g.fillStyle='#12050a';g.fillRect(-20,214,W+40,60);
 banner(70,44,spec.c1,spec.c2,lt,2.4);banner(424,44,spec.c1,spec.c2,lt+1,2.4);
 man(280,252,4.8,lordU(spec.c1,spec.c2,spec.hi),lt,{f:-1,mv:0,ph:lt*3,atk:-1});
 for(let i=0;i<34;i++){const x=hs(i,1)*W+Math.sin(lt+i)*6,y=H-((lt*(16+hs(i,2)*24)+hs(i,3)*H)%H);g.fillStyle='rgba(255,'+(90+hs(i,4)*90|0)+',40,'+(.3+.4*hs(i,5))+')';g.fillRect(x,y,1.6,1.6)}
 const a=ease(clamp((lt-.4)/.7,0,1));g.globalAlpha=a;g.textAlign='center';g.font='bold 62px MedievalSharp,Georgia,serif';g.fillStyle='#3a0006';g.fillText(spec.title,282,92);g.fillStyle='#ff4a30';g.fillText(spec.title,280,88);
 g.font='bold 16px MedievalSharp,Georgia,serif';g.fillStyle='#000';g.fillText(spec.lordName+' of '+spec.realm,281,118);g.fillStyle='#f6e6b8';g.fillText(spec.lordName+' of '+spec.realm,280,117);g.globalAlpha=1}
function setup(){const w=spec.war;spec.title=w?'WAR!':'SLAIN';
 SCN=[{d:3.2,fi:.5,fo:.3,dr:sRide,ev:[[0,()=>{sub('Your messenger rides into unknown lands…',3);nar('Your messenger rides into unknown lands.')}]]},
 {d:4.2,fi:.2,fo:.3,dr:sAmb,ev:[[.2,()=>{sub('But the land is not empty…',1.8)}],[1.5,()=>{sfx('horn')}],[1.95,()=>{spark(250,196,12);flashA=.8;sfx('hit');setTimeout(()=>sfx('hit'),140)}],[2.5,()=>{sub('Your messenger is cut down.',2);nar(spec.lordName+' strikes down your messenger.')}]]},
 {d:3.4,fi:.15,fo:.6,dr:sWar,ev:[[0,()=>{flashA=.9;sfx('horn')}],[.3,()=>{sub(w?spec.realm+' declares WAR upon you!':spec.realm+' has spilled your blood.',3);nar(w?spec.realm+' declares war upon us!':'The road to '+spec.realm+' is soaked in blood.')}]]}];
 if(spec.short)SCN=SCN.slice(1)}
function frame(){if(fin)return;raf=requestAnimationFrame(frame);
 const t=(performance.now()-T0)/1000;let tot=0;SCN.forEach(s=>tot+=s.d);if(t>=tot){end();return}
 let i=0,ac=0;while(i<SCN.length-1&&t>=ac+SCN[i].d){ac+=SCN[i].d;i++}const S=SCN[i],lt=t-ac;
 if(i!==cur){cur=i;last=0;parts=[]}
 S.ev.forEach((e,j)=>{const key=i+':'+j;if(!fired[key]&&lt>=e[0]){fired[key]=1;try{e[1]()}catch(x){}}});
 g.setTransform(SC,0,0,SC,0,0);g.fillStyle='#000';g.fillRect(0,0,W,H);
 g.save();try{S.dr(lt)}catch(x){}g.restore();g.setTransform(SC,0,0,SC,0,0);
 let a=0;if(lt<S.fi)a=1-lt/S.fi;if(lt>S.d-S.fo)a=Math.max(a,(lt-(S.d-S.fo))/S.fo);if(a>0){g.fillStyle='rgba(0,0,0,'+clamp(a,0,1)+')';g.fillRect(0,0,W,H)}
 if(flashA>0){g.fillStyle='rgba(255,246,220,'+flashA+')';g.fillRect(0,0,W,H);flashA=Math.max(0,flashA-.035)}}
function end(){if(fin)return;fin=1;cancelAnimationFrame(raf);try{window.speechSynthesis&&speechSynthesis.cancel()}catch(e){}
 box.classList.remove('on');setTimeout(()=>{if(box){box.remove();box=null}},380);CUT.playing=0;
 try{const ov=document.getElementById('ov');if(!pp&&(!ov||ov.style.display!='flex'))paused=0}catch(e){}
 const f=cb;cb=null;try{f&&f()}catch(e){console.error(e)}}
window.CUT={playing:0,slain(s,done){
 if(CUT.playing||typeof Zman!=='function'){done&&done();return}
 try{let k=s.k,P=s.P,c1,c2,hi,ln,rn;
  if(k){c1=hex(k.c1);c2=hex(k.c2);hi=Math.max(0,KG.indexOf(k))%4;ln='Lord '+((k.hs&&(k.hs.ln||k.hs.n))||'of the realm');rn=k._nm}
  else{c1=hex(P.c1);c2=hex(P.c2);hi=(P.s|0)%4;ln=P.n;rn=P.kn}
  spec={c1,c2,hi,lordName:ln,realm:rn,esc:s.esc|0,war:s.war,short:s.short,pc1:hex(PB.c1),pc2:hex(PB.c2)};
  build();fin=0;cur=-1;fired={};parts=[];flashA=0;last=0;cb=done;CUT.playing=1;pp=paused;paused=1;setup();
  box.classList.add('on');T0=performance.now();raf=requestAnimationFrame(frame)}
 catch(e){console.error('cutscene failed',e);CUT.playing=0;try{paused=0}catch(x){}done&&done()}}};
})();
