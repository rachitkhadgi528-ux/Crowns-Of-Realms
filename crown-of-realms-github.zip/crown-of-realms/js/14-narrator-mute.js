/* ===== v9.8b: always-visible narrator mute (menu, story, in game) ===== */
(function(){
const b=document.createElement('button');b.id='nmute';b.className='b';
b.style.cssText="position:fixed;z-index:40;right:max(8px,env(safe-area-inset-right,0px));top:calc(8px + env(safe-area-inset-top,0px));padding:8px 10px;font-size:9px;background:#a8324a;color:#fff;border:3px solid #0a0710;display:none";
document.body.appendChild(b);
const nv=$('nv');if(nv){nv.style.width='auto';nv.style.minWidth='34px';nv.style.padding='0 6px';nv.style.whiteSpace='nowrap'}
function lab(){const t=voiceOn?'🔊 Narrator ON':'🔇 Narrator OFF';b.textContent=t+' (tap)';if(nv)nv.textContent=voiceOn?'🔊 Voice':'🔇 Voice';const sn=$('sn');if(sn)sn.textContent=voiceOn?'🔊 Narrator: On':'🔇 Narrator: Off'}
const _sv=setVoice;setVoice=function(v){_sv(v);lab()};
b.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();setVoice(!voiceOn)});
setInterval(()=>{const m=$('menu'),show=m&&m.style.display!='none';b.style.display=show?'block':'none';lab()},300);
lab();
})();
