/* ===== v15-5-11: pre-match cutscene — replaces the plain text story screen; also plays when a PvP match starts ===== */
(()=>{'use strict';
const $=id=>document.getElementById(id),G=f=>{try{return f()}catch(e){}},cl=(v,a,b)=>v<a?a:v>b?b:v;
let busy=0;
const off=()=>G(()=>localStorage.getItem('cor_precut'))==='0';
function cut(mode,done){
 const pvp=mode=='pvp',W=560,H=266,hi0=((G(()=>HI)|0)%4+4)%4,HH=G(()=>HS[hi0])||HS[0];
 const BC1=G(()=>PB.c1)||HH.c1,BC2=G(()=>PB.c2)||HH.c2;
 const nm=String(G(()=>RULER)||'').replace(/[<>&]/g,'').trim().slice(0,14),KN=String(G(()=>KNAME)||'').replace(/[<>&]/g,'').slice(0,24);
 const FOC=[];if(pvp)G(()=>MP.peers.forEach(p=>{if(FOC.length<4)FOC.push({c:p.c1||'#c0392b',d:p.c2||'#222',n:String(p.n||'Rival').replace(/[<>&]/g,'').slice(0,12)})}));
 while(FOC.length<3){const h=HS[(hi0+1+FOC.length)%4];FOC.push({c:h.c1,d:h.c2,n:''})}
 const wrap=document.createElement('div'),cv=document.createElement('canvas'),g=cv.getContext('2d'),sk=document.createElement('button'),sa=document.createElement('button'),vb=document.createElement('button');
 let SC=((devicePixelRatio||1)>1.5&&Math.min(innerWidth,innerHeight)>600)?2:1;wrap.style.cssText='position:fixed;inset:0;z-index:99999;background:#000;transition:opacity .8s';cv.width=W*SC;cv.height=H*SC;cv.style.cssText='position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#000';
 const bs='position:absolute;top:calc(8px + env(safe-area-inset-top,0px));z-index:2;font:15px Georgia,serif;padding:6px 12px;background:#c04e22;border:3px solid #24100a;color:#f6e2b8';
 sk.textContent='Skip ▸';sk.style.cssText=bs+';right:10px';sa.textContent='Skip always';sa.style.cssText=bs+';right:96px;background:#4a3a2a;font-size:12px;padding:8px 10px';
 const vl=()=>{vb.textContent=G(()=>voiceOn)?'🔊':'🔇'};vb.style.cssText=bs+';left:10px;background:#2c2250;border-color:#4b3d86';vl();vb.onclick=()=>{G(()=>setVoice(!voiceOn));vl()};
 wrap.append(cv,sk,sa,vb);document.body.append(wrap);
 const clamp=cl,ease=q=>q*q*(3-2*q),lerp=(a,b,q)=>a+(b-a)*q;let flashA=0,fin=0,raf=0,cur=-1,T0=performance.now(),lastF=0;const fired={};let parts=[];
/* ---------- sound ---------- */
let ia=null,mg=null,nb=null;
const mut=()=>{try{return !!muted}catch(e){return false}};
function ainit(){if(ia)return;try{ia=new(window.AudioContext||window.webkitAudioContext)();mg=ia.createGain();mg.gain.value=.55;mg.connect(ia.destination);const L=ia.sampleRate*2;nb=ia.createBuffer(1,L,ia.sampleRate);const d=nb.getChannelData(0);for(let i=0;i<L;i++)d[i]=Math.random()*2-1}catch(e){ia=null}}
const ok=()=>ia&&mg&&!mut();
function drum(v,f0){if(!ok())return;const n=ia.currentTime,o=ia.createOscillator(),q=ia.createGain();o.type='sine';o.frequency.setValueAtTime(f0||120,n);o.frequency.exponentialRampToValueAtTime(40,n+.3);q.gain.setValueAtTime(v||.6,n);q.gain.exponentialRampToValueAtTime(.001,n+.5);o.connect(q);q.connect(mg);o.start(n);o.stop(n+.55)}
function nz(dur,fq,Q,v,type,at){if(!ok())return;const n=ia.currentTime,s=ia.createBufferSource();s.buffer=nb;s.loop=true;const f=ia.createBiquadFilter();f.type=type||'bandpass';f.frequency.value=fq;f.Q.value=Q||1;const q=ia.createGain();q.gain.setValueAtTime(.0001,n);q.gain.linearRampToValueAtTime(v,n+(at||.005));q.gain.exponentialRampToValueAtTime(.0001,n+dur);s.connect(f);f.connect(q);q.connect(mg);s.start(n);s.stop(n+dur+.05)}
function tone(fq,dur,v,type,at,det){if(!ok())return;const n=ia.currentTime;[0,det||4].forEach(dt=>{const o=ia.createOscillator(),f=ia.createBiquadFilter(),q=ia.createGain();o.type=type||'sawtooth';o.frequency.value=fq;o.detune.value=dt;f.type='lowpass';f.frequency.value=fq*5;q.gain.setValueAtTime(.0001,n);q.gain.linearRampToValueAtTime(v,n+(at||.5));q.gain.setValueAtTime(v,n+dur*.6);q.gain.exponentialRampToValueAtTime(.0001,n+dur);o.connect(f);f.connect(q);q.connect(mg);o.start(n);o.stop(n+dur+.05)})}
const horn=(fq,dur)=>tone(fq,dur||2.2,.07,'sawtooth',.5,6);
const clash=v=>{nz(.12,2600+Math.random()*1800,1.4,v||.1);tone(900+Math.random()*700,.1,.02,'square',.004,0)};
const pad=()=>[55,82.4,110].forEach(f=>tone(f,6.5,.05,'triangle',2.4,3));
const chime=()=>[880,1318.5,1760].forEach((f,i)=>setTimeout(()=>tone(f,1.8,.05,'sine',.02,2),i*120));
function narr(t){try{if(window.speechSynthesis&&typeof say==='function')say(t,1)}catch(e){}}
/* ---------- drawing helpers ---------- */
function cam(z,px,py){g.translate(W/2+px,H/2+py);g.scale(z,z);g.translate(-W/2,-H/2)}
function sky(a,b,h){const gr=g.createLinearGradient(0,0,0,h||H*.75);gr.addColorStop(0,a);gr.addColorStop(1,b);g.fillStyle=gr;g.fillRect(-20,-20,W+40,H+40)}
function stars(t,n,al){for(let i=0;i<n;i++){g.fillStyle='rgba(255,255,230,'+(al*(.35+.65*Math.abs(Math.sin(t*1.5+i))))+')';g.fillRect(Math.floor(hs(i,1)*W),Math.floor(hs(i,2)*H*.55),hs(i,3)>.9?2:1,1)}}
function ridge(col,base,amp,seed,off,step){g.fillStyle=col;g.beginPath();g.moveTo(-20,H+20);const o=((off%step)+step)%step,k0=Math.floor(off/step);for(let i=-1;i*step-o<=W+step;i++){g.lineTo(i*step-o,base-amp*(.3+.7*hs(k0+i,seed)))}g.lineTo(W+step+20,H+20);g.closePath();g.fill()}
function fog(t,y,col,sp){for(let i=0;i<3;i++){const gx=((t*sp*(8+i*5)+i*190)%(W+240))-120,gr=g.createRadialGradient(gx,y+i*7,2,gx,y+i*7,95);gr.addColorStop(0,col);gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(gx-100,y-45,200,110)}}
function flame(x,y,t,k){k=k||1;const f=Math.sin(t*17+x)*1.2,gr=g.createRadialGradient(x,y,1,x,y,46*k+f*3);gr.addColorStop(0,'rgba(255,176,74,.8)');gr.addColorStop(1,'rgba(255,106,26,0)');g.fillStyle=gr;g.fillRect(x-50*k,y-50*k,100*k,100*k);g.fillStyle='#e8501a';g.beginPath();g.moveTo(x-4,y);g.quadraticCurveTo(x-5,y-8,x+f,y-15-f);g.quadraticCurveTo(x+5,y-8,x+4,y);g.fill();g.fillStyle='#ffd070';g.beginPath();g.moveTo(x-2,y);g.quadraticCurveTo(x-2,y-5,x+f*.5,y-9);g.quadraticCurveTo(x+2,y-5,x+2,y);g.fill();g.fillStyle='#3a2410';g.fillRect(x-1,y,2,12)}
function banner(x,y,c1,c2,t,s){s=s||1;g.fillStyle='#d8b060';g.fillRect(x-2*s,y-4*s,30*s,3*s);for(let i=0;i<26;i++){const wy=Math.sin(t*3+i*.45)*1.6*(i/26),bl=(50-(13-Math.abs(i-13))*.9)*s;g.fillStyle=c1;g.fillRect(x+i*s,y+wy,Math.ceil(s),bl);g.fillStyle=c2;g.fillRect(x+i*s,y+wy+bl*.35,Math.ceil(s),5*s)}}
function castle(x,y,s,col,t){const R=(a,b,w,h)=>g.fillRect(Math.round(x+a*s),Math.round(y+b*s),Math.ceil(w*s),Math.ceil(h*s));g.fillStyle=col;R(-40,-30,80,30);R(-50,-54,18,54);R(32,-54,18,54);R(-9,-74,18,74);
 for(let i=-40;i<40;i+=8)R(i,-34,4,4);[[-50,-54,18],[32,-54,18],[-9,-74,18]].forEach(a=>{for(let i=0;i<a[2];i+=6)R(a[0]+i,a[1]-4,3,4)});
 g.beginPath();g.moveTo(x-12*s,y-78*s);g.lineTo(x,y-100*s);g.lineTo(x+12*s,y-78*s);g.fill();
 const fl=.6+.4*Math.sin(t*9+1);g.fillStyle='rgba(255,196,96,'+fl+')';R(-3,-62,6,9);R(-44,-42,5,8);R(38,-42,5,8);R(-24,-20,5,7);R(18,-20,5,7)}
function throne(x,y,s,glow,t){if(glow){const gr=g.createRadialGradient(x,y-26*s,2,x,y-26*s,75*s);gr.addColorStop(0,'rgba(255,214,110,'+glow+')');gr.addColorStop(1,'rgba(255,170,60,0)');g.fillStyle=gr;g.fillRect(x-80*s,y-105*s,160*s,135*s)}
 const R=(c,a,b,w,h)=>{g.fillStyle=c;g.fillRect(Math.round(x+a*s),Math.round(y+b*s),Math.ceil(w*s),Math.ceil(h*s))};
 R('#2a1a0e',-26,-3,52,4);R('#3a2410',-22,-7,44,4);R('#5a3a1a',-18,-11,36,4);
 R('#2a1408',-11,-48,22,38);R('#7a1a1a',-8,-45,16,32);R('#d4af37',-12,-52,24,4);R('#d4af37',-12,-52,3,42);R('#d4af37',9,-52,3,42);
 R('#f0d070',-13,-57,5,5);R('#f0d070',8,-57,5,5);R('#f0d070',-2,-60,4,8);
 R('#4a2a10',-15,-26,30,5);R('#8a1c1c',-10,-30,20,5);R('#d4af37',-15,-26,4,16);R('#d4af37',11,-26,4,16)}
function crown(x,y,s,t){const gr=g.createRadialGradient(x,y,2,x,y,34*s);gr.addColorStop(0,'rgba(255,230,140,.75)');gr.addColorStop(1,'rgba(255,190,60,0)');g.fillStyle=gr;g.fillRect(x-36*s,y-36*s,72*s,72*s);
 const R=(c,a,b,w,h)=>{g.fillStyle=c;g.fillRect(Math.round(x+a*s),Math.round(y+b*s),Math.ceil(w*s),Math.ceil(h*s))};
 R('#b8901c',-8,0,16,5);R('#e8c040',-8,0,16,3);[-8,-4,0,4,7].forEach((a,i)=>{R('#f0d070',a,-(i==2?7:4),i==4?1:3,i==2?7:4)});R('#d01830',-1,1,2,2);R('#3a7ad0',-6,1,1.5,1.5);R('#30b060',4.5,1,1.5,1.5)}

 const FOL=[[['crus','sword',0],['crus','sword',0],['hcav','spear',0]],[['saru','sword','katana'],['xbow','bow'],['saru','sword','katana']],[['legi','sword','gladius'],['jave','spear'],['legi','sword','gladius']],[['tarc','bow',0],['tlan','spear'],['tarc','bow',0]]];
 const heroU=(hi,c1,c2,horse)=>({st:ZHERO[hi]||ZHERO[0],wep:'sword',wv:ZHW[hi],jp:hi==1,horse:!!horse,coat:hi==0?'#e2e2e8':'#8a5a2a',col:c1,acc:c2,sd:hi*5+2,sc:1.12,hs:1.05});
 const unitU=(hi,k)=>{const f=FOL[hi][k%FOL[hi].length],ty=f[0],h=HS[hi]||HS[0];return{st:ZMS[ty]||ZMS.sword,wep:f[1],wv:f[2]||null,jp:f[2]=='katana',horse:false,coat:'#6a4326',col:h.c1,acc:h.c2,sd:k*3+hi}};
 const SPC=new Map();let uid=0;
 function spr(x,y,bs,u,t,o){const mv=o.mv?1:0,ph=o.ph||0,f=o.f;if(!u.__id)u.__id=++uid;
  const pq=Math.round(((ph%6.2832+6.2832)%6.2832)/6.2832*10)%10,aq=o.atk===undefined||o.atk<0?-1:Math.round(o.atk*8),tq=Math.floor(t*8)%32,key=u.__id+'|'+f+'|'+mv+'|'+(mv?pq:0)+'|'+aq+'|'+(o.fl|0)+'|'+(o.tint||'')+'|'+tq;
  let img=SPC.get(key);
  if(!img){img=document.createElement('canvas');img.width=img.height=64;const sx=img.getContext('2d'),prev=Z;Z=sx;
  try{if(u.horse)Zhorse(32,54,f,ph,0,mv,u.coat||'#6a4326',u.col);
   Zman({x:32-(u.horse?f:0),y:54,f:f,sc:u.sc||1,t:tq/8,sd:u.sd|0,mv:mv,ph:ph,fl:o.fl||0,col:u.col,acc:u.acc,st:u.st,up:0,atk:o.atk===undefined?-1:o.atk,wep:u.wep,wv:u.wv,jp:!!u.jp,ride:u.horse?12:0,hb:u.horse&&mv?-Math.round(Math.abs(Math.sin(ph))*1.4):0,cape:u.acc,wp:-1,hs:u.hs||1})}finally{Z=prev}
  if(o.tint){sx.globalCompositeOperation='source-atop';sx.fillStyle=o.tint;sx.fillRect(0,0,64,64);sx.globalCompositeOperation='source-over'}
  if(SPC.size>900){let n=0;for(const k of SPC.keys()){SPC.delete(k);if(++n>=300)break}}SPC.set(key,img)}
  g.fillStyle='rgba(0,0,0,.4)';g.beginPath();g.ellipse(x,y,(u.horse?15:7)*bs,2.2*bs,0,0,6.3);g.fill();
  g.imageSmoothingEnabled=false;g.drawImage(img,0,0,64,64,Math.round(x-32*bs),Math.round(y-54*bs),64*bs,64*bs)}
 function fw(x,y){const col=['#ffd24a','#ff6a4a','#6ad0ff','#fff','#b46aff'][Math.random()*5|0];for(let i=0;i<26;i++){const a=i/26*6.283,v=45+Math.random()*30;parts.push({x:x,y:y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:1.2,c:col})}try{nz(.5,900,.8,.08,'bandpass',.01)}catch(e){}}
 function drawParts(dt){parts=parts.filter(p=>(p.l-=dt)>0);parts.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=70*dt;g.globalAlpha=clamp(p.l,0,1);g.fillStyle=p.c;g.fillRect(p.x,p.y,2,2)});g.globalAlpha=1}
 let fwT=0;function fwAuto(lt,from,to){if(lt>from&&lt<to&&lt>fwT){fwT=lt+.5+Math.random()*.4;fw(120+Math.random()*320,30+Math.random()*70)}}
 function txt(s,x,y,sz,col,a){g.globalAlpha=clamp(a,0,1);g.textAlign='center';g.fillStyle='#000';g.font=(sz>20?'bold ':'')+sz+'px Georgia,serif';g.fillText(s,x+1,y+1);g.fillStyle=col;g.fillText(s,x,y);g.globalAlpha=1}
 const HERO=heroU(hi0,BC1,BC2,0),HEROH=heroU(hi0,BC1,BC2,hi0==0||hi0==3);
 const ARMY=[];for(let i=0;i<12;i++){const u=unitU(hi0,i);u.col=BC1;u.acc=BC2;ARMY.push(u)}
 const VIL=[];for(let i=0;i<5;i++){const u=unitU(hi0,i+3);u.coat='#6a4326';VIL.push(u)}
 const sub2=(s,lt,d)=>{const a=clamp(lt/.6,0,1)*clamp((d-lt)/.6,0,1);g.setTransform(SC,0,0,SC,0,0);if(a>0){g.globalAlpha=a*.55;g.fillStyle='#000';g.fillRect(0,H*.82,W,H*.12);g.globalAlpha=1}txt(s,280,H*.9,14,'#f3e1b0',a)};
 const pole=(x,y,h,c1,c2,lt,s)=>{g.fillStyle='#3a2a1a';g.fillRect(x,y-h,2,h);banner(x+2,y-h+2,c1,c2,lt,s||.6)};
 const embers=(lt,n)=>{for(let i=0;i<n;i++){const x=hs(i,1)*W+Math.sin(lt+i)*6,y=H-((lt*(14+hs(i,2)*22)+hs(i,3)*H)%H);g.fillStyle='rgba(255,'+(120+hs(i,4)*90|0)+',50,'+(.3+.4*hs(i,5))+')';g.fillRect(x,y,1.6,1.6)}};
 /* S1: the shattered realm at dusk */
 function s1(lt){cam(1+.05*lt/4.4,-lt*3,0);sky('#14081e','#d2602c',H*.8);
  let gr=g.createRadialGradient(150,176,4,150,176,130);gr.addColorStop(0,'rgba(255,170,80,.7)');gr.addColorStop(1,'rgba(255,100,40,0)');g.fillStyle=gr;g.fillRect(-20,30,400,236);
  stars(lt,40,.45);ridge('#4a2438',170,54,2,lt*2,26);ridge('#2a1424',188,34,5,lt*4,18);g.fillStyle='#1c1016';g.fillRect(-40,198,W+80,H);
  castle(430,200,1.5,'#120a12',lt);flame(402,132,lt,1.1);flame(458,142,lt,.9);flame(430,96,lt,1.3);
  for(let k=0;k<5;k++){const yy=120-((lt*10+k*26)%110);g.fillStyle='rgba(30,22,26,'+(.4-(120-yy)/330)+')';g.beginPath();g.ellipse(430+Math.sin(lt+k)*10+(k-2)*14,yy,10+(120-yy)/5,13,0,0,6.3);g.fill()}
  FOC.slice(0,3).forEach((f,i)=>pole(60+i*130,198,50,f.c,f.d,lt+i,.7));
  g.fillStyle='#0a0508';for(let i=0;i<6;i++){const x=(lt*34+i*96)%(W+40)-20,y=56+Math.sin(lt*2+i)*14+i*4,fl=Math.sin(lt*14+i)>0?1:-1;g.fillRect(x,y,3,1);g.fillRect(x-3,y-fl,3,1);g.fillRect(x+3,y-fl,3,1)}
  embers(lt,36);fog(lt,214,'rgba(70,40,30,.3)',2)}
 /* S2: the campfire at night — you and the first villagers */
 function s2(lt){cam(1+.04*lt/4.4,0,0);sky('#04030a','#1a1030',H*.8);stars(lt,90,.95);
  g.fillStyle='#e8e4d0';g.beginPath();g.arc(452,50,12,0,6.3);g.fill();g.fillStyle='#0a0618';g.beginPath();g.arc(457,47,11,0,6.3);g.fill();
  ridge('#120c20',176,50,3,lt,26);ridge('#0a0614',196,30,6,lt*2,18);g.fillStyle='#0c0810';g.fillRect(-20,206,W+40,H);
  for(let i=0;i<9;i++){const x=i*70+hs(i,1)*30-10,h=50+hs(i,2)*40;g.fillStyle='#07040c';g.beginPath();g.moveTo(x,206);g.lineTo(x+14,206-h);g.lineTo(x+28,206);g.fill()}
  const fl=.85+.15*Math.sin(lt*13);let gr=g.createRadialGradient(280,214,4,280,214,200*fl);gr.addColorStop(0,'rgba(255,170,70,.6)');gr.addColorStop(1,'rgba(255,100,30,0)');g.fillStyle=gr;g.fillRect(-20,-20,W+40,H+40);
  g.fillStyle='#3a2210';g.fillRect(262,220,36,5);g.fillStyle='#4a2c14';g.fillRect(268,216,24,5);flame(280,218,lt,1.6);
  for(let i=0;i<10;i++){const u=(lt*.7+i*.1)%1;g.fillStyle='rgba(255,'+(150+i*8)+',60,'+(1-u)+')';g.fillRect(280+Math.sin(i*2.3+lt*3)*14*u,214-u*70,1.6,1.6)}
  [[-40,170,1],[W+40,392,-1],[-40,130,1],[W+40,432,-1],[-40,340,1]].forEach((a,i)=>{if(i>=VIL.length)return;const q=ease(clamp((lt-.5-i*.45)/2.4,0,1)),x=lerp(a[0],a[1],q),f=q<1?a[2]:(a[1]<280?1:-1);spr(x,236+(i%2)*9,3.2,VIL[i],lt+i,{f:f,mv:q>0&&q<1,ph:lt*8+i*1.7,atk:-1})});
  spr(232,238,4.4,HERO,lt,{f:1,mv:0,atk:lt>2.6?((lt-2.6)*1.1%1)*.7:-1})}
 /* S3: gather, build, train */
 function s3(lt){cam(1.02+.03*lt/4.4,-lt*2,0);sky('#2a1a48','#f2a45a',H*.72);
  let gr=g.createRadialGradient(430,150-lt*4,4,430,150-lt*4,120);gr.addColorStop(0,'rgba(255,220,140,.9)');gr.addColorStop(1,'rgba(255,170,80,0)');g.fillStyle=gr;g.fillRect(280,-20,300,290);g.fillStyle='#ffe2a0';g.beginPath();g.arc(430,150-lt*4,24,0,6.3);g.fill();
  ridge('#5a3a5c',156,46,2,lt*3,28);ridge('#3a2848',176,30,5,lt*6,20);gr=g.createLinearGradient(0,186,0,H);gr.addColorStop(0,'#4a3626');gr.addColorStop(1,'#1c1210');g.fillStyle=gr;g.fillRect(-20,186,W+40,H);
  for(let r=0;r<3;r++)for(let c=0;c<7;c++){const q=ease(clamp((lt-1.6-c*.12-r*.2)/.6,0,1));if(q){g.fillStyle='#4a8a3a';g.fillRect(330+c*16,196+r*8,3,5*q);g.fillStyle='#e8c040';g.fillRect(330+c*16,196+r*8,3,q>.9?2:0)}}
  for(let i=0;i<11;i++){const q=ease(clamp((lt-.2-i*.28)/.7,0,1));if(!q)continue;const x=20+i*27,hh=36*q;g.fillStyle='#8a7a6a';g.fillRect(x,194-hh,27,hh);g.fillStyle='#6a5a4c';g.fillRect(x,194-hh,27,3);if(q>.95){g.fillStyle='#a09080';g.fillRect(x+2,194-hh-4,6,4);g.fillRect(x+15,194-hh-4,6,4)}}
  const tq=ease(clamp((lt-2.4)/1,0,1));if(tq){g.fillStyle='#7a6a5c';g.fillRect(300,194-70*tq,26,70*tq);g.fillStyle='#5a4a3e';g.fillRect(297,194-70*tq,32,5)}
  pole(318,194,96*tq+1,BC1,BC2,lt,.7);
  for(let i=0;i<3;i++)spr(70+i*86+((lt*10)%20),226+(i%2)*10,2.8,VIL[i],lt+i,{f:1,mv:1,ph:lt*8+i*1.9,atk:-1});
  for(let i=0;i<6;i++)spr(310+i*34,236+(i%2)*12,3.1,ARMY[i],lt+i*.2,{f:-1,mv:0,atk:((lt*1.5+i*.31)%1)*.7});
  fog(lt,214,'rgba(90,60,40,.22)',1.4)}
 /* S4: the army marches on the enemy keep */
 function s4(lt){cam(1.02,0,0);sky('#2a1848','#f6b060',H*.7);
  let gr=g.createRadialGradient(280,150,6,280,150,190);gr.addColorStop(0,'rgba(255,224,150,.8)');gr.addColorStop(1,'rgba(255,150,60,0)');g.fillStyle=gr;g.fillRect(-20,-20,W+40,H+40);g.fillStyle='#ffe2a0';g.beginPath();g.arc(280,150,30,0,6.3);g.fill();
  ridge('#6a4268',158,44,2,lt*22,28);ridge('#46304e',180,30,5,lt*44,20);
  const kq=ease(clamp(lt/4.8,0,1));g.save();castle(440,196,.55+.95*kq,'#2a0e16',lt);flame(440-30*kq,170-70*kq,lt,.5+.7*kq);flame(440+34*kq,172-60*kq,lt,.4+.6*kq);g.restore();
  pole(440+10*kq,196-105*kq,36+30*kq,'#8a1018','#1a0a0a',lt,.4+.4*kq);
  gr=g.createLinearGradient(0,196,0,H);gr.addColorStop(0,'#4a3a26');gr.addColorStop(1,'#1c140e');g.fillStyle=gr;g.fillRect(-20,196,W+40,H);
  g.fillStyle='rgba(0,0,0,.18)';for(let i=0;i<9;i++)g.fillRect(((i*90-lt*160)%(W+90)+W+90)%(W+90)-45,206+(i%4)*14,40,2);
  for(let r=0;r<2;r++)for(let c=0;c<5;c++){const i=r*5+c;spr(190-c*40-r*14,232+r*16,3.1,ARMY[i],lt+i*.2,{f:1,mv:1,ph:lt*9+i*1.2+r,atk:-1})}
  pole(150,232,92,BC1,BC2,lt,.8);pole(90,248,92,BC1,BC2,lt+1,.8);
  spr(262,236,4.6,HEROH,lt,{f:1,mv:1,ph:lt*11});
  for(let i=0;i<14;i++){const u=(lt*1.4+i*.07)%1;g.fillStyle='rgba(190,150,110,'+(.5*(1-u))+')';g.beginPath();g.ellipse(230-u*120-(i%3)*6,236-u*16+(i%2)*4,3+u*7,2+u*3,0,0,6.3);g.fill()}
  fog(lt,222,'rgba(70,40,30,.25)',2)}
 /* S5: the rally — victory is yours to take */
 function s5(lt){cam(1+.05*lt/5.2,0,0);sky('#1a0a2a','#f08a50',H*.8);
  g.save();g.translate(280,120);g.rotate(lt*.12);for(let i=0;i<12;i++){g.rotate(Math.PI/6);g.fillStyle='rgba(255,214,120,.08)';g.beginPath();g.moveTo(0,0);g.lineTo(-22,-420);g.lineTo(22,-420);g.fill()}g.restore();
  stars(lt,50,.5);ridge('#4a2a44',172,46,3,lt*2,26);ridge('#241020',192,30,7,lt*3,18);
  g.fillStyle='#1c1218';g.beginPath();g.ellipse(280,246,300,56,0,Math.PI,0);g.fill();g.fillRect(-20,246,W+40,40);
  [70,130,430,490].forEach((x,i)=>pole(x,226,110,BC1,BC2,lt+i,.9));
  for(let i=0;i<10;i++){const left=i<5,k=i%5,x=left?196-k*32:364+k*32,y=240+(k%2)*8;spr(x,y,3.1+(k%2)*.2,ARMY[i],lt+i*.2,{f:left?1:-1,mv:0,atk:((lt*1.6+i*.31)%1)*.7})}
  const rq=ease(clamp(lt/1.6,0,1));spr(280,lerp(280,244,rq),5.2,HEROH,lt,{f:1,mv:rq<1,ph:lt*11,atk:lt>1.4?((lt*1.2)%1)*.6:-1});
  const dt=Math.min(.05,Math.max(0,lt-lastF));lastF=lt;fwAuto(lt,1.2,5.6);drawParts(dt);
  g.setTransform(SC,0,0,SC,0,0);
  txt(pvp?'LAST CROWN STANDING':'CLAIM THE CROWN',280,68,pvp?28:32,'#ffd24a',(lt-.8)/.7);
  txt((nm||'My liege')+(KN?' of '+KN:''),280,92,15,'#fff',(lt-1.5)/.7);
  txt(pvp?'☮ 3 minutes of peace — build fast, arm faster!':'Rise, and let none stand before you!',280,114,12,'#f3e1b0',(lt-2.2)/.7)}
 const T1=pvp?'Rival lords circle a shattered realm.':'The realm lies shattered, its crown lost in fire.',
  T2=pvp?'Each lord begins with a campfire and a sword.':'You have a campfire, a sword, and the will to rise.',
  T3=pvp?'Build faster. Train harder. Then strike.':'Gather your people. Raise your walls. Forge an army.',
  T4=pvp?'Break their gates. Burn their banners.':'Break the gates of Malric’s keep, and claim the Crown!',
  T5=pvp?'Only one crown remains. Make it yours!':'This is your moment. Rise, and win!';
 const SCN=[
 {d:4.4,fi:.9,fo:.5,dr:lt=>{s1(lt);sub2(T1,lt,4.2)},ev:[[0,()=>{narr(T1);pad();horn(73,2.6)}],[2.6,()=>drum(.6,90)]]},
 {d:4.4,fi:.5,fo:.5,dr:lt=>{s2(lt);sub2(T2,lt,4.2)},ev:[[0,()=>{narr(T2);nz(1.2,1800,.8,.05,'highpass',.1)}],[2.6,()=>{chime();drum(.5,100)}]]},
 {d:4.4,fi:.5,fo:.5,dr:lt=>{s3(lt);sub2(T3,lt,4.2)},ev:[[0,()=>narr(T3)],[.4,()=>clash(.07)],[1.2,()=>clash(.07)],[2,()=>{drum(.5,110);clash(.08)}],[3,()=>{drum(.6,100);clash(.08)}]]},
 {d:4.8,fi:.4,fo:.5,dr:lt=>{s4(lt);sub2(T4,lt,4.6)},ev:[[0,()=>{narr(T4);horn(98,3)}],[.2,()=>drum(.8,100)],[1,()=>drum(.7,95)],[1.8,()=>drum(.8,100)],[2.6,()=>drum(.7,95)],[3.4,()=>drum(.9,105)],[4.2,()=>drum(.9,110)]]},
 {d:5.6,fi:.3,fo:.9,dr:s5,ev:[[0,()=>{pad();horn(82,3)}],[.3,()=>narr(T5)],[1.2,()=>{flashA=.8;chime();horn(110,2.6);drum(1,140)}],[3.8,()=>{[110,165,220].forEach(f=>tone(f,3,.05,'triangle',1,3))}]]}];
 const TOTAL=SCN.reduce((a,s)=>a+s.d,0);
 function finish(always){if(fin)return;fin=1;cancelAnimationFrame(raf);try{window.speechSynthesis&&speechSynthesis.cancel()}catch(e){}try{mg&&mg.gain.setTargetAtTime(0,ia.currentTime,.12)}catch(e){}wrap.style.opacity=0;setTimeout(()=>{wrap.remove();try{ia&&ia.close()}catch(e){}busy=0;done()},700)}
 function frame(){if(fin)return;raf=requestAnimationFrame(frame);try{
  gov();const t=(performance.now()-T0)/1000;if(t>=TOTAL){finish();return}
  let i=0,ac=0;while(i<SCN.length-1&&t>=ac+SCN[i].d){ac+=SCN[i].d;i++}const S=SCN[i],lt=t-ac;
  if(i!==cur){cur=i;lastF=0;fwT=0;parts=[]}
  S.ev.forEach((e,j)=>{const key=i+':'+j;if(!fired[key]&&lt>=e[0]){fired[key]=1;try{e[1]()}catch(x){}}});
  g.setTransform(SC,0,0,SC,0,0);g.fillStyle='#000';g.fillRect(0,0,W,H);g.save();S.dr(lt);g.restore();g.setTransform(SC,0,0,SC,0,0);
  g.fillStyle='#000';g.fillRect(0,0,W,H*.07);g.fillRect(0,H*.93,W,H*.07);
  let a=0;if(lt<S.fi)a=1-lt/S.fi;if(lt>S.d-S.fo)a=Math.max(a,(lt-(S.d-S.fo))/S.fo);if(a>0){g.fillStyle='rgba(0,0,0,'+clamp(a,0,1)+')';g.fillRect(0,0,W,H)}
  if(flashA>0){g.fillStyle='rgba(255,246,220,'+flashA+')';g.fillRect(0,0,W,H);flashA=Math.max(0,flashA-.035)}
  g.setTransform(1,0,0,1,0,0);g.drawImage(vg,0,0)}catch(e){finish();setTimeout(()=>{throw e})}}
 let vg=null;function mkvg(){vg=document.createElement('canvas');vg.width=W*SC;vg.height=H*SC;const v=vg.getContext('2d'),gr=v.createRadialGradient(W*SC/2,H*SC/2,H*SC*.3,W*SC/2,H*SC/2,W*SC*.62);gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(1,'rgba(0,0,0,.6)');v.fillStyle=gr;v.fillRect(0,0,W*SC,H*SC)}
 let gF=0,gT=performance.now(),gS=0;function gov(){gF++;const n=performance.now();if(n-gT>=1000){const fps=gF*1000/(n-gT);gF=0;gT=n;if(fps<40&&SC>.7&&gS<3){gS++;SC=SC>1?1:SC*.75;cv.width=Math.round(W*SC);cv.height=Math.round(H*SC);mkvg()}}}
 mkvg();sk.onclick=()=>finish();sa.onclick=()=>{try{localStorage.setItem('cor_precut','0')}catch(e){}finish()};
 try{ainit();ia&&ia.state=='suspended'&&ia.resume()}catch(e){}raf=requestAnimationFrame(()=>{T0=performance.now();frame()})}
function play(mode,done){if(busy){done();return}busy=1;try{cut(mode,done)}catch(e){busy=0;console.error(e);done()}}
/* solo: the old text story screen is replaced by the cutscene */
G(()=>{story=function(i,k){if(k!=sq)return;const sp=$('sp');if(sp)sp.style.display='none';
 if(off()){begin();return}
 const kn=$('kn');if(kn&&!String(kn.value||'').trim())kn.value=DN[Math.floor(Math.random()*DN.length)];
 try{setName()}catch(e){}
 play('solo',()=>{if(k==sq)begin()})}});
/* PvP: plays over the first seconds of the match (the 3 minutes of peace give you time) */
G(()=>{const _pv=pvStart;pvStart=function(l){const was=PV.live;_pv(l);try{if(!was&&PV.live&&!off())play('pvp',()=>{})}catch(e){}}});
/* pause-menu switch to bring the intro back (or turn it off) */
G(()=>{const _pz=pzMenu;pzMenu=function(){_pz();const p=document.querySelector('#pz .pn');if(!p)return;const q=[...p.querySelectorAll('button')].pop(),b=document.createElement('button'),l=()=>{b.textContent=off()?'🎬 Match intro: Off':'🎬 Match intro: On'};l();
 b.onclick=function(){try{localStorage.setItem('cor_precut',off()?'1':'0')}catch(e){}l()};p.insertBefore(b,q)}});
})();
