/* ===== v12: opening cinematic: the empty throne, four lords, one great battle ===== */
(function(){
const $=id=>document.getElementById(id),I=$('intro'),cv=$('ic'),menu=$('menu');
function fin0(){if(menu)menu.classList.remove('pre');if(I)I.remove()}
if(!I||!cv||!menu||menu.style.display=='none'){fin0();return}
try{
const W=560,H=266,SC=((window.devicePixelRatio||1)>1.5&&Math.min(innerWidth,innerHeight)>600)?2:1.5;cv.width=W*SC;cv.height=H*SC;const g=cv.getContext('2d');
let done=0,go=0,T0=0,cur=-1,flashA=0,lastF=0;const fired={};
const sp=document.createElement('canvas');sp.width=sp.height=64;const sg=sp.getContext('2d');
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),ease=q=>q*q*(3-2*q),lerp=(a,b,q)=>a+(b-a)*q;
/* ---------- sound ---------- */
let ia=null,mg=null,nb=null;
const mut=()=>{try{return !!muted}catch(e){return false}};
function ainit(){if(ia)return;try{ia=new(window.AudioContext||window.webkitAudioContext)();mg=ia.createGain();mg.gain.value=.55;mg.connect(ia.destination);const L=ia.sampleRate*2;nb=ia.createBuffer(1,L,ia.sampleRate);const d=nb.getChannelData(0);for(let i=0;i<L;i++)d[i]=Math.random()*2-1}catch(e){ia=null}}
const ok=()=>ia&&mg&&!mut();
function drum(v,f0){if(!ok())return;const n=ia.currentTime,o=ia.createOscillator(),q=ia.createGain();o.type='sine';o.frequency.setValueAtTime(f0||120,n);o.frequency.exponentialRampToValueAtTime(40,n+.3);q.gain.setValueAtTime(v||.6,n);q.gain.exponentialRampToValueAtTime(.001,n+.5);o.connect(q);q.connect(mg);o.start(n);o.stop(n+.55)}
function nz(dur,fq,Q,v,type,at){if(!ok())return;const n=ia.currentTime,s=ia.createBufferSource();s.buffer=nb;s.loop=true;const f=ia.createBiquadFilter();f.type=type||'bandpass';f.frequency.value=fq;f.Q.value=Q||1;const q=ia.createGain();q.gain.setValueAtTime(.0001,n);q.gain.linearRampToValueAtTime(v,n+(at||.005));q.gain.exponentialRampToValueAtTime(.0001,n+dur);s.connect(f);f.connect(q);q.connect(mg);s.start(n);s.stop(n+dur+.05)}
function tone(fq,dur,v,type,at,det){if(!ok())return;const n=ia.currentTime;[0,det||4].forEach(dt=>{const o=ia.createOscillator(),f=ia.createBiquadFilter(),q=ia.createGain();o.type=type||'sawtooth';o.frequency.value=fq;o.detune.value=dt;f.type='lowpass';f.frequency.value=fq*5;q.gain.setValueAtTime(.0001,n);q.gain.linearRampToValueAtTime(v,n+(at||.5));q.gain.setValueAtTime(v,n+dur*.6);q.gain.exponentialRampToValueAtTime(.0001,n+dur);o.connect(f);f.connect(q);q.connect(mg);o.start(n);o.stop(n+dur+.05)})}
const horn=(fq,dur)=>tone(fq,dur||2.2,.07,'sawtooth',.5,6);
const clash=v=>{nz(.12,2600+Math.random()*1800,1.4,v||.1);tone(900+Math.random()*700,.1,.02,'square',.004,0)};
const pad=()=>[55,82.4,110].forEach(f=>tone(f,6.5,.05,'triangle',2.4,3));
const chime=()=>[880,1318.5,1760].forEach((f,i)=>setTimeout(()=>tone(f,1.8,.05,'sine',.02,2),i*120));
function narr(t){try{if(window.speechSynthesis&&typeof say==='function')say(t,1)}catch(e){}}
function sub(txt,d){const e=$('isub');e.classList.remove('on');void e.offsetWidth;e.textContent=txt;e.style.setProperty('--d',d+'s');e.classList.add('on')}
function flash(a){flashA=a}
/* ---------- drawing helpers ---------- */
function cam(z,px,py){g.translate(W/2+px,H/2+py);g.scale(z,z);g.translate(-W/2,-H/2)}
function sky(a,b,h){const gr=g.createLinearGradient(0,0,0,h||H*.75);gr.addColorStop(0,a);gr.addColorStop(1,b);g.fillStyle=gr;g.fillRect(-20,-20,W+40,H+40)}
function stars(t,n,al){for(let i=0;i<n;i++){g.fillStyle='rgba(255,255,230,'+(al*(.35+.65*Math.abs(Math.sin(t*1.5+i))))+')';g.fillRect(Math.floor(hs(i,1)*W),Math.floor(hs(i,2)*H*.55),hs(i,3)>.9?2:1,1)}}
function ridge(col,base,amp,seed,off,step){g.fillStyle=col;g.beginPath();g.moveTo(-20,H+20);const o=((off%step)+step)%step,k0=Math.floor(off/step);for(let i=-1;i*step-o<=W+step;i++){g.lineTo(i*step-o,base-amp*(.3+.7*hs(k0+i,seed)))}g.lineTo(W+step+20,H+20);g.closePath();g.fill()}
function fog(t,y,col,sp){for(let i=0;i<3;i++){const gx=((t*sp*(8+i*5)+i*190)%(W+240))-120,gr=g.createRadialGradient(gx,y+i*7,2,gx,y+i*7,95);gr.addColorStop(0,col);gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(gx-100,y-45,200,110)}}
function flame(x,y,t,k){k=k||1;const f=Math.sin(t*17+x)*1.2,gr=g.createRadialGradient(x,y,1,x,y,46*k+f*3);gr.addColorStop(0,'rgba(255,176,74,.8)');gr.addColorStop(1,'rgba(255,106,26,0)');g.fillStyle=gr;g.fillRect(x-50*k,y-50*k,100*k,100*k);g.fillStyle='#e8501a';g.beginPath();g.moveTo(x-4,y);g.quadraticCurveTo(x-5,y-8,x+f,y-15-f);g.quadraticCurveTo(x+5,y-8,x+4,y);g.fill();g.fillStyle='#ffd070';g.beginPath();g.moveTo(x-2,y);g.quadraticCurveTo(x-2,y-5,x+f*.5,y-9);g.quadraticCurveTo(x+2,y-5,x+2,y);g.fill();g.fillStyle='#3a2410';g.fillRect(x-1,y,2,12)}
function banner(x,y,c1,c2,t,s){s=s||1;g.fillStyle='#d8b060';g.fillRect(x-2*s,y-4*s,30*s,3*s);for(let i=0;i<26;i++){const wy=Math.sin(t*3+i*.45)*1.6*(i/26),bl=(50-(13-Math.abs(i-13))*.9)*s;g.fillStyle=c1;g.fillRect(x+i*s,y+wy,Math.ceil(s),bl);g.fillStyle=c2;g.fillRect(x+i*s,y+wy+bl*.35,Math.ceil(s),5*s)}}
function castle(x,y,s,col,t){const R=(a,b,w,h)=>g.fillRect(Math.round(x+a*s),Math.round(y+b*s),Math.ceil(w*s),Math.ceil(h*s));g.fillStyle=col;R(-40,-30,80,30);R(-50,-54,18,54);R(32,-54,18,54);R(-9,-74,18,74);
 for(let i=-40;i<40;i+=8)R(i,-34,4,4);[[-50,-54,18],[32,-54,18],[-9,-74,18]].forEach(a=>{for(let i=0;i<a[2];i+=6)R(a[0]+i,a[1]-4,3,4)});
 g.beginPath();g.moveTo(x-12*s,y-78*s);g.lineTo(x,y-100*s);g.lineTo(x+12*s,y-78*s);g.fill();
 const fl=.6+.4*Math.sin(t*9+1);g.fillStyle='rgba(255,196,96,'+fl+')';R(-3,-62,6,9);R(-44,-42,5,8);R(38,-42,5,8);R(-24,-20,5,7);R(18,-20,5,7)}
function throne(x,y,s,glow,t){if(glow){const gr=g.createRadialGradient(x,y-26*s,2,x,y-26*s,75*s);gr.addColorStop(0,'rgba(255,214,110,'+glow+')');gr.addColorStop(1,'rgba(255,170,60,0)');g.fillStyle=gr;g.fillRect(x-80*s,y-105*s,160*s,135*s)}
 const R=(c,a,b,w,h)=>{g.fillStyle=c;g.fillRect(Math.round(x+a*s),Math.round(y+b*s),Math.ceil(w*s),Math.ceil(h*s))};
 R('#2a1a0e',-26,-3,52,4);R('#3a2410',-22,-7,44,4);R('#5a3a1a',-18,-11,36,4);
 R('#2a1408',-11,-48,22,38);R('#7a1a1a',-8,-45,16,32);R('#d4af37',-12,-52,24,4);R('#d4af37',-12,-52,3,42);R('#d4af37',9,-52,3,42);
 R('#f0d070',-13,-57,5,5);R('#f0d070',8,-57,5,5);R('#f0d070',-2,-60,4,8);
 R('#4a2a10',-15,-26,30,5);R('#8a1c1c',-10,-30,20,5);R('#d4af37',-15,-26,4,16);R('#d4af37',11,-26,4,16)}
function crown(x,y,s,t){const gr=g.createRadialGradient(x,y,2,x,y,34*s);gr.addColorStop(0,'rgba(255,230,140,.75)');gr.addColorStop(1,'rgba(255,190,60,0)');g.fillStyle=gr;g.fillRect(x-36*s,y-36*s,72*s,72*s);
 const R=(c,a,b,w,h)=>{g.fillStyle=c;g.fillRect(Math.round(x+a*s),Math.round(y+b*s),Math.ceil(w*s),Math.ceil(h*s))};
 R('#b8901c',-8,0,16,5);R('#e8c040',-8,0,16,3);[-8,-4,0,4,7].forEach((a,i)=>{R('#f0d070',a,-(i==2?7:4),i==4?1:3,i==2?7:4)});R('#d01830',-1,1,2,2);R('#3a7ad0',-6,1,1.5,1.5);R('#30b060',4.5,1,1.5,1.5)}
/* ---------- soldier sprites (the game's own engine) ---------- */
function man(x,y,bs,u,t,o){const mv=o.mv?1:0,ph=o.ph||0,f=o.f;sg.clearRect(0,0,64,64);const prev=Z;Z=sg;
 try{if(u.horse)Zhorse(32,54,f,ph,0,mv,u.coat||'#6a4326',u.col);
  Zman({x:32-(u.horse?f:0),y:54,f:f,sc:u.sc||1,t:t,sd:u.sd|0,mv:mv,ph:ph,fl:o.fl||0,col:u.col,acc:u.acc,st:u.st,up:0,atk:o.atk===undefined?-1:o.atk,wep:u.wep,wv:u.wv,jp:!!u.jp,ride:u.horse?12:0,hb:u.horse&&mv?-Math.round(Math.abs(Math.sin(ph))*1.4):0,cape:u.acc,wp:-1,hs:u.hs||1})}finally{Z=prev}
 if(o.tint){sg.globalCompositeOperation='source-atop';sg.fillStyle=o.tint;sg.fillRect(0,0,64,64);sg.globalCompositeOperation='source-over'}
 if(o.sh!==0){g.fillStyle='rgba(0,0,0,.4)';g.beginPath();g.ellipse(x,y,(u.horse?15:7)*bs,2.2*bs,0,0,6.3);g.fill()}
 g.imageSmoothingEnabled=false;g.drawImage(sp,0,0,64,64,Math.round(x-32*bs),Math.round(y-54*bs),64*bs,64*bs)}
function heroU(L){return{st:ZHERO[L.hi]||ZHERO[0],wep:'sword',wv:ZHW[L.hi],jp:L.hi==1,horse:!!L.horse,coat:L.hi==0?'#e2e2e8':'#8a5a2a',col:L.c1,acc:L.c2,sd:L.hi*5+2,sc:1.12,hs:1.05}}
function unitU(L,k){const f=L.fol[k],ty=f[0];return{st:ZMS[ty]||ZMS.sword,wep:f[1],wv:f[2]||null,jp:f[2]=='katana',horse:!!f[3],coat:ty=='hcav'?'#8e8e98':ty=='tarc'?'#8a5a2a':'#6a4326',col:L.c1,acc:L.c2,sd:k*3+L.hi}}
const LORDS=[
{n:'RACHIT',t:'THE CRUSADER',k:'LORD OF THE IRON HOST',u:'Knights & Heavy Cavalry',c1:'#e8e8ee',c2:'#b01c1c',hi:0,horse:1,fol:[['crus','sword',0,0],['hcav','spear',0,1],['crus','sword',0,0]],say:'Rachit, the Crusader. His knights ride beneath the iron cross.',bg:0,hn:98},
{n:'SAJAN',t:'THE SHOGUN',k:'WARLORD OF THE RISING SUN',u:'Samurai & Crossbowmen',c1:'#a82a2a',c2:'#1a1a22',hi:1,fol:[['saru','sword','katana'],['xbow','bow'],['saru','sword','katana']],say:'Sajan, the Shogun. His samurai strike like a falling blade.',bg:1,hn:130},
{n:'NIGAM',t:'THE ROMAN',k:'LEGATE OF THE EAGLE',u:'Legionaries & Javelineers',c1:'#a02020',c2:'#d8b040',hi:2,fol:[['legi','sword','gladius'],['jave','spear'],['legi','sword','gladius']],say:'Nigam, the Roman. Where his legions march, the earth obeys.',bg:2,hn:110},
{n:'ELEANOR',t:'THE HIGHLANDER',k:'QUEEN OF THE HIGH PASSES',u:'Horse Archers & Lancers',c1:'#7a2a6a',c2:'#e8b94a',hi:3,horse:1,fol:[['tarc','bow',0,1],['tlan','spear'],['tarc','bow',0,1]],say:'Eleanor of the high passes. Her riders fly like the mountain wind.',bg:3,hn:82}];
/* ---------- scenes ---------- */
function sNight(lt){cam(1+.1*lt/4.8,-lt*2,0);sky('#04050e','#241438',H*.8);stars(lt,90,.9);
 let gr=g.createRadialGradient(120,50,4,120,50,70);gr.addColorStop(0,'rgba(240,236,208,.35)');gr.addColorStop(1,'rgba(240,236,208,0)');g.fillStyle=gr;g.fillRect(40,-20,170,140);
 g.fillStyle='#f0ecd0';g.beginPath();g.arc(120,50,16,0,6.3);g.fill();g.fillStyle='rgba(140,140,110,.3)';g.beginPath();g.arc(114,46,4,0,6.3);g.arc(125,55,3,0,6.3);g.fill();
 ridge('#10112a',172,76,3,lt*3,24);ridge('#0b0a1c',192,52,5,lt*6,18);
 g.fillStyle='#07060f';g.beginPath();g.ellipse(400,214,120,50,0,Math.PI,0);g.fill();castle(400,170,2.2,'#05040b',lt);
 fog(lt,170,'rgba(110,120,170,.2)',1);ridge('#05040c',226,30,9,lt*14,14);g.fillStyle='#05040c';g.fillRect(-20,226,W+40,60);fog(lt,236,'rgba(90,100,150,.16)',1.6)}
function sHall(lt){cam(1.02+.1*lt/4.4,0,-lt*2);g.fillStyle='#120c07';g.fillRect(-20,-20,W+40,H+40);
 for(let r=0;r<14;r++)for(let c=0;c<25;c++){const bx=c*24+(r&1?12:0)-12,by=r*20;g.strokeStyle='rgba(0,0,0,.45)';g.strokeRect(bx,by,24,20);if(hs(r,c)>.75){g.fillStyle='rgba(255,255,255,.04)';g.fillRect(bx+1,by+1,22,18)}}
 for(const px of[60,474]){const pg=g.createLinearGradient(px,0,px+26,0);pg.addColorStop(0,'#3a2a18');pg.addColorStop(.5,'#9a7a48');pg.addColorStop(1,'#3a2a18');g.fillStyle=pg;g.fillRect(px,0,26,H);g.fillStyle='#b8985c';g.fillRect(px-4,34,34,8);g.fillRect(px-4,200,34,8)}
 g.fillStyle='#1c1612';g.fillRect(-20,208,W+40,80);g.fillStyle='#8a1c1c';g.beginPath();g.moveTo(262,208);g.lineTo(298,208);g.lineTo(430,H+20);g.lineTo(130,H+20);g.fill();g.strokeStyle='#d9a84a';g.lineWidth=2;g.beginPath();g.moveTo(262,208);g.lineTo(130,H+20);g.moveTo(298,208);g.lineTo(430,H+20);g.stroke();g.lineWidth=1;
 LORDS.forEach((L,i)=>banner([130,184,346,400][i],22,L.c1,L.c2,lt+i,1.1));
 const gl=.55+.12*Math.sin(lt*3);throne(280,208,2.5,gl,lt);crown(280,48+Math.sin(lt*2)*3,2.2,lt);
 flame(96,110,lt);flame(504,110,lt);flame(224,150,lt,.7);flame(336,150,lt,.7);
 for(let i=0;i<30;i++){const px=(hs(i,5)*W+lt*(4+hs(i,6)*6))%W,py=(hs(i,8)*H-lt*(3+hs(i,9)*4)+H*4)%H;g.fillStyle='rgba(255,220,150,'+(.15+.15*Math.sin(lt*2+i))+')';g.fillRect(px,py,1.4,1.4)}}
function bgLord(b,sc,lt){
 if(b==0){sky('#6aa0d8','#e6f0e0',H*.7);let gr=g.createRadialGradient(440,60,4,440,60,90);gr.addColorStop(0,'rgba(255,250,210,.9)');gr.addColorStop(1,'rgba(255,250,210,0)');g.fillStyle=gr;g.fillRect(340,-20,200,160);
  ridge('#8aa6c4',150,56,2,sc*.08,28);ridge('#5f8c5a',172,40,4,sc*.2,22);
  for(let i=-1;i<9;i++){const tx=((i*88-sc*.5)%(W+90)+W+90)%(W+90)-40,ty=190;g.fillStyle='#2a4a2a';for(let k=0;k<3;k++){g.beginPath();g.moveTo(tx,ty-60+k*12);g.lineTo(tx-14+k*-2,ty-30+k*12);g.lineTo(tx+14+k*2,ty-30+k*12);g.fill()}g.fillStyle='#3a2410';g.fillRect(tx-2,ty-12,4,12)}
  g.fillStyle='#4a7a34';g.fillRect(-20,190,W+40,90);g.fillStyle='#5a8a40';for(let i=0;i<50;i++){const x=((hs(i,1)*W*2-sc)%W+W)%W;g.fillRect(x,192+hs(i,2)*70,3,2)}}
 else if(b==1){sky('#b8485a','#f8d8a0',H*.7);g.fillStyle='#e84a3a';g.beginPath();g.arc(400,128,46,0,6.3);g.fill();
  g.fillStyle='#5a4a6a';g.beginPath();g.moveTo(150,190);g.lineTo(285,52);g.lineTo(420,190);g.fill();g.fillStyle='#f0e8f0';g.beginPath();g.moveTo(262,78);g.lineTo(285,52);g.lineTo(308,78);g.lineTo(296,72);g.lineTo(285,82);g.lineTo(274,72);g.fill();
  ridge('#4a3a52',176,34,3,sc*.12,24);
  const tx=((560-sc*.5)%900+900)%900-100;g.fillStyle='#b82a1a';g.fillRect(tx,120,6,70);g.fillRect(tx+46,120,6,70);g.fillRect(tx-8,112,66,8);g.fillRect(tx-2,126,54,5);
  g.fillStyle='#5a4030';g.fillRect(-20,190,W+40,90);g.fillStyle='#7a6048';for(let i=0;i<30;i++){const x=((hs(i,1)*W*2-sc)%W+W)%W;g.fillRect(x,196+hs(i,2)*60,8,3)}
  g.fillStyle='#f8b8c8';for(let i=0;i<36;i++){const x=((hs(i,4)*W-lt*(30+hs(i,5)*30)-sc*.3)%W+W)%W,y=(hs(i,6)*H+lt*(20+hs(i,7)*20))%H;g.fillRect(x,y,2,2)}}
 else if(b==2){sky('#58a8e0','#f4e8c0',H*.7);let gr=g.createRadialGradient(130,62,4,130,62,90);gr.addColorStop(0,'rgba(255,248,208,.95)');gr.addColorStop(1,'rgba(255,248,208,0)');g.fillStyle=gr;g.fillRect(30,-20,200,170);
  ridge('#d4b684',172,36,5,sc*.1,30);
  const o=((sc*.3)%56+56)%56;g.fillStyle='#dcc590';g.fillRect(-20,126,W+40,62);g.fillStyle='#8a6a40';for(let i=-1;i<12;i++){const ax=i*56-o+28;g.beginPath();g.arc(ax,176,17,Math.PI,0);g.lineTo(ax+17,190);g.lineTo(ax-17,190);g.fill()}g.fillStyle='#c4a874';g.fillRect(-20,120,W+40,8);
  g.fillStyle='#c8a468';g.fillRect(-20,190,W+40,90);g.fillStyle='#a8844a';for(let i=0;i<40;i++){const x=((hs(i,1)*W*2-sc)%W+W)%W;g.fillRect(x,194+hs(i,2)*64,6,2)}
  for(let i=-1;i<6;i++){const cx=((i*140-sc*.6)%(W+140)+W+140)%(W+140)-60;g.fillStyle='#ece0c4';g.fillRect(cx,90,14,106);g.fillStyle='#c8b894';g.fillRect(cx+10,90,4,106);g.fillStyle='#f4ead0';g.fillRect(cx-4,84,22,8);g.fillRect(cx-3,194,20,6)}}
 else{sky('#7a98d0','#e8f0fa',H*.7);ridge('#e2eaf6',128,110,3,sc*.06,40);ridge('#a6bcdc',152,70,7,sc*.12,30);ridge('#d8e4f2',176,40,5,sc*.22,24);
  for(let i=0;i<26;i++){const x=i*22.4,sag=Math.sin(i/25*Math.PI)*14,y=44+sag,wv=Math.sin(lt*5+i*.8)*1.5;g.fillStyle=['#2a6ad0','#f4f4f4','#d83a2a','#30a050','#f0c030'][i%5];g.fillRect(x,y+wv,10,8)}g.fillStyle='#3a2a20';g.fillRect(-20,44,W+40,1);
  g.fillStyle='#e6edf4';g.fillRect(-20,190,W+40,90);g.fillStyle='#c4d2e4';for(let i=0;i<40;i++){const x=((hs(i,1)*W*2-sc)%W+W)%W;g.fillRect(x,194+hs(i,2)*64,7,2)}
  g.fillStyle='#fff';for(let i=0;i<60;i++){const x=((hs(i,4)*W-lt*(10+hs(i,5)*14)-sc*.3)%W+W)%W,y=(hs(i,6)*H+lt*(26+hs(i,7)*26))%H;g.fillRect(x,y,2,2)}}}
function sLord(i){return function(lt){const L=LORDS[i],sc=lt*46;cam(1.01+.04*lt/4.2,0,0);bgLord(L.bg,sc,lt);
 banner(500,26,L.c1,L.c2,lt,1.5);
 const ps=[[255,206,3.0],[186,212,3.0],[122,216,3.0]];
 L.fol.forEach((f,k)=>{man(ps[k][0],ps[k][1],ps[k][2]*(f[3]?.9:1),unitU(L,k),lt,{f:1,mv:1,ph:lt*(f[3]?9:7.5)+k*1.9,atk:-1})});
 man(375,238,L.horse?4.3:5.0,heroU(L),lt,{f:1,mv:1,ph:lt*(L.horse?9:7)});
 if(lt<.6){const q=ease(lt/.6);g.fillStyle=L.c1;g.fillRect(W*q,-20,W*(1-q)+20,H+40);g.fillStyle='#d4af37';g.fillRect(W*q-2,-20,3,H+40)}}}
/* the great battle */
const DU=[[150,240,3.9,heroU(LORDS[0]),heroU(LORDS[1]),0,36,0],[410,240,3.9,heroU(LORDS[2]),heroU(LORDS[3]),.7,36,.3],
[238,218,2.9,unitU(LORDS[0],0),unitU(LORDS[1],0),.3,19,.2],[292,220,2.9,unitU(LORDS[2],0),unitU(LORDS[3],1),1.1,19,.5],[345,216,2.9,unitU(LORDS[0],2),unitU(LORDS[1],2),.6,19,.4],
[215,196,2.1,unitU(LORDS[2],2),unitU(LORDS[1],0),1.3,19,.7],[268,194,2.1,unitU(LORDS[0],2),unitU(LORDS[3],1),.2,19,.9],[322,196,2.1,unitU(LORDS[2],0),unitU(LORDS[3],1),.9,19,.6],[372,194,2.1,unitU(LORDS[0],0),unitU(LORDS[1],2),1.5,19,1.0]].sort((a,b)=>a[1]-b[1]);
const AT=3.2,PER=1.7;let parts=[];const DS=DU.map(()=>({sp:-1}));
function spark(x,y,n){for(let i=0;i<n;i++){const a=Math.random()*6.28,v=20+Math.random()*50;parts.push({x:x,y:y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-25,l:.35+Math.random()*.3,c:Math.random()<.5?'#fff2b0':'#ffb040'})}}
function sil(x,y,s,col,t,i){g.fillStyle=col;g.fillRect(x-1.5*s,y-8*s,3*s,6*s);g.fillRect(x-s,y-10.5*s,2*s,2.5*s);g.fillRect(x+2*s,y-12*s+Math.sin(t*5+i)*3,.8*s,10*s)}
function sBattle(lt){const fight=lt>=AT,ft=lt-AT,dt=Math.min(.05,Math.max(0,lt-lastF));lastF=lt;
 const sh=fight?Math.max(0,1-ft/5)*1.8:0;cam(fight?1.02+.05*ft/6:1+.02*lt/AT,(Math.random()-.5)*sh,(Math.random()-.5)*sh);
 sky('#26091a','#d2602a',H*.72);let gr=g.createRadialGradient(280,150,4,280,150,150);gr.addColorStop(0,'rgba(255,190,90,.55)');gr.addColorStop(1,'rgba(255,120,40,0)');g.fillStyle=gr;g.fillRect(100,0,360,200);
 for(let k=0;k<3;k++){const sx=[90,470,330][k],gg=g.createLinearGradient(0,60,0,176);gg.addColorStop(0,'rgba(30,18,22,0)');gg.addColorStop(1,'rgba(30,18,22,.7)');g.fillStyle=gg;g.fillRect(sx-12+Math.sin(lt*.8+k)*5,60,26,116)}
 ridge('#3a1424',166,50,3,lt*2,26);ridge('#241018',178,30,6,lt*3,18);
 g.fillStyle='#2a1a16';g.beginPath();g.ellipse(280,184,130,40,0,Math.PI,0);g.fill();
 const bm=g.createLinearGradient(0,0,0,150);bm.addColorStop(0,'rgba(255,230,150,0)');bm.addColorStop(1,'rgba(255,230,150,.35)');g.fillStyle=bm;g.fillRect(268,0,24,150);
 throne(280,152,1.35,.7+.15*Math.sin(lt*4),lt);
 g.fillStyle='#4a3220';g.fillRect(-20,178,W+40,H);const gg2=g.createLinearGradient(0,178,0,H);gg2.addColorStop(0,'#5a3a24');gg2.addColorStop(1,'#1c1210');g.fillStyle=gg2;g.fillRect(-20,178,W+40,H);
 for(let i=0;i<16;i++){sil(20+i*8+hs(i,1)*4,178,1.1,'#1a0c10',lt,i);sil(540-i*8-hs(i,2)*4,178,1.1,'#1a0c10',lt,i+9)}
 [[34,0],[86,2],[474,1],[526,3]].forEach((p,i)=>{g.fillStyle='#3a2410';g.fillRect(p[0],110,2,70);banner(p[0]-12,114,LORDS[p[1]].c1,LORDS[p[1]].c2,lt+i,.7)});
 DU.forEach((d,i)=>{const s=d[2],st=DS[i],a=d[3],b=d[4],off=d[5],sep=d[6],dl=d[7],cx=d[0],cy=d[1],t=lt+i*.37;
  const q=clamp((lt-dl)/(AT-dl-.2),0,1),e=ease(q);
  const half=sep*s/2,xa=lerp(-70-i*26,cx-half,e),xb=lerp(W+70+i*26,cx+half,e),walk=q<1;
  let atkA=-1,atkB=-1,flA=0,flB=0;
  if(!walk&&fight){const u=ft+off,k=Math.floor(u/PER),p=(u%PER)/PER,side=k&1,at=p<.6?p/.6:-1;if(side)atkB=at;else atkA=at;
   if(p>.42&&p<.52){if(side)flA=1;else flB=1}
   if(p>=.45&&st.sp!==k){st.sp=k;spark(cx,cy-s*9,9);clash(.05+.01*s)}}
  man(xa,cy,s,a,t,{f:1,mv:walk,ph:lt*(a.horse?11:8)+i,atk:atkA,fl:flA});man(xb,cy,s,b,t,{f:-1,mv:walk,ph:lt*(b.horse?11:8)+i+2,atk:atkB,fl:flB})});
 if(lt>1.4)for(let k=0;k<8;k++){const u=(lt*.5+k*.125)%1,L=k&1,x0=L?30:530,x1=L?250:310,x=lerp(x0,x1,u),y=176-Math.sin(u*Math.PI)*78,u2=Math.max(0,u-.03),xx=lerp(x0,x1,u2),yy=176-Math.sin(u2*Math.PI)*78;g.strokeStyle='#e8d8a8';g.lineWidth=1;g.beginPath();g.moveTo(xx,yy);g.lineTo(x,y);g.stroke()}
 for(let i=0;i<40;i++){const x=hs(i,1)*W+Math.sin(lt+i)*6,y=H-((lt*(14+hs(i,2)*22)+hs(i,3)*H)%H);g.fillStyle='rgba(255,'+(120+hs(i,4)*90|0)+',50,'+(.3+.4*hs(i,5))+')';g.fillRect(x,y,1.6,1.6)}
 parts=parts.filter(p=>(p.l-=dt)>0);parts.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=90*dt;g.fillStyle=p.c;g.fillRect(p.x,p.y,2,2)});
 const bt=Math.floor(lt*2.2);if(fired.bt!==bt){fired.bt=bt;drum(bt&1?.4:.8,bt&1?90:120)}
 fog(lt,214,'rgba(70,40,30,.28)',2)}
function sFinal(lt){cam(1+.04*lt/5.2,0,0);sky('#0e0618','#4a1a24',H*.85);stars(lt,60,.8);
 g.save();g.translate(280,130);g.rotate(lt*.15);for(let i=0;i<12;i++){g.rotate(Math.PI/6);g.fillStyle='rgba(255,214,120,.07)';g.beginPath();g.moveTo(0,0);g.lineTo(-20,-420);g.lineTo(20,-420);g.fill()}g.restore();
 ridge('#2a0e1a',196,46,4,lt*2,26);ridge('#160812',214,28,8,lt*3,18);g.fillStyle='#160812';g.fillRect(-20,214,W+40,60);
 LORDS.forEach((L,i)=>banner([86,140,394,448][i],64,L.c1,L.c2,lt+i,1.1));
 throne(280,214,2.5,.9+.1*Math.sin(lt*4),lt);flame(214,150,lt,.8);flame(346,150,lt,.8);npPole(36,214,lt);npPole(490,214,lt);
 const q=clamp(lt/2.3,0,1);crown(280,lerp(-30,50,ease(q)),3.0,lt);
 for(let i=0;i<30;i++){const px=(hs(i,5)*W+lt*8)%W,py=(hs(i,8)*H-lt*(8+hs(i,9)*8)+H*4)%H;g.fillStyle='rgba(255,220,150,'+(.2+.2*Math.sin(lt*3+i))+')';g.fillRect(px,py,1.5,1.5)}}
function sNepal(lt){g.fillStyle='#06050c';g.fillRect(-20,-20,W+40,H+40);stars(lt,80,.9);
 let gr=g.createRadialGradient(150,120,4,150,120,170);gr.addColorStop(0,'rgba(220,20,60,.3)');gr.addColorStop(1,'rgba(220,20,60,0)');g.fillStyle=gr;g.fillRect(-20,-20,W+40,H+40);
 ridge('#150f24',200,70,3,lt*3,30);ridge('#0b0716',226,40,7,lt*5,22);
 g.globalAlpha=ease(clamp(lt/.8,0,1));g.fillStyle='#8a6a40';g.fillRect(117,56,3,150);g.fillStyle='#e8c050';g.fillRect(116,52,5,5);if(window.npWave)npWave(g,121,60,66,lt);g.globalAlpha=1;
 const T=(txt,x,y,sz,col,t0)=>{const k=clamp((lt-t0)/.6,0,1);if(!k)return;g.globalAlpha=k;g.font=sz+'px MedievalSharp,Georgia,serif';g.textAlign='left';g.fillStyle='#000';g.fillText(txt,x+1,y+2);g.fillStyle=col;g.fillText(txt,x,y);g.globalAlpha=1};
 T('RACHIT PRODUCTION',230,98,26,'#e9c46a',.5);T('presents',232,117,13,'#c9b88a',1.0);T('MADE IN NEPAL',230,153,24,'#ff8a9a',1.5);T('The first pixel game of Nepal',232,173,13,'#f3e1b0',2.0)}
function sAll(lt){cam(1.02+.03*lt/6.8,0,0);sky('#2a1a48','#f2a45a',H*.72);
 g.fillStyle='#ffd890';g.beginPath();g.arc(280,118,38,0,6.3);g.fill();
 let gr=g.createRadialGradient(280,118,6,280,118,160);gr.addColorStop(0,'rgba(255,210,120,.5)');gr.addColorStop(1,'rgba(255,150,60,0)');g.fillStyle=gr;g.fillRect(100,-20,360,260);
 stars(lt,40,.3);ridge('#5a3a5c',150,50,2,lt*4,28);ridge('#3a2848',172,34,5,lt*8,22);
 const gg=g.createLinearGradient(0,178,0,H);gg.addColorStop(0,'#3a3a2a');gg.addColorStop(1,'#14100c');g.fillStyle=gg;g.fillRect(-20,178,W+40,H);
 g.fillStyle='#2a1c30';g.beginPath();g.ellipse(280,186,110,30,0,Math.PI,0);g.fill();
 throne(280,168,1.5,.8+.15*Math.sin(lt*3),lt);crown(280,96+Math.sin(lt*2)*2,1.5,lt);
 const POS=[[84,236,1],[200,240,1],[360,240,-1],[476,236,-1]];
 LORDS.forEach((L,i)=>{const at=.2+i*1.25;if(lt<at)return;const q=clamp((lt-at)/1.0,0,1),e=ease(q),x=lerp(i<2?-70:W+70,POS[i][0],e),y=POS[i][1],f=POS[i][2],wk=q<1;
  g.fillStyle='#3a2410';g.fillRect(Math.round(x-f*30),y-70,2,70);banner(x-f*30+(f>0?-2:-26),y-70,L.c1,L.c2,lt+i,.5);
  man(x-f*36,y-4,3.0,unitU(L,0),lt,{f:f,mv:wk,ph:lt*7+i*1.3});
  man(x,y,L.horse?4.1:4.7,heroU(L),lt,{f:f,mv:wk,ph:lt*(L.horse?9:7)});
  const na=clamp((lt-at-.9)/.5,0,1);if(na>0){g.globalAlpha=na;g.textAlign='center';g.font='bold 17px MedievalSharp,Georgia,serif';g.fillStyle='#000';g.fillText(L.n,x+1,y-143);g.fillStyle='#f6e6b8';g.fillText(L.n,x,y-144);g.font='10px MedievalSharp,Georgia,serif';g.fillStyle='#000';g.fillText(L.t,x+1,y-129);g.fillStyle='#e9c46a';g.fillText(L.t,x,y-130);g.fillStyle=L.c1;g.fillRect(x-11,y-124,11,5);g.fillStyle=L.c2;g.fillRect(x,y-124,11,5);g.globalAlpha=1}});
 fog(lt,226,'rgba(70,40,40,.2)',1.4)}
function npPole(x,yb,lt){g.fillStyle='#8a6a40';g.fillRect(x,yb-100,3,100);g.fillStyle='#e8c050';g.fillRect(x-1,yb-103,5,4);if(window.npWave)npWave(g,x+3,yb-98,36,lt)}
const SCN=[
{d:3.8,fi:.4,fo:.5,dr:sNepal,ev:[[.15,()=>{narr('Rachit Production presents. Made in Nepal.');chime();pad()}]]},
{d:3.8,fi:.5,fo:.5,dr:sNight,ev:[[0,()=>{sub('The old king is dead. The throne of the realm stands empty.',3.4);narr('The old king is dead, and the throne of the realm stands empty.');nz(4.6,500,.4,.05,'lowpass',2);pad()}]]},
{d:3.4,fi:.4,fo:.4,dr:sHall,ev:[[0,()=>{sub('Four lords have come to claim it.',3.0);narr('Four lords have come to claim it.');drum(.8,100)}],[.8,()=>drum(.8,90)]]},
{d:6.8,fi:.3,fo:.5,dr:sAll,ev:[[0,()=>{sub('From the four corners of the world, they came.',3.4);narr('From the four corners of the world, they came.')}],[.2,()=>{narr('Rachit, the Crusader.');horn(98,1.4);drum(.8,110)}],[1.45,()=>{narr('Sajan, the Shogun.');horn(130,1.4);drum(.7,100)}],[2.7,()=>{narr('Nigam, the Roman.');horn(110,1.4);drum(.7,100)}],[3.95,()=>{narr('Eleanor, the Highlander.');horn(82,1.4);drum(.7,100)}],[5.3,()=>{sub('Four lords. One throne.',1.4);drum(1,90)}]]},
{d:8.2,fi:.4,fo:.2,dr:sBattle,ev:[[0,()=>{sub('Four armies. One throne.',3);narr('Four armies. One throne.');horn(73,2.8)}],[AT,()=>{flash(.9);drum(1,140);nz(.6,300,.5,.35,'lowpass',.02);clash(.2);setTimeout(()=>clash(.2),150);horn(65,3)}],[AT+.5,()=>{sub('Only one shall wear the crown.',4.6);narr('And only one shall wear the crown.')}]]},
{d:6.4,fi:.15,fo:.9,dr:sFinal,ev:[[0,()=>{pad();[110,165,220].forEach(f=>tone(f,5,.05,'triangle',2,3))}],[2.3,()=>{flash(.7);chime();$('itit').classList.add('on')}]]}];
const TOTAL=SCN.reduce((a,s)=>a+s.d,0);
const vg=document.createElement('canvas');vg.width=W*SC;vg.height=H*SC;{const v=vg.getContext('2d'),gr=v.createRadialGradient(W*SC/2,H*SC/2,H*SC*.3,W*SC/2,H*SC/2,W*SC*.62);gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(1,'rgba(0,0,0,.6)');v.fillStyle=gr;v.fillRect(0,0,W*SC,H*SC)}
function finish(){if(done)return;done=1;try{window.speechSynthesis&&speechSynthesis.cancel()}catch(e){}try{mg&&mg.gain.setTargetAtTime(0,ia.currentTime,.12)}catch(e){}I.classList.add('out');menu.classList.remove('pre');setTimeout(()=>{I.remove();try{ia&&ia.close()}catch(e){}},900)}
function frame(){if(done)return;requestAnimationFrame(frame);if(menu.style.display=='none'){finish();return}
 const t=(performance.now()-T0)/1000;if(t>=TOTAL){finish();return}
 let i=0,ac=0;while(i<SCN.length-1&&t>=ac+SCN[i].d){ac+=SCN[i].d;i++}const S=SCN[i],lt=t-ac;
 if(i!==cur){cur=i;lastF=0;parts=[];$('itit').classList.remove('on')}
 S.ev.forEach((e,j)=>{const key=i+':'+j;if(!fired[key]&&lt>=e[0]){fired[key]=1;try{e[1]()}catch(x){}}});
 g.setTransform(SC,0,0,SC,0,0);g.fillStyle='#000';g.fillRect(0,0,W,H);
 g.save();S.dr(lt);g.restore();g.setTransform(SC,0,0,SC,0,0);
 let a=0;if(lt<S.fi)a=1-lt/S.fi;if(lt>S.d-S.fo)a=Math.max(a,(lt-(S.d-S.fo))/S.fo);if(a>0){g.fillStyle='rgba(0,0,0,'+clamp(a,0,1)+')';g.fillRect(0,0,W,H)}
 if(flashA>0){g.fillStyle='rgba(255,246,220,'+flashA+')';g.fillRect(0,0,W,H);flashA=Math.max(0,flashA-.035)}
 g.setTransform(1,0,0,1,0,0);g.drawImage(vg,0,0)}
function start(){if(go)return;go=1;$('igate').style.display='none';try{if(window.speechSynthesis){const p=new SpeechSynthesisUtterance(' ');p.volume=0;speechSynthesis.speak(p)}}catch(e){}ainit();try{ia&&ia.state=='suspended'&&ia.resume()}catch(e){}T0=performance.now();requestAnimationFrame(frame)}
$('igate').addEventListener('click',start);
$('isk').addEventListener('click',e=>{e.stopPropagation();finish()});
$('ivo').addEventListener('click',e=>{e.stopPropagation();try{setVoice(!voiceOn)}catch(x){}$('ivo').textContent=(typeof voiceOn!=='undefined'&&!voiceOn)?'🔇':'🔊'});
document.addEventListener('keydown',e=>{if(done)return;if(!go&&(e.key=='Enter'||e.key==' '))start();else if(e.key=='Escape')finish()});
setTimeout(()=>{if(!done&&!go){/* never tapped: keep gate */}},0);
}catch(err){console.error('intro failed',err);fin0()}
})();
