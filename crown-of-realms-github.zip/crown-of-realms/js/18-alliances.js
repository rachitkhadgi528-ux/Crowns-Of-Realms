/* ===== v13: rival kingdoms form alliances, help each other, offer pacts ===== */
(function(){try{
if(typeof MPI!='undefined'&&MPI)return;
setInterval(()=>{try{
 if(!inGame||won||paused||typeof KG=='undefined')return;
 const t=now(),foes=KG.filter(k=>!k.owned);
 foes.forEach(k=>{k.ally=(k.ally||[]).filter(a=>!a.owned)});
 /* form AI-to-AI alliances against the player */
 foes.forEach(a=>{if((a.ally.length<2)&&Math.random()<.25){const b=foes.find(o=>o!==a&&!a.ally.includes(o)&&o.ally.length<2);
  if(b){a.ally.push(b);b.ally.push(a);if(Math.hypot(H.x-a.x,H.y-a.y)<1200)toast(a.name+' and '+b.name+' form an alliance!')}}});
 /* allies send troops when a kingdom is hurt */
 foes.forEach(k=>{if(k.cast.hp>=k.cast.mhp*.85||k.rel>=0&&k.cast.hp>=k.cast.mhp*.95)return;
  k.ally.forEach(a=>{if(a.rel>=0&&a.rel!==undefined&&k.rel>=0)return;if(t<(a.hlp||0))return;a.hlp=t+45;
   const fr=US.filter(u=>u.kg===a&&u.team&&!u.dead&&!u.raid&&u.type!='lord'&&!u.ex);
   fr.slice(0,Math.ceil(fr.length*.5)).forEach((u,i)=>{u.raid=1;u.si=i});
   if(fr.length&&Math.hypot(H.x-a.x,H.y-a.y)<1400)toast(a.name+' sends aid to '+k.name+'!')})});
 /* allies share gold with a kingdom that is losing */
 foes.forEach(k=>{if(k.cast.hp<k.cast.mhp*.6)k.ally.forEach(a=>{if(a.r&&k.r&&a.r.gold>300){a.r.gold-=100;k.r.gold+=100}})});
 /* peaceful kingdoms may offer you an alliance */
 foes.forEach(k=>{if(k.rel===0&&t>(k.offer||90)&&!$('ov').innerHTML&&$('ov').style.display!='flex'&&Math.random()<.2){k.offer=t+240;paused=1;if(window.discK)discK(k,1);
  $('ov').innerHTML='<div><h3>🤝 '+k.name+' offers an alliance</h3><p>Their king proposes a pact of mutual defence.</p><button class="g" id="a13y">Accept</button> <button id="a13n">Decline</button></div>';$('ov').style.display='flex';
  $('a13y').onclick=()=>{k.rel=1;toast('You are allied with '+k.name);ovx()};$('a13n').onclick=()=>ovx()}});
}catch(e){console.error(e)}},8000);
}catch(e){console.error(e)}})();
