/* ===== v15: ages, peace, 5000 economy, lord chat ===== */
(function(){try{
const PEACE=420,AGE_T=[0,600,1200],AGE_N=['Stone Age','Iron Age','Medieval Age'],AGE_Y=[1,1.3,1.6],AGE_WM=[1,1.4,2],CAP=RESMAX;
let GT=0,AGE=0,GP=0,lastT=performance.now(),wasIn=0,wasLive=0,peaceDone=0,prevPeace=1;
if(typeof PEND!=='undefined'&&PEND&&PEND.gt>0)GT=PEND.gt;
window.GT_=()=>GT;window.AGE_=()=>AGE;
const mm=s=>{s=Math.max(0,Math.ceil(s));return((s/60)|0)+':'+('0'+s%60).slice(-2)};
const peaceOn=()=>PV.live?now()<PV.peaceEnd:GT<PEACE;
window.peaceOn=peaceOn;
window.YM=()=>2*AGE_Y[AGE];   /* base worker yield x2, grows with age */
/* ---------- age sprites ---------- */
const M=(w,h,f)=>{const k=document.createElement('canvas');k.width=w;k.height=h;const x=k.getContext('2d');f((col,a,b,ww,hh)=>{x.fillStyle=col;x.fillRect(a,b,ww,hh)});try{k.hd=hdify(k)}catch(e){}return k};
const hs=(x,y)=>Math.abs(Math.sin(x*12.9898+y*78.233)*43758.5453)%1;
const hutA=l=>M(24,20,r=>{r('#6b4a2c',4,11,16,9);r('#8a6a44',5,11,14,8);r('#4a2e18',4,11,1,9);r('#4a2e18',19,11,1,9);
 for(let y=2;y<11;y++){const w=4+(y-2)*2,x=12-w/2;r(y%2?'#c9a85a':'#b8964a',x,y,w,1);if(y%3==0)r('#a98a3c',x+1,y,2,1)}
 r('#8a6a2c',1,11,22,1);r('#6a4e20',11,1,2,1);r('#7d7d78',3,18,18,2);for(let i=0;i<6;i++)r('#9a9a94',4+i*3,18,2,1);
 r('#2a1a0a',10,13,4,7);r('#2a1a0a',11,12,2,1);if(l){r('#f3a233',11,14,2,5);r('#ffd070',11,15,2,2)}});
const hutB=l=>M(24,20,r=>{r('#7a5a38',3,12,18,8);r('#5a3a1e',3,12,1,8);r('#5a3a1e',20,12,1,8);
 for(let y=2;y<12;y++){const w=3+(y-2)*2,x=12-w/2;r(y%2?'#b89a6e':'#a68a5e',x,y,w,1)}
 r('#e8e0c8',9,0,1,4);r('#e8e0c8',14,0,1,4);r('#6a5030',2,12,20,1);for(let i=0;i<5;i++)r('#6a5030',4+i*4,5+i%2,1,5);
 r('#7d7d78',2,18,20,2);r('#2a1a0a',10,14,4,6);if(l){r('#f3a233',11,15,2,4)}});
const timb=(roof,rr,l)=>M(24,20,r=>{r('#8a5a30',3,9,18,11);for(let i=0;i<9;i++)r('#6e4624',4+i*2,9,1,11);r('#4a2e18',3,9,18,1);r('#4a2e18',3,9,1,11);r('#4a2e18',20,9,1,11);r('#4a2e18',3,14,18,1);
 r('#7d7d78',3,17,18,3);for(let i=0;i<6;i++)r('#9a9a94',4+i*3,17,2,1);
 for(let i=0;i<6;i++){r(i%2?roof:rr,10-2*i,3+i,4+4*i,1)}r(rr,2,9,20,1);r(roof,2,10,20,1);r('#5a4a3a',17,1,3,4);
 r('#3a2210',10,13,4,7);r(l?'#f3c14a':'#2a1a0a',5,12,3,3);r(l?'#f3c14a':'#2a1a0a',16,12,3,3)});
const AGH=[[[hutA(0),hutA(1)],[hutB(0),hutB(1)]],[[timb('#c8a24e','#b08a3a',0),timb('#c8a24e','#b08a3a',1)],[timb('#7a6a3e','#625430',0),timb('#7a6a3e','#625430',1)]]];
const palA=v=>M(14,16,r=>{const hh=v?[12,10,13,11]:[11,13,12,13];
 for(let i=0;i<4;i++){const x=i*3.5|0,t=3+(13-hh[i]);r(i%2?'#7a5230':'#5e3c1e',x,t,3,16-t);r(i%2?'#7a5230':'#5e3c1e',x+1,t-2,1,2);r('#9a6e40',x,t+1,1,10)}
 r('#b89a5a',0,9,14,1);r('#b89a5a',0,12,14,1)});
const palB=v=>M(14,16,r=>{r('#8a8a98',0,11,14,5);r('#a8a8b4',1,12,12,3);r('#55556a',0,11,14,1);r('#55556a',6,12,1,4);
 for(let i=0;i<4;i++){const x=i*3.5|0,t=2+(i+v)%2*2;r(i%2?'#8a5a30':'#6e4624',x,t,3,11-t+1);r('#4a2e18',x+1,t-1,1,1);r('#a8743c',x,t+1,1,7)}r('#3a2210',0,8,14,1)});
const AGW=[[palA(0),palA(1)],[palB(0),palB(1)]];
const farmA=(v,f)=>M(18,10,r=>{r('#5a3a1e',0,0,18,10);r('#6e4a2a',1,1,16,8);for(let i=0;i<4;i++)r('#4a2e18',1,2+i*2,16,1);
 for(let i=0;i<4;i++)if((i+v)%2==0){const x=2+i*4;r('#9ac060',x+(f%2),3+(i%2)*2,1,3);r('#c4d880',x+(f%2),2+(i%2)*2,1,1)}r('#7a5230',0,0,1,3);r('#7a5230',17,7,1,3)});
const farmB=(v,f)=>M(18,10,r=>{r('#5a3a1e',0,0,18,10);r('#7a5230',1,1,16,8);for(let i=0;i<4;i++){const x=2+i*4,sw=(f+i)%2;r('#4c9a3c',x,3-sw,2,5);r(v?'#d8b84a':'#8acb4a',x,2-sw,2,2)}
 r('#8a5a30',0,0,18,1);r('#8a5a30',0,9,18,1);for(let i=0;i<5;i++)r('#6e4624',i*4,0,1,10)});
const AGF=[[0,1].map(v=>[0,1,2,3].map(f=>farmA(v,f))),[0,1].map(v=>[0,1,2,3].map(f=>farmB(v,f)))];
const twA=M(16,36,r=>{r('#5e3c1e',3,16,2,20);r('#5e3c1e',11,16,2,20);r('#7a5230',4,24,8,1);r('#7a5230',4,31,8,1);r('#6e4624',2,14,12,3);r('#8a5a30',3,8,10,6);
 for(let i=0;i<5;i++)r(i%2?'#c9a85a':'#b8964a',8-i*2,2+i,2+i*4,1);r('#2a1a0a',6,10,4,4)});
const twB=M(16,36,r=>{r('#8a8a98',3,22,10,14);r('#a8a8b4',3,22,2,14);r('#55556a',11,22,2,14);r('#8a5a30',3,10,10,12);r('#6e4624',3,10,10,1);r('#6e4624',3,16,10,1);
 for(let i=0;i<5;i++)r(i%2?'#c8a24e':'#b08a3a',8-i*2,3+i,2+i*4,1);r('#2a1a0a',6,12,4,4)});
const AGT=[twA,twB];
function ageSet(o){const k=o.k;if(!o.m)o.m={img:o.img,vd:o.vd,vl:o.vl,fr:o.fr};const h=hs(o.x,o.y),v=h<.5?0:1;
 if(AGE>=2){const n=o.m.vd&&o.img===o.vl;o.img=o.m.img;if(o.m.vd){o.vd=o.m.vd;o.vl=o.m.vl;o.img=n?o.vl:o.vd}if(o.m.fr){o.fr=o.m.fr;o.img=o.fr[0]}o.ag=AGE;return}
 if(k=='home'){const n=o.m.vl&&o.img===o.vl;o.vd=AGH[AGE][v][0];o.vl=AGH[AGE][v][1];o.img=n?o.vl:o.vd}
 else if(k=='wall')o.img=AGW[AGE][v];
 else if(k=='farm'){o.fr=AGF[AGE][v];o.img=o.fr[0]}
 else if(k=='tower')o.img=AGT[AGE];
 o.ag=AGE}
function agePass(){const t=performance.now();if(t-GP<600)return;GP=t;
 for(let i=0;i<objs.length;i++){const o=objs[i];if(o.ag===AGE||o.dec||!o.xv)continue;const k=o.k;if(k=='home'||k=='wall'||k=='farm'||k=='tower')ageSet(o)}
 WALLS.forEach(w=>{if(w.ag!==AGE){const b=w.b0||(w.b0=w.mhp),r=w.mhp?w.hp/w.mhp:1;w.mhp=b*AGE_WM[AGE];w.hp=w.mhp*r;w.ag=AGE}});
 if(typeof KW!='undefined')KW.forEach(w=>{if(w.ag!==AGE){const b=w.b0||(w.b0=w.mhp),r=w.mhp?w.hp/w.mhp:1;w.mhp=b*AGE_WM[AGE];w.hp=w.mhp*r;w.ag=AGE}})}
const _amb2=ambient;ambient=function(a,b,c2,d,e){_amb2(a,b,c2,d,e);try{agePass()}catch(x){}};
/* ---------- clock, peace, caps ---------- */
function hudLine(){const e=$('hud');if(!e)return;let d=document.getElementById('agl');if(!d||d.parentNode!==e){d=document.createElement('div');d.id='agl';d.className='hr';e.appendChild(d)}
 const nx=AGE<2?' \u2192 '+AGE_N[AGE+1]+' '+mm(AGE_T[AGE+1]-GT):'';let pe='';if(PV.live){const r=(PV.peaceEnd-now());if(r>0)pe=' \u00b7 Peace '+mm(r)}else if(GT<PEACE)pe=' \u00b7 Peace '+mm(PEACE-GT);
 const x='\u23f3 '+mm(GT)+' \u00b7 '+AGE_N[AGE]+nx+pe;if(d.textContent!==x)d.textContent=x}
const _hud=hud;hud=function(){_hud();try{hudLine()}catch(e){}};
setInterval(()=>{try{const n=performance.now(),dt=Math.min(1,(n-lastT)/1000);lastT=n;
 if(PV.live&&!wasLive){GT=0;AGE=0;GP=0}wasLive=PV.live?1:0;
 if(inGame&&!wasIn&&!PV.live&&GT<1){toast('Peace for 7 minutes: build your economy first');}
 wasIn=inGame?1:0;
 if(inGame&&(!paused||PV.live)&&!won)GT+=dt;
 const a=GT>=AGE_T[2]?2:GT>=AGE_T[1]?1:0;if(a!==AGE){AGE=a;GP=0;toast('The '+AGE_N[AGE]+' begins: stronger walls, faster workers!');try{sfx('horn')}catch(e){}}
 ['wood','stone','gold','food'].forEach(r=>{if(H[r]>CAP)H[r]=CAP});
 if(!PV.live&&inGame&&GT<PEACE){nextRaid=Znow()+(PEACE-GT)+60;if(!MPI)KG.forEach(k=>{if(k.wp<(PEACE-GT)+30)k.wp=(PEACE-GT)+30})}
 const pn=peaceOn();if(inGame&&prevPeace&&!pn&&!PV.live){toast('The peace is over. Raids and war are now possible!');try{sfx('horn')}catch(e){}}prevPeace=pn?1:0;
 hudLine();lords()}catch(e){}},500);
/* ---------- save / load ---------- */
const _sn=snap;snap=function(){const o=_sn();o.gt=GT;o.ai=KG.map(k=>k.ai?{m:k.ai.mood,g:k.ai.gifts||0}:null);return o};
const _ap=applySave;applySave=function(S){_ap(S);GT=+S.gt||0;GP=0;if(Array.isArray(S.ai))S.ai.forEach((a,i)=>{if(a&&KG[i]){initAI(KG[i],i);KG[i].ai.mood=+a.m||0;KG[i].ai.gifts=+a.g||0}})};
/* ---------- lords: personalities, moods, chat ---------- */
const RN=['Aldric','Brenna','Cedric','Dagna','Eadric','Freya','Godwin','Hilda','Ivor','Jorund','Kenric','Leofric','Maelis','Osric'],FEM={Brenna:1,Dagna:1,Freya:1,Hilda:1,Maelis:1};
const PERS=['proud','greedy','honorable','cunning','warlike','pious'];
const TONE={proud:{o:['Hmph.','You stand before a ruler.','Speak, and be brief.'],f:'My crown outshines yours'},greedy:{o:['Ah, a visitor with a purse?','Coin first, words after.','Time is gold, friend.'],f:'Gold keeps friends loyal'},honorable:{o:['On my honour,','Hear me plainly:','I speak true:'],f:'A promise is iron'},cunning:{o:['Hmm, interesting...','Walk softly in my halls.','I hear many things.'],f:'Every road has two ends'},warlike:{o:['Steel decides all.','Make it quick.','My spears grow restless.'],f:'Blood is the only ink'},pious:{o:['Peace be upon you.','The heavens watch us.','Bless this meeting.'],f:'The saints see all'}};
const pick=a=>a[Math.random()*a.length|0];
function initAI(k,i){if(k.ai)return;const h=Math.abs(Math.sin((i+1)*91.7)*10000)%1,p=PERS[(i*2+Math.floor(h*6))%6],rn=RN[(i*5+Math.floor(h*14))%14];
 k.ai={rn,title:FEM[rn]?'Lady':'Lord',p,mood:p=='warlike'?-5:p=='pious'?20:8,gifts:0,log:[],unread:0,nx:GT+120+Math.random()*120,pend:null,cd:0,ally:0}}
const nm=k=>k.ai.title+' '+k.ai.rn;
const band=m=>m>=70?'devoted':m>=40?'friendly':m>=10?'warm':m>-10?'neutral':m>-40?'irritated':m>-70?'hostile':'furious';
const emo={devoted:'\u2764',friendly:'\u263a',warm:'\u263a',neutral:'\u25cb',irritated:'\u2639',hostile:'\u2639',furious:'\u2620'};
function say2(k,t,me){k.ai.log.push({me:me?1:0,t});if(k.ai.log.length>30)k.ai.log.shift();if(!me&&!(CH.k===k&&CH.open))k.ai.unread++;if(CH.k===k&&CH.open)drawChat()}
const CH={k:null,open:0,list:1};
function mood(k,d){k.ai.mood=Math.max(-100,Math.min(100,k.ai.mood+d))}
function words(s,l){return l.some(w=>s.includes(w))}
function strong(k){return ARM.length>=Math.max(6,k.n*2.5)}
function replyBase(k,raw){const A=k.ai,s=' '+raw.toLowerCase().replace(/[^a-z0-9 ]/g,' ')+' ',T=TONE[A.p],md=A.mood,b=band(md);let out=[],pre=Math.random()<.6?pick(T.o)+' ':'';
 if(A.pend&&words(s,[' yes ',' pay ',' agree',' accept',' fine ',' deal',' ok '])){const p=A.pend;A.pend=null;
  if(p.t=='tribute'){if(H.gold>=p.n){H.gold-=p.n;mood(k,18);return pre+'A wise choice. We part as friends. ('+p.n+' gold paid)'}return 'You cannot even afford it. Do not waste my time.'}
  if(p.t=='peace'){k.rel=0;mood(k,15);toast(nm(k)+' agrees to peace');return pre+'Then let the swords rest. Peace between us.'}
  if(p.t=='ally'){k.rel=1;mood(k,10);toast(nm(k)+' is now your ally!');return pre+'Then we stand together. My banners are yours.'}}
 if(A.pend&&words(s,[' no ',' refuse',' never',' decline'])){const p=A.pend;A.pend=null;if(p.t=='tribute'){mood(k,-14);return pre+'Then you choose the hard road. Remember this refusal.'}return 'As you wish.'}
 const g=s.match(/(\d{1,4})\s*(gold|wood|stone|food)/),isG=words(s,[' gift',' give ',' send you',' present',' offer ',' donate',' tribute']);
 if(g||isG){const n=g?Math.min(+g[1],RESMAX):100,r=g?g[2]:'gold';if(!(n>0))return pre+'Name an amount.';if(H[r]<n)return 'You lack '+n+' '+r+', my friend.';
  H[r]-=n;A.gifts+=n;const val=n*({gold:1,food:.6,wood:.7,stone:.8}[r]),gain=Math.min(30,val/10*(A.p=='greedy'?1.6:1));mood(k,gain);hud();
  return pre+(gain>12?'A magnificent gift! You have my thanks.':gain>4?'A kind gesture. I will remember it.':'A small offering, but I accept.')+' ('+n+' '+r+')'}
 if(words(s,[' declare war',' fight me',' war on you',' let us fight',' go to war',' i challenge'])){if(k.rel<0)return 'We are already at war, fool.';decl(k,0);mood(k,-50);return 'So be it! My banners rise against you.'}
 if(words(s,[' fool',' coward',' idiot',' stupid',' pig',' dog ',' weak',' pathetic',' worthless',' scum',' ugly',' trash',' liar'])){mood(k,-16);return (A.p=='pious'?'Such words stain your soul. ':A.p=='warlike'?'Say that on the battlefield! ':'You insult me in my own hall. ')+'My patience thins.'}
 if(words(s,[' surrender',' kneel',' bow ',' submit',' destroy',' crush',' attack',' burn',' kill',' invade',' conquer'])){
  if(strong(k)&&md<30){const t=60+(Math.random()*80|0);H.gold+=t;mood(k,-10);return 'Your host is too great... take '+t+' gold and leave us be. (+'+t+' gold)'}
  mood(k,-12);if(md<-30)A.pend={t:'tribute',n:120,until:GT+90};return pre+'Threats? My walls have seen bigger armies than yours.'}
 if(words(s,[' peace',' truce',' ceasefire',' stop the war',' end the war',' sorry',' apolog',' forgive'])){
  if(k.rel>=0){mood(k,3);return pre+'We are not at war. Peace holds, for now.'}
  if(md>-35||k.cast.hp<k.cast.mhp*.6||strong(k)){k.rel=0;mood(k,12);toast(nm(k)+' accepts peace');return pre+'Enough blood. I accept your peace.'}
  mood(k,-2);return pre+'No. You have wronged me too deeply. Perhaps a gift would soften my heart...'}
 if(words(s,[' alliance',' ally',' allies',' pact',' unite',' join me',' join us',' together',' friends'])){
  if(k.rel>0)return 'We are already allies, '+(md>50?'my friend':'for now')+'.';
  if(k.rel<0)return 'We are at war! Ask for peace first.';
  if(md>=45){k.rel=1;mood(k,5);toast(nm(k)+' is now your ally!');try{sfx('recruit')}catch(e){}return pre+'I accept. Our realms stand together.'}
  if(md>=20)return pre+'I do not yet trust you enough. Show friendship with a gift, and ask again.';
  return pre+'An alliance? '+(A.p=='proud'?'You are beneath me.':A.p=='greedy'?'What does it pay?':'Not while I doubt you.')}
 if(words(s,[' help',' troops',' reinforce',' send men',' send troops'])){
  if(k.rel>0&&md>=35&&GT>A.cd){A.cd=GT+150;try{callAllies()}catch(e){}return pre+'My riders will come to your aid.'}
  if(k.rel>0)return 'Ask me again soon; my men are busy.';return 'Why would I send men to a stranger?'}
 if(words(s,[' trade',' market',' goods',' barter',' buy ',' sell ',' merchant'])){
  if(md<-10||k.rel<0)return pre+'I do not trade with enemies.';return pre+'My market is open at my gates. My merchants give you better prices there.'}
 if(words(s,[' news',' rumor',' rumour',' gossip',' other lords',' neighbor',' neighbour',' heard'])){
  const o=KG.filter(q=>q!==k&&q.known);if(!o.length)return pre+'My riders have seen little. Explore more yourself.';const q=pick(o);return pre+q.ai.title+' '+q.ai.rn+' of '+q.name+' keeps about '+(q.n||0)+' soldiers, and I hear their mood is '+band(q.ai.mood)+'.'}
 if(words(s,[' army',' strong',' how many',' soldiers'])){return md>0?pre+'We muster around '+(k.n||0)+' soldiers.':pre+'My strength is none of your concern.'}
 if(words(s,[' who are you',' your realm',' your kingdom',' your people',' tell me about'])){return pre+'I am '+nm(k)+' of '+k.name+', of the '+k.cu.n+'. '+T.f+'.'}
 if(words(s,[' how are you',' feel',' mood',' well '])){return pre+'I feel '+b+' toward you. '+(md>40?'Your friendship warms my halls.':md<-30?'Do not test me.':'We shall see where this road leads.')}
 if(words(s,[' great',' mighty',' wise',' noble',' brave',' friend',' honour',' honor',' respect',' admire',' beautiful',' thank',' thanks',' love'])){mood(k,A.p=='proud'?9:5);return pre+(md>30?'You are kind. I enjoy your company.':'Flattery... but pleasantly delivered.')}
 if(words(s,[' hello',' hi ',' hail',' greetings',' good day',' hey '])){return pre+(md>40?'Welcome, friend!':md<-30?'What do you want?':'Greetings.')+(A.p=='pious'?' May the saints keep you.':'')}
 return pre+(md>20?'Say more, friend. Try asking about alliance, peace, trade, news, or send a gift.':md<-30?'Speak plainly or leave.':'I follow not. Try alliance, peace, trade, news, or a gift.')}
const STOPW=new Set('the a an and or but is are was were be been am you your yours my mine me we us our he she it they them this that these those to of in on at for with from by as do does did have has had not no yes so if then than too very can could would should will shall just about into over any some what who whom which when where why how there here also let like want need tell say said know think going get make please really much more most its ill ive dont cant wont im'.split(' '));
const KWD=s=>s.split(' ').filter(w=>w.length>2&&!STOPW.has(w));
const JOKES=['Why did the knight bring a ladder to the tavern? He heard the drinks were on the house.','A peasant told his lord: "I have good news and bad news." "The bad?" "Your horse is dead." "And the good?" "It was the tax collector\'s horse."','I once knew a king so forgetful he lost his crown twice. The second time it was on his head.','Three squires walk into a castle. One ducks. Sensible fellow.','Why do bards never win wars? They keep losing the beat... and the battle.'];
const PRSN={proud:{no:'Such things are beneath a crown.'},greedy:{no:'Free? Nothing is free.'},honorable:{no:'Honour forbids it.'},cunning:{no:'Not so easily.'},warlike:{no:'Weakness disgusts me.'},pious:{no:'The saints would frown.'}};
function spec(k,s,raw,A,T,md,pre){
 const isQ=/\?/.test(raw)||/^ (what|who|why|how|where|when|do|does|did|can|could|are|is|will|would|should) /.test(s);
 const dist=Math.round(Math.hypot(k.x-H.x,k.y-H.y)/100),dirs=['east','south-east','south','south-west','west','north-west','north','north-east'],ang=Math.atan2(k.y-H.y,k.x-H.x),dir=dirs[((Math.round(ang/(Math.PI/4))%8)+8)%8];
 const pn=A.pn?', '+A.pn:'';const m=raw.match(/(?:my name is|i am called|call me|they call me|i'm called)\s+([A-Za-z]{2,14})/i);
 if(m){A.pn=m[1];return pre+'Well met, '+A.pn+'. A name I shall remember.'}
 if(/ (fuk|fuck|fucking|shit|bitch|asshole|bastard|screw you|damn you|go to hell|piss off) /.test(s)){mood(k,-14);return (A.p=='pious'?'Such filth from your mouth. Mend your tongue, or the saints will not.':A.p=='warlike'?'Bold words. Repeat them on the battlefield.':A.p=='greedy'?'Cursing costs you nothing, but it has cost you my goodwill.':A.p=='cunning'?'Anger makes a poor advisor. I shall remember this.':A.p=='honorable'?'That is unworthy of you. Speak with honour or not at all.':'You dare speak so in my hall? My patience thins.')}
 if(/ (meaning of life|purpose of life|why are we here|what is life) /.test(s))return pre+(A.p=='pious'?'To serve the saints and leave the world a little better.':A.p=='warlike'?'To fight well and be remembered.':A.p=='greedy'?'To gather what you can and spend it wisely.':'To build something that outlasts you. A hall, a name, a peace.');
 if(/ (joke|funny|make me laugh|riddle) /.test(s))return pre+pick(JOKES);
 if(/ (story|legend|legends|tale|history|your past|past) /.test(s))return pre+'The '+k.cu.n+' of '+k.name+' tell of the first hall raised on this ground, burned twice and raised thrice. '+(A.p=='warlike'?'Every stone was paid for in blood.':A.p=='pious'?'The saints spared it each time.':A.p=='greedy'?'And the treasury has never been empty since.':'We endure, and that is the whole story.');
 if(/ (where) /.test(s)&&/ (you|your|castle|kingdom|hall|live|realm|are) /.test(s))return pre+'My hall lies about '+dist+' leagues '+dir+' of your camp.';
 if(/ (how old|your age) /.test(s))return pre+'I have seen '+(28+((KG.indexOf(k)*7)%31))+' winters, and each one tried to kill me.';
 if(/ (are you|r u) (an )?(ai|bot|robot|real|human|program|machine|chatgpt|gpt|claude)|artificial|language model/.test(s))return pre+'I am a lord of '+k.name+', as real as the stone of my keep. If a stranger voice whispers my words, it is the voice of the realm itself.';
 if(/ (weather|rain|snow|storm|sunny|cloudy|cold|freezing|hot|dark|night) /.test(s))return pre+(A.p=='pious'?'The heavens write their moods in the sky, and we read them as we can.':A.p=='warlike'?'Bad weather is a fine time to march. The enemy stays indoors.':A.p=='greedy'?'Rain is good for crops, snow is good for nothing. Is there profit in it?':'My scouts say the roads are passable, though the lights burn low at night.');
 if(/ (love|marry|marriage|wife|husband|wed|kiss|romance|romantic|date me|handsome|beautiful) /.test(s)){mood(k,1);return pre+(A.p=='proud'?'You aim high. But my hand is promised to my crown.':A.p=='greedy'?'Romance is a fine thing. A dowry is finer.':A.p=='warlike'?'I wed the battlefield. She is jealous.':A.p=='pious'?'Love is a blessing. Court it with patience and prayer.':'A charming thought. Politics rarely allows such luxuries.')}
 if(/ (advice|tips|strategy|what should i do|help me win) /.test(s)||/ how (do|can|to) i (win|beat|defeat|conquer|rule|survive|grow) /.test(s)){const n=ARM.length;return pre+(n<80?'You have '+n+' soldiers. Build your host first: the Training Ground upgrades troops, and walls buy you time.':n<250?'A fair host of '+n+'. Train your ranks, keep archers behind pikes, and do not march a lone army against a lord with allies.':'Your '+n+' soldiers are formidable. Seek allies, hit the weakest lord first, and take their castle before reinforcements arrive.')+(k.rel<0?' But do not ask me how to defeat myself.':'')}
 if((/ (what do you think|opinion|thoughts?) /.test(s)&&/ (me|my|army|kingdom|realm|rule) /.test(s))||/ (how strong am i|am i strong|do you respect me|do you trust me|do you like me|do you hate me) /.test(s)){const n=ARM.length;return pre+'Your host numbers about '+n+'. '+(n>300?'It shakes the earth.':n>120?'It is no small force.':'It is yet a young army.')+' As for you, I feel '+band(md)+' toward you.'}
 for(const q of KG){if(q===k||!q.ai||(!q.known&&!q.owned))continue;if(s.includes(' '+q.ai.rn.toLowerCase()+' ')||s.includes(' '+q.name.toLowerCase()+' ')){return pre+q.ai.title+' '+q.ai.rn+' of '+q.name+' keeps about '+(q.n||0)+' soldiers and is '+band(q.ai.mood)+' in temper. '+(q.rel<0?'They are at war with you.':q.rel>0?'They are your ally.':'They watch from afar.')+' '+(A.p=='cunning'?'I trust none of them.':A.p=='warlike'?'I would test their steel.':A.p=='greedy'?'Their treasury interests me.':'We shall see how they act.')}}
 if(/ (give me|lend me|spare me|donate to me|can i have) /.test(s)&&!/ \d/.test(s)){
  if(md>=55&&GT>(A.cd2||0)){const g=60+Math.round((md-50)*2);H.gold=Math.min(RESMAX,H.gold+g);A.cd2=GT+300;hud();return pre+'You have been a good friend. Take '+g+' gold. ('+g+' gold)'}
  return pre+(md>=55?'I have already been generous. Ask again later.':PRSN[A.p].no+' Earn my trust first.')}
 if(/ (what are you (doing|up to)|your plans?|what do you plan) /.test(s))return pre+(k.rm?'My riders are abroad, exploring the far lands.':k.rel<0?'I am mustering my host. You will see it soon.':k.rel>0?'Tending the realm, and watching our common enemies.':'Tending my realm. I am at level '+(k.lv||1)+' and growing.');
 if(/ (food|drink|wine|ale|beer|feast|hungry|bread|meat) /.test(s))return pre+(A.p=='greedy'?'The finest feasts cost the most. Join me when you have gold.':A.p=='pious'?'We fast on holy days, and feast when the saints allow.':'A good feast keeps an army loyal. My cooks are the true heroes of '+k.name+'.');
 if(/ (god|gods|pray|prayer|church|saint|saints|heaven|faith) /.test(s))return pre+(A.p=='pious'?'Faith is my shield. Pray with me, and your road will be lighter.':'I leave such matters to the priests, though I light a candle when the battle turns.');
 if(/ (afraid|scared|fear|die|death|dying) /.test(s))return pre+(A.p=='warlike'?'Fear is only the whisper before the charge.':'We all fear something. The wise march anyway.');
 if(/ (dragon|dragons|magic|wizard|witch|sorcerer|ghost|monster|monsters) /.test(s))return pre+'Tales for children and bards. Yet my scouts speak of strange shapes in the dark, and I keep my torches lit.';
 if(/ (treasure|rich|riches|wealth|money|coins?) /.test(s)&&isQ)return pre+(md>20?'My treasury holds about '+(Math.round(((k.r&&k.r.gold)||0)/10)*10)+' gold. Not enough, never enough.':'My treasury is my own affair.');
 if(/ (horse|horses|knight|knights|cavalry) /.test(s))return pre+'A well-bred horse and a stout knight win more fields than a thousand peasants. Mine ride in '+k.name+' colours.';
 if(/ (castle|walls|wall|fortress|keep|tower) /.test(s))return pre+'My walls are at level '+(k.lv||1)+' and I raise more each season. '+(A.p=='cunning'?'Every wall has a gate, as you well know.':'Test them if you dare.');
 if(/ (bye|goodbye|farewell|see you|must go|leave now|good night|later) /.test(s))return pre+(md>40?'Farewell, friend'+pn+'. My gates are open to you.':md<-30?'Good. Leave.':'Farewell'+pn+'. Walk carefully.');
 if(/ why /.test(s)&&isQ)return pre+'Why? Because the world is iron and men are stubborn. '+(A.p=='pious'?'And the saints are patient.':A.p=='cunning'?'But I suspect you already know.':'Ask a better question and I will give a better answer.');
 return null}
function freeReply(k,s,raw,A,md,pre){
 const kw=KWD(s).sort((a,b)=>b.length-a.length),W=kw[0],pn=A.pn?A.pn:'stranger',tail=k.rel<0?' Remember: we are at war.':k.rel>0?' Between allies, speak freely.':'';
 if(!W)return pre+pick(['Speak up, '+pn+'. I do not hear well over the wind.','Say it plainly, '+pn+'.','Words, '+pn+'. Give me words that mean something.'])+tail;
 const L={proud:[W+'? A small matter for a crown, yet I will indulge you. What is it to you?','You bring up '+W+' as if I had not thought of it. What do you seek?'],greedy:[W+'? Is there coin in it? Tell me more, and mind the price.','If '+W+' makes gold, I am listening. If not, be brief.'],honorable:['You speak of '+W+'. I would hear your meaning plainly. What do you ask of me?','On '+W+', I will speak true. What do you want to know?'],cunning:['Curious that you raise '+W+'. Who put that thought in your head?','Hm. '+W+'. Everything is a sign if you read it right. What do you intend?'],warlike:[W+'... Can it be won with steel? If not, I care little. What do you want?','Is '+W+' worth a fight? Say so, and I will listen.'],pious:[W+'... The saints have no single answer, but I will listen. Go on.','You speak of '+W+'. May wisdom guide us both. What troubles you?']}[A.p];
 return pre+pick(L)+tail}
function reply(k,raw){const A=k.ai;A.n=(A.n||0)+1;const s=' '+raw.toLowerCase().replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ')+' ',T=TONE[A.p],md=A.mood,pre=Math.random()<.5?pick(T.o)+' ':'';
 if(A.last===s){A.rep=(A.rep||0)+1;if(A.rep>=1){return pick(['You repeat yourself. Do I look deaf?','Again? Say something new.','I heard you the first time.'])}}else A.rep=0;A.last=s;
 if(A.n%4==0&&md<30)mood(k,1);
 let out=null;try{out=spec(k,s,raw,A,T,md,pre)}catch(e){out=null}
 if(out==null){out=replyBase(k,raw);if(/I follow not|Say more, friend|Speak plainly or leave/.test(out))out=freeReply(k,s,raw,A,md,pre)}
 return out}
function chatSend(txt){const k=CH.k;if(!k||!txt)return;say2(k,txt,1);const url=window.LORD_AI_URL;
 if(url&&window.fetch){const ctl=window.AbortController?new AbortController():null,to=setTimeout(()=>{ctl&&ctl.abort()},6000);
  fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({lord:nm(k),realm:k.name,personality:k.ai.p,mood:band(k.ai.mood),relation:k.rel>0?'ally':k.rel<0?'war':'neutral',soldiers:k.n||0,player_army:ARM.length,history:k.ai.log.slice(-10),message:txt}),signal:ctl?ctl.signal:undefined}).then(r=>r.json()).then(j=>{clearTimeout(to);say2(k,(j&&(j.reply||j.text))||reply(k,txt),0)}).catch(()=>{clearTimeout(to);try{say2(k,reply(k,txt),0)}catch(e){}});return}
 setTimeout(()=>{try{say2(k,reply(k,txt),0)}catch(e){}},350+Math.random()*500)}
window.lordSend=chatSend;
function drawChat(){const L=document.getElementById('lcLog');if(!L||!CH.k)return;const k=CH.k;L.innerHTML='';k.ai.log.forEach(m=>{const d=document.createElement('div');d.style.cssText='margin:4px 0;padding:5px 7px;border-radius:5px;font-size:9px;line-height:1.4;max-width:88%;'+(m.me?'margin-left:auto;background:#3a2a10;color:#f3e6b8':'background:#1c2a3a;color:#cfe0f0');d.textContent=m.t;L.appendChild(d)});L.scrollTop=L.scrollHeight;
 const h=document.getElementById('lcHead');if(h)h.textContent=nm(k)+' of '+k.name+' \u00b7 '+emo[band(k.ai.mood)]+' '+band(k.ai.mood)+' \u00b7 '+(k.rel>0?'ally':k.rel<0?'at war':'neutral')}
function openList(){CH.open=1;CH.list=1;CH.k=null;paused=1;const e=$('ov');e.style.display='flex';
 const ks=KG.filter(k=>k.known||k.owned);let h='<div style="width:min(94vw,480px)"><div class="xh"><h3>Lords</h3><button onclick="ovx();lordClose()">Close</button></div>';
 if(!ks.length)h+='<p style="font-size:9px">You have not met any lords yet. Send your Messenger to explore and find them.</p>';
 ks.forEach(k=>{initAI(k,KG.indexOf(k));const A=k.ai,b=band(A.mood);h+='<p style="margin:6px 0"><button onclick="lordOpen('+KG.indexOf(k)+')" style="width:100%;text-align:left">'+emo[b]+' '+nm(k)+' of '+k.name+' \u00b7 '+b+' \u00b7 '+(k.rel>0?'ally':k.rel<0?'war':'neutral')+(A.unread?' \u00b7 ('+A.unread+' new)':'')+'</button></p>'});
 e.innerHTML=h+'</div>'}
window.lordClose=()=>{CH.open=0;CH.k=null};
window.lordOpen=i=>{const k=KG[i];if(!k)return;initAI(k,i);CH.k=k;CH.open=1;CH.list=0;k.ai.unread=0;paused=1;const e=$('ov');e.style.display='flex';
 if(!k.ai.log.length)say2(k,(TONE[k.ai.p].o[0])+' I am '+nm(k)+'. What brings you to speak with me?',0);
 e.innerHTML='<div style="width:min(94vw,520px)"><div class="xh"><h3 id="lcHead"></h3><button onclick="openLords()">Back</button></div><div id="lcLog" style="height:150px;overflow-y:auto;background:#0e1418;border:2px solid #3a2410;padding:4px"></div>'+
 '<div style="margin:5px 0;display:flex;flex-wrap:wrap;gap:4px">'+[['Hello','Greetings!'],['Gift 100 gold','I send you a gift of 100 gold'],['Alliance','Let us form an alliance'],['Peace','I ask for peace'],['Trade','Can we trade?'],['News','Any news or rumors?'],['Help','Send troops to help me'],['Praise','You are a mighty and noble ruler']].map(a=>'<button style="font-size:9px" onclick="lordSend(\''+a[1]+'\')">'+a[0]+'</button>').join('')+'</div>'+
 '<div style="display:flex;gap:4px"><input id="lcIn" maxlength="140" placeholder="Speak to the lord..." style="flex:1;font:10px monospace;padding:6px;background:#f4e6b8;color:#2a1a05;border:2px solid #3a2410"><button onclick="lordGo()">Send</button></div></div>';
 const inp=document.getElementById('lcIn');['keydown','keyup','keypress'].forEach(t=>inp.addEventListener(t,ev=>{ev.stopPropagation();if(t=='keydown'&&ev.key=='Enter')lordGo()}));drawChat()};
window.lordGo=()=>{const i=document.getElementById('lcIn');if(!i||!i.value.trim())return;const v=i.value.trim();i.value='';chatSend(v)};
window.openLords=()=>{if(PV.live||MPI||!KG.length){toast('Lord talks are for solo mode');return}openList()};
/* lords speak and act on their own */
function lords(){if(PV.live||MPI)return;if(CH.open&&$('ov').style.display!='flex')CH.open=0;const b=document.getElementById('lordbtn');let un=0;
 KG.forEach((k,i)=>{if(!(k.known||k.owned))return;initAI(k,i);const A=k.ai;un+=A.unread;
  if(k.owned)return;
  A.mood+=((k.rel<0)?-.01:(k.rel>0)?.01:(A.mood>8?-.004:.004))*.5*(1);A.mood=Math.max(-100,Math.min(100,A.mood));
  if(A.pend&&GT>A.pend.until){const p=A.pend;A.pend=null;if(p.t=='tribute'&&!peaceOn()&&k.rel>=0){mood(k,-25);say2(k,'You ignored my demand. My patience is spent.',0);if(A.mood<-35){decl(k,1);say2(k,'War, then.',0)}}}
  if(GT>=A.nx){A.nx=GT+110+Math.random()*130;const m=A.mood,pn=peaceOn();
   if(m>=45){if(k.rel==0&&Math.random()<.5){A.pend={t:'ally',until:GT+120};say2(k,pick(TONE[A.p].o)+' I would see our realms allied. Will you accept? (yes / no)',0);toast(nm(k)+' proposes an alliance')}
    else{H.food=Math.min(CAP,H.food+40);say2(k,'A gift of food for a friend. May your granaries stay full. (+40 food)',0);toast(nm(k)+' sends you a gift')}}
   else if(m<-20&&!pn&&k.rel>=0){if(m<-55){decl(k,1);say2(k,'My patience is gone. We are at war!',0)}else{const n=80+(Math.random()*120|0);A.pend={t:'tribute',n,until:GT+120};say2(k,pick(TONE[A.p].o)+' Pay me '+n+' gold within two minutes, or face my spears. (yes / no)',0);toast(nm(k)+' demands tribute')}}
   else if(k.rel<0&&m>-30&&window.peaceReady&&peaceReady(k)){A.pend={t:'peace',until:GT+120};say2(k,'This war wearies me. Shall we make peace? (yes / no)',0);toast(nm(k)+' offers peace');window.__pmT=GT_()}
   else if(m>=10){say2(k,pick(k.cu.l)+' '+TONE[A.p].f+'.',0)}}});
 if(b){const t='Lords'+(un?' ('+un+')':'');if(b.textContent!==t)b.textContent=t}}
function addBtn(){const r=$('brow');if(!r||document.getElementById('lordbtn'))return;const b=document.createElement('button');b.className='b';b.id='lordbtn';b.textContent='Lords';b.addEventListener('pointerdown',e=>{e.preventDefault();window.openLords()});r.appendChild(b)}
addBtn();
/* lords also turn hostile when you hit them */
const _dc=decl;decl=function(k,auto){const was=k.rel;_dc(k,auto);if(was>=0&&k.rel<0&&k.ai){mood(k,-45);if(auto)say2(k,'You dared strike my people. War!',0)}};
}catch(e){console.error('v15',e)}})();
