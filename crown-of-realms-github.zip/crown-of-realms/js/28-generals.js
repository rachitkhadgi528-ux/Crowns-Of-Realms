/* ===== Generals: serve a lord/player after defeat, lord-vs-lord war, king cutscene, EXP ===== */
(function(){
const nm=k=>'Lord '+((k.hs&&(k.hs.ln||k.hs.n))||'')+' of '+(k._nm||k.name);
let GEN=null,lw=3,lastDef=null,fin=0;const GENOF={};
const exp=()=>{try{return +(localStorage.getItem('cor_gexp')||0)}catch(e){return 0}};
const addExp=n=>{try{localStorage.setItem('cor_gexp',exp()+n)}catch(e){}return exp()};
const rank=()=>['Recruit','Captain','Commander','Marshal','Grand General'][Math.min(4,Math.floor(exp()/200))];
const eligible=()=>KG.filter(k=>!k.owned&&!k.dfd&&!GENOF['k:'+KG.indexOf(k)]);
function menu(t,m){$('ov').innerHTML='<div><h3>'+t+'</h3><p>'+m+'</p><p style="color:#e8b94a">General rank: '+rank()+' ('+exp()+' EXP)</p><button class="g" onclick="ovx()">👁 Spectate</button> <button onclick="genPick()">⚔ Serve as General</button> <button onclick="genGo()">🔁 New match</button> <button onclick="genGo(1)">🚪 Exit</button></div>';$('ov').style.display='flex'}
window.genGo=x=>{if(x)try{sessionStorage.removeItem('cor_mp')}catch(e){}if(MP.on)mpLeave();else reloadToMenu()};
window.menu2=()=>menu('Defeated','Watch the war, serve a lord as his general, or start anew.');
window.genPick=function(){let b='';
 if(PV.live)MP.peers.forEach(P=>{if(!P.out)b+='<button onclick="genStart(\''+P.id+'\')">'+P.n+'</button> '});
 else KG.forEach((k,i)=>{if(!k.owned&&!k.dfd&&!GENOF['k:'+i])b+='<button onclick="genStart(\'k:'+i+'\')">'+nm(k)+'</button> '});
 $('ov').innerHTML='<div><h3>⚔ Choose your lord</h3><p>You serve as his general. If he wins the crown, you share the glory.</p>'+(b||'<p>Every lord already has a general.</p>')+'<br><button onclick="genRand()">🎲 Random</button> <button onclick="menu2()">Back</button></div>';$('ov').style.display='flex'};
window.genRand=function(){let L=[];if(PV.live)MP.peers.forEach(P=>{if(!P.out)L.push(P.id)});else L=eligible().map(k=>'k:'+KG.indexOf(k));if(!L.length)return genPick();genStart(L[Math.floor(Math.random()*L.length)])};
{const s=document.createElement('style');s.textContent='#gsk{display:none;right:max(8px,env(safe-area-inset-right,0px));top:calc(234px + env(safe-area-inset-top,0px));width:116px;padding:6px 4px;font-size:8px;background:#8a5a1a;color:#fff;z-index:6}@media (orientation:landscape) and (max-height:340px){#gsk{width:90px;padding:4px 2px;font-size:7px;top:calc(158px + env(safe-area-inset-top,0px))}}';document.head.appendChild(s)}
const isAlly=(a,b)=>!!a&&!!b&&(a===b||(a.ally&&a.ally.includes(b))||(b.ally&&b.ally.includes(a)));
const friendU=u=>!u.team||(!!GEN&&!!GEN.k&&isAlly(GEN.k,u.kg));
window.genStart=function(cid){
 const k=cid[0]=='k'&&cid[1]==':'?KG[+cid.slice(2)]:null,P=k?null:MP.peers.get(cid);if(!k&&!P)return;
 if(GEN&&GEN.k)delete GENOF[GEN.cid];
 GEN={cid,k,P,sh:0,shT:0,bf:0,sk:0,gt:0};if(k)GENOF[cid]='me';
 {const SF=__PRS.get();if(SF){const i=__PRS.PR.indexOf(SF);if(i>=0)__PRS.PR.splice(i,1);__PRS.clr()}}
 window.SPEC=0;window.GENM=1;H.mhp=170;H.hp=H.mhp;H.cd=0;H.inv=now()+3;
 if(P)ME.tm=P.tm;
 PB={c1:k?k.c1:P.c1,c2:k?k.c2:P.c2,em:k?k.em:P.em,p:(k||P).p,s:(k||P).s,c3:(k||P).c3};
 const cp=__PRS.resolveCap(cid);if(cp){H.x=cp.x+30;H.y=cp.y+16;cam.x=H.x-VW/2;cam.y=H.y-VH/2}
 const who=k?nm(k):P.n,bar=$('spb');if(bar){bar.style.display='flex';bar.firstChild.nodeValue='\u2694 General of '+who+' \u00b7 '+rank()+' '}
 gsk();feed('You now serve '+who+' as general');ovx();toast('You are the general of '+who+'. Attack, ride, and use Rally!');say('You serve '+who+' as general. Ride with honour.',1)};
window.genRespawn=function(){if(!GEN)return;const cp=__PRS.resolveCap(GEN.cid)||GEN.cp,lu=GEN.k&&GEN.k.lord&&!GEN.k.lord.dead?GEN.k.lord:null;if(lu){H.x=lu.x+30;H.y=lu.y+16}else if(cp){H.x=cp.x+30;H.y=cp.y+16}
 H.hp=H.mhp;H.m=0;H.inv=now()+3;GEN.sh=Math.max(GEN.sh,80);GEN.shT=now()+6;$('mnt').textContent='Mount';
 toast('You fell! You rise again beside '+(GEN.k?nm(GEN.k):GEN.P.n));sfx('recruit');
 for(let i=0;i<14;i++)PS.push({x:H.x,y:H.y-10,vx:(Math.random()-.5)*60,vy:-Math.random()*60,l:.7,c:'#ffd24a'})};
function gsk(){let b=$('gsk');if(!b){b=document.createElement('button');b.className='b';b.id='gsk';b.addEventListener('pointerdown',e=>{e.preventDefault();useSk()});document.body.appendChild(b)}b.style.display=GEN&&window.GENM?'block':'none'}
function useSk(){if(!GEN||!window.GENM)return;const t=now();if(t<GEN.sk){sfx('no');toast('Rally ready in '+Math.ceil(GEN.sk-t)+'s');return}
 GEN.sk=t+30;GEN.sh=170;GEN.shT=t+16;GEN.bf=t+14;H.hp=Math.min(H.mhp,H.hp+H.mhp*.35);
 let n=0;if(GEN.k)USK(GEN.k).forEach(u=>{if(Math.hypot(u.x-H.x,u.y-H.y)<300){u.mo=1;u.hp=Math.min(u.mhp,u.hp+u.mhp*.3);u.rb=t+14;u._em='\u2605';u._emt=t+3;n++}});
 for(let i=0;i<28;i++){const a=i/28*6.283;PS.push({x:H.x+Math.cos(a)*10,y:H.y-8+Math.sin(a)*6,vx:Math.cos(a)*70,vy:Math.sin(a)*40-10,l:.8,c:i%2?'#ffd24a':'#8cf'})}
 FX.push({x:H.x,y:H.y-40,t:'RALLY!',l:1.2,c:'#ffd24a'});sfx('horn');
 toast('Rally! Shield raised, you hit 30% harder'+(GEN.k?' ('+n+' allies inspired)':''));say('For the crown! Stand firm!',1)}
const _hu2=hurt;hurt=function(tg,dmg,from){
 if(window.GENM&&GEN&&tg===H){if(now()<(H.inv||0))return;dmg*=.65;
  if(GEN.sh>0){const a=Math.min(GEN.sh,dmg);GEN.sh-=a;dmg-=a;FX.push({x:H.x,y:H.y-34,t:'\u{1F6E1}'+(a|0),l:.6,c:'#8cf'});if(dmg<.5)return}}
 _hu2(tg,dmg,from)};
const _sw=swing;swing=function(){if(!window.GENM||!GEN)return _sw();
 if(H.cd>0)return;H.cd=.4;H.atk=.25;sfx('swing');
 const dm=14*(1+.15*gear+(H.wb||0))*(H.m?1.35:1)*(GEN.bf>now()?1.3:1);
 US.forEach(u=>{if(!u.team||u.dead||u.hp<=0||friendU(u)||u.type=='lord'||u.type=='queen')return;const dx=u.x-H.x,dy=u.y-H.y;if(Math.hypot(dx,dy)<36&&(dx*H.fx+dy*H.fy>-5))hurt(u,dm,H)});
 if(PV.live)MP.peers.forEach(P=>{if(P.out||P.tm===ME.tm)return;P.gu.forEach(g=>{if(g.hp<=0)return;const dx=g.x-H.x,dy=g.y-H.y;if(Math.hypot(dx,dy)<36&&(dx*H.fx+dy*H.fy>-5))hurt(g,dm,H)})});
 hunt(dm);
 if(false)CAPS.forEach(o=>{if(o.hp<=0||o.kg.dfd||isAlly(GEN.k,o.kg))return;if(Math.hypot(o.x-H.x,o.y+4-H.y)<46){o.hp-=dm*.4;sfx('hit',o.x,o.y);FX.push({x:o.x+(Math.random()-.5)*30,y:o.y-20,t:'-'+((dm*.4)|0),l:.6,c:'#fff'});if(o.hp<=0)defeat(o.kg,GEN.k)}})};
const _mn2=mnt;mnt=function(){if(window.GENM){H.m=H.m?0:1;HR.on=0;toast(H.m?'You mount your warhorse':'You dismount');sfx('loot');$('mnt').textContent=H.m?'Dismount':'Mount';return}_mn2()};
const _amb=ambient;ambient=function(dt,cx,cy,b,dn){_amb(dt,cx,cy,b,dn);try{gtick(dt,cx,cy)}catch(e){console.error(e)}};
function gtick(dt,cx,cy){const t=now(),bt=$('gsk');
 if(GEN&&window.GENM){
  if(bt){const r=GEN.sk-t,tx=r>0?'Rally '+Math.ceil(r)+'s':'Rally (skill)';if(bt.textContent!==tx)bt.textContent=tx;bt.style.opacity=r>0?.55:1;if(bt.style.display!=='block')bt.style.display='block'}
  if(t>GEN.shT)GEN.sh=0;
  if(GEN.sh>0){const x=H.x-cx,y=H.y-cy-12,a=.25+.15*Math.sin(t*8);c.save();c.globalAlpha=Math.min(1,GEN.sh/60)*.9;c.strokeStyle='rgba(140,200,255,'+(a+.4)+')';c.lineWidth=1.5;c.beginPath();c.ellipse(x,y,15,19,0,0,6.283);c.stroke();c.fillStyle='rgba(120,180,255,'+a*.45+')';c.fill();c.restore()}
  if(dt>0&&PV.live&&PV.war&&t>GEN.gt){GEN.gt=t+.5;let n=0;ghostTargets().forEach(g=>{if(n>=6||g.hp<=0)return;const isH=g.lx!==undefined,d=isH?{dmg:14,cd:.7,rng:26}:(UT[g.type]||{dmg:8,cd:1,rng:20});if(Math.hypot(g.x-H.x,g.y-H.y)<Math.min(d.rng||20,70)+10){n++;hurt(H,(d.dmg||6)/(d.cd||1)*.5,{nm:g.nm||g.n||'Enemy'})}})}
 }else if(bt&&bt.style.display!=='none')bt.style.display='none';
 if(dt>0&&window.FALLEN&&won&&!PV.live&&!MPI)gfight(dt)}
setInterval(()=>{if(!GEN||!inGame)return;const cp=__PRS.resolveCap(GEN.cid);
 if(!cp){GEN=null;window.GENM=0;if(!PV.live&&eligible().length){toast('Your lord has fallen. You join another lord.');genRand()}else{window.SPEC=0;const b=$('gsk');if(b)b.style.display='none';menu('Your lord has fallen','Choose another lord to serve, or leave.')}return}
 GEN.cp=cp;const d=Math.hypot(cp.x-H.x,cp.y-H.y);{const lu=GEN.k&&GEN.k.lord&&!GEN.k.lord.dead?GEN.k.lord:null,ax=lu?lu.x:cp.x,ay=lu?lu.y:cp.y;if(Math.hypot(ax-H.x,ay-H.y)>2800){H.x=ax+30;H.y=ay+16}}
 if(H.hp<H.mhp&&d<120)H.hp=Math.min(H.mhp,H.hp+.6)},100);
/* solo: lords fight each other once your castle has fallen */
function assault(A,B){const fr=USK(A).filter(u=>!u.gw&&!u.qg&&u.type!='lord'&&u.type!='queen'&&UT[u.type]&&UT[u.type].dmg);if(fr.length<4)return 0;
 const n=Math.min(18,Math.ceil(fr.length*.65)),t=now();fr.slice(0,n).forEach(u=>{u.gw=B;u.gwt=t+110});
 if(A.lord&&!A.lord.dead&&Math.random()<.5){A.lord.gw=B;A.lord.gwt=t+110}return n}
function lordWar(dt){lw-=dt;if(lw>0)return;lw=5;const t=now(),al=KG.filter(k=>!k.owned&&!k.dfd);
 al.forEach(k=>{if(USK(k).length<22&&t>(k._rf||0)){k._rf=t+9;for(let i=0;i<2;i++){const a=Math.random()*6.283;mku(1,['sword','pike','bow','cav'][Math.random()*4|0],k.x+Math.cos(a)*50,k.y-10+Math.sin(a)*34,{kg:k})}}});
 if(al.length<=1){if(al.length==1&&!fin){fin=1;finish(al[0])}return}
 const rdy=al.filter(k=>t>(k._as||0)&&!USK(k).some(u=>u.gw));if(!rdy.length)return;
 const A=(GEN&&GEN.k&&rdy.includes(GEN.k)&&Math.random()<.5)?GEN.k:rdy[Math.floor(Math.random()*rdy.length)];
 const ot=al.filter(k=>k!==A&&!isAlly(A,k));if(!ot.length)return;
 ot.sort((a,b)=>Math.hypot(a.x-A.x,a.y-A.y)-Math.hypot(b.x-A.x,b.y-A.y));const B=ot[Math.floor(Math.random()*Math.min(2,ot.length))];
 const n=assault(A,B);A._as=t+40+Math.random()*35;
 if(n){sfx('horn');feed(nm(A)+' marches on '+nm(B));if(GEN&&(GEN.k===A||GEN.k===B))toast(nm(A)+' marches on '+nm(B)+'!')}}
function gfight(dt){const t=now(),all=US,gk=GEN&&GEN.k;
 for(let i=0;i<all.length;i++){const u=all[i];
  if(!u.team||u.dead||!u.kg||u.hp<=0||u.type=='messenger'||u.type=='ram'||u.type=='treb')continue;
  const d=UT[u.type];if(!d||!d.dmg)continue;
  u.cd-=dt;u.atk-=dt;u.hit-=dt;
  if(t>(u.gn||0)){u.gn=t+.35+Math.random()*.2;let bt=null,bd=u.gw?150:110;
   for(let k=0;k<all.length;k++){const e=all[k];if(e===u||!e.team||e.dead||e.hp<=0||!e.kg||e.type=='messenger'||isAlly(u.kg,e.kg))continue;
    const dx=e.x-u.x,dy=e.y-u.y;if(dx>bd||dx<-bd||dy>bd||dy<-bd)continue;const dd=Math.hypot(dx,dy);
    if(dd<bd){if(!u.gw&&Math.hypot(e.x-u.hx,e.y-u.hy)>210)continue;bd=dd;bt=e}}
   if(!bt&&window.GENM&&H.hp>0&&!isAlly(u.kg,gk)){const dd=Math.hypot(H.x-u.x,H.y-u.y);if(dd<bd&&(u.gw||Math.hypot(H.x-u.hx,H.y-u.hy)<210))bt=H}
   u.gt=bt}
  let tg=u.gt;if(tg&&(tg.dead||tg.hp<=0))tg=u.gt=null;
  let px,py,stop=3;const sp=(d.spd||50)*.9;
  if(tg){px=tg.x;py=tg.y;stop=Math.max(6,d.rng*.8)}
  else if(u.gw){const B=u.gw;if(B.dfd||B.cast.hp<=0||t>u.gwt){u.gw=0;continue}px=B.x;py=B.y+12;stop=Math.min(52,d.rng*.8+30)}
  else{px=u.hx;py=u.hy;stop=8}
  const dx=px-u.x,dy=py-u.y,dist=Math.hypot(dx,dy);
  if(dist>stop){const s=Math.min(sp*dt,dist-stop+.01);u.x+=dx/dist*s;u.y+=dy/dist*s;u.ph+=dt*10;if(Math.abs(dx)>3)u.face=dx>0?1:-1}
  if(u.cd<=0){const dm=d.dmg*(u.rb>t?1.25:1);
   if(tg&&Math.hypot(tg.x-u.x,tg.y-u.y)<=d.rng+4){u.cd=d.cd||1;u.atk=.25;u.face=tg.x>=u.x?1:-1;
    if(d.w=='bow'){const L=Math.hypot(tg.x-u.x,tg.y-u.y)||1;AR.push({x:u.x,y:u.y-10,vx:(tg.x-u.x)/L*230,vy:(tg.y-u.y)/L*230,team:2,vis:1,dmg:0,l:Math.min(.5,L/230),from:null});sfx('arrow',u.x,u.y)}
    hurt(tg,dm,u)}
   else if(!tg&&u.gw&&dist<=stop+8){u.cd=d.cd||1;u.atk=.25;const B=u.gw,h=dm*.4;B.cast.hp-=h;sfx('hit',B.x,B.y);FX.push({x:B.x+(Math.random()-.5)*30,y:B.y-20,t:'-'+(h|0),l:.6,c:'#fff'});if(B.cast.hp<=0&&!B.dfd)defeat(B,u.kg)}}}}
function defeat(B,A){if(B.dfd)return;B.dfd=1;B.owned=1;B.cv=1;USK(B).forEach(u=>u.dead=Znow());US.forEach(u=>{if(u.gw===B)u.gw=0});B.cast.hp=0;
 KW.filter(w=>w.kg===B).forEach(kbrk);{const j=objs.indexOf(B.cast);if(j>=0)objs.splice(j,1)}
 (B.cp||[]).forEach(b=>{const j=objs.indexOf(b.o);if(j>=0)objs.splice(j,1)});objs.push({k:'ruin',img:TX.ruin,x:B.x,y:B.y-30,w:48,h:40,dead:0,done:0});
 lastDef=B;feed(nm(B)+' has fallen to '+(A?nm(A):'a rival'));toast(nm(B)+' has fallen!');sfx('horn');
 const c=eligible();if(c.length){const g=c[Math.floor(Math.random()*c.length)];GENOF['k:'+KG.indexOf(g)]=nm(B);feed(nm(B)+' now serves '+nm(g)+' as general')}
 if(GEN&&GEN.k&&GEN.k===A){toast('+50 EXP: your lord conquers '+nm(B));addExp(50)}}
function finish(W){const mine=GEN&&GEN.k===W;
 if(mine)cut({king:nm(W),rival:lastDef?nm(lastDef):'the usurper',c1:(W.hs&&W.hs.c1)||'#2a5aa8',c2:(W.hs&&W.hs.c2)||'#e8b94a',gain:200});
 else{say(nm(W)+' is crowned king.',1);menu('👑 '+nm(W)+' is king','Every rival has fallen and the crown is taken.')}}
setInterval(()=>{if(!inGame||MPI||PV.live||!window.FALLEN||paused||!won)return;lordWar(.5)},500);
/* PvP: the last surviving player is crowned */
const _po=pOut;pOut=function(P,why){const was=P.out;_po(P,why);if(was)return;lastDef={_nm:P.n,name:P.n,hs:null,pn:P.n};
 setTimeout(()=>{try{if(!PV.live||PC.hp>0||fin)return;const al=[];MP.peers.forEach(Q=>{if(!Q.out)al.push(Q)});if(!al.length||new Set(al.map(Q=>Q.tm)).size>1)return;fin=1;
  const W=al.find(Q=>GEN&&Q.id===GEN.cid)||al[0];
  if(GEN&&GEN.cid===W.id)cut({king:W.n,rival:lastDef.pn||'the last rival',c1:W.c1||'#2a5aa8',c2:W.c2||'#e8b94a',gain:200});else menu('👑 '+W.n+' wins the match','The last crown standing.')}catch(e){console.error(e)}},700)};
/* defeat menu with the General option */
const _o3=over;over=function(){const w=won;_o3();if(w||!won)return;window.FALLEN=1;PC.hp=0;US.forEach(u=>{if(u.team&&u.raid){u.raid=0;u.fm=0}});if(!PV.live)KG.forEach(k=>{if(k.rel<0)k.rel=0});try{menu(PV.live?'⛓ Your castle has fallen':'⛓ Captured!','Your castle is gone, but your sword is not. Watch the war, serve another lord as his general, or start anew.')}catch(e){console.error(e)}};
/* king cutscene */
function cut(o){paused=1;const w=document.createElement('div');w.style.cssText='position:fixed;inset:0;z-index:200;background:#000;display:flex;flex-direction:column;align-items:center;justify-content:center;font:13px monospace;color:#f3e9d2';
 const cv=document.createElement('canvas');cv.width=320;cv.height=180;cv.style.cssText='width:min(96vw,calc(66vh*1.78));image-rendering:pixelated;border:2px solid #e8b94a';
 const cp=document.createElement('div');cp.style.cssText='margin:8px;min-height:44px;text-align:center;max-width:92vw';
 const bt=document.createElement('button');bt.className='b';bt.style.cssText='position:static;min-width:0;padding:6px 14px;display:none';bt.textContent='Continue';
 w.append(cv,cp,bt);document.body.appendChild(w);const g=cv.getContext('2d'),R=(c,x,y,ww,h)=>{g.fillStyle=c;g.fillRect(x|0,y|0,ww,h)};
 const man=(x,y,c,p)=>{p=p||{};const h=p.kn?14:22;R('rgba(0,0,0,.35)',x-6,y-1,12,2);R('#3a2a1a',x-3,y-2,2,2);R('#3a2a1a',x+1,y-2,2,2);R(c,x-4,y-h,8,h-4);R('#f0c9a0',x-3,y-h-6,6,6);
  if(p.cr){R('#e8c040',x-3,y-h-9,6,3);R('#e8c040',x-3,y-h-11,1,2);R('#e8c040',x,y-h-11,1,2);R('#e8c040',x+2,y-h-11,1,2)}
  if(p.sw==1){R('#cfd4dc',x+5,y-h-14,2,18);R('#8a6a2a',x+4,y-h+3,4,2)}else if(p.sw==2){R('#cfd4dc',x+5,y-12,2,12);R('#8a6a2a',x+4,y-13,4,2)}else if(p.sw==3){R('#cfd4dc',x+5,y-h+2,2,12)}};
 const CAP=[[0,'🏰 '+o.king+' stands victorious. Every rival has fallen.'],[3.5,'The last rival lord, '+o.rival+', is brought before the throne.'],[6.5,'The king passes judgement. The usurper is executed.'],[9,'👑 '+o.king+' is crowned King of the Realm!'],[12,'You kneel before your king, sword in hand. +'+o.gain+' EXP']];
 const t0=performance.now();let done=0,raf;sfx('win');say(o.king+' is crowned king of the realm.',1);let hornD=0,hitD=0;
 function fr(){const t=(performance.now()-t0)/1000;
  R('#241a2c',0,0,320,180);R('#46364a',0,118,320,62);R('#5a465e',0,118,320,2);
  for(const cx of[26,294]){R('#6a5a70',cx-6,20,12,98);R('#8a7a90',cx-8,16,16,5)}
  for(const bx of[70,250]){R(o.c1,bx-8,26,16,34);R(o.c2,bx-8,26,16,5);R(o.c2,bx-2,38,4,12)}
  R('#a01828',140,118,40,62);R('#c02838',144,118,32,62);R('#6a5020',212,78,40,44);R('#8a6a2a',216,82,32,36);
  const fl=Math.sin(t*12)*1.5;for(const tx of[110,206]){R('#5a3a1a',tx,52,2,8);R('#f0a020',tx-1,48+fl,4,5);R('#fff0a0',tx,50,2,2)}
  const kcr=t>=9||t<9;man(232,118,o.c1,{cr:1,sw:(t>=6.5&&t<7.6)?1:3});
  man(200,118,'#7a7a8a',{sw:3});man(262,118,'#7a7a8a',{sw:3});
  if(t<7.6){const rx=Math.min(140,-20+t*60);man(rx,118,'#8a2a2a',{kn:t>=3.2});if(t>=3.4)g.font='6px monospace',g.fillStyle='#e8b94a',g.textAlign='center',g.fillText(o.rival.slice(0,22),rx,92)}
  if(t>=7.6&&t<8.6){for(let i=0;i<14;i++)R('rgba(200,190,170,'+(.6-(t-7.6)*.6)+')',136+((i*37)%24)-12+(t-7.6)*(i%5-2)*8,112-(i%4)*5-(t-7.6)*10,2,2)}
  if(t>=6.9&&t<7.4){g.globalAlpha=.8*(1-(t-6.9)/.5);R('#fff',0,0,320,180);g.globalAlpha=1;if(!hitD){hitD=1;sfx('hit')}}
  if(t>=6.5&&!hornD){hornD=1;sfx('horn')}
  if(t>=9&&t<13){for(let i=0;i<30;i++)R(i%3?o.c2:'#fff',(i*53+t*40*(1+i%3))%320,(i*29+t*50)%118,2,2)}
  if(t>=11){const yx=Math.min(176,-20+(t-11)*100);man(yx,118,'#2a5aa8',{kn:t>=13.2,sw:t>=13.2?2:3})}
  let c='';for(const q of CAP)if(t>=q[0])c=q[1];cp.textContent=c;
  if(t>=15&&!done){done=1;cp.textContent='Rank: '+rank()+' · '+addExp(o.gain)+' EXP total (+'+o.gain+')';bt.style.display=''}
  if(!done||t<16)raf=requestAnimationFrame(fr)}
 fr();bt.onclick=()=>{cancelAnimationFrame(raf);w.remove();paused=0;menu('👑 '+o.king+' is King','You served him well, general.')};
 const sk=document.createElement('button');sk.textContent='Skip';sk.style.cssText='position:absolute;top:8px;right:8px';sk.onclick=()=>{if(!done){done=1;cp.textContent='Rank: '+rank()+' · '+addExp(o.gain)+' EXP total (+'+o.gain+')';bt.style.display=''}};w.appendChild(sk)}
window.genCut=cut;
})();
