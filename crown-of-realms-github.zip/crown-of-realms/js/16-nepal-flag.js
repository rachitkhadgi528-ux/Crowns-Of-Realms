/* ===== v15-5-9: waving Nepal flag (splash, intro, main menu) ===== */
(function(){
let FC=null;
function mk(){try{FC=document.createElement('canvas');FC.width=120;FC.height=146;if(typeof nepal==='function')nepal(FC.getContext('2d'),0,0,120,146,{c1:'#dc143c',c2:'#003893'});else FC=null}catch(e){FC=null}}
window.npWave=function(g,x,y,w,t){if(!FC)mk();if(!FC)return;const h=w*1.217,n=Math.max(8,Math.round(w/2));for(let i=0;i<n;i++){const wy=Math.sin(t*3.4+i*.38)*(w*.028)*(i/n+.15);g.drawImage(FC,i/n*120,0,120/n+.5,146,x+i*(w/n),y+wy,w/n+.7,h)}};
const cs=[].slice.call(document.querySelectorAll('canvas.npf'));let last=0;
function paint(t){cs.forEach(c=>{if(!c.offsetParent)return;const g=c.getContext('2d');g.clearRect(0,0,c.width,c.height);g.fillStyle='#8a6a40';g.fillRect(2,0,3,c.height);window.npWave(g,5,2,c.width-8,t)})}
(function L(n){requestAnimationFrame(L);const m=document.getElementById('menu');if(!m||m.style.display=='none'||document.hidden)return;if(n-last<45)return;last=n;paint(n/1000)})(0);
})();
