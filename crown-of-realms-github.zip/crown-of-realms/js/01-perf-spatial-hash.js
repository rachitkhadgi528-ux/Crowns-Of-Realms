/* v24: spatial hash for kingdom walls (army x walls was O(units x walls) every frame) */
(function(){let g=null,n=-1,f=null;const E=[];window.kwN=function(x,y){if(!g||n!==KW.length||f!==KW[0]){g=new Map();KW.forEach(w=>{const k=(w.x>>5)*2000+(w.y>>5);let l=g.get(k);if(!l)g.set(k,l=[]);l.push(w)});n=KW.length;f=KW[0]}
const cx=x>>5,cy=y>>5;let o=E;for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++){const l=g.get((cx+a)*2000+cy+b);if(l){if(o===E)o=[];for(let i=0;i<l.length;i++)o.push(l[i])}}return o}})();
