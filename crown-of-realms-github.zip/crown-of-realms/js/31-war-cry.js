/* ===== WAR CRY: castle-only morale ritual (solo + PvP) ===== */
(function(){
const WC={on:0,ph:'',t0:0,pt:0,n:0,buff:0,until:0,cd:0,lift:0,hop:0,sl:0,lastS:0,lastB:0,lastF:0,lastA:0,skip:0,cried:0};
window.WC=WC;
const $_=id=>document.getElementById(id);
const css=document.createElement('style');
css.textContent=`#wcb{position:fixed;left:max(8px,env(safe-area-inset-left,0px));bottom:calc(52px + env(safe-area-inset-bottom,0px));z-index:6;display:none;padding:7px 9px;font:bold 9px monospace;background:#a8321a;color:#fff;border:2px solid #f3c35a;border-radius:6px;cursor:pointer;box-shadow:0 0 10px #f3a31a88;animation:wcp 1.4s infinite}
#wcb[disabled]{background:#555;border-color:#888;box-shadow:none;animation:none;opacity:.75}
@keyframes wcp{50%{box-shadow:0 0 18px #ffd24acc}}
#wcs{position:fixed;left:50%;top:calc(34px + env(safe-area-inset-top,0px));transform:translateX(-50%);z-index:5;display:none;padding:3px 9px;font:bold 9px monospace;color:#ffe9a8;background:#5a1410cc;border:1px solid #f3c35a;border-radius:10px;pointer-events:none;white-space:nowrap}
#wco{position:fixed;inset:0;z-index:20;display:none;touch-action:none}
.wcbar{position:fixed;left:0;right:0;height:0;background:#000;z-index:21;transition:height .8s ease;pointer-events:none}
#wct{top:0}#wcbm{bottom:0}
#wcc{position:fixed;left:50%;bottom:13%;transform:translateX(-50%);z-index:22;width:min(86vw,640px);text-align:center;font:italic bold clamp(14px,3.2vw,24px) Georgia,serif;color:#ffe9a8;text-shadow:0 2px 0 #000,0 0 12px #c0300a;opacity:0;transition:opacity .35s;pointer-events:none}
#wcf{position:fixed;inset:0;z-index:21;background:#ffd98a;opacity:0;pointer-events:none;transition:opacity .5s}
#wcsk{position:fixed;right:10px;bottom:calc(8px + env(safe-area-inset-bottom,0px));z-index:23;font:8px monospace;color:#fff9;pointer-events:none}`;
document.head.appendChild(css);
const mk=(tag,id,cls,txt)=>{const e=document.createElement(tag);if(id)e.id=id;if(cls)e.className=cls;if(txt)e.textContent=txt;document.body.appendChild(e);return e};
const btn=mk('button','wcb','','📣 War Cry'),badge=mk('div','wcs'),ov=mk('div','wco'),bt=mk('div','wct','wcbar'),bb=mk('div','wcbm','wcbar'),cap=mk('div','wcc'),fl=mk('div','wcf'),sk=mk('div','wcsk','','Tap or Esc to skip');sk.style.display='none';
const stop=e=>{e.stopPropagation();e.preventDefault()};
['pointerdown','mousedown','touchstart','touchmove','touchend','click','contextmenu'].forEach(ev=>ov.addEventListener(ev,e=>{stop(e);if(ev=='pointerdown'||ev=='touchstart')WC.skip=1},{passive:false}));
['keydown','keyup'].forEach(ev=>window.addEventListener(ev,e=>{if(!WC.on)return;if(ev=='keydown'&&(e.key=='Escape'||e.key==' '||e.key=='Enter'))WC.skip=1;e.stopImmediatePropagation();e.preventDefault()},true));

const defeated=()=>{let d=0;try{d+=KG.filter(k=>k.dfd).length}catch(e){}try{d+=[...MP.peers.values()].filter(p=>p.out).length}catch(e){}return d};
const pct=()=>Math.round(WC.buff*100);
const buffOn=()=>WC.buff>0&&now()<WC.until&&!window.GENM;
const mine=u=>u&&(u===H||(u.team===0&&!u.gh));
function calcBuff(){return Math.min(.9,.08+.05*defeated()+.03*Math.max(0,WC.n-1))}
function inCastle(){try{return Math.hypot(H.x-PC.x,H.y-(PC.y+30))<170}catch(e){return false}}
function say_(s){try{if(window.say)say(s,1)}catch(e){}}
function snd(k){try{if(k=='horn'){sfx('horn');tn(110,1.4,'sawtooth',.16,95);tn(165,1.4,'triangle',.14,150)}else if(k=='roar'){ns(.9,.5,'bandpass',500,1100);tn(95,.7,'sawtooth',.14,70);tn(140,.5,'square',.05,100)}else if(k=='clang'){ns(.12,.5,'highpass',2500);tn(900,.15,'triangle',.12,500)}}catch(e){}}

/* ---- damage buff + invulnerable hero while the ritual plays ---- */
const _h=hurt;hurt=function(tg,dmg,from){
 if(WC.on&&tg===H)return;
 if(buffOn()){const b=1+WC.buff;if(from&&mine(from)&&!mine(tg))dmg*=b;else if(mine(tg)&&!(from&&mine(from)))dmg/=(1+WC.buff*.6)}
 return _h(tg,dmg,from)};
const _sw=swing;swing=function(){if(WC.on)return;return _sw.apply(this,arguments)};

/* ---- render hooks ---- */
const _pr=window.PRL;window.PRL=function(L,cx,cy){if(_pr)_pr(L,cx,cy);if(WC.on&&WC.lift>0){for(let i=0;i<L.length;i++){const e=L[i];if(e.k=='hero'){e.y=H.y-WC.lift;e.sy=PC.y+2;break}}}};
const _du=drawU;drawU=function(u,x,y){if(WC.on&&WC.hop&&u._wc)y-=(Math.abs(Math.sin(now()*9+u.ph))*3.5)|0;return _du.call(this,u,x,y)};
const _am=ambient;ambient=function(dt,cx,cy){_am.apply(this,arguments);try{frame(cx,cy)}catch(e){}};
const _hd=hud;hud=function(){_hd.apply(this,arguments);try{ui()}catch(e){}};

/* ---- formation ---- */
function formation(){
 const L=ARM.filter(u=>!u.gd&&u.hp>0&&!u.dead&&Math.hypot(u.x-PC.x,u.y-PC.y)<650).sort((a,b)=>CLS.indexOf(a.type)-CLS.indexOf(b.type)||a.uid-b.uid);
 const n=L.length,cols=Math.max(6,Math.min(34,Math.ceil(Math.sqrt(n*2.6))));
 L.forEach((u,i)=>{if(!u._wc)u._wc=[u.hold,u.hx,u.hy];const r=Math.floor(i/cols),c=i%cols,rowN=Math.min(cols,n-r*cols);u.hold=1;u.hx=PC.x+(c-(rowN-1)/2)*13;u.hy=PC.y+38+r*11})}
function release(){ARM.forEach(u=>{if(u._wc){u.hold=u._wc[0];u.hx=u._wc[1];u.hy=u._wc[2];u._wc=null}});US.forEach(u=>{if(u._wc){u._wc=null}})}

/* ---- sequence ---- */
function caption(s){cap.textContent=s||'';cap.style.opacity=s?1:0}
function start(){
 if(WC.on||now()<WC.cd||window.GENM||!inCastle())return;
 try{if(won||paused&&!PV.live||!inGame)return}catch(e){}
 WC.on=1;window.WCS=1;WC.ph='gather';WC.t0=WC.pt=now();WC.skip=0;WC.lift=0;WC.hop=0;WC.cried=0;
 try{H.m=0;atkHeld=false;jid=null;K.w=K.a=K.s=K.d=0}catch(e){}
 ov.style.display='block';sk.style.display='block';bt.style.height=bb.style.height='11vh';
 caption('📣 The army gathers before the keep…');formation();WC.lastF=now();
}
function recruits(){
 const D=defeated(),want=Math.min(12,2*D);let got=0;if(want<=0)return 0;
 const pool=['pike','sword','bow','cav'].filter(t=>UT[t]);
 const room=Math.max(0,(typeof LIM=='function'?LIM():500)-ARM.length);
 for(let i=0;i<Math.min(want,room);i++){
  const ty=pool[(Math.random()*pool.length)|0],u=mku(0,ty,PC.x+(Math.random()-.5)*30,PC.y+6);
  u.hold=1;u.hx=PC.x+(Math.random()-.5)*300;u.hy=PC.y+38+Math.random()*70;u._wc=[0,u.hx,u.hy];got++;
  for(let k=0;k<4;k++)PS.push({x:u.x,y:u.y-8,vx:(Math.random()-.5)*40,vy:-Math.random()*40,l:.7,c:'#ffd24a'})}
 return got}
function finish(){
 if(!WC.on)return;
 try{if(!WC.cried){applyCry()}}catch(e){}
 try{release()}catch(e){}WC.on=0;window.WCS=0;WC.lift=0;WC.hop=0;WC.ph='';
 try{jx=jy=0}catch(e){}
 ov.style.display='none';sk.style.display='none';bt.style.height=bb.style.height='0';caption('');fl.style.opacity=0;
 WC.cd=now()+75;
}
function applyCry(){
 WC.cried=1;WC.n++;WC.buff=calcBuff();WC.until=now()+110;
 const r=recruits();
 ARM.forEach(u=>{u.hp=Math.min(u.mhp,u.hp+u.mhp*.3)});
 try{toast('📣 War Cry! +'+pct()+'% army power for 110s'+(r?' · +'+r+' soldiers from fallen armies':''))}catch(e){}
}
function frame(cx,cy){
 const t=now();
 if(!WC.on)return;
 const e=t-WC.pt;
 try{K.w=K.a=K.s=K.d=0;atkHeld=false}catch(er){}
 if(WC.skip){finish();return}
 const tx=PC.x,ty=PC.y+10;
 // hero auto-walk (uses the normal movement so the walk animation plays)
 if(WC.ph=='gather'){const dx=tx-H.x,dy=ty-H.y,d=Math.hypot(dx,dy);if(d>5){jx=dx/d;jy=dy/d}else{jx=jy=0;H.x=tx;H.y=ty}}
 else{jx=jy=0;H.x=tx;H.y=ty;H.fx=1;H.fy=0;H.face=1}
 if(t-WC.lastF>.6){formation();WC.lastF=t}
 const roofH=(PC.h||90)+10;
 const hx=H.x,hy=H.y-WC.lift-14;
 if(WC.ph=='gather'){
  if((Math.hypot(tx-H.x,ty-H.y)<6&&e>2.8)||e>8){WC.ph='ascend';WC.pt=t;caption('⚔ The king ascends the keep…')}
 }else if(WC.ph=='ascend'){
  const k=Math.min(1,e/1.5);WC.lift=roofH*(k*k*(3-2*k));
  if(Math.random()<.3)PS.push({x:H.x+(Math.random()-.5)*10,y:PC.y,vx:(Math.random()-.5)*20,vy:-30,l:.6,c:'#cbb'});
  if(e>1.5){WC.ph='cry';WC.pt=t;WC.lastS=0;caption('“WARRIORS OF '+String(KNAME).toUpperCase()+'! TODAY WE RIDE FOR THE CROWN!”');snd('horn');say_('Warriors of '+KNAME+'! Today we ride for the crown! Let none stand before us!');fl.style.opacity=.55;setTimeout(()=>fl.style.opacity=0,120)}
 }else if(WC.ph=='cry'){
  WC.lift=roofH;
  if(t-WC.lastS>.45){WC.lastS=t;H.atk=.25;snd('clang');ringT.push({t,x:hx,y:hy,r:4})}
  for(let i=0;i<3;i++){const a=Math.random()*6.283;PS.push({x:hx+Math.cos(a)*8,y:hy-10+Math.sin(a)*8,vx:Math.cos(a)*55,vy:Math.sin(a)*55-20,l:.7,c:Math.random()<.5?'#ffd24a':'#ff7a3a'})}
  if(e>3.4){WC.ph='reply';WC.pt=t;WC.hop=1;WC.lastB=0;WC.lastA=0;caption('🗡 “READY TO DIE!  READY TO KILL!”');snd('roar');applyCry();fl.style.opacity=.4;setTimeout(()=>fl.style.opacity=0,150);formation()}
 }else if(WC.ph=='reply'){
  WC.lift=roofH;
  if(t-WC.lastA>.55){WC.lastA=t;ARM.forEach(u=>{if(u._wc)u.atk=.25});H.atk=.25;snd('clang');if(Math.random()<.5)snd('roar')}
  if(t-WC.lastB>.4){WC.lastB=t;const L=ARM.filter(u=>u._wc);const say=['Ready to die!','Ready to kill!','For the crown!','Aye, my liege!','Victory or death!'];
   for(let i=0;i<3&&L.length;i++){const u=L[(Math.random()*L.length)|0];u.bub=say[(Math.random()*say.length)|0];u.bt=2.2;u._em='!';u._emt=t+1.5}
   for(let i=0;i<6&&L.length;i++){const u=L[(Math.random()*L.length)|0];FX.push({x:u.x,y:u.y-26,t:say[(Math.random()*2)|0].toUpperCase(),l:1,c:'#ffe08a'})}}
  for(let i=0;i<4;i++){const L=ARM;if(!L.length)break;const u=L[(Math.random()*L.length)|0];if(u._wc)PS.push({x:u.x,y:u.y-14,vx:(Math.random()-.5)*20,vy:-35-Math.random()*20,l:.9,c:'#ffd24a'})}
  if(t-(WC.lastR||0)>.9){WC.lastR=t;ringT.push({t,x:hx,y:hy,r:4,big:1})}
  if(e>3.6){WC.ph='outro';WC.pt=t;caption('🔥 +'+pct()+'% army power!');WC.hop=0}
 }else if(WC.ph=='outro'){
  const k=Math.min(1,e/.9);WC.lift=roofH*(1-k*k*(3-2*k));
  bt.style.height=bb.style.height='0';
  if(e>.9){finish();return}
 }
}
/* shockwave rings drawn over the world */
const ringT=[];
const _frame=frame;
function drawRings(cx,cy){
 for(let i=ringT.length-1;i>=0;i--){const r=ringT[i],a=1-(now()-r.t)/(r.big?1.2:.9);if(a<=0){ringT.splice(i,1);continue}
  const R=(r.big?30:14)+(1-a)*(r.big?360:150);c.globalAlpha=a*.7;c.strokeStyle=r.big?'#ffd24a':'#ff8a3a';c.lineWidth=r.big?3:2;c.beginPath();c.ellipse(r.x-cx,r.y-cy,R,R*.45,0,0,6.283);c.stroke()}
 c.globalAlpha=1}
const _am2=ambient;ambient=function(dt,cx,cy){_am2.apply(this,arguments);try{if(WC.on)drawRings(cx,cy)}catch(e){}};

/* ---- button + badge ---- */
function ui(){
 const t=now(),show=!!(window.inGame!==false&&typeof inGame!='undefined'&&inGame&&!window.GENM&&!WC.on&&inCastle()&&!(typeof won!='undefined'&&won));
 btn.style.display=show?'block':'none';
 if(show){const cd=WC.cd-t;btn.disabled=cd>0;const s=cd>0?'📣 '+Math.ceil(cd)+'s':'📣 War Cry'+(WC.n?' ×'+(WC.n+1):'');if(btn.textContent!==s)btn.textContent=s}
 const on=buffOn();badge.style.display=on&&!WC.on?'block':'none';
 if(on){const s=Math.ceil(WC.until-t),tx='🔥 War Cry +'+pct()+'%  '+(s/60|0)+':'+String(s%60).padStart(2,'0');if(badge.textContent!==tx)badge.textContent=tx}
}
btn.addEventListener('click',e=>{e.stopPropagation();start()});
['pointerdown','touchstart','mousedown'].forEach(ev=>btn.addEventListener(ev,e=>e.stopPropagation(),{passive:true}));
setInterval(()=>{try{ui()}catch(e){}
 /* watchdog: never let the ritual lock the screen (hero dead, game ended, menu opened, or the sequence stalled) */
 if(WC.on){let bad=false;try{bad=PC.hp<=0||won||!inGame||now()-WC.t0>30||H.hp<=0}catch(e){}if(bad){WC.skip=0;WC.cried=1;finish()}}
},250);
document.addEventListener('visibilitychange',()=>{if(document.hidden&&WC.on){try{finish()}catch(e){}}});
})();
