/* ===== v15-5: victory cutscene, scoreboard, perf guard ===== */
(()=>{'use strict';
const $=id=>document.getElementById(id),G=f=>{try{return f()}catch(e){}},cl=(v,a,b)=>v<a?a:v>b?b:v;
let busy=0;
function prof(){const o=G(()=>JSON.parse(localStorage.getItem('cor_prof')))||{};let lf={};(function s(x,d){if(!x||typeof x!='object'||d>3)return;if('swins'in x||'pwins'in x||'kills'in x)lf=x;else for(const k in x)s(x[k],d+1)})(o,0);return{name:String(o.name||G(()=>RULER)||'Lord').slice(0,14),xp:o.xp|0,lf}}
function foes(){const a=[];if(G(()=>PV.live))G(()=>MP.peers.forEach(p=>a.push({n:String(p.n||'Rival'),c:p.c1||'#c0392b',lv:p.lv,ti:p.ti,o:p.out})));else G(()=>KG.forEach(k=>a.push({n:String(k.name),c:k.c1||'#c0392b',o:k.owned})));return a}
function cut(done){
 const W=560,H=266,hi0=((G(()=>HI)|0)%4+4)%4,HH=G(()=>HS[hi0])||HS[0],me=prof(),KN=String(G(()=>KNAME)||'').replace(/[<>&]/g,'').slice(0,24);
 const PC1=HH.c1,PC2=HH.c2,FO=foes().slice(0,4);
 const wrap=document.createElement('div'),cv=document.createElement('canvas'),g=cv.getContext('2d'),sk=document.createElement('button');
 let SC=((devicePixelRatio||1)>1.5&&Math.min(innerWidth,innerHeight)>600)?2:1;wrap.style.cssText='position:fixed;inset:0;z-index:99999;background:#000;transition:opacity .8s';cv.width=W*SC;cv.height=H*SC;cv.style.cssText='position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#000';
 sk.textContent='Skip ▸';sk.style.cssText='position:absolute;right:10px;top:calc(8px + env(safe-area-inset-top,0px));z-index:2;font:15px Georgia,serif;padding:6px 12px;background:#c04e22;border:3px solid #24100a;color:#f6e2b8';
 wrap.append(cv,sk);document.body.append(wrap);
 const clamp=cl,ease=q=>q*q*(3-2*q),lerp=(a,b,q)=>a+(b-a)*q;let flashA=0,fin=0,raf=0,cur=-1,T0=performance.now(),lastF=0;const fired={};let parts=[];
 const sp=document.createElement('canvas');sp.width=sp.height=64;const sg=sp.getContext('2d');
/* ---------- sound ---------- */
let ia=null,mg=null,nb=null;
const mut=()=>{try{return !!muted}catch(e){return false}};
function ainit(){if(ia)return;try{ia=new(window.AudioContext||window.webkitAudioContext)();mg=ia.createGain();mg.gain.value=.55;mg.connect(ia.destination);const L=ia.sampleRate*2;nb=ia.createBuffer(1,L,ia.sampleRate);const d=nb.getChannelData(0);for(let i=0;i<L;i++)d[i]=Math.random()*2-1}catch(e){ia=null}}
const ok=()=>ia&&mg&&!mut();
function drum(v,f0){if(!ok())return;const n=ia.currentTime,o=ia.createOscillator(),q=ia.createGain();o.type='sine';o.frequency.setValueAtTime(f0||120,n);o.frequency.exponentialRampToValueAtTime(40,n+.3);q.gain.setValueAtTime(v||.6,n);q.gain.exponentialRampToValueAtTime(.001,n+.5);o.connect(q);q.connect(mg);o.start(n);o.stop(n+.55)}
function nz(dur,fq,Q,v,type,at){if(!ok())return;const n=ia.currentTime,s=ia.createBufferSource();s.buffer=nb;s.loop=true;const f=ia.createBiquadFilter();f.type=type||'bandpass';f.frequency.value=fq;f.Q.value=Q||1;const q=ia.createGain();q.gain.setValueAtTime(.0001,n);q.gain.linearRampToValueAtTime(v,n+(at||.005));q.gain.exponentialRampToValueAtTime(.0001,n+dur);s.connect(f);f.connect(q);q.connect(mg);s.start(n);s.stop(n+dur+.05)}
function tone(fq,dur,v,type,at,det){if(!ok())return;const n=ia.currentTime;[0,det||4].forEach(dt=>{const o=ia.createOscillator(),f=ia.createBiquadFilter(),q=ia.createGain();o.type=type||'sawtooth';o.frequency.value=fq;o.detune.value=dt;f.type='lowpass';f.frequency.value=fq*5;q.gain.setValueAtTime(.0001,n);q.gain.linearRampToValueAtTime(v,n+(at||.5));q.gain.setValueAtTime(v,n+dur*.6);q.gain.exponentialRampToValueAtTime(.0001,n+dur);o.connect(f);f.connect(q);q.connect(mg);o.start(n);o.stop(n+dur+.05)})}
const horn=(fq,dur)=>tone(fq,dur||2.2,.07,'sawtooth',.5,6);
const clash=v=>{nz(.12,2600+Math.random()*1800,1.4,v||.1);tone(900+Math.random()*700,.1,.02,'square',.004,0)};
const pad=()=>[55,82.4,110].forEach(f=>tone(f,6.5,.05,'triangle',2.4,3));
const chime=()=>[880,1318.5,1760].forEach((f,i)=>setTimeout(()=>tone(f,1.8,.05,'sine',.02,2),i*120));
function narr(t){try{if(window.speechSynthesis&&typeof say==='function')say(t,1)}catch(e){}}
/* ---------- drawing helpers ---------- */
function cam(z,px,py){g.translate(W/2+px,H/2+py);g.scale(z,z);g.translate(-W/2,-H/2)}
function sky(a,b,h){const gr=g.createLinearGradient(0,0,0,h||H*.75);gr.addColorStop(0,a);gr.addColorStop(1,b);g.fillStyle=gr;g.fillRect(-20,-20,W+40,H+40)}
function stars(t,n,al){for(let i=0;i<n;i++){g.fillStyle='rgba(255,255,230,'+(al*(.35+.65*Math.abs(Math.sin(t*1.5+i))))+')';g.fillRect(Math.floor(hs(i,1)*W),Math.floor(hs(i,2)*H*.55),hs(i,3)>.9?2:1,1)}}
function ridge(col,base,amp,seed,off,step){g.fillStyle=col;g.beginPath();g.moveTo(-20,H+20);const o=((off%step)+step)%step,k0=Math.floor(off/step);for(let i=-1;i*step-o<=W+step;i++){g.lineTo(i*step-o,base-amp*(.3+.7*hs(k0+i,seed)))}g.lineTo(W+step+20,H+20);g.closePath();g.fill()}
function fog(t,y,col,sp){for(let i=0;i<3;i++){const gx=((t*sp*(8+i*5)+i*190)%(W+240))-120,gr=g.createRadialGradient(gx,y+i*7,2,gx,y+i*7,95);gr.addColorStop(0,col);gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(gx-100,y-45,200,110)}}
function flame(x,y,t,k){k=k||1;const f=Math.sin(t*17+x)*1.2,gr=g.createRadialGradient(x,y,1,x,y,46*k+f*3);gr.addColorStop(0,'rgba(255,176,74,.8)');gr.addColorStop(1,'rgba(255,106,26,0)');g.fillStyle=gr;g.fillRect(x-50*k,y-50*k,100*k,100*k);g.fillStyle='#e8501a';g.beginPath();g.moveTo(x-4,y);g.quadraticCurveTo(x-5,y-8,x+f,y-15-f);g.quadraticCurveTo(x+5,y-8,x+4,y);g.fill();g.fillStyle='#ffd070';g.beginPath();g.moveTo(x-2,y);g.quadraticCurveTo(x-2,y-5,x+f*.5,y-9);g.quadraticCurveTo(x+2,y-5,x+2,y);g.fill();g.fillStyle='#3a2410';g.fillRect(x-1,y,2,12)}
function banner(x,y,c1,c2,t,s){s=s||1;g.fillStyle='#d8b060';g.fillRect(x-2*s,y-4*s,30*s,3*s);for(let i=0;i<26;i++){const wy=Math.sin(t*3+i*.45)*1.6*(i/26),bl=(50-(13-Math.abs(i-13))*.9)*s;g.fillStyle=c1;g.fillRect(x+i*s,y+wy,Math.ceil(s),bl);g.fillStyle=c2;g.fillRect(x+i*s,y+wy+bl*.35,Math.ceil(s),5*s)}}
function castle(x,y,s,col,t){const R=(a,b,w,h)=>g.fillRect(Math.round(x+a*s),Math.round(y+b*s),Math.ceil(w*s),Math.ceil(h*s));g.fillStyle=col;R(-40,-30,80,30);R(-50,-54,18,54);R(32,-54,18,54);R(-9,-74,18,74);
 for(let i=-40;i<40;i+=8)R(i,-34,4,4);[[-50,-54,18],[32,-54,18],[-9,-74,18]].forEach(a=>{for(let i=0;i<a[2];i+=6)R(a[0]+i,a[1]-4,3,4)});
 g.beginPath();g.moveTo(x-12*s,y-78*s);g.lineTo(x,y-100*s);g.lineTo(x+12*s,y-78*s);g.fill();
 const fl=.6+.4*Math.sin(t*9+1);g.fillStyle='rgba(255,196,96,'+fl+')';R(-3,-62,6,9);R(-44,-42,5,8);R(38,-42,5,8);R(-24,-20,5,7);R(18,-20,5,7)}
function throne(x,y,s,glow,t){if(glow){const gr=g.createRadialGradient(x,y-26*s,2,x,y-26*s,75*s);gr.addColorStop(0,'rgba(255,214,110,'+glow+')');gr.addColorStop(1,'rgba(255,170,60,0)');g.fillStyle=gr;g.fillRect(x-80*s,y-105*s,160*s,135*s)}
 const R=(c,a,b,w,h)=>{g.fillStyle=c;g.fillRect(Math.round(x+a*s),Math.round(y+b*s),Math.ceil(w*s),Math.ceil(h*s))};
 R('#2a1a0e',-26,-3,52,4);R('#3a2410',-22,-7,44,4);R('#5a3a1a',-18,-11,36,4);
 R('#2a1408',-11,-48,22,38);R('#7a1a1a',-8,-45,16,32);R('#d4af37',-12,-52,24,4);R('#d4af37',-12,-52,3,42);R('#d4af37',9,-52,3,42);
 R('#f0d070',-13,-57,5,5);R('#f0d070',8,-57,5,5);R('#f0d070',-2,-60,4,8);
 R('#4a2a10',-15,-26,30,5);R('#8a1c1c',-10,-30,20,5);R('#d4af37',-15,-26,4,16);R('#d4af37',11,-26,4,16)}
function crown(x,y,s,t){const gr=g.createRadialGradient(x,y,2,x,y,34*s);gr.addColorStop(0,'rgba(255,230,140,.75)');gr.addColorStop(1,'rgba(255,190,60,0)');g.fillStyle=gr;g.fillRect(x-36*s,y-36*s,72*s,72*s);
 const R=(c,a,b,w,h)=>{g.fillStyle=c;g.fillRect(Math.round(x+a*s),Math.round(y+b*s),Math.ceil(w*s),Math.ceil(h*s))};
 R('#b8901c',-8,0,16,5);R('#e8c040',-8,0,16,3);[-8,-4,0,4,7].forEach((a,i)=>{R('#f0d070',a,-(i==2?7:4),i==4?1:3,i==2?7:4)});R('#d01830',-1,1,2,2);R('#3a7ad0',-6,1,1.5,1.5);R('#30b060',4.5,1,1.5,1.5)}

 const FOL=[[['crus','sword',0],['crus','sword',0],['hcav','spear',0]],[['saru','sword','katana'],['xbow','bow'],['saru','sword','katana']],[['legi','sword','gladius'],['jave','spear'],['legi','sword','gladius']],[['tarc','bow',0],['tlan','spear'],['tarc','bow',0]]];
 const heroU=(hi,c1,c2,horse)=>({st:ZHERO[hi]||ZHERO[0],wep:'sword',wv:ZHW[hi],jp:hi==1,horse:!!horse,coat:hi==0?'#e2e2e8':'#8a5a2a',col:c1,acc:c2,sd:hi*5+2,sc:1.12,hs:1.05});
 const unitU=(hi,k)=>{const f=FOL[hi][k%FOL[hi].length],ty=f[0],h=HS[hi]||HS[0];return{st:ZMS[ty]||ZMS.sword,wep:f[1],wv:f[2]||null,jp:f[2]=='katana',horse:false,coat:'#6a4326',col:h.c1,acc:h.c2,sd:k*3+hi}};
 const SPC=new Map();let uid=0;
 function spr(x,y,bs,u,t,o){const mv=o.mv?1:0,ph=o.ph||0,f=o.f;if(!u.__id)u.__id=++uid;
  const pq=Math.round(((ph%6.2832+6.2832)%6.2832)/6.2832*10)%10,aq=o.atk===undefined||o.atk<0?-1:Math.round(o.atk*8),tq=Math.floor(t*8)%32,key=u.__id+'|'+f+'|'+mv+'|'+(mv?pq:0)+'|'+aq+'|'+(o.fl|0)+'|'+(o.tint||'')+'|'+tq;
  let img=SPC.get(key);
  if(!img){img=document.createElement('canvas');img.width=img.height=64;const sx=img.getContext('2d'),prev=Z;Z=sx;
  try{if(u.horse)Zhorse(32,54,f,ph,0,mv,u.coat||'#6a4326',u.col);
   Zman({x:32-(u.horse?f:0),y:54,f:f,sc:u.sc||1,t:tq/8,sd:u.sd|0,mv:mv,ph:ph,fl:o.fl||0,col:u.col,acc:u.acc,st:u.st,up:0,atk:o.atk===undefined?-1:o.atk,wep:u.wep,wv:u.wv,jp:!!u.jp,ride:u.horse?12:0,hb:u.horse&&mv?-Math.round(Math.abs(Math.sin(ph))*1.4):0,cape:u.acc,wp:-1,hs:u.hs||1})}finally{Z=prev}
  if(o.tint){sx.globalCompositeOperation='source-atop';sx.fillStyle=o.tint;sx.fillRect(0,0,64,64);sx.globalCompositeOperation='source-over'}
  if(SPC.size>900){let n=0;for(const k of SPC.keys()){SPC.delete(k);if(++n>=300)break}}SPC.set(key,img)}
  g.fillStyle='rgba(0,0,0,.4)';g.beginPath();g.ellipse(x,y,(u.horse?15:7)*bs,2.2*bs,0,0,6.3);g.fill();
  g.imageSmoothingEnabled=false;g.drawImage(img,0,0,64,64,Math.round(x-32*bs),Math.round(y-54*bs),64*bs,64*bs)}
 const HERO=heroU(hi0,PC1,PC2,0),HEROH=heroU(hi0,PC1,PC2,hi0==0||hi0==3);
 const FH=FO.map((f,i)=>{const h=(hi0+1+i)%4;return heroU(h,f.c||HS[h].c1,HS[h].c2,0)});
 const ARMY=[];for(let i=0;i<10;i++)ARMY.push(unitU(hi0,i));
 function fw(x,y){const col=['#ffd24a','#ff6a4a','#6ad0ff','#fff','#b46aff'][Math.random()*5|0];for(let i=0;i<26;i++){const a=i/26*6.283,v=45+Math.random()*30;parts.push({x:x,y:y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:1.2,c:col})}try{nz(.5,900,.8,.08,'bandpass',.01)}catch(e){}}
 function drawParts(dt){parts=parts.filter(p=>(p.l-=dt)>0);parts.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=70*dt;g.globalAlpha=clamp(p.l,0,1);g.fillStyle=p.c;g.fillRect(p.x,p.y,2,2)});g.globalAlpha=1}
 let fwT=0;function fwAuto(lt,from,to){if(lt>from&&lt<to&&lt>fwT){fwT=lt+.5+Math.random()*.4;fw(120+Math.random()*320,30+Math.random()*70)}}
 function txt(s,x,y,sz,col,a){g.globalAlpha=clamp(a,0,1);g.textAlign='center';g.fillStyle='#000';g.font=(sz>20?'bold ':'')+sz+'px Georgia,serif';g.fillText(s,x+1,y+1);g.fillStyle=col;g.fillText(s,x,y);g.globalAlpha=1}
 /* scene A: dawn after the last battle */
 function sA(lt){cam(1+.03*lt/7,-lt*1.5,0);sky('#1c1030','#f08a50',H*.75);
  let gr=g.createRadialGradient(400,150-lt*3,4,400,150-lt*3,110);gr.addColorStop(0,'rgba(255,230,160,.9)');gr.addColorStop(1,'rgba(255,170,80,0)');g.fillStyle=gr;g.fillRect(250,0,300,266);g.fillStyle='#ffe2a0';g.beginPath();g.arc(400,150-lt*3,24,0,6.3);g.fill();
  ridge('#4a2a40',166,50,3,lt*2,26);ridge('#2a1624',180,30,6,lt*3,18);g.fillStyle='#3a2a20';g.fillRect(-20,182,W+40,H);gr=g.createLinearGradient(0,182,0,H);gr.addColorStop(0,'#4a3626');gr.addColorStop(1,'#1c1210');g.fillStyle=gr;g.fillRect(-20,182,W+40,H);
  for(let k=0;k<4;k++){const sx=[60,170,430,520][k],yy=170-((lt*8+k*30)%90);g.fillStyle='rgba(30,22,26,'+(.35-(170-yy)/300)+')';g.beginPath();g.ellipse(sx+Math.sin(lt+k)*6,yy,10+(170-yy)/6,14,0,0,6.3);g.fill()}
  FO.forEach((f,i)=>{g.save();g.translate(30+i*130,196);g.rotate(-.9);banner(0,0,f.c||'#c0392b','#222',lt+i,.7);g.restore()});
  const hx=lerp(-50,110,ease(clamp(lt/4.8,0,1))),walk=lt<4.8;
  FH.forEach((u,i)=>spr(210+i*58,216+(i%2)*8,3.5,u,lt+i,{f:-1,mv:0,atk:-1,tint:'rgba(0,0,0,.3)'}));
  ARMY.slice(0,6).forEach((u,i)=>spr(hx-44-i*34,232+(i%2)*10,3.2,u,lt+i,{f:1,mv:walk,ph:lt*8+i*1.3,atk:-1}));
  spr(hx,236,4.6,HEROH,lt,{f:1,mv:walk,ph:lt*(HEROH.horse?11:8)});fog(lt,214,'rgba(70,40,30,.28)',2)}
 /* hall (shared by B and C) */
 function hall(lt,cr){g.fillStyle='#120c07';g.fillRect(-20,-20,W+40,H+40);
  for(let r=0;r<14;r++)for(let c=0;c<25;c++){const bx=c*24+(r&1?12:0)-12,by=r*20;g.strokeStyle='rgba(0,0,0,.45)';g.strokeRect(bx,by,24,20);if(hs(r,c)>.75){g.fillStyle='rgba(255,255,255,.04)';g.fillRect(bx+1,by+1,22,18)}}
  for(const px of[60,474]){const pg=g.createLinearGradient(px,0,px+26,0);pg.addColorStop(0,'#3a2a18');pg.addColorStop(.5,'#9a7a48');pg.addColorStop(1,'#3a2a18');g.fillStyle=pg;g.fillRect(px,0,26,H);g.fillStyle='#b8985c';g.fillRect(px-4,34,34,8);g.fillRect(px-4,200,34,8)}
  g.fillStyle='#1c1612';g.fillRect(-20,208,W+40,80);g.fillStyle='#8a1c1c';g.beginPath();g.moveTo(262,208);g.lineTo(298,208);g.lineTo(430,H+20);g.lineTo(130,H+20);g.fill();g.strokeStyle='#d9a84a';g.lineWidth=2;g.beginPath();g.moveTo(262,208);g.lineTo(130,H+20);g.moveTo(298,208);g.lineTo(430,H+20);g.stroke();g.lineWidth=1;
  banner(130,22,PC1,PC2,lt,1.1);banner(184,22,PC1,PC2,lt+1,1.1);banner(346,22,PC1,PC2,lt+2,1.1);banner(400,22,PC1,PC2,lt+3,1.1);
  throne(280,208,2.5,.55+.12*Math.sin(lt*3),lt);if(cr)cr();
  flame(96,110,lt);flame(504,110,lt);flame(224,150,lt,.7);flame(336,150,lt,.7);
  for(let i=0;i<30;i++){const px=(hs(i,5)*W+lt*(4+hs(i,6)*6))%W,py=(hs(i,8)*H-lt*(3+hs(i,9)*4)+H*4)%H;g.fillStyle='rgba(255,220,150,'+(.15+.15*Math.sin(lt*2+i))+')';g.fillRect(px,py,1.4,1.4)}}
 function lines(lt,cheer){const L=[];for(let r=0;r<4;r++)for(let s=0;s<2;s++){const y=222+r*17,k=(y-208)*1.69,x=s?298+k+30:262-k-30;L.push({y,x,s,r,bs:2.4+(y-208)/42})}
  L.sort((a,b)=>a.y-b.y).forEach((q,i)=>{const u=ARMY[(q.r*2+q.s)%ARMY.length];spr(q.x,q.y,q.bs,u,lt+i*.3,{f:q.s?-1:1,mv:0,atk:cheer?((lt*1.6+i*.31)%1)*.7:-1})})}
 function sB(lt){cam(1.02+.05*lt/7,0,-lt*1.5);const cy=48+Math.sin(lt*2)*3;hall(lt,()=>crown(280,cy,2.2,lt));lines(lt,0);
  const q=ease(clamp(lt/5.4,0,1)),y=lerp(272,224,q),bs=lerp(4.8,3.3,q);spr(280,y,bs,HERO,lt,{f:1,mv:q<1,ph:lt*8})}
 function sC(lt){cam(1.04-.03*lt/7,0,0);const hy=224,hb=3.3,q=ease(clamp((lt-1.2)/2.2,0,1)),cy=lerp(48,hy-21*hb,q);
  hall(lt,()=>{if(q<1)crown(280,cy,2.2-q*.8,lt)});lines(lt,lt>3.4);spr(280,hy,hb,HERO,lt,{f:1,mv:0,atk:lt>3.4?((lt*1.4)%1)*.5:-1});
  if(q>=1)crown(280,hy-21*hb,1.3,lt);const dt=Math.min(.05,Math.max(0,lt-lastF));lastF=lt;fwAuto(lt,3.6,7);drawParts(dt)}
 /* scene D: title */
 function sD(lt){cam(1+.04*lt/8,0,0);sky('#0e0618','#4a1a24',H*.85);stars(lt,60,.8);
  g.save();g.translate(280,130);g.rotate(lt*.15);for(let i=0;i<12;i++){g.rotate(Math.PI/6);g.fillStyle='rgba(255,214,120,.07)';g.beginPath();g.moveTo(0,0);g.lineTo(-20,-420);g.lineTo(20,-420);g.fill()}g.restore();
  ridge('#2a0e1a',196,46,4,lt*2,26);ridge('#160812',214,28,8,lt*3,18);g.fillStyle='#160812';g.fillRect(-20,214,W+40,60);
  [86,140,394,448].forEach((x,i)=>banner(x,64,PC1,PC2,lt+i,1.1));
  throne(280,206,2.2,.9+.1*Math.sin(lt*4),lt);flame(214,150,lt,.8);flame(346,150,lt,.8);
  for(let i=0;i<8;i++){const x=i<4?100+i*30:350+(i-4)*30;spr(x,238,3,ARMY[i],lt+i*.2,{f:i<4?1:-1,mv:0,atk:((lt*1.5+i*.27)%1)*.7})}
  spr(280,236,4.2,HERO,lt,{f:1,mv:0});crown(280,236-21*4.2,1.5,lt);
  const dt=Math.min(.05,Math.max(0,lt-lastF));lastF=lt;fwAuto(lt,.4,5);drawParts(dt);
  g.setTransform(SC,0,0,SC,0,0);
  txt('SOLE RULER OF THE REALMS',280,40,26,'#ffd24a',(lt-.6)/.8*clamp((5-lt)/.6,0,1));txt(me.name+(KN?' of '+KN:''),280,64,15,'#fff',(lt-1.4)/.8*clamp((5-lt)/.6,0,1));
  if(lt>5){g.fillStyle='rgba(0,0,0,'+clamp((lt-5)/.8,0,.82)+')';g.fillRect(0,0,W,H)}
  txt('CROWN OF REALMS',280,126,34,'#ffd24a',(lt-5.6)/.8);txt('PIXEL ASCENDANCE',280,150,16,'#fff',(lt-6.2)/.8);txt('A Rachit Production',280,236,13,'#c9b88a',(lt-6.8)/.8)}
 function sub2(s,lt,d){const a=clamp(lt/.6,0,1)*clamp((d-lt)/.6,0,1);g.setTransform(SC,0,0,SC,0,0);txt(s,280,H*.9,14,'#f3e1b0',a)}
 const SCN=[
 {d:7,fi:.9,fo:.6,dr:lt=>{sA(lt);sub2('The last rival has fallen.',lt,6.4)},ev:[[0,()=>{narr('The last rival has fallen.');pad();horn(98,2.6)}],[4.8,()=>drum(.7,90)]]},
 {d:7,fi:.5,fo:.6,dr:lt=>{sB(lt);sub2('The Crown of Realms awaits.',lt,6.4)},ev:[[.3,()=>{narr('The Crown of Realms awaits its king.');drum(.8,100)}],[2.2,()=>drum(.6,90)],[4.2,()=>drum(.6,90)]]},
 {d:7,fi:.4,fo:.5,dr:lt=>{sC(lt);sub2('Long may you reign.',lt,6.4)},ev:[[1.2,()=>{narr('Kneel before your king.')}],[3.4,()=>{flashA=.8;chime();horn(110,2.6);drum(1,140);narr('Long may you reign, my liege.')}]]},
 {d:8.5,fi:.3,fo:.9,dr:sD,ev:[[0,()=>{pad();horn(82,3)}],[.6,()=>chime()],[5.6,()=>{[110,165,220].forEach(f=>tone(f,3,.05,'triangle',1,3))}]]}];
 const TOTAL=SCN.reduce((a,s)=>a+s.d,0);
 function finish(){if(fin)return;fin=1;cancelAnimationFrame(raf);try{window.speechSynthesis&&speechSynthesis.cancel()}catch(e){}try{mg&&mg.gain.setTargetAtTime(0,ia.currentTime,.12)}catch(e){}wrap.style.opacity=0;setTimeout(()=>{wrap.remove();try{ia&&ia.close()}catch(e){}done()},700)}
 function frame(){if(fin)return;raf=requestAnimationFrame(frame);try{
  gov();const t=(performance.now()-T0)/1000;if(t>=TOTAL){finish();return}
  let i=0,ac=0;while(i<SCN.length-1&&t>=ac+SCN[i].d){ac+=SCN[i].d;i++}const S=SCN[i],lt=t-ac;
  if(i!==cur){cur=i;lastF=0;fwT=0;parts=[]}
  S.ev.forEach((e,j)=>{const key=i+':'+j;if(!fired[key]&&lt>=e[0]){fired[key]=1;try{e[1]()}catch(x){}}});
  g.setTransform(SC,0,0,SC,0,0);g.fillStyle='#000';g.fillRect(0,0,W,H);g.save();S.dr(lt);g.restore();g.setTransform(SC,0,0,SC,0,0);
  g.fillStyle='#000';g.fillRect(0,0,W,H*.07);g.fillRect(0,H*.93,W,H*.07);
  let a=0;if(lt<S.fi)a=1-lt/S.fi;if(lt>S.d-S.fo)a=Math.max(a,(lt-(S.d-S.fo))/S.fo);if(a>0){g.fillStyle='rgba(0,0,0,'+clamp(a,0,1)+')';g.fillRect(0,0,W,H)}
  if(flashA>0){g.fillStyle='rgba(255,246,220,'+flashA+')';g.fillRect(0,0,W,H);flashA=Math.max(0,flashA-.035)}
  g.setTransform(1,0,0,1,0,0);g.drawImage(vg,0,0)}catch(e){finish();setTimeout(()=>{throw e})}}
 let vg=null;function mkvg(){vg=document.createElement('canvas');vg.width=W*SC;vg.height=H*SC;const v=vg.getContext('2d'),gr=v.createRadialGradient(W*SC/2,H*SC/2,H*SC*.3,W*SC/2,H*SC/2,W*SC*.62);gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(1,'rgba(0,0,0,.6)');v.fillStyle=gr;v.fillRect(0,0,W*SC,H*SC)}
 let gF=0,gT=performance.now(),gS=0;function gov(){gF++;const n=performance.now();if(n-gT>=1000){const fps=gF*1000/(n-gT);gF=0;gT=n;if(fps<40&&SC>.7&&gS<3){gS++;SC=SC>1?1:SC*.75;cv.width=Math.round(W*SC);cv.height=Math.round(H*SC);mkvg()}}}
 mkvg();sk.onclick=finish;try{ainit();ia&&ia.state=='suspended'&&ia.resume()}catch(e){}raf=requestAnimationFrame(()=>{T0=performance.now();frame()})}
const frs=()=>((G(()=>JSON.parse(localStorage.getItem('cor_prof')))||{}).friends||[]).map(f=>({n:String(f.n||'Friend'),lv:f.lv,o:1}));
function board(btns,live){if(window.RK)return RK.panel(btns);const me=prof(),lf=me.lf,F=live==2?frs():foes(),lv=G(()=>lvInfo(me.xp).l)||'-',w=(lf.swins|0)+(lf.pwins|0);
 const R=[{n:me.name,lv,w,k:lf.kills|0,sc:(lv|0)*100+w*50+(lf.kills|0)*2+(live?0:1e5),st:live==2?'🙋 You':live?'🛡 Alive':'👑 Sovereign'}].concat(F.map(f=>({n:f.n,lv:f.lv||'-',w:'-',k:'-',sc:(f.lv|0)*100,st:live==2?'👥 Friend':(live&&!f.o)?'⚔ Alive':'⚰ Fallen'}))).sort((a,b)=>b.sc-a.sc);
 const td='padding:4px 6px;border-bottom:1px solid #fff2';
 const rows=R.map((r,i)=>'<tr style="'+(i?'':'color:#ffd24a;font-weight:bold')+'"><td style="'+td+'">'+(i+1)+'</td><td style="'+td+';text-align:left">'+r.n.replace(/[<>&]/g,'')+'</td><td style="'+td+'">'+r.lv+'</td><td style="'+td+'">'+r.w+'</td><td style="'+td+'">'+r.k+'</td><td style="'+td+'">'+r.st+'</td></tr>').join('');
 const d=document.createElement('div');d.className='cr5';d.style.cssText='max-width:96vw;max-height:94vh;overflow:auto;background:#241a33;border:4px solid #e8b94a;padding:10px;color:#f3e9d2;font:14px Georgia,serif;text-align:center';
 d.innerHTML='<h3 style="margin:0 0 6px;color:#ffd24a">👑 Scoreboard</h3><table style="border-collapse:collapse;margin:auto;font-size:13px"><tr style="color:#8ee"><th>#</th><th>Lord</th><th>Lv</th><th>Wins</th><th>Foes slain</th><th>Status</th></tr>'+rows+'</table><div style="margin-top:8px"></div>';
 btns.forEach(b=>d.lastChild.append(b,' '));return d}
const ov=$('ov');if(ov)new MutationObserver(()=>{if(busy||ov.style.display!='flex'||ov.querySelector('.cr5')||!/👑\s*(Sole ruler|Last crown standing)/.test(ov.textContent))return;busy=1;
 const t=document.createElement('div');t.innerHTML=ov.innerHTML;const b=[...t.querySelectorAll('button')];ov.style.display='none';
 try{cut(()=>{ov.innerHTML='';ov.append(board(b));ov.style.display='flex';busy=0})}catch(e){console.error(e);ov.innerHTML='';ov.append(board(b));ov.style.display='flex';busy=0}}).observe(ov,{childList:true,attributes:true,attributeFilter:['style']});

// live scoreboard: 🏆 button or Tab key during a match (solo and PvP)
const lb=document.createElement('button'),lp=document.createElement('div');let lo=0,lm=1;
lb.textContent='🏆';lb.title='Scoreboard (Tab)';lb.style.cssText='position:fixed;left:8px;bottom:8px;z-index:60;width:40px;height:40px;font-size:20px;background:#241a33;border:3px solid #e8b94a;color:#fff;display:none';
lp.style.cssText='position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:9999;display:none';document.body.append(lb,lp);
const lr=()=>{if(!lo||lm==3)return;lp.innerHTML='';const d=board([],lm);const x=document.createElement('button');x.textContent='Close';x.onclick=lt;const w=bt('🌍 World',()=>{lm=3;wr()});d.lastChild.append(w,' ',x);lp.append(d)};
function lt(){if(window.RK){RK.toggle(G(()=>inGame)&&!busy?'live':'pvp');return}lo=!lo;lp.style.display=lo?'block':'none';lm==3&&lo?wr():lr()}
lb.onclick=()=>{lm=1;lt()};G(()=>{const m=$('mb'),b=document.createElement('button');b.className='mb';b.id='b10';b.textContent='🏆 Scoreboard';b.onclick=()=>{lm=2;lt()};m.appendChild(b);const w=document.createElement('button');w.className='mb';w.id='b11';w.textContent='🌍 World Ranking';w.onclick=()=>{lm=3;lo=0;lt()};m.appendChild(w);const v=document.createElement('button');v.className='mb';v.id='b12';v.textContent='⚔ War Scene';v.onclick=()=>{if(!wq)wcut({n:'Takeda',c:'#c0392b',hi:1,kn:'Rival Realm'})};m.appendChild(v)});addEventListener('keydown',e=>{if(e.key=='Tab'&&G(()=>inGame)&&!busy){e.preventDefault();lt()}});
setInterval(()=>G(()=>{lb.style.display=(inGame&&!busy&&!won)?'block':'none';if(lo&&((lm==1&&(!inGame||busy))||(lm==2&&inGame)||(lm==3&&busy))){lo=0;lp.style.display='none'}lr()}),1000);

// world ranking: shared online leaderboard (Firebase Realtime Database REST). URL is set once in-game via ⚙ Server.
const LBK='cor_lburl',DEFURL='',bt=(t,f)=>{const b=document.createElement('button');b.textContent=t;b.onclick=f;return b};
const lbUrl=()=>{let v=String(G(()=>localStorage.getItem(LBK))||DEFURL||'').trim().replace(/^["'<]+|["'>]+$/g,'');if(!v)return'';if(!/^https?:\/\//i.test(v))v='https://'+v;try{v=new URL(v).origin}catch(e){}return v};
function myRow(){const m=prof(),lf=m.lf,lv=G(()=>lvInfo(m.xp).l)||1,w=(lf.swins|0)+(lf.pwins|0);return{pid:String(G(()=>JSON.parse(localStorage.getItem('cor_prof')).pid)||'').replace(/[^A-Za-z0-9]/g,''),n:m.name,lv,xp:m.xp,w,k:lf.kills|0,sc:lv*100+w*50+(lf.kills|0)*2,t:Date.now()}}
const lbSend=()=>{const u=lbUrl(),r=myRow();return u&&r.pid?fetch(u+'/lb/'+r.pid+'.json',{method:'PUT',body:JSON.stringify(r)}).catch(()=>{}):Promise.resolve()};
const lbGet=()=>{const u=lbUrl();return u?fetch(u+'/lb.json').then(r=>{if(!r.ok)throw new Error('HTTP '+r.status);return r.json()}).then(o=>Object.values(o||{}).filter(x=>x&&x.pid).sort((a,b)=>b.sc-a.sc)).catch(e=>({err:String(e&&e.message||e)})):Promise.resolve(null)};
function wr(){lp.innerHTML='';const d=document.createElement('div');d.className='cr5';d.style.cssText='max-width:96vw;max-height:94vh;overflow:auto;background:#241a33;border:4px solid #e8b94a;padding:10px;color:#f3e9d2;font:14px Georgia,serif;text-align:center';
 d.innerHTML='<h3 style="margin:0 0 6px;color:#ffd24a">🌍 World Ranking</h3><div class="w5">Loading…</div><div style="margin-top:8px"></div>';
 d.lastChild.append(bt('↻ Refresh',wr),' ',bt('⚙ Server',()=>{const v=prompt('Firebase Realtime Database URL (https://…firebaseio.com or …firebasedatabase.app)',lbUrl());if(v!==null){try{localStorage.setItem(LBK,v.trim())}catch(e){}wr()}}),' ',bt('Close',lt));lp.append(d);
 const bx=d.querySelector('.w5');if(!lbUrl()){bx.innerHTML='No ranking server set yet.<br>Tap ⚙ Server and paste your Firebase Realtime Database URL. Everyone using the same URL shares one ranking.';return}
 lbSend().then(lbGet).then(L=>{if(L&&L.err){const h=L.err,u=lbUrl();bx.innerHTML='Could not reach the server ('+h.replace(/[<>&]/g,'')+').<br><small>Tried: '+u.replace(/[<>&]/g,'')+'</small><br>'+(/401|403/.test(h)?'Rules block access: in Firebase open Rules, paste the rules and tap Publish.':/404/.test(h)?'Database not found: copy the URL from the top of the Data tab.':/console\.firebase|google\.com/.test(u)?'That is the console link, not the database URL.':'Network blocked or the URL is wrong. Tap ⚙ Server and re-paste it.');return}if(!L||!L.length){bx.textContent='No players ranked yet.';return}
  const me=myRow().pid,td='padding:4px 6px;border-bottom:1px solid #fff2',e=v=>String(v==null?'-':v).replace(/[<>&"]/g,''),i0=L.findIndex(x=>x.pid==me);
  bx.innerHTML='<table style="border-collapse:collapse;margin:auto;font-size:13px"><tr style="color:#8ee"><th>#</th><th>Lord</th><th>Lv</th><th>Wins</th><th>Slain</th><th>Score</th></tr>'+L.slice(0,50).map((r,i)=>'<tr style="'+(i?'':'color:#ffd24a;font-weight:bold;')+(r.pid==me?'background:#e8b94a33':'')+'"><td style="'+td+'">'+(i?i+1:'👑')+'</td><td style="'+td+';text-align:left">'+e(r.n)+'</td><td style="'+td+'">'+e(r.lv)+'</td><td style="'+td+'">'+e(r.w)+'</td><td style="'+td+'">'+e(r.k)+'</td><td style="'+td+'">'+e(r.sc)+'</td></tr>').join('')+'</table>'+(i0>=0?'<div style="margin-top:6px;color:#8ee">Your rank: #'+(i0+1)+' of '+L.length+'</div>':'')})}
let lsc='';setInterval(()=>G(()=>{const r=myRow(),k=r.sc+'|'+r.xp;if(k!==lsc){lsc=k;lbSend()}}),30000);

// war declaration cutscene (solo: a kingdom's relation flips to war; PvP: peace ends)
let wq=0,pr=null,pw=0,gt=0;
function wcut(f){if(typeof Zman!='function'||typeof HS=='undefined')return;wq=1;
 const was=G(()=>paused),pv=G(()=>PV.live);if(!pv)G(()=>{paused=1});
 const myh=(G(()=>HI)|0)&3;let fh=f.hi>=0?f.hi:(String(f.n).length*7+3)&3;if(fh===myh)fh=(fh+1)&3;
 const HA=HS[myh],nm=prof().name,an=nm&&nm!='Lord'?nm:HA.n,
  hero=hi=>{const L=HS[hi];return{st:ZHERO[hi]||ZHERO[0],wep:'sword',wv:ZHW[hi],jp:hi==1,col:L.c1,acc:L.c2,sd:hi*5+2,sc:1.12,hs:1.05}},
  SO=[[['crus','sword'],['crus','sword']],[['saru','sword','katana'],['xbow','bow']],[['legi','sword','gladius'],['jave','spear']],[['tlan','spear'],['tarc','bow']]],
  sol=(hi,k)=>{const q=SO[hi][k&1];return{st:ZMS[q[0]]||ZMS.sword,wep:q[1],wv:q[2]||null,jp:q[2]=='katana',col:HS[hi].c1,acc:HS[hi].c2,sd:k*3+hi}},
  UA=hero(myh),UB=hero(fh),Q=[['You dare defy me?!','Your crown is mine!'],['Kneel, or burn!','Come and take it!'],['This ends today!','Not by your hand!']][Math.random()*3|0],
  SUB=[[.9,3.2,'Peace shatters between '+an+' and '+f.n+(f.kn?' of '+f.kn:'')+'.'],[3.4,6.2,'Two crowns. One realm. No retreat.'],[6.4,10,'Steel will decide who rules.']];
 const cv=document.createElement('canvas'),c=cv.getContext('2d'),sk=bt('Skip ▶▶',()=>fin()),spc=document.createElement('canvas'),sg2=spc.getContext('2d');spc.width=spc.height=64;
 cv.style.cssText='position:fixed;inset:0;width:100%;height:100%;z-index:99999;background:#000';sk.style.cssText='position:fixed;right:10px;top:10px;z-index:100000;font:16px Georgia,serif;padding:6px 12px;background:#e8b94a;border:3px solid #2a1a05;color:#2a1a05';document.body.append(cv,sk);
 let W,H,u,vg,s=0,last=performance.now(),raf,end=0,pt=[],hk=-1,cx=320,cy=195,z=1,sh=0,wf=0,ev={};
 const rs=()=>{const d=Math.min(devicePixelRatio||1,2);W=cv.width=innerWidth*d|0;H=cv.height=innerHeight*d|0;u=Math.min(W/640,H/360);vg=c.createRadialGradient(W/2,H/2,H*.3,W/2,H/2,H*.85);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.7)')};rs();addEventListener('resize',rs);
 const E=v=>v*v*(3-2*v),T=13,GY=262,sky=c.createLinearGradient(0,-300,0,GY),glow=c.createRadialGradient(320,GY-10,4,320,GY-10,170),PC=['#ffd24a','#9a7a58','#ff9a40','#e8e0e8'];
 sky.addColorStop(0,'#0e0820');sky.addColorStop(.55,'#4a1a3a');sky.addColorStop(.85,'#c85a38');sky.addColorStop(1,'#f0a050');glow.addColorStop(0,'rgba(255,200,110,.85)');glow.addColorStop(1,'rgba(255,120,40,0)');
 function fin(){if(end)return;end=1;cancelAnimationFrame(raf);removeEventListener('resize',rs);cv.remove();sk.remove();if(!pv&&was!==undefined)G(()=>{paused=was});wq=0}
 const once=(t,fn)=>{if(s>=t&&!ev[t]){ev[t]=1;fn()}},P=(x,y)=>[W/2+(x-cx)*u*z,H/2+(y-cy)*u*z],
  spark=(x,y,n,k)=>{for(let i=0;i<n&&pt.length<150;i++)pt.push({x,y,vx:(Math.random()-.5)*(k?90:240),vy:-Math.random()*(k?40:170)-10,l:k?1:.6,m:k?1:.6,k})};
 function man(x,y,bs,U,o){const pr=Z;sg2.clearRect(0,0,64,64);Z=sg2;try{Zman({x:32,y:54,f:o.f,sc:U.sc||1,t:s,sd:U.sd|0,mv:o.mv?1:0,ph:o.ph||0,fl:o.fl||0,col:U.col,acc:U.acc,st:U.st,up:0,atk:o.atk===undefined?-1:o.atk,wep:U.wep,wv:U.wv,jp:!!U.jp,ride:0,hb:0,cape:U.acc,wp:-1,hs:U.hs||1})}finally{Z=pr}
  if(o.tint){sg2.globalCompositeOperation='source-atop';sg2.fillStyle=o.tint;sg2.fillRect(0,0,64,64);sg2.globalCompositeOperation='source-over'}
  c.fillStyle='rgba(0,0,0,.4)';c.beginPath();c.ellipse(x,y,7*bs,2.2*bs,0,0,6.3);c.fill();c.imageSmoothingEnabled=false;c.drawImage(spc,0,0,64,64,Math.round(x-32*bs),Math.round(y-54*bs),64*bs,64*bs)}
 function banner(x,d,c1,c2){c.fillStyle='#3a2a1a';c.fillRect(x,GY-60,2,64);for(let i=0;i<14;i++){c.fillStyle=i%5<2?c2:c1;c.fillRect(d>0?x+2+i*1.6:x-2-i*1.6,GY-58+Math.sin(s*5+i*.5)*i*.22,2,13)}}
 function army(d,hi){const sg=E(cl((s-10.2)/2.2,0,1)),run=sg>0&&sg<1,ch=s>3.4&&s<6.6;for(let i=0;i<8;i++){const x=(d>0?34:606)+d*((i>>1)*20+(i&1)*9)+d*sg*140,q=(s*1.3+i*.29)%1;man(x,GY-4+(i&1)*12,1.5,sol(hi,i),{f:d,mv:run,ph:s*9+i,atk:ch&&q<.5?q/.5:-1})}banner(d>0?18:622,d,HS[hi].c1,HS[hi].c2)}
 function ridge(col,base,amp,sd,par){c.fillStyle=col;c.beginPath();c.moveTo(-600,GY);for(let x=-600;x<=1240;x+=24){const q=(x+cx*par)*.012;c.lineTo(x,base-amp*(Math.sin(q+sd)+.6*Math.sin(q*2.4+sd*2)+1.2))}c.lineTo(1240,GY);c.fill()}
 function fr(n){try{fr0(n)}catch(e){fin();setTimeout(()=>{throw e})}}
 function fr0(n){raf=requestAnimationFrame(fr);const dt=Math.min(.05,(n-last)/1e3);last=n;s+=dt*((s>9.6&&s<10.4)?.45:1);
  once(.5,()=>G(()=>sfx('horn')));once(.9,()=>G(()=>say('War! '+an+' and '+f.n+' draw their swords.',1)));once(10.2,()=>{G(()=>sfx('horn'));wf=.5;sh=4});
  const ag=cl((s-3)/2.2,0,1);let ax=150,bx=490,wA=0,wB=0,atkA=-1,atkB=-1,flA=0,flB=0;
  if(s>3.2){const p=E(cl((s-3.2)/1.5,0,1));ax=150+p*85;bx=490-p*85;wA=wB=p>0&&p<1}
  if(s>6.4){const p=E(cl((s-6.4)/.8,0,1));ax=235+p*61;bx=405-p*61;wA=wB=p>0&&p<1}
  const mx=(ax+bx)/2;
  if(s>7.2&&s<10){const ft=s-7.2,k=Math.floor(ft/.62),p=(ft%.62)/.62,sd=k&1,at=p<.6?p/.6:-1;if(sd)atkB=at;else atkA=at;if(p>.42&&p<.52){if(sd)flA=1;else flB=1}if(p>=.45&&hk!==k){hk=k;spark(mx,GY-55,16,0);spark(mx,GY-4,10,1);sh=3;wf=.3;G(()=>sfx('sword'))}}
  else if(s>=10){atkA=atkB=.5+Math.sin(s*26)*.06}
  let tz=1+.1*cl(s/3.2,0,1),tx=320,ty=195;if(s>=3.2){tz=1.62;ty=212}if(s>=7.2){tz=1.7;tx=mx;ty=205}if(s>=10){tz=1.25;tx=320;ty=200}
  const kk=Math.min(1,dt*2.4);z+=(tz-z)*kk;cx+=(tx-cx)*kk;cy+=(ty-cy)*kk;sh=Math.max(0,sh-dt*8);wf=Math.max(0,wf-dt*3);
  c.setTransform(1,0,0,1,0,0);c.fillStyle='#000';c.fillRect(0,0,W,H);
  c.setTransform(u*z,0,0,u*z,W/2-cx*u*z+(Math.random()-.5)*sh*2*u,H/2-cy*u*z+(Math.random()-.5)*sh*2*u);
  c.fillStyle=sky;c.fillRect(-600,-300,1840,GY+300);c.fillStyle=glow;c.fillRect(-100,GY-190,840,200);c.fillStyle='#ffb25a';c.beginPath();c.arc(320,GY-6,34,Math.PI,0);c.fill();
  c.fillStyle='rgba(30,14,36,.85)';for(let i=0;i<6;i++){const x=((i*170+s*10)%1000)-300,y=40+(i%3)*30;c.fillRect(x,y,120,14);c.fillRect(x+20,y-8,70,10)}
  ridge('#3a1a34',GY-30,26,1,.25);ridge('#24122a',GY-14,18,4,.1);
  c.fillStyle='#1d1a18';c.fillRect(-600,GY,1840,200);c.fillStyle='#2e241c';c.fillRect(-600,GY,1840,3);c.fillStyle='rgba(0,0,0,.14)';for(let i=0;i<7;i++)c.fillRect(-600,GY+8+i*i*2.2,1840,2);
  c.fillStyle='rgba(255,160,110,.07)';c.fillRect(-600,GY-22+Math.sin(s*.8)*3,1840,26);
  army(1,myh);army(-1,fh);
  const jit=s>4.2&&s<6.6?ag*1.3:0,tint=ag>0?'rgba(255,40,20,'+(.08+.22*ag*(.5+.5*Math.sin(s*9)))+')':0;
  man(ax+(Math.random()-.5)*jit,GY,2.2,UA,{f:1,mv:wA,ph:s*8,atk:atkA,fl:flA,tint});man(bx+(Math.random()-.5)*jit,GY,2.2,UB,{f:-1,mv:wB,ph:s*8+2,atk:atkB,fl:flB,tint});
  if(pt.length<120&&Math.random()<.5)pt.push({x:cx-330+Math.random()*660,y:GY-Math.random()*40,vx:18+Math.random()*20,vy:-(14+Math.random()*26),l:3,m:3,k:2});
  if(ag>.3&&s<10&&Math.random()<.4)pt.push({x:(Math.random()<.5?ax+12:bx-12),y:GY-84,vx:(Math.random()-.5)*10,vy:-20,l:.9,m:.9,k:3});
  for(let i=pt.length;i--;){const p=pt[i];p.l-=dt;if(p.l<=0){pt.splice(i,1);continue}if(p.k==0)p.vy+=260*dt;else if(p.k==1){p.vy+=20*dt;p.vx*=.98}p.x+=p.vx*dt;p.y+=p.vy*dt;c.globalAlpha=Math.min(1,p.l/p.m*1.5);c.fillStyle=PC[p.k];c.fillRect(p.x,p.y,p.k==1?4:2,p.k==1?4:2)}c.globalAlpha=1;
  c.setTransform(1,0,0,1,0,0);c.fillStyle=vg;c.fillRect(0,0,W,H);
  const fs=Math.round(15*u);c.textAlign='center';c.lineJoin='round';
  if(s>3.2&&s<10){const a=P(ax,GY+12),b=P(bx,GY+12),w=s<6.4?1:0;if(w){c.font='bold '+fs+'px Georgia,serif';c.lineWidth=4;c.strokeStyle='#000';c.fillStyle='#ffd24a';[[a,an,HA.t],[b,f.n,HS[fh].t]].forEach(([q,t1,t2])=>{c.strokeText(t1,q[0],q[1]);c.fillText(t1,q[0],q[1]);c.font=Math.round(11*u)+'px Georgia,serif';c.fillStyle='#fff';c.fillText(String(t2||''),q[0],q[1]+14*u);c.font='bold '+fs+'px Georgia,serif';c.fillStyle='#ffd24a'})}
   if(ag>.4){c.font=Math.round(22*u)+'px sans-serif';[P(ax+14,GY-90),P(bx-14,GY-90)].forEach(q=>c.fillText('💢',q[0],q[1]+Math.sin(s*14)*2))}}
  const bub=(t,x,y)=>{const q=P(x,y);c.font='bold '+fs+'px Georgia,serif';const w=c.measureText(t).width+16*u,h=26*u;c.fillStyle='#2a1a05';c.fillRect(q[0]-w/2-2,q[1]-2,w+4,h+4);c.fillStyle='#f3e9d2';c.fillRect(q[0]-w/2,q[1],w,h);c.beginPath();c.moveTo(q[0]-6*u,q[1]+h);c.lineTo(q[0]+6*u,q[1]+h);c.lineTo(q[0],q[1]+h+9*u);c.fill();c.fillStyle='#2a1a05';c.fillText(t,q[0],q[1]+h*.7)};
  if(s>4.4&&s<5.6)bub(Q[0],ax,128);if(s>5.2&&s<6.4)bub(Q[1],bx,128);
  if(s>10.2){const p=E(cl((s-10.2)/.3,0,1)),sc=1.8-.8*p,q=P(mx,GY-90);c.strokeStyle='rgba(255,230,160,'+Math.max(0,.9-(s-10.2)*1.1)+')';c.lineWidth=4*u;c.beginPath();c.arc(q[0],q[1],20*u+(s-10.2)*380*u,0,6.3);c.stroke();
   c.font='bold '+Math.round(96*u*sc)+'px Georgia,serif';c.lineWidth=8*u;c.strokeStyle='#000';c.strokeText('WAR!',W/2,H*.4);c.fillStyle='#e23a2a';c.fillText('WAR!',W/2,H*.4);c.lineWidth=1.5*u;c.strokeStyle='#ffd24a';c.strokeText('WAR!',W/2,H*.4);
   c.font='bold '+Math.round(20*u)+'px Georgia,serif';c.fillStyle='#fff';c.fillText(an+'  ⚔  '+f.n,W/2,H*.4+34*u)}
  if(wf){c.fillStyle='rgba(255,255,255,'+wf+')';c.fillRect(0,0,W,H)}
  c.fillStyle='#000';c.fillRect(0,0,W,H*.1);c.fillRect(0,H*.9,W,H*.1);
  SUB.forEach(([a,b,t])=>{if(s>a&&s<b){const k=Math.min(t.length,Math.floor((s-a)*38));c.font='bold '+Math.round(16*u)+'px Georgia,serif';c.fillStyle='#f3e9d2';c.fillText(t.slice(0,k),W/2,H*.9+H*.055)}});
  if(s<.7){c.fillStyle='rgba(0,0,0,'+(1-s/.7)+')';c.fillRect(0,0,W,H)}if(s>T-.8){c.fillStyle='rgba(0,0,0,'+cl((s-T+.8)/.8,0,1)+')';c.fillRect(0,0,W,H)}
  if(s>=T)fin()}
 raf=requestAnimationFrame(n=>{last=n;fr(n)})}
setInterval(()=>{try{const n=performance.now();if(!inGame){pr=null;pw=0;gt=0;return}if(!gt)gt=n;
 const rel=G(()=>KG.map(k=>k.rel))||[],war=G(()=>PV.live&&PV.war?1:0)|0;if(!pr||n-gt<5000){pr=rel;pw=war;return}if(busy||wq)return;
 let f=null;if(PV.live){if(war&&!pw){const a=[...MP.peers.values()],P=a.find(p=>!p.out&&p.tm!==ME.tm)||a[0];if(P)f={n:String(P.n||'Rival'),c:P.c1||'#c0392b',hi:-1,kn:P.kn}}}
 else rel.forEach((r,i)=>{if(r<0&&pr[i]>=0&&!f){const k=KG[i];f={n:String(G(()=>k.hs.ln)||k.name),c:k.c1||'#c0392b',hi:G(()=>HS.indexOf(k.hs)),kn:k.name}}});
 pr=rel;pw=war;if(f)wcut(f)}catch(e){setTimeout(()=>{throw e})}},500);
// perf guard: drop render scale if FPS stays low; cap effect arrays
let fr=0,t0=performance.now(),low=0;(function m(){requestAnimationFrame(m);fr++;const n=performance.now();if(n-t0>=1500){const f=fr*1e3/(n-t0);fr=0;t0=n;G(()=>{if(inGame&&!paused&&!document.hidden&&!busy){low=f<45?low+1:0;if(low>=2&&!window.PERF){window.PERF=1;size()}}})}})();
setInterval(()=>G(()=>{if(FX.length>350)FX.splice(0,FX.length-350)}),1000);
})();
