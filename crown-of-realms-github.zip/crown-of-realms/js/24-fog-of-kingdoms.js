/* ===== v15-5-9: kingdoms stay unknown until a lord or messenger finds them; mobile polish ===== */
(function(){
window.discK=function(k,q){if(!k||k.known||k.owned)return;k.known=1;if(!q){try{toast('🔎 Kingdom found: '+k._nm);feed('Found '+k._nm);say('We have found the realm of '+k._nm+', my liege.')}catch(e){}}};
window.discP=function(P,q){if(!P||P.known)return;P.known=1;if(!q){try{toast('🔎 Rival lord found: '+P.n+' of '+P.kn);feed('Found '+P.n);say('We have found '+P.n+' of '+P.kn+'.')}catch(e){}}};
function reveal(){window.NOFOG=1;try{KG.forEach(k=>{k.known=1})}catch(e){}try{MP.peers.forEach(P=>{P.known=1})}catch(e){}}
setInterval(()=>{try{
 if(!inGame)return;
 if(won||window.WON2){if(!window.NOFOG)reveal();return}
 if(!MPI){
  const seen=new Set();
  US.forEach(u=>{const k=u.kg;if(!k||k.known||k.owned||!u.team||u.dead)return;if((Math.abs(u.x-H.x)<150&&Math.abs(u.y-H.y)<120)||Math.hypot(u.x-CX,u.y-CX)<330)seen.add(k)});
  KG.forEach(k=>{if(k.known||k.owned)return;if(k.rel!==0||seen.has(k)||Math.hypot(H.x-k.x,H.y-k.y)<300)discK(k)})
 }else if(PV.live){
  MP.peers.forEach(P=>{if(P.known||P.out)return;if(P.tm===ME.tm){P.known=1;return}
   if(Math.hypot(H.x-P.lx,H.y-P.ly)<320||Math.hypot(H.x-P.x,H.y-P.y)<200){discP(P);return}
   for(const g of P.gu.values()){if(g.hp>0&&Math.hypot(g.x-CX,g.y-CX)<330){discP(P);break}}})
 }
}catch(e){}},500);
/* mobile polish */
document.addEventListener('contextmenu',e=>{if(!/INPUT|TEXTAREA/.test(e.target.tagName))e.preventDefault()});
['gesturestart','gesturechange','gestureend'].forEach(ev=>document.addEventListener(ev,e=>e.preventDefault()));
setInterval(()=>{try{if(window.PERF){if(PS.length>200)PS.splice(0,PS.length-200)}}catch(e){}},1000);
})();
