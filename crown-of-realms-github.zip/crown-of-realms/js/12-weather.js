/* ===== v10: Living weather — sun, cloud, mist, rain, thunderstorms, rainbows =====
   Cosmetic + atmospheric only (never changes gameplay, so PvP stays fair).
   Test any weather: add ?weather=storm (sunny|cloudy|fog|rain|storm|rainbow) to the URL,
   or call setWeather('storm') in the console. */
(function(){
'use strict';
const G=f=>{try{return f()}catch(e){return undefined}};
const clamp=(v,a,b)=>v<a?a:v>b?b:v,R=Math.random,rr=(a,b)=>a+R()*(b-a);
const sm=v=>{v=clamp(v,0,1);return v*v*(3-2*v)};
const hh=(i,j,s)=>{const n=Math.sin(i*127.1+j*311.7+s*74.7)*43758.5453;return n-Math.floor(n)};

/* ---------- overlay canvas (sits above the world, below the HUD) ---------- */
const gl=document.getElementById('gl');
const cvs=document.createElement('canvas');cvs.id='wx';
cvs.style.cssText='position:fixed;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:0';
gl.after(cvs);
const x=cvs.getContext('2d');
const bd=document.createElement('div');bd.id='wxb';
bd.style.cssText="position:fixed;left:50%;transform:translateX(-50%);top:calc(6px + env(safe-area-inset-top,0px));z-index:3;pointer-events:none;background:#000a;color:#f3e9d2;border:2px solid #6b5a8a;padding:3px 7px;font:7px 'Press Start 2P',ui-monospace,monospace;white-space:nowrap;display:none";
document.body.appendChild(bd);
const rbc=document.createElement('canvas'),rbx=rbc.getContext('2d');
let SW=0,SH=0,DP=1,SC=1;
function rs(){DP=.6;SW=innerWidth;SH=innerHeight;cvs.width=Math.round(SW*DP);cvs.height=Math.round(SH*DP);rbc.width=Math.round(SW*.75);rbc.height=Math.round(SH*.75);SC=clamp(SH/450,.7,1.6)}
rs();addEventListener('resize',rs);

/* ---------- soft sprites ---------- */
function spr(w,h,f){const c=document.createElement('canvas');c.width=w;c.height=h;f(c.getContext('2d'),w,h);return c}
const BLOB=spr(160,80,(q,w,h)=>{q.scale(1,h/w);const g=q.createRadialGradient(w/2,w/2,0,w/2,w/2,w/2);g.addColorStop(0,'rgba(10,14,28,1)');g.addColorStop(.55,'rgba(10,14,28,.55)');g.addColorStop(1,'rgba(10,14,28,0)');q.fillStyle=g;q.fillRect(0,0,w,w)});
const fogS=(r,g,b)=>spr(256,100,(q,w,h)=>{q.scale(1,h/w);const gr=q.createRadialGradient(w/2,w/2,0,w/2,w/2,w/2);gr.addColorStop(0,`rgba(${r},${g},${b},.9)`);gr.addColorStop(.5,`rgba(${r},${g},${b},.45)`);gr.addColorStop(1,`rgba(${r},${g},${b},0)`);q.fillStyle=gr;q.fillRect(0,0,w,w)});
const FD=fogS(205,212,218),FN=fogS(52,62,88);

/* ---------- weather states ---------- */
const WS={
 sunny:{cloud:.04,rain:0,fog:0,wind:.18,sun:1,storm:0,rb:0,name:'Sunny',ic:'☀'},
 cloudy:{cloud:.72,rain:0,fog:.06,wind:.5,sun:.15,storm:0,rb:0,name:'Cloudy',ic:'☁'},
 fog:{cloud:.45,rain:0,fog:.85,wind:.08,sun:.1,storm:0,rb:0,name:'Misty',ic:'🌫'},
 rain:{cloud:.88,rain:.6,fog:.22,wind:.55,sun:0,storm:0,rb:0,name:'Rain',ic:'🌧'},
 storm:{cloud:1,rain:1,fog:.3,wind:1,sun:0,storm:1,rb:0,name:'Thunderstorm',ic:'⛈'},
 rainbow:{cloud:.3,rain:0,fog:.04,wind:.2,sun:.85,storm:0,rb:1,name:'Rainbow',ic:'🌈'}
};
const NX={
 sunny:[['cloudy',.65],['fog',.2],['rain',.15]],
 cloudy:[['rain',.4],['storm',.2],['sunny',.3],['fog',.1]],
 fog:[['sunny',.5],['cloudy',.4],['rain',.1]],
 rain:[['storm',.25],['rainbow',.4],['cloudy',.35]],
 storm:[['rain',.45],['cloudy',.3],['rainbow',.25]],
 rainbow:[['sunny',.75],['cloudy',.25]]
};
const DUR={sunny:[55,100],cloudy:[35,70],fog:[35,60],rain:[55,95],storm:[50,85],rainbow:[40,60]};
const MSG={sunny:'☀ The sun breaks through',cloudy:'☁ Clouds roll in…',fog:'🌫 A thick mist rises',rain:'🌧 Rain begins to fall',storm:'⛈ A thunderstorm is upon you!',rainbow:'🌈 The storm passes: a rainbow!'};
const cur={cloud:.04,rain:0,fog:0,wind:.18,sun:1,storm:0,rb:0};
let st='sunny',stT=28,FORCE=0,wet=0,pType='rain',pFade=1,lite=0,first=1;
function pick(a){let r=R(),s=0;for(const[k,p]of a){s+=p;if(r<=s)return k}return a[0][0]}
function setState(n,hold){const same=n==st;st=n;const D=DUR[n];stT=hold?1e9:rr(D[0],D[1]);FORCE=hold?1:0;if(!same){bd.textContent=WS[n].ic+' '+WS[n].name;if(!first&&G(()=>inGame))G(()=>toast(MSG[n]));if(n=='storm'){TQ.push({at:tn_(),d:.85});ltT=rr(5,8)}}}
const tn_=()=>performance.now()/1000+5;
window.setWeather=function(n,hold){if(WS[n])setState(n,hold!==false)};
(function(){const p=G(()=>new URLSearchParams(location.search).get('weather'));if(p&&WS[p]){st=p;FORCE=1;stT=1e9;for(const k in cur)cur[k]=WS[p][k];wet=p=='rain'||p=='storm'?.8:0}bd.textContent=WS[st].ic+' '+WS[st].name})();

/* ---------- particle pools ---------- */
const NR=420,rp=new Float32Array(NR*4);
for(let i=0;i<NR;i++){rp[i*4]=R();rp[i*4+1]=R();rp[i*4+2]=[.5,.8,1.05][i%3]*(.92+.16*R());rp[i*4+3]=R()}
const RIP=[],LV=[];let ripAcc=0;
for(let i=0;i<28;i++)LV.push({x:R(),y:R(),z:.5+R()*.7,p:R()*6});

/* ---------- lightning ---------- */
let ltT=8,flash=null,bolt=null,shk=0,shkOn=0,roll=null;const TQ=[];
const KF=[[0,0],[.03,1],[.09,.25],[.14,.9],[.2,.15],[.28,.55],[.5,0]];
function kf(tau){if(tau<=0)return 0;for(let i=1;i<KF.length;i++)if(tau<=KF[i][0]){const a=KF[i-1],b=KF[i];return a[1]+(b[1]-a[1])*(tau-a[0])/(b[0]-a[0])}return 0}
function mkBolt(bx,sc){const pts=[],br=[];let px=bx,py=-6;const step=SH/17,end=SH*(.42+.4*R());pts.push([px,py]);
 while(py<end){px+=(R()-.5)*46*sc*SC;py+=step*(.6+R()*.8);pts.push([px,py]);
  if(R()<.2&&py<end*.85){let bx2=px,by2=py;const dir=R()<.5?-1:1,b=[[bx2,by2]];for(let k=0;k<2+(R()*4|0);k++){bx2+=dir*(8+R()*26)*sc*SC;by2+=step*(.4+R()*.6);b.push([bx2,by2])}br.push(b)}}
 return{pts,br}}
function strike(){const d=clamp(Math.pow(R(),.8)*.95+.05,.05,1),bx=rr(.1,.9)*SW;flash={t:0,d};bolt=d<.78?mkBolt(bx,1-d*.55):null;TQ.push({at:performance.now()/1000+.12+d*3.4,d})}
function shake(a){shk=Math.max(shk,a)}

/* ---------- audio (re-uses the game's AudioContext, honours its mute) ---------- */
const A={ok:0};
function aInit(){const ctx=G(()=>ac);if(!ctx||A.ok)return;try{A.c=ctx;const m=A.m=ctx.createGain();m.gain.value=0;m.connect(ctx.destination);
 const len=ctx.sampleRate*2,b=ctx.createBuffer(1,len,ctx.sampleRate),d=b.getChannelData(0);for(let i=0;i<len;i++)d[i]=R()*2-1;A.nb=b;
 const mk=(ty,f,q,off)=>{const s=ctx.createBufferSource();s.buffer=b;s.loop=true;const fl=ctx.createBiquadFilter();fl.type=ty;fl.frequency.value=f;fl.Q.value=q;const g=ctx.createGain();g.gain.value=0;s.connect(fl);fl.connect(g);g.connect(m);s.start(0,off);return{g,fl}};
 A.r1=mk('bandpass',2400,.45,0);A.r2=mk('lowpass',750,.7,.7);A.w=mk('lowpass',300,.8,1.3);A.ok=1}catch(e){}}
function aTick(active,amt,wd){if(!A.ok){aInit();if(!A.ok)return}const n=A.c.currentTime;
 A.m.gain.setTargetAtTime(active&&!G(()=>muted)?1:0,n,.35);
 const rain=pType=='rain'?amt:0;
 A.r1.g.gain.setTargetAtTime(rain*.05,n,.5);A.r2.g.gain.setTargetAtTime(rain*(.04+.03*cur.storm),n,.5);
 A.w.g.gain.setTargetAtTime(wd*.05+(pType=='sand'?amt*.05:0)+(pType=='snow'?amt*.02:0),n,.5);
 A.w.fl.frequency.setTargetAtTime(170+wd*650,n,.4)}
function thunder(d){if(!A.ok||G(()=>muted))return;const ctx=A.c,n=ctx.currentTime,v=1-d*.7,dur=2.4+(1-d)*2.2+d*1.4;
 const s=ctx.createBufferSource();s.buffer=A.nb;s.loop=true;const lp=ctx.createBiquadFilter();lp.type='lowpass';lp.frequency.setValueAtTime(720-d*380,n);lp.frequency.exponentialRampToValueAtTime(55,n+dur);lp.Q.value=.8;
 const g=ctx.createGain();g.gain.setValueAtTime(0,n);g.gain.linearRampToValueAtTime(.6*v,n+.03+d*.25);
 const nb=3+(R()*3|0);for(let k=1;k<=nb;k++){const tt=n+dur*(k/(nb+1))*.8,f=1-k/(nb+1);g.gain.linearRampToValueAtTime((.18+R()*.32)*v*f,tt);g.gain.linearRampToValueAtTime(.06*v*f,tt+dur*.07)}
 g.gain.linearRampToValueAtTime(0,n+dur);s.connect(lp);lp.connect(g);g.connect(A.m);s.start(n,R()*1.5);s.stop(n+dur+.1);
 const o=ctx.createOscillator(),og=ctx.createGain();o.type='sine';o.frequency.setValueAtTime(64,n);o.frequency.exponentialRampToValueAtTime(28,n+dur*.7);og.gain.setValueAtTime(0,n);og.gain.linearRampToValueAtTime(.32*v,n+.08);og.gain.exponentialRampToValueAtTime(.001,n+dur*.7);o.connect(og);og.connect(A.m);o.start(n);o.stop(n+dur*.7+.05);
 if(d<.35){const c=ctx.createBufferSource();c.buffer=A.nb;c.loop=true;const hp=ctx.createBiquadFilter();hp.type='highpass';hp.frequency.value=1100;const cg=ctx.createGain();cg.gain.setValueAtTime(.55*v,n);cg.gain.exponentialRampToValueAtTime(.001,n+.3);c.connect(hp);hp.connect(cg);cg.connect(A.m);c.start(n);c.stop(n+.32)}}

/* ---------- main loop ---------- */
let last=performance.now()/1000,fa=.016,slow=0,fil='',gust=.5;
const RBC=['255,60,60','255,150,40','255,230,70','90,210,90','70,160,255','90,90,230','160,90,220'];
function frame(){requestAnimationFrame(frame);
 const t=performance.now()/1000,raw=t-last;last=t;
 if(!G(()=>inGame)){x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,cvs.width,cvs.height);bd.style.display='none';if(A.ok)aTick(0,0,0);return}
 bd.style.display='block';
 const run=!G(()=>paused&&!PV.live),dt=run?Math.min(.05,raw):0;
 if(run){fa+=(raw-fa)*.02;if(fa>.034)slow+=raw;else slow=Math.max(0,slow-raw);if(slow>4&&!lite){lite=1;if(fil){gl.style.filter='';fil=''}}}
 /* weather state machine */
 if(dt>0){stT-=dt;if(stT<=0&&!FORCE){setState(pick(NX[st]));first=0}
  const W=WS[st];for(const k in cur){const tg=W[k],tau=(k=='rain'||k=='storm')?(tg>cur[k]?8:12):k=='rb'?5:6;cur[k]+=(tg-cur[k])*(1-Math.exp(-dt/tau))}
  wet=clamp(wet+(cur.rain>.05?cur.rain*dt*.035:-dt*.006),0,1)}
 if(first&&t>4)first=0;
 /* biome decides what falls from the sky: rain / snow / sand */
 if(window.PERF>=1)lite=1;const bm=G(()=>bio(H.x,H.y))||'forest',want=bm=='snow'?'snow':bm=='desert'?'sand':'rain';
 if(want!=pType){pFade-=dt*1.2;if(pFade<=0){pType=want;pFade=0}}else pFade=Math.min(1,pFade+dt*1.2);
 const amt=cur.rain*pFade*(pType=='sand'?.8:1);
 gust=.5+.5*Math.sin(t*.43)*Math.sin(t*1.13+1.7);const wd=cur.wind*(.35+.65*gust);
 const dn=Math.sin(t*.05)*.5+.5,night=dn<.55,day=sm((dn-.3)/.5);
 const cm=G(()=>cam)||{x:0,y:0},gw=G(()=>VW)||384,gh=G(()=>VH)||216,kx=SW/gw,ky=SH/gh;
 /* the world itself goes grey and flat under cloud, vivid in sun */
 if(false){const sat=clamp(1-cur.cloud*.26-cur.rain*.1-cur.fog*.2+cur.sun*.07,.55,1.1),con=clamp(1-cur.fog*.14+cur.sun*.02,.8,1.05),f=`saturate(${sat.toFixed(2)}) contrast(${con.toFixed(2)})`;if(f!=fil){fil=f;gl.style.filter=f}}
 x.setTransform(DP,0,0,DP,0,0);x.globalAlpha=1;x.globalCompositeOperation='source-over';x.clearRect(0,0,SW,SH);
 /* 1. heavy sky tint */
 const dark=cur.cloud*.18+cur.rain*.1+cur.storm*.14;
 if(dark>.004){const g=x.createLinearGradient(0,0,0,SH);g.addColorStop(0,`rgba(18,24,40,${dark*1.15})`);g.addColorStop(1,`rgba(34,44,62,${dark*.75})`);x.fillStyle=g;x.fillRect(0,0,SW,SH)}
 /* 2. drifting cloud shadows */
 if(cur.cloud>.25&&!lite){x.globalAlpha=(cur.cloud-.2)*.3;for(let i=0;i<3;i++){const w=(260+i*60)*SC,h=w*.5,MX=SW+w*2,MY=SH+h*2,sp=10+i*3.1;
  const px=(((t*sp*(.4+wd)+i*517-cm.x*kx*.4)%MX)+MX)%MX-w,py=(((i*211-cm.y*ky*.4+t*2)%MY)+MY)%MY-h;x.drawImage(BLOB,px,py,w,h)}x.globalAlpha=1}
 /* 3. mist */
 if(cur.fog>.02){const fa_=cur.fog*.5;for(let i=0;i<(lite?2:3);i++){const w=(420+i*70)*SC,h=w*.39,MX=SW+w*2,sp=6+i*2.4,
  px=(((t*sp*(.5+wd)+i*389-cm.x*kx*.25)%MX)+MX)%MX-w,py=SH*(.12+i*.15)+Math.sin(t*.2+i)*14-cm.y*ky*.1%40;
  x.globalAlpha=fa_*dn*.85;x.drawImage(FD,px,py,w,h);x.globalAlpha=fa_*(1-dn)*.85;x.drawImage(FN,px,py,w,h)}x.globalAlpha=1;
  const fr=(196*dn+46*(1-dn))|0,fg=(204*dn+56*(1-dn))|0,fb=(210*dn+80*(1-dn))|0;x.fillStyle=`rgba(${fr},${fg},${fb},${cur.fog*.26})`;x.fillRect(0,0,SW,SH)}
 /* 4. warm sun, glow and god-rays */
 const s=cur.sun*day;
 if(s>.03){const sx=SW*.84,sy=-SH*.08,g=x.createRadialGradient(sx,sy,0,sx,sy,SW*.95);g.addColorStop(0,`rgba(255,238,175,${.3*s})`);g.addColorStop(1,'rgba(255,238,175,0)');x.fillStyle=g;x.fillRect(0,0,SW,SH);
  x.fillStyle=`rgba(255,196,110,${.045*s})`;x.fillRect(0,0,SW,SH);
  x.globalCompositeOperation='lighter';const bright=s*(1-cur.cloud*.6);
  for(let i=0;i<(lite?0:3);i++){const a=1.95+i*.15+Math.sin(t*.1+i)*.02,wd2=.05+.02*(i%3),L=SH*1.6,ex=sx+Math.cos(a)*L,ey=sy+Math.sin(a)*L,g2=x.createLinearGradient(sx,sy,ex,ey),al=(.03+.022*Math.sin(t*.4+i*1.7))*bright;
   g2.addColorStop(0,`rgba(255,240,190,${al})`);g2.addColorStop(1,'rgba(255,240,190,0)');x.fillStyle=g2;x.beginPath();x.moveTo(sx,sy);x.lineTo(sx+Math.cos(a-wd2)*L,sy+Math.sin(a-wd2)*L);x.lineTo(sx+Math.cos(a+wd2)*L,sy+Math.sin(a+wd2)*L);x.closePath();x.fill()}
  x.globalCompositeOperation='source-over'}
 /* 5. rainbow (own buffer so its feet fade into the ground) */
 if(cur.rb>.01&&day>.05){const a=cur.rb*day,bw=SH*.017*.75,cx0=SW*.38*.75+clamp(-((cm.x-(G(()=>CX)||0))*kx*.03),-SW*.3,SW*.3)*.75,cy0=SH*1.3*.75,R0=SH*1.05*.75;
  rbx.clearRect(0,0,rbc.width,rbc.height);rbx.lineCap='butt';
  rbx.strokeStyle='rgba(255,255,255,.13)';rbx.lineWidth=bw*8;rbx.beginPath();rbx.arc(cx0,cy0,R0-bw*3,Math.PI,2*Math.PI);rbx.stroke();
  for(let i=0;i<7;i++){rbx.strokeStyle=`rgba(${RBC[i]},.62)`;rbx.lineWidth=bw+.8;rbx.beginPath();rbx.arc(cx0,cy0,R0-i*bw,Math.PI,2*Math.PI);rbx.stroke()}
  rbx.strokeStyle='rgba(255,255,255,.18)';rbx.lineWidth=bw*.8;rbx.beginPath();rbx.arc(cx0,cy0,R0*1.2,Math.PI,2*Math.PI);rbx.stroke();
  rbx.globalCompositeOperation='destination-out';const mg=rbx.createLinearGradient(0,rbc.height*.5,0,rbc.height*.92);mg.addColorStop(0,'rgba(0,0,0,0)');mg.addColorStop(1,'rgba(0,0,0,1)');rbx.fillStyle=mg;rbx.fillRect(0,0,rbc.width,rbc.height);rbx.globalCompositeOperation='source-over';
  x.globalAlpha=a*.7;x.globalCompositeOperation='screen';x.drawImage(rbc,0,0,SW,SH);x.globalCompositeOperation='source-over';x.globalAlpha=1}
 /* 6. wet ground: sheen + puddles that ripple */
 if(pType=='rain'&&wet>.05){const g=x.createLinearGradient(0,SH*.35,0,SH);g.addColorStop(0,'rgba(120,150,190,0)');g.addColorStop(1,`rgba(120,150,190,${wet*.07})`);x.fillStyle=g;x.fillRect(0,0,SW,SH);
  if(wet>.25){const cs=72,i0=Math.floor(cm.x/cs)-1,j0=Math.floor(cm.y/cs)-1,ni=Math.ceil(gw/cs)+3,nj=Math.ceil(gh/cs)+3;
   for(let j=j0;j<j0+nj;j++)for(let i=i0;i<i0+ni;i++){const h=hh(i,j,1);if(h<.4)continue;const wx=i*cs+hh(i,j,2)*cs,wy=j*cs+hh(i,j,3)*cs,sx=(wx-cm.x)*kx,sy=(wy-cm.y)*ky;if(sx<-60||sx>SW+60||sy<-30||sy>SH+30)continue;
    const b2=G(()=>bio(wx,wy));if(b2!='forest'&&b2!='swamp')continue;const r=(9+hh(i,j,4)*16)*kx,al=clamp((wet-.25)*1.2)*Math.min(1,(h-.4)*5)*.3;
    x.fillStyle=`rgba(140,168,200,${al*.55})`;x.beginPath();x.ellipse(sx,sy,r,r*.38,0,0,6.2832);x.fill();x.strokeStyle=`rgba(225,238,255,${al*.8})`;x.lineWidth=1;x.beginPath();x.ellipse(sx,sy,r*.96,r*.36,0,Math.PI*1.1,Math.PI*1.9);x.stroke();
    if(amt>.1){const ph=(t*1.1+h*7)%1;x.strokeStyle=`rgba(235,245,255,${(1-ph)*al*1.4})`;x.beginPath();x.ellipse(sx+Math.sin(h*30)*r*.3,sy,r*.5*ph,r*.19*ph,0,0,6.2832);x.stroke()}}}}
 /* 7. rain / snow / sand */
 const area=Math.min(1.35,SW*SH/(1000*560));
 if(amt>.01){
  if(pType=='rain'){const n=Math.min(lite?NR*.55:NR,Math.floor(NR*Math.pow(amt,.85)*area)),sp0=(560+160*cur.storm)*SC,tilt=wd*.55,col=night?'168,184,214':'200,214,232',AL=[.16,.28,.42],LW=[.8,1.1,1.5];
   for(let b=0;b<3;b++){x.strokeStyle=`rgba(${col},${AL[b]*(.7+amt*.5)})`;x.lineWidth=LW[b];x.beginPath();
    for(let i=b;i<n;i+=3){const o=i*4,z=rp[o+2],vy=sp0*(.7+.5*z);if(dt>0){rp[o]+=vy*tilt*dt/SW;rp[o+1]+=vy*dt/SH;if(rp[o+1]>1.02){rp[o+1]-=1.04;rp[o]=R()}if(rp[o]>1.05)rp[o]-=1.1}
     const X=rp[o]*SW,Y=rp[o+1]*SH,L=(9+14*z)*SC*(.7+amt*.5);x.moveTo(X,Y);x.lineTo(X-tilt*L,Y-L)}x.stroke()}
   if(dt>0){ripAcc+=amt*(lite?25:55)*area*dt;while(ripAcc>1){ripAcc--;RIP.push({x:rr(.02,.98)*SW,y:SH*(.25+.75*Math.pow(R(),.7)),a:0,s:.6+R()*.8})}}
   for(let i=RIP.length-1;i>=0;i--){const p=RIP[i];p.a+=dt*1.8;if(p.a>=1){RIP.splice(i,1);continue}const rx=p.s*(2+11*p.a)*SC;x.strokeStyle=`rgba(225,238,255,${.5*(1-p.a)})`;x.lineWidth=1;x.beginPath();x.ellipse(p.x,p.y,rx,rx*.38,0,0,6.2832);x.stroke()}}
  else if(pType=='snow'){const n=Math.min(lite?240:420,Math.floor(420*Math.pow(amt,.8)*area));x.fillStyle=night?'rgba(205,216,238,.9)':'rgba(255,255,255,.92)';
   for(let i=0;i<n;i++){const o=i*4,z=rp[o+2];if(dt>0){rp[o]+=(wd*110*z*SC+Math.sin(t*1.3+rp[o+3]*40)*18*z*SC)*dt/SW;rp[o+1]+=(26+34*z)*SC*dt/SH;if(rp[o+1]>1.02){rp[o+1]-=1.04;rp[o]=R()}if(rp[o]>1.05)rp[o]-=1.1;if(rp[o]<-.05)rp[o]+=1.1}
    const sz=Math.max(1,Math.round((z>.9?2.6:z>.6?1.9:1.3)*SC));x.fillRect(Math.round(rp[o]*SW),Math.round(rp[o+1]*SH),sz,sz)}
   x.fillStyle=`rgba(${night?'70,80,105':'235,242,250'},${amt*.12})`;x.fillRect(0,0,SW,SH)}
  else{const n=Math.min(lite?150:260,Math.floor(260*amt*area));x.strokeStyle=`rgba(${night?'150,120,80':'222,184,120'},.34)`;x.lineWidth=1.2;x.beginPath();
   for(let i=0;i<n;i++){const o=i*4,z=rp[o+2];if(dt>0){rp[o]+=(420+500*z)*SC*(.5+wd)*dt/SW;rp[o+1]+=(40+60*z)*SC*dt/SH;if(rp[o]>1.05){rp[o]=-.05;rp[o+1]=R()}if(rp[o+1]>1.02)rp[o+1]-=1.04}
    const X=rp[o]*SW,Y=rp[o+1]*SH,L=(14+24*z)*SC;x.moveTo(X,Y);x.lineTo(X-L,Y-L*.08)}x.stroke();
   x.fillStyle=`rgba(${night?'90,64,36':'214,168,98'},${amt*.22})`;x.fillRect(0,0,SW,SH)}}
 /* 8. gusts: leaves / dust blown across the screen */
 const lk=clamp((wd-.32)/.55,0,1);
 if(lk>.02&&pType!='snow'){const cols=bm=='desert'?['#e8c888','#c8a060']:bm=='swamp'?['#9ac060','#6a7a3a','#4a5a30']:['#6cae48','#d8b040','#8a5a2a'],n=Math.floor(LV.length*lk);
  for(let i=0;i<n;i++){const p=LV[i];if(dt>0){p.x+=(90+260*wd)*p.z*SC*dt/SW;p.y+=(Math.sin(t*3+p.p)*30*p.z+25)*SC*dt/SH;if(p.x>1.05){p.x=-.05;p.y=R()}if(p.y>1.03)p.y=-.03}
   const sz=Math.max(2,Math.round(2.2*SC*p.z));x.fillStyle=cols[i%cols.length];x.globalAlpha=.85;x.fillRect(Math.round(p.x*SW),Math.round(p.y*SH),sz,Math.max(1,Math.round(sz*(.5+.5*Math.abs(Math.sin(t*5+p.p))))))}x.globalAlpha=1}
 /* 9. lightning: queue of thunder claps, flash and bolt */
 if(dt>0&&cur.storm>.35){ltT-=dt;if(ltT<=0){strike();ltT=rr(3,9)/(.4+cur.storm)}}
 while(TQ.length&&TQ[0].at<=t){const q=TQ.shift();thunder(q.d);if(q.d<.55){const a=(1-q.d*1.7)*6.5;shake(a);roll={t0:t,dur:1.6+(1-q.d)*1.6,amp:a*.35};if(q.d<.4)G(()=>navigator.vibrate(q.d<.2?[60,40,130]:[45]))}}
 if(flash){flash.t+=dt;const f=kf(flash.t)*(.12+.88*(1-flash.d));if(flash.t>.5){flash=null;bolt=null}else{
  x.fillStyle=`rgba(215,228,255,${f*.55})`;x.fillRect(0,0,SW,SH);
  if(bolt&&flash.t<.3){const fb=kf(flash.t);x.lineJoin='round';x.lineCap='round';
   const draw=(lw,al,col)=>{x.strokeStyle=`rgba(${col},${al*fb})`;x.lineWidth=lw;x.beginPath();bolt.pts.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]));bolt.br.forEach(b=>{b.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]))});x.stroke()};
   draw(12*SC,.1,'150,170,255');draw(5*SC,.28,'190,205,255');draw(1.8*SC,.95,'255,255,255')}}}
 /* storm vignette */
 if(cur.storm>.05){const g=x.createRadialGradient(SW/2,SH/2,SH*.35,SW/2,SH/2,SW*.65);g.addColorStop(0,'rgba(0,0,10,0)');g.addColorStop(1,`rgba(0,0,10,${cur.storm*.3})`);x.fillStyle=g;x.fillRect(0,0,SW,SH)}
 /* screen shake from close thunder */
 if(roll){if(t<roll.t0+roll.dur)shk=Math.max(shk,roll.amp*(1-(t-roll.t0)/roll.dur)*(.5+.5*R()));else roll=null}
 if(shk>.08){const sc=1+2.2*shk/Math.min(SW,SH),tr=`translate(${((R()-.5)*2*shk).toFixed(1)}px,${((R()-.5)*1.4*shk).toFixed(1)}px) scale(${sc.toFixed(3)})`;gl.style.transform=tr;cvs.style.transform=tr;shkOn=1;if(dt>0)shk*=Math.exp(-dt*3.4)}
 else if(shkOn){shk=0;shkOn=0;gl.style.transform='';cvs.style.transform=''}
 aTick(run,amt,wd);
}
requestAnimationFrame(frame);
})();
