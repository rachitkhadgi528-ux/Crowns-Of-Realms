/* ===== v5.8: troop command (pick All or one unit type, then Follow / Hold / Send ahead) ===== */
(function(){
let SELG='all',SELN=1,open=0;const tp=$('tpb'),pn=document.createElement('div');pn.id='tc';document.body.appendChild(pn);
const TYN=t=>(UT[t]&&UT[t].n)||t,isG=u=>u.type=='cguard'||u.type=='bguard',alive=()=>ARM.filter(u=>!u.dead);
const grp=()=>{const l=SELG=='all'?alive().filter(u=>!u.gd):alive().filter(u=>u.type==SELG);return SELN>=1?l:l.slice(0,Math.max(1,Math.round(l.length*SELN)))};
const fix=()=>{if(SELG!='all'&&!alive().some(u=>u.type==SELG))SELG='all'};
const chip=(v,l)=>'<button class="ch'+(SELG==v?' on':'')+'" onclick="tcSel(\''+v+'\')">'+l+'</button>';
window.tbl=function(){fix();const h=ARM.filter(u=>u.hold).length;tp.textContent='Troops: '+(SELG=='all'?'All':TYN(SELG))+(SELN<1?' '+Math.round(SELN*100)+'%':'')+(h?' (hold '+h+')':'')};
function R(){fix();const m={};alive().forEach(u=>{m[u.type]=(m[u.type]||0)+1});
 pn.innerHTML='<b style="color:#e8b94a">Which troops?</b><div>'+chip('all','All ('+alive().filter(u=>!u.gd).length+')')+Object.keys(m).map(t=>chip(t,TYN(t)+' '+m[t])).join('')+'</div><b style="color:#e8b94a">How many?</b><div>'+[.25,.5,.75,1].map(v=>'<button class="ch'+(SELN==v?' on':'')+'" onclick="tcN('+v+')">'+(v==1?'All':v*100+'%')+'</button>').join('')+'</div><b style="color:#e8b94a">Order</b><div><button class="ch od" onclick="tcOrd(\'f\')">Follow me</button><button class="ch od" onclick="tcOrd(\'f\')">✖ Cancel orders</button><button class="ch od" onclick="tcOrd(\'h\')">Hold here</button><button class="ch od" onclick="tcOrd(\'s\')">Send ahead</button><button class="ch od" onclick="tcOrd(\'g\')">🏰 Guard castle</button><button class="ch od" onclick="tcOrd(\'r\')">🚶 Roam freely</button><button class="ch" onclick="tcShow(0)">Close \u2715</button></div>'}
window.tcSel=v=>{SELG=v;R();tbl()};window.tcN=v=>{SELN=v;R();tbl()};
window.tcShow=f=>{open=f;pn.style.display=f?'block':'none';if(f)R()};
window.tcOrd=o=>{const g=grp();if(!g.length){toast('No troops in that group');return}
 if(o=='f'){g.forEach(u=>{u.hold=0;u.rl=0;if(isG(u))u.gd=0});toast(g.length+' following you')}
 else if(o=='h'){g.forEach(u=>{u.rl=0;u.hx=u.x;u.hy=u.y;if(isG(u))u.gd=1;else u.hold=1});toast(g.length+' holding position')}
 else if(o=='g'||o=='r'){if(window.xRelax)xRelax(g,o)}
 else{const px=Math.max(20,Math.min(WD-20,H.x+(H.fx||1)*110)),py=Math.max(20,Math.min(WD-20,H.y+(H.fy||0)*110));g.forEach((u,i)=>{u.rl=0;u.hx=px+((i%20)-9.5)*14;u.hy=py+Math.floor(i/20)*14;if(isG(u))u.gd=1;else u.hold=1});toast(g.length+' sent ahead')}
 tcShow(0);tbl();hud()};
tp.addEventListener('pointerdown',e=>{e.preventDefault();tcShow(open?0:1)});
setInterval(()=>{if(open)R()},1500);tbl();
})();
