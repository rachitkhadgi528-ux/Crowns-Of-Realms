/* ===== v15.6 fixes: keep zoom/cinematic buttons below the HUD (never over it) ===== */
(function(){
setInterval(()=>{try{const h=document.getElementById('hud'),z=document.getElementById('zmb');if(!h||!z)return;
 const hb=h.getBoundingClientRect();if(!hb.height)return;
 const f=document.getElementById('feed'),fb=f&&f.getBoundingClientRect();
 /* buttons stay fixed under the HUD; the kill feed is pushed below them so nothing bounces */
 let top=Math.round(hb.bottom+4);
 z.style.bottom='auto';z.style.top=top+'px';z.style.left=hb.left+'px';z.style.padding='4px 8px';z.style.fontSize='12px';
 const zr=z.getBoundingClientRect();
 for(const q of document.querySelectorAll('button')){if(q.textContent.startsWith('🎬')){q.style.top=top+'px';q.style.left=(zr.right+6)+'px';q.style.padding='4px 8px';q.style.fontSize='12px';q.style.zIndex=20;break}}
 if(f){const nb=Math.round(zr.bottom+4);if(f.style.top!==nb+'px')f.style.setProperty('top',nb+'px','important')}
}catch(e){}},250);
})();
