/* ===== v9.5: advanced formations (Legion / Phalanx / Cohort), marching songs & emotions,
   relax orders (guard castle / roam freely) and the Messenger (alliance, war calls, troop requests) ===== */
(function(){
const TAU=6.2832,clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),R=Math.random,pick=a=>a[R()*a.length|0];
const X={song:1,nb:0,k:-1,lyr:0,mi:0,fight:0,kills:0,vic:1,hudT:0,wvT:0,mp:null,mpN:'',cm:0};
try{if(localStorage.getItem('cor_song')==='0')X.song=0}catch(e){}
const SPA=11,SPB=13;
let MAINK=null;                       // solo: kingdom everyone should hit
const MS=[],XV=[];                    // active messenger missions, active chats

/* ---------- formation names + effects ---------- */
FRM.push('Legion','Phalanx','Cohort');
Object.assign(FD,{Legion:'all −12% dmg taken',Phalanx:'pikes −35%, others −10%',Cohort:'all −8% taken, +6% dmg dealt'});

/* ---------- unit roles (so any army balances itself) ---------- */
function role(u){const d=UT[u.type]||{};
 if(u.type=='ram'||u.type=='treb')return 'sg';
 if(d.horse)return 'cv';
 if(d.w=='bow'||d.rng>=60)return 'rg';     // skirmishers / archers = velites, psiloi
 if(d.w=='spear')return 'pk';              // pikemen = hoplites, triarii
 return 'in'}                              // swordsmen = hastati, principes, peltasts

/* ---------- advanced formations ----------
   a = distance behind the king (grows backwards), b = sideways. Every block is sized from the
   number of soldiers of that kind, so 20 or 400 troops both look right. */
function grid(list,cb,a,per,spB,spA,put){per=Math.max(1,per);const rows=Math.ceil(list.length/per);
 list.forEach((u,i)=>{const r=(i/per)|0,c=i%per,n=Math.min(per,list.length-r*per);put(u,a-r*spA,cb+(c-(n-1)/2)*spB)});return rows}
function wings(list,edge,a,put){            // cavalry on both flanks
 if(!list.length)return;const h=Math.ceil(list.length/2),L=list.slice(0,h),Rt=list.slice(h);
 [[L,-1],[Rt,1]].forEach(([l,s])=>{if(!l.length)return;const w=clamp(Math.ceil(Math.sqrt(l.length*.9)),2,6);grid(l,s*(edge+w*7.5),a,w,15,15,put)})}
function advForm(order,fx,fy){
 const rx=-fy,ry=fx,G={rg:[],pk:[],in:[],cv:[],sg:[]};order.forEach(u=>G[role(u)].push(u));
 const put=(u,a,b)=>{u.sx=H.x+fx*a+rx*b;u.sy=H.y+fy*a+ry*b};let a=-26,span=40;
 const skirm=(w)=>{if(!G.rg.length)return;const per=clamp(Math.ceil(w/18),3,44),rows=grid(G.rg,0,a,per,18,12,put);a-=rows*12+8};
 if(form==4){                                   // Macedonian phalanx
  const core=G.pk.length?G.pk:G.in,pel=G.pk.length?G.in:[],W=clamp(Math.ceil(Math.sqrt(core.length*2.4)),4,34);span=W*SPB;
  skirm(span);const aF=a,rows=grid(core,0,a,W,SPB,SPA,put);a-=rows*SPA+9;
  if(pel.length){const w2=clamp(Math.ceil(pel.length/2),3,W+6),r2=grid(pel,0,a,w2,SPB,SPA,put);a-=r2*SPA+8}
  wings(G.cv,span/2+10,aF,put)}
 else if(form==3){                              // Roman manipular legion (quincunx)
  const inf=G.in,tri=G.pk,heavy=inf.concat(tri);let L1,L2,L3;
  if(inf.length&&tri.length){const h=Math.ceil(inf.length/2);L1=inf.slice(0,h);L2=inf.slice(h);L3=tri}
  else{const n=heavy.length,p=Math.ceil(n*.4),q=Math.ceil(n*.8);L1=heavy.slice(0,p);L2=heavy.slice(p,q);L3=heavy.slice(q)}
  const m=clamp(Math.round(Math.sqrt(heavy.length)*.9),3,12),wm=clamp(Math.ceil(Math.sqrt(m*1.8)),2,6),pitch=wm*SPB*1.9,rowsM=Math.ceil(m/wm);
  const lines=[L1,L2,L3],ks=lines.map(l=>Math.ceil(l.length/m)),kmax=Math.max(1,...ks);span=kmax*pitch;
  skirm(span);const aF=a;
  lines.forEach((l,li)=>{if(!l.length)return;const k=ks[li],off=li==1?pitch/2:0;
   for(let j=0;j<k;j++)grid(l.slice(j*m,(j+1)*m),(j-(k-1)/2)*pitch+off,a,wm,SPB,SPA,put);a-=rowsM*SPA+16});
  wings(G.cv,span/2+16,aF,put)}
 else{                                          // Marian cohorts (4-3-3 blocks)
  const heavy=G.in.concat(G.pk),c=clamp(Math.round(heavy.length/9),1,10),r1=Math.ceil(c*.4),r2=Math.ceil((c-r1)/2),rowsC=[r1,r2,c-r1-r2].filter(n=>n>0);
  const co=Array.from({length:c},()=>[]);heavy.forEach((u,i)=>co[i%c].push(u));
  const sz=Math.max(1,...co.map(l=>l.length)),wc=clamp(Math.ceil(Math.sqrt(sz*2)),2,9),rc=Math.ceil(sz/wc),pb=wc*SPB+SPB*1.3,pa=rc*SPA+12;span=Math.max(...rowsC)*pb;
  skirm(span);const aF=a;let ci=0;
  rowsC.forEach(n=>{for(let j=0;j<n;j++)grid(co[ci++],(j-(n-1)/2)*pb,a,wc,SPB,SPA,put);a-=pa});
  wings(G.cv,span/2+10,aF,put)}
 grid(G.sg,0,a-6,6,22,18,put)}
window.advForm=advForm;

/* formation damage rules */
const _hurt=hurt;
hurt=function(tg,dmg,from){
 if(tg&&!tg.gh&&!tg.team&&form>=3){const m=form==3?.88:form==4?(tg.type=='pike'||tg.type=='cguard'?.65:.9):.92;dmg*=m}
 if(from&&!from.team&&!from.gh&&from.mo!==undefined){dmg*=.88+.24*from.mo;if(form==5)dmg*=1.06}
 _hurt(tg,dmg,from)};

/* ---------- speech, emotes, songs ---------- */
const SONG={pk:['Pikes up, boys, hold the line!','Iron hedge and ash-wood shaft!','No horse shall break our wall!'],
 in:['Shield to shield, blade to blade!','Steel and sunlight, march as one!','Hey-ho, the long road home!'],
 rg:['Loose and fly, the arrows fly!','Keep the string tight, keep the eye keen!','Sing, bowmen, sing!'],
 cv:['Hooves like thunder, hearts like fire!','Ride, ride, the dawn is ours!'],
 sg:['Heave and haul, the timber rolls!'],any:['March, march, march to the drum!','Left, left, left, right, left!','For the crown and for the hearth!']};
const BATTLE=['For the Crown!','Hold the line!','Steady, lads!','Take that!','Stand fast!','Cut them down!'],
 FEAR=['I can’t hold…','Fall back!?','Gods, help us!'],GRIEF=['No! Brother!','They got him!','Avenge him!'],
 CHEER=['Victory!','Hail the king!','We held!','Glory!','Another day alive!'],ALERT=['To arms!','Enemy!','Form up!'];
const EM={'♪':'#ffe27a','!':'#ff4a3a','?':'#cfe8ff','…':'#7aa8ff','★':'#ffd84a','☺':'#9fe070'};
const near=u=>Math.abs(u.x-H.x)<190&&Math.abs(u.y-H.y)<120;
function shout(u,txt,em,dur){if(X.nb>=4||!near(u))return;dur=dur||2.4;if(txt){u.bub=txt;u.bt=dur;X.nb++}if(em){u._em=em;u._emt=now()+dur}}
const _du=drawU;
drawU=function(u,x,y){_du(u,x,y);const t=now();
 if(u.type=='messenger'){const f=u.face,up=u.dl?-6:0;c.fillStyle='#4a3020';c.fillRect(x+f*5,y-19+up,1,6);
  c.fillStyle='#f3e9d2';c.fillRect(x+f*4-2,y-24+up,5,6);c.fillStyle='#d8c8a0';c.fillRect(x+f*4-2,y-24+up,5,1);c.fillStyle='#b01c1c';c.fillRect(x+f*4,y-20+up,2,2)}
 if(u._em&&u._emt>t){const d=UT[u.type]||{},hy=d.horse?38:Math.round(26*(d.big||1)),b=Math.sin(t*6+u.uid)*1.2;
  c.font='bold 8px monospace';c.textAlign='center';c.fillStyle='#000';c.fillText(u._em,x+8,y-hy+b+1);c.fillStyle=EM[u._em]||'#fff';c.fillText(u._em,x+8,y-hy+b)}};

/* ---------- audio: drum, chant and clinking mail on the same clock as the footsteps ---------- */
/* v14: LOUD marching audio on its own bus (bypasses the quiet 0.2 sfx bus) */
let MB=null;
function mbus(){if(MB&&MB.ctx===ac)return MB;const cp=ac.createDynamicsCompressor();cp.threshold.value=-14;cp.ratio.value=4;const g=ac.createGain();g.gain.value=1.9;g.connect(cp);cp.connect(ac.destination);MB={ctx:ac,g};return MB}
function mN(f,d,ty,v,lp,at){const o=ac.createOscillator(),g=ac.createGain(),fl=ac.createBiquadFilter(),n=ac.currentTime;o.type=ty;o.frequency.setValueAtTime(f,n);fl.type='lowpass';fl.frequency.value=lp||2400;g.gain.setValueAtTime(.0001,n);g.gain.linearRampToValueAtTime(v,n+(at||.015));g.gain.exponentialRampToValueAtTime(.001,n+d);o.connect(fl);fl.connect(g);g.connect(mbus().g);o.start(n);o.stop(n+d+.03)}
function mD(f,d,v,f2){const o=ac.createOscillator(),g=ac.createGain(),n=ac.currentTime;o.type='sine';o.frequency.setValueAtTime(f,n);o.frequency.exponentialRampToValueAtTime(f2||40,n+d);g.gain.setValueAtTime(v,n);g.gain.exponentialRampToValueAtTime(.001,n+d);o.connect(g);g.connect(mbus().g);o.start(n);o.stop(n+d+.03)}
function mS(d,v,ty,fq,f2){const s=ac.createBufferSource(),fl=ac.createBiquadFilter(),g=ac.createGain(),n=ac.currentTime;s.buffer=nb;s.loop=true;fl.type=ty;fl.frequency.setValueAtTime(fq,n);if(f2)fl.frequency.exponentialRampToValueAtTime(f2,n+d);g.gain.setValueAtTime(v,n);g.gain.exponentialRampToValueAtTime(.001,n+d);s.connect(fl);fl.connect(g);g.connect(mbus().g);s.start(n,Math.random()*.5);s.stop(n+d+.03)}
/* D-minor march: 32 beats of melody (semitones above D4), bass roots per 8 beats */
const MEL=[0,0,3,5,7,5,3,0, 3,3,5,7,10,7,5,3, 7,7,10,12,10,7,5,3, 5,3,0,-2,0,0,0,-99],
 BAS=[-24,-26,-21,-26];
let _bl=0,_bn=0;
function beat(k,c){if(!ac||!sb||!nb||muted)return;const tn_=performance.now();if(tn_-_bl<300)return;_bl=tn_;const v=clamp(.45+c/40,.45,1),st=k%4;
 /* LIGHT version: ~8 audio nodes per beat instead of ~30 (long armies used to flood the audio thread) */
 mS(.12,.5*v,'lowpass',520,160);
 if(BT.on){}else if(st==0)mD(120,.26,.9*v,48);else if(st==2)mD(105,.2,.7*v,50);else mS(.07,.35*v,'bandpass',1900,1100);
 if(X.song&&!BT.on&&c>=8&&(k&1)==0){const q=k%32,n=MEL[q],root=BAS[(q>>3)&3],d0=293.66;
  if(n>-90)mN(d0*Math.pow(2,n/12),.5,'sawtooth',.14*v,2400);
  if(q%4==0)mN(d0*Math.pow(2,root/12),.5,'triangle',.18*v,700)}}

/* ---------- think wrapper: rhythmic marching, battle emotion, relaxed behaviour ---------- */
const GP=()=>now()*8;                   // one shared leg-phase: the whole army steps together
const isG=u=>u.type=='cguard'||u.type=='bguard';
const _th=think;
think=function(u,dt,EN,TG){
 if(u.team){_th(u,dt,EN,TG);return}
 if(!u.rl&&u.xcv)endConv(u.xcv);
 if(u.rl&&relax(u,dt,EN))return;
 const ph0=u.ph,r0=role(u);_th(u,dt,EN,TG);
 if(u.ph!==ph0&&!u.lt&&r0!='sg'&&!u.rl){u._mv=now();u.ph=GP()}
 if(u.atk>.2){X.fight=now();u._fg=now();if(R()<.025)shout(u,pick(BATTLE),'!',1.6)}
 if(u.hp<u.mhp*.3&&R()<.003)shout(u,pick(FEAR),'?',2)};

/* ---------- relax: guard the castle / roam freely and chat with civilians ---------- */
const SOLC=['Good day, citizen. All well?','Any trouble in the village?','Need anything from the guard?','Fine weather, friend.','Your fields look healthy.'],
 CIVR=['Thank you for the walls, soldier.','Quiet, thank the gods.','The harvest comes in nicely.','Mind the wolves at night.','My boy wants to be a soldier too.'],
 SOLF=['We’ll keep the bandits from your door.','The king looks after his people.','That’s a fine pot you carry.','Hard work, but worth it.'],
 CIVE=['Bless you, soldier.','Come eat with us tonight!','Stay safe out there.','Long live the king!'],
 KIDS=['Hello, little one.','Can I hold your spear?','When you’re grown, lad!','I’ll be a knight one day!'],
 SS1=['Quiet night, eh?','Did you hear the horns?','Pay’s late again.','My feet ache.','Share the flask?'],
 SS2=['Aye. Let them come.','Same as ever.','Ha! Don’t tell the captain.','Better than the march, at least.','Save me a swig!'],
 GRD=['All quiet on the wall.','Keep your spear steady.','Eyes sharp, lads.','Nothing stirs out there.'],
 GCV=['Halt! … Ah, it’s you. Pass.','Move along, citizen.','Mind the gate.'];
function endConv(v){if(!v||v.dn)return;v.dn=1;[v.a,v.b].forEach(p=>{if(p.xcv===v)p.xcv=null;if(p.cv===v){p.cv=null;p.cd=8+R()*10}});const i=XV.indexOf(v);if(i>=0)XV.splice(i,1)}
function chat(a,b,L,civ){if(a.xcv||b.xcv||b.cv)return 0;const v={a,b,n:0,t:.3,l:L,dn:0};a.xcv=v;if(civ)b.cv=v;else b.xcv=v;XV.push(v);return 1}
function convLines(a,b){const kid=b.type=='child',soc=CT.indexOf(b)>=0;
 if(kid)return[KIDS[0],KIDS[1],KIDS[2],KIDS[3]];if(soc)return[pick(SOLC),pick(CIVR),pick(SOLF),pick(CIVE)];
 return[pick(SS1),pick(SS2),pick(SS1),pick(SS2)]}
function stepConvs(dt){for(let i=XV.length-1;i>=0;i--){const v=XV[i];if(!v||v.dn)continue;const a=v.a,b=v.b;
  if(a.dead||b.dead||(a.hp<=0)||(b.hp<=0)||!a.rl){endConv(v);continue}
  v.t-=dt;if(v.t>0)continue;
  if(v.n>=v.l.length){endConv(v);continue}
  if(v.n==0&&X.nb>=2){v.t=1.2;continue}
  const sp=v.n%2?b:a;sp.bub=v.l[v.n];sp.bt=2.6;if(sp.rl){sp._em='☺';sp._emt=now()+2.4}v.n++;v.t=2.8}}
function walk(u,tx,ty,sp,dt){let dx=tx-u.x,dy=ty-u.y,d=Math.hypot(dx,dy);if(d<2.5)return 0;
 const g=gateWP(u,tx,ty);if(g){dx=g[0]-u.x;dy=g[1]-u.y;d=Math.hypot(dx,dy)||1}
 const s=Math.min(sp*dt,d);u.x+=dx/d*s;u.y+=dy/d*s;u.ph+=dt*6.5;if(Math.abs(dx)>.5)u.face=dx>0?1:-1;return 1}
function freeSpot(x,y){for(const o of objs){if((o.k=='home'||o.k=='farm'||o.k=='keep'||o.k=='tower'||(o.dec&&o.blk))&&Math.abs(o.x-x)<(o.blk||16)&&Math.abs(o.y-y)<(o.blk?o.blk-2:14))return 0}return 1}
function roamSpot(u){
 if(u.ar){return[u.ax+(R()-.5)*u.ar*2,u.ay+(R()-.5)*u.ar*1.4]}
 for(let i=0;i<8;i++){let x,y;const r=R();
  if(r<.28){const a=R()*TAU,d=22+R()*14;x=camp.x+Math.cos(a)*d;y=camp.y+Math.sin(a)*d*.7}      // around the campfire
  else if(r<.48){x=CX+(R()-.5)*70;y=CX-56+34+R()*20}                                         // keep courtyard
  else{const a=R()*TAU,q=Math.sqrt(R())*.78;x=CX+Math.cos(a)*284*q;y=CX+Math.sin(a)*243*q}
  if(freeSpot(x,y))return[x,y]}
 return[CX+(R()-.5)*100,CX+20+R()*30]}
function relax(u,dt,EN){const t=now();
 if(t>(u._tt||0)){u._tt=t+.25+R()*.1;u._thr=0;for(let i=0;i<EN.length;i++){const e=EN[i];if(e.dead)continue;if(Math.abs(e.x-u.x)<125&&Math.abs(e.y-u.y)<125){u._thr=1;break}}}
 if(u._thr){if(u.xcv)endConv(u.xcv);if(!u._al){u._al=1;u.hx=u.x;u.hy=u.y;u.rd=null;shout(u,pick(ALERT),'!',1.6);X.fight=t}return false}
 if(u._al){u._al=0;u.rd=null;u.pd=null}
 u.cd-=dt;u.hit-=dt;u.atk-=dt;
 if(u.xcv){const o=u.xcv.a===u?u.xcv.b:u.xcv.a;u.face=o.x>=u.x?1:-1;return true}
 if(u.rl=='g')guard(u,dt,t);else roam(u,dt,t);return true}
function roam(u,dt,t){
 if(u.rt>0){u.rt-=dt;if(R()<dt*.04)u.face*=-1;return}
 if(!u.rd){const w=u.wnt;if(w&&!w.cv&&!w.dead&&!w.xcv){u.rd=[w.x+(R()<.5?14:-14),w.y+2]}else{u.wnt=null;
   if(R()<.42){const c=CT.filter(q=>!q.kg&&!q.cv&&(u.ar?Math.hypot(q.x-u.ax,q.y-u.ay)<130:1)),ct=c.length?pick(c):null;if(ct){u.wnt=ct;u.rd=[ct.x+14,ct.y+2]}}
   if(!u.rd)u.rd=roamSpot(u)}}
 if(!walk(u,u.rd[0],u.rd[1],24,dt)){const w=u.wnt;u.rd=null;u.rt=3+R()*7;
  if(w&&Math.hypot(w.x-u.x,w.y-u.y)<30&&!w.cv&&!w.dead){chat(u,w,convLines(u,w),1)}
  else if(R()<.35){const m=ARM.find(q=>q!==u&&q.rl&&!q.xcv&&Math.hypot(q.x-u.x,q.y-u.y)<26);if(m)chat(u,m,convLines(u,m),0)}
  if(Math.hypot(camp.x-u.x,camp.y-u.y)<45)u.face=camp.x>u.x?1:-1}}
function guard(u,dt,t){
 const tx=u.pd?u.pd[0]:u.hx,ty=u.pd?u.pd[1]:u.hy;
 if(u.pw>0){u.pw-=dt;return}
 if(walk(u,tx,ty,u.pd?20:34,dt))return;
 if(u.pd){u.pd=null;u.pw=1.5;return}
 u.face=u.hx>=CX?1:-1;u.rt=(u.rt||0)-dt;
 if(u.rt<=0){u.rt=9+R()*16;const r=R();
  if(r<.35){u.pd=[u.hx+(R()-.5)*44,u.hy+(R()-.5)*24];u.pw=.8}
  else if(r<.75){const m=ARM.find(q=>q!==u&&q.rl=='g'&&!q.xcv&&Math.hypot(q.x-u.x,q.y-u.y)<34);if(m)chat(u,m,[pick(GRD),pick(GRD),pick(SS2),pick(GRD)],0)}
  else{const c=CT.find(q=>!q.kg&&Math.hypot(q.x-u.x,q.y-u.y)<60);shout(u,pick(c?GCV:GRD),null,2.4)}}}
window.xRelax=function(g,mode){
 g=g.filter(u=>!u.dead&&!u.aid&&!u.kg&&!u.ttl&&u.type!='ram'&&u.type!='treb');
 if(!g.length){toast('No troops to give that order');return}
 const home=Math.hypot(H.x-CX,H.y-CX)<420;
 g.forEach(u=>{u.rl=mode;u.rd=null;u.pd=null;u.wnt=null;u.rt=R()*2;u._al=0;u.hold=1;if(isG(u))u.gd=1;
  if(mode=='r'){if(home){u.ar=0}else{u.ax=H.x;u.ay=H.y;u.ar=60}}});
 if(mode=='g'){const keep=clamp(Math.round(g.length*.25),Math.min(2,g.length),12),gate=Math.min(4,Math.round((g.length-keep)*.2)),wall=g.length-keep-gate;
  const P=[];for(let i=0;i<keep;i++){const a=.35+(i+.5)/keep*(Math.PI-.7);P.push([CX+Math.cos(a)*(34+(i&1)*8),CX-56+14+Math.sin(a)*(22+(i&1)*6)])}
  for(let i=0;i<gate;i++)P.push([CX+257,CX+((i&1)?14:-14)+((i>>1)?-0:0)]);
  const o=R()*TAU;for(let i=0;i<wall;i++){const a=o+i/Math.max(1,wall)*TAU;P.push([CX+Math.cos(a)*239,CX+Math.sin(a)*204])}
  g.forEach((u,i)=>{u.hx=P[i][0];u.hy=P[i][1]});toast(g.length+' troops guard the castle')}
 else toast(g.length+' troops at ease'+(home?' in the camp':' here'));
 hud()};

/* ---------- messenger ---------- */
UT.messenger={n:'Messenger',hp:30,dmg:0,rng:0,spd:125,cd:1,c:'#2a4a8a',s:'#e8b94a',w:'none',horse:1,cost:{gold:15}};
ZMS.messenger={a:'leath',h:'cap',cape:1};
const COST=15,MAXM=3,ESC=[{n:'Lone rider',k:0,c:15},{n:'Guard · 10 soldiers',k:10,c:70},{n:'Strong guard · 20 soldiers',k:20,c:140},{n:'Royal escort · 36 soldiers',k:36,c:260}];let EI=1;
function nearestOrder(L,sx,sy){const out=[];let x=sx,y=sy,rest=L.slice();while(rest.length){rest.sort((p,q)=>Math.hypot(p.x-x,p.y-y)-Math.hypot(q.x-x,q.y-y));const s=rest.shift();out.push(s);x=s.x;y=s.y}return out}
function launch(kind,stops){
 if(MS.length>=MAXM){toast('Three messengers are already riding');return 0}
 if(!stops.length){toast('There is nobody to carry that message to');return 0}
 const E=ESC[EI];
 if(H.gold<E.c){sfx('no');toast('That ride costs '+E.c+' gold');return 0}
 H.gold-=E.c;const gx=CX+287,gy=CX+12;
 const u={uid:++UID,team:0,type:'messenger',x:gx,y:gy,hx:gx,hy:gy,sx:gx,sy:gy,hp:160,mhp:160,cd:0,face:1,atk:0,hit:0,dead:0,ph:0,nm:'Messenger',bt:0,bub:''};
 US.push(u);
 const esc=[];for(let i=0;i<E.k&&ARM.length<500;i++){const e=mku(0,i%4==3?'bow':(i%5==0?'cguard':'sword'),gx-8-(i%12)*3,gy+4+(i%4)*3+(i/12|0)*6,{});e.mhp=Math.round(e.mhp*1.8);e.hp=e.mhp;e.hold=1;e.esc=1;e.hx=e.x;e.hy=e.y;esc.push(e)}
 const route=nearestOrder(stops,gx,gy);route.push({x:gx,y:gy,home:1});
 MS.push({u,route,i:0,st:'go',t:0,kind,esc});sfx('recruit');hud();return 1}
function killEsc(e){if(e.dead)return;e.dead=now();const j=ARM.indexOf(e);if(j>=0)ARM.splice(j,1)}
function escLose(m,all){(m.esc||[]).forEach((e,i)=>{if(e.dead)return;if(all||i%2==0)killEsc(e);else{e.hold=0;e.esc=0}})}
function failMsg(m,why,killer,war){const i=MS.indexOf(m);if(i>=0)MS.splice(i,1);if(!m.u.dead)m.u.dead=now();
 const ne=(m.esc||[]).filter(e=>!e.dead).length;escLose(m,ne<8);
 if(why!==false)toast(why||'Your messenger was cut down!');sfx('horn');
 const kg=killer&&killer.kg&&!killer.kg.owned?killer.kg:null,pe=killer&&killer.lx!==undefined?killer:null;
 if(kg){discK(kg,1);const go=()=>{if(war&&kg.rel>=0)decl(kg,1)};if(window.CUT)CUT.slain({k:kg,esc:ne,war:war?1:0},go);else go()}
 else if(pe){discP(pe,1);if(window.CUT)CUT.slain({P:pe,esc:ne,war:0,short:1})}}
function hazard(u){
 if(PV.live){if(!PV.war)return 0;for(const P of MP.peers.values()){if(P.out||P.tm===ME.tm)continue;for(const g of P.gu.values()){if(g.hp>0&&Math.abs(g.x-u.x)<26&&Math.abs(g.y-u.y)<26)return P}}return 0}
 return US.find(e=>e!==u&&e.team&&!e.dead&&e.type!='messenger'&&(e.raid||!e.kg||e.kg.rel<0)&&Math.abs(e.x-u.x)<26&&Math.abs(e.y-u.y)<26)||0}
function stepMsgs(dt){UT.messenger.c=PB.c1;UT.messenger.s=PB.c2;const t=now();
 for(let i=MS.length-1;i>=0;i--){const m=MS[i],u=m.u;if(u.dead){failMsg(m);continue}
  const s=m.route[m.i];
  if(m.esc)m.esc.forEach((e,j)=>{if(e.dead)return;const tx=u.x-u.face*(12+(j%4)*8),ty=u.y+((j/4|0)-.5)*12+((j%4)-1.5)*3,k=Math.min(1,dt*6);e.hx=tx;e.hy=ty;e.x+=(tx-e.x)*k;e.y+=(ty-e.y)*k;e.face=u.face;e.ph+=dt*10});
  if(m.st=='dl'){m.t-=dt;if(m.t<=0){u.dl=0;try{s.fn&&s.fn(m)}catch(e){console.error(e)}m.i++;m.st='go'}continue}
  const dx=s.x-u.x,dy=s.y-u.y,d=Math.hypot(dx,dy);
  if(d>6){const ae=(m.esc&&m.esc.some(e=>!e.dead))?.6:1,sp=Math.min(UT.messenger.spd*ae*dt,d);u.x+=dx/d*sp;u.y+=dy/d*sp;u.ph+=dt*11;u.face=dx>0?1:-1;
   if(R()<dt*10)PS.push({x:u.x-u.face*6,y:u.y,vx:-u.face*14,vy:-10,l:.5,c:'#b8a070'})}
  else if(s.home){const j=US.indexOf(u);if(j>=0)US.splice(j,1);MS.splice(i,1);(m.esc||[]).forEach(e=>{if(!e.dead){e.hold=0;e.esc=0}});toast('✉ Your messenger is back safe');sfx('loot');hud()}
  else{m.st='dl';m.t=2.4;u.dl=1;u.bub=s.say||'A message from '+(RULER||KNAME)+'!';u.bt=2.4}}
 if(t>X.mi){X.mi=t+.5;MS.slice().forEach(m=>{if(m.u.dead)return;
  if(!MPI)KG.forEach(k=>{if(!k.known&&!k.owned&&Math.hypot(k.x-m.u.x,k.y-m.u.y)<230)discK(k)});
  else if(PV.live)MP.peers.forEach(P=>{if(!P.known&&!P.out&&Math.hypot(P.lx-m.u.x,P.ly-m.u.y)<230)discP(P)});
  const kl=hazard(m.u);if(!kl)return;
  const al=(m.esc||[]).filter(e=>!e.dead);
  if(al.length&&R()<.7){killEsc(al[al.length-1]);toast('🛡 A guard fell defending the messenger');sfx('hit')}
  else failMsg(m,'✉ Your messenger was ambushed on the road!',kl)})}}

/* solo: what each kingdom does when the rider arrives */
function strikeUnits(k,T,n,ttl){const ty=['sword','bow','pike','cav','sword','bow'];
 for(let i=0;i<n;i++){const u=mku(0,ty[i%ty.length],k.gx+(R()-.5)*50,k.gy+(R()-.5)*30);u.kg=k;u.hold=1;u.strike=T;
  u.hx=T.gx+(R()-.5)*80;u.hy=T.gy+(R()-.5)*50;u.ttl=Znow()+ttl}}
function helpUnits(k,n){const ty=['sword','bow','pike','cav'];
 for(let i=0;i<n;i++){const a=R()*TAU,u=mku(0,ty[i%4],k.gx+(R()-.5)*50,k.gy+(R()-.5)*30);u.kg=k;u.gd=1;u.hold=1;
  u.hx=CX+Math.cos(a)*248;u.hy=CX+Math.sin(a)*203;u.ttl=Znow()+200}}
function deliver(kind,k,T,m){const t=Znow();
 if(kind=='explore'){explore(k,m)}
 else if(kind=='decl'){if(k.rel>=0){discK(k,1);decl(k,0);MAINK=MAINK||k}}
 else if(kind=='troops'){const n=Math.min(10,4+((k.n||0)/6|0));helpUnits(k,n);toast(k.name+' sends '+n+' soldiers to your castle');say(k.name+' answers your call.')}
 else if(kind=='war'){if(!T||T.owned)return;const n=Math.min(14,5+((k.n||0)/5|0));strikeUnits(k,T,n,360);k.xwT=t+110;k.xwN=0;toast(k.name+' marches '+n+' soldiers on '+T.name+'!');sfx('horn')}
 else if(kind=='peace'){if(k.rel<0){if(k.cast.hp<k.cast.mhp*.7||k.n<8||R()<.25){k.rel=0;if(MAINK===k)MAINK=null;toast(k.name+' accepts peace')}else toast(k.name+' refuses peace')}}
 else if(kind=='ally'){if(k.rel>0)toast('Already allied with '+k.name);else if(k.rel<0&&k.cast.hp>=k.cast.mhp*.6){toast(k.name+' spits on your offer');k.cool=t+40}
  else if(R()<.8){k.rel=1;toast(k.name+' is now your ally!');sfx('recruit')}else{toast(k.name+' declines for now');k.cool=t+25}}
 else if(kind=='scout'){toast('Scout: '+k.name+' · castle '+Math.max(0,k.cast.hp|0)+'/'+(k.cast.mhp|0)+' · '+(k.n|0)+' soldiers · Lv '+(k.lv||1));feed(k.name+': '+(k.n|0)+' soldiers')}}
function explore(k,m){discK(k,1);const lord=(k.hs&&(k.hs.ln||k.hs.n))||'';
 if(k.rel>=0&&m&&R()<.34){toast('✉ '+k._nm+' meets your rider with steel…');failMsg(m,false,{kg:k},1);return}
 toast('🔎 Found '+k._nm+(lord?' · ruled by Lord '+lord:'')+' · '+(k.n|0)+' soldiers');feed('Found '+k._nm);say('We have found '+k._nm+', my liege.')}
function alliesNow(){return KG.filter(k=>!k.owned&&k.rel==1)}
function stops(L,kind,T){return L.map(k=>({x:k.gx,y:k.gy,k,say:kind=='war'?'Rally to arms! Target: '+T.name:kind=='troops'?'We need your soldiers!':kind=='ally'?'My lord proposes an alliance.':kind=='peace'?'My lord asks for peace.':kind=='explore'?'We come in peace. Who rules these lands?':kind=='decl'?'My lord declares war upon you!':'Just passing through…',fn:(m)=>deliver(kind,k,T,m)}))}

/* PvP: delivering to lords */
function sendMk(P,F){const m={t:'mk',id:MP.id,to:P.id,tg:F.id,n:RULER||'Ally'};if(P.bot&&MP.host)botD(m);else mpSend(m);toast('📣 '+P.n+' is told to hit '+F.n)}
function pvStops(L,kind,F){return L.map(P=>({x:P.lx+180,y:P.ly,say:kind=='war'?'Hear me! Strike '+F.n+'!':kind=='troops'?'Send soldiers!':kind=='explore'?'I come in peace. Who rules here?':'Let me see your walls…',
 fn:(m)=>{if(P.out)return;if(kind=='troops')alAsk(P.id);else if(kind=='war')sendMk(P,F);
  else if(kind=='explore'){discP(P,1);if(PV.war&&P.tm!==ME.tm&&m&&R()<.34){toast('✉ The lord of '+P.kn+' cuts down your rider!');failMsg(m,false,P,0)}else{toast('🔎 Found '+P.n+' of '+P.kn);feed('Found '+P.n);say('We have found '+P.n+'.')}}
  else{toast('Scout: '+P.n+' · '+P.gu.size+' soldiers · castle '+(P.ck?Math.max(0,P.ck.hp|0):'?'));feed(P.n+': '+P.gu.size+' soldiers')}}}))}


/* UI */
const stName=k=>k.owned?'YOURS':k.rel<0?'WAR':k.rel>0?'ALLIED':'Neutral';
const btn=(fn,l)=>'<button onclick="'+fn+'" style="margin:2px">'+l+'</button>';
function escUI(){return '<p style="margin:6px 0 2px;font-size:8px;color:#e8b94a">Escort (guards defend the rider):</p>'+ESC.map((E,i)=>'<button onclick="xm.esc('+i+')" style="margin:2px;'+(i==EI?'background:#8a5a1a;border-color:#e8b94a':'')+'">'+E.n+' · '+E.c+'🪙</button>').join('')}
function msgUI(){
 if(!inGame)return;const e=$('ov');e.style.display='flex';let h='<div style="width:min(94vw,520px)"><div class="xh"><h3>✉ Messenger</h3><button onclick="ovx()">✕ Close</button></div>';
 h+='<p style="margin:4px 0;font-size:8px;color:#c9b88a">The messenger carries all diplomacy and explores unknown lands (max '+MAXM+' riders). Roads are dangerous: a lone rider is cheap but easily cut down.</p>'+escUI();
 if(PV.live){paused=0;
  const L=[...MP.peers.values()].filter(P=>!P.out),al=L.filter(P=>P.tm===ME.tm),fo=L.filter(P=>P.tm!==ME.tm);
  h+='<p style="margin:6px 0">🗺 '+fo.length+' rival lords fight in this war · '+fo.filter(P=>P.known).length+' found</p>';
  h+='<p style="margin:6px 0">🎯 Main enemy: <b>'+(X.mp?esc(X.mpN):'none')+'</b>'+(X.mp?' '+btn('xm.clr()','Clear'):'')+'</p>';
  if(al.length){h+='<b style="color:#e8b94a">Allies</b>'+btn('xm.pvAll(\'troops\')','📣 Ask all allies for troops');
   h+='<br>'+al.map(P=>'<span style="margin-right:6px">'+esc(P.n)+(P.bot?' 🤖':'')+' '+btn('xm.pv(\''+P.id+'\',\'troops\')','📣 Troops')+'</span>').join('')}
  if(fo.length){h+='<br><b style="color:#e8b94a">Rival lords</b>'+fo.map(P=>P.known?'<p style="margin:5px 0">'+esc(P.n)+(P.bot?' 🤖':'')+'<br>'+btn('xm.pv(\''+P.id+'\',\'scout\')','🔍 Scout')+(al.length?btn('xm.rally(\''+P.id+'\')','🎯 Rally allies against them'):'')+'</p>':'<p style="margin:5px 0">❓ '+esc(P.n)+'<br>'+btn('xm.pex(\''+P.id+'\')','🧭 Send explorer')+'</p>').join('')}
  if(!al.length&&!fo.length)h+='<p>No other lords are left.</p>'}
 else if(MPI){h+='<p>Messengers ride once the war begins.</p>'}
 else{paused=1;const al=alliesNow(),rv=KG.filter(k=>!k.owned),un=rv.filter(k=>!k.known),kn=KG.filter(k=>k.owned||k.known);
  h+='<p style="margin:6px 0">🗺 '+rv.length+' rival kingdoms rule this land · '+(rv.length-un.length)+' found</p>';
  h+='<p style="margin:6px 0">🎯 Main enemy: <b>'+(MAINK&&!MAINK.owned?MAINK.name:'none')+'</b>'+(MAINK&&!MAINK.owned?' '+btn('xm.clr()','Clear'):'')+'</p>';
  if(un.length)h+='<b style="color:#e8b94a">Unexplored lands</b>'+un.map(k=>'<p style="margin:5px 0">❓ '+k.name+'<br>'+btn('xm.ex('+KG.indexOf(k)+')','🧭 Send explorer')+'</p>').join('');
  if(al.length){h+='<br><b style="color:#e8b94a">Alliance ('+al.length+')</b><br>'+btn('xm.troops()','📣 Request troops from all allies')+'<br><span style="font-size:8px">Raise war on:</span><br>'
   +KG.filter(k=>!k.owned&&k.known&&k.rel!=1).map(k=>btn('xm.war('+KG.indexOf(k)+')','🎯 '+k.name)).join('')}
  h+='<br><b style="color:#e8b94a">Known kingdoms</b>'+(kn.length?kn.map(k=>{const i=KG.indexOf(k);return '<p style="margin:5px 0"><span style="display:inline-block;width:12px;height:12px;background:'+k.c1+';border:2px solid '+k.c2+'"></span> '+k.name+' · '+stName(k)+'<br>'
   +(k.owned?'':(k.rel==1?btn('xm.one('+i+',\'troops\')','📣 Troops'):k.rel<0?btn('xm.one('+i+',\'peace\')','🕊 Offer peace'):btn('xm.one('+i+',\'ally\')','🤝 Propose alliance'))+(k.rel>=0?btn('xm.one('+i+',\'decl\')','⚔ Declare war'):'')+btn('xm.one('+i+',\'scout\')','🔍 Scout'))+'</p>'}).join(''):'<p style="color:#e8b94a">No kingdom found yet. Send an explorer or ride out with your hero.</p>')}
 e.innerHTML=h+'</div>'}
function done(){ovx()}
window.xm={open(){msgUI()},esc(i){EI=i;msgUI()},ex(i){const k=KG[i];if(!k||k.known)return;if(launch('explore',stops([k],'explore',null)))done()},pex(id){const P=MP.peers.get(id);if(P&&launch('explore',pvStops([P],'explore',null)))done()},clr(){MAINK=null;X.mp=null;toast('Main enemy cleared');msgUI()},
 one(i,kind){const k=KG[i];if(launch(kind,stops([k],kind,null)))done()},
 troops(){if(launch('troops',stops(alliesNow(),'troops',null)))done()},
 war(i){const T=KG[i];if(!alliesNow().length)return toast('You have no allies to call');
  if(!launch('war',stops(alliesNow(),'war',T)))return;MAINK=T;if(T.rel>=0)decl(T,0);toast('🎯 '+T.name+' is now the main enemy');done()},
 pv(id,kind){const P=MP.peers.get(id);if(P&&launch(kind,pvStops([P],kind,null)))done()},
 pvAll(kind){const al=[...MP.peers.values()].filter(P=>!P.out&&P.tm===ME.tm);if(launch(kind,pvStops(al,kind,null)))done()},
 rally(id){const F=MP.peers.get(id),al=[...MP.peers.values()].filter(P=>!P.out&&P.tm===ME.tm);if(!F||!launch('war',pvStops(al,'war',F)))return;X.mp=F.id;X.mpN=F.n;toast('🎯 '+F.n+' is your main enemy');done()}};
(function(){const b=document.createElement('button');b.className='b';b.id='msg';b.textContent='✉ Messenger';b.addEventListener('pointerdown',e=>{e.preventDefault();msgUI()});$('brow').appendChild(b)})();

/* PvP: receiving a rally call, and bots following it */
const _mr=mpRecv;
mpRecv=function(m,from){_mr(m,from);
 if(m&&m.t=='mk'&&m.id!==MP.id&&(!m.to||m.to===MP.id)&&PV.live){const P=MP.peers.get(m.id);if(!P||P.tm!==ME.tm)return;
  const F=m.tg===MP.id?{id:MP.id,n:RULER||'You'}:MP.peers.get(m.tg);if(!F||F.out||F.tm===ME.tm)return;
  X.mp=F.id;X.mpN=F.n;toast('📣 '+P.n+' marks '+F.n+' as the MAIN ENEMY!');sfx('horn');say(P.n+' calls us to strike '+F.n+'.')}};
const _bd=botD;
botD=function(m){if(m.t=='mk'){const b=BOT[m.to];if(b&&!b.P.out){b.mt=m.tg;b.mtT=now()+160}return}_bd(m)};
const _bt=botTick;
botTick=function(dt,t){_bt(dt,t);for(const id in BOT){const b=BOT[id];if(!b.mt)continue;
  if(t>b.mtT){b.mt=null;continue}
  if(b.mt===MP.id){if(PC.hp>0&&!won&&ME.tm!==b.tm)b.tg={x:CX,y:CX};else b.mt=null}
  else{const P=MP.peers.get(b.mt);if(P&&!P.out&&P.tm!==b.tm)b.tg={x:P.lx,y:P.ly};else b.mt=null}}};

/* ---------- main enemy marker ---------- */
function marker(cx,cy){let tx,ty,nm;
 if(PV.live&&X.mp){const P=X.mp===MP.id?null:MP.peers.get(X.mp);if(!P||P.out){X.mp=null;return}tx=P.lx;ty=P.ly;nm=P.n}
 else if(MAINK&&!MAINK.owned){tx=MAINK.x;ty=MAINK.y;nm=MAINK.name}else return;
 const sx=tx-cx,sy=ty-cy-40,pad=16,on=sx>pad&&sx<VW-pad&&sy>pad&&sy<VH-pad,t=now(),bob=Math.sin(t*5)*2;
 c.textAlign='center';c.font='bold 8px monospace';
 if(on){c.fillStyle='#c0141c';c.beginPath();c.moveTo(sx,sy+8+bob);c.lineTo(sx-6,sy-2+bob);c.lineTo(sx+6,sy-2+bob);c.fill();c.fillStyle='#000';c.fillText('MAIN ENEMY',sx+1,sy-8+bob);c.fillStyle='#ff6a5a';c.fillText('MAIN ENEMY',sx,sy-9+bob)}
 else{const mx=VW/2,my=VH/2,dx=sx-mx,dy=sy-my,k=Math.min((mx-pad)/(Math.abs(dx)||1e-6),(my-pad)/(Math.abs(dy)||1e-6)),px=mx+dx*k,py=my+dy*k,a=Math.atan2(dy,dx);
  c.save();c.translate(px,py);c.rotate(a);c.fillStyle='#c0141c';c.beginPath();c.moveTo(8,0);c.lineTo(-5,-6);c.lineTo(-5,6);c.fill();c.restore();
  c.fillStyle='#000';c.fillText(nm,px+1,py-9);c.fillStyle='#ff9a8a';c.fillText(nm,px,py-10)}}

/* ---------- per-frame tick (hooked on the ambient pass) ---------- */
const _amb=ambient;
ambient=function(dt,cx,cy,b,dn){_amb(dt,cx,cy,b,dn);try{tick(dt,cx,cy)}catch(e){console.error(e)}};
function tick(dt,cx,cy){
 BUBR=[];if(!inGame){return}const t=now();
 if(dt>0){
  X.nb=0;ARM.forEach(u=>{if(u.bt>0){u.bt-=dt;if(u.bt>0)X.nb++}});
  stepConvs(dt);stepMsgs(dt);
  // marching: count soldiers currently stepping in time
  let c=0,mv=[];ARM.forEach(u=>{if(t-(u._mv||0)<.3&&!u.rl){c++;if(mv.length<40&&near(u))mv.push(u)}});
  const k=Math.floor(GP()/Math.PI);
  if(k!==X.k){X.k=k;if(c>=5)beat(k,c)}
  if(c>=8&&X.song&&t>X.lyr){X.lyr=t+4+R()*3;const n=Math.min(2,mv.length);for(let i=0;i<n;i++){const u=pick(mv),r=role(u);shout(u,pick(R()<.25?SONG.any:SONG[r]||SONG.any),'♪',3)}
   mv.forEach(u=>{if(R()<.2){u._em='♪';u._emt=t+2.5}})}
  // fights, grief, victory, morale
  if(t>X.cm){X.cm=t+.5;
   US.forEach(u=>{if(!u.dead||u._mn||u.type=='messenger')return;u._mn=1;
    if(!u.team){ARM.forEach(a=>{if(a!==u&&Math.abs(a.x-u.x)<70&&Math.abs(a.y-u.y)<50){a.mo=Math.max(.1,(a.mo===undefined?.6:a.mo)-.08);if(R()<.3)shout(a,pick(GRIEF),'…',2.4)}})}
    else{let q=0;ARM.forEach(a=>{if(!q&&Math.abs(a.x-u.x)<60&&Math.abs(a.y-u.y)<50)q=a});if(q){X.kills++;X.fight=t;q.mo=Math.min(1,(q.mo===undefined?.6:q.mo)+.04)}}});
   const calm=t-X.fight>3.5,anyEn=US.some(e=>e.team&&!e.dead&&(e.raid||!e.kg||e.kg.rel<0)&&Math.abs(e.x-H.x)<260&&Math.abs(e.y-H.y)<200);
   if(X.fight&&calm&&!anyEn&&X.kills>=2&&!X.vic){X.vic=1;X.kills=0;const L=ARM.filter(near);
    for(let i=0;i<Math.min(4,L.length);i++){const u=pick(L);shout(u,pick(CHEER),'★',3);u.mo=Math.min(1,(u.mo===undefined?.6:u.mo)+.15)}
    if(ac&&sb&&!muted)arp([392,523,659],'triangle',.05,130)}
   if(t-X.fight<1)X.vic=0;
   ARM.forEach(u=>{if(u.mo===undefined)u.mo=.6;let g=.55+(c>=8&&X.song&&t-(u._mv||0)<1?.15:0)+(u.rl?.25:0)+(Math.hypot(u.x-H.x,u.y-H.y)<120?.1:0)-(u.hp<u.mhp*.4?.25:0);u.mo+=(clamp(g,.1,1)-u.mo)*.25;
    if(u.rl&&!u.xcv&&R()<.01)shout(u,null,'☺',2)})}
  // allied kingdoms keep fighting for the main enemy
  if(MAINK&&!MAINK.owned&&MAINK.rel<0&&t>X.wvT){X.wvT=t+5;alliesNow().forEach(k=>{if(k.xwT&&t>k.xwT&&(k.xwN|0)<3){k.xwT=t+110;k.xwN=(k.xwN|0)+1;strikeUnits(k,MAINK,Math.min(8,3+((k.n||0)/8|0)),300);toast(k.name+' sends another wave against '+MAINK.name)}})}
  if(MAINK&&MAINK.owned){toast('🎯 '+MAINK.name+' has fallen!');MAINK=null}
 }
 marker(cx,cy);
}

/* ---------- HUD line, pause-menu toggle, tutorial text ---------- */
const _hud=hud;
hud=function(){_hud();const h=$('hud');if(!h)return;let s='';
 if(ARM.length){let m=0;ARM.forEach(u=>m+=u.mo===undefined?.6:u.mo);m/=ARM.length;s+='<span>'+(m>.72?'😄':m>.5?'🙂':m>.32?'😟':'😨')+'Morale '+(m>.72?'High':m>.5?'Steady':m>.32?'Shaky':'Broken')+'</span>'}
 const rl=ARM.filter(u=>u.rl).length;if(rl)s+='<span>🏰At ease '+rl+'</span>';
 if(MS.length)s+='<span>✉Riders '+MS.length+'</span>';
 const mn=PV.live?(X.mp?X.mpN:''):(MAINK&&!MAINK.owned?MAINK.name:'');if(mn)s+='<span style="color:#ff8a7a">🎯 '+esc(mn)+'</span>';
 h.querySelectorAll('.hx').forEach(e=>e.remove());if(s)h.insertAdjacentHTML('beforeend','<div class="hr hx">'+s+'</div>')};

/* ===== v15-5-11: BATTLE THEME — the march in D minor, faster and heavier, only during big fights =====
   Same key as the marching song (D minor), 144 bpm, war drums + galloping bass + brass-ish lead + string pad.
   Fades in on the first beat of a big fight, fades out ~6s after it ends. Soft filters, own gentle bus (no harsh peaks). */
const BT={on:0,en:1,t0:0,step:0,pass:0,calm:0,g:null};
try{if(localStorage.getItem('cor_btheme')==='0')BT.en=0}catch(e){}
const BMEL=[12,-99,12,10, 12,-99,15,-99,   15,-99,15,13, 15,-99,17,-99,   17,-99,17,15, 17,-99,19,-99,   14,-99,14,11, 14,-99,11,-99],
 BCH=[[0,3,7],[-4,0,3],[-2,2,5],[-5,-1,2]],BBS=[-12,-16,-14,-19],BSP=60/144/2,BD0=293.66;
const bF=n=>BD0*Math.pow(2,n/12);
function bbus(){if(BT.g&&BT.g.ctx===ac)return BT.g.g;const cp=ac.createDynamicsCompressor();cp.threshold.value=-16;cp.ratio.value=4;const g=ac.createGain();g.gain.value=0;g.connect(cp);cp.connect(ac.destination);BT.g={ctx:ac,g};return g}
function bN(f,t,d,ty,v,lp,at){const o=ac.createOscillator(),g=ac.createGain(),fl=ac.createBiquadFilter();o.type=ty;o.frequency.value=f;fl.type='lowpass';fl.frequency.value=lp;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+at);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(fl);fl.connect(g);g.connect(bbus());o.start(t);o.stop(t+d+.03)}
function bDr(t,v,f0,f1,d){const o=ac.createOscillator(),g=ac.createGain();o.type='sine';o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(f1,t+d);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(bbus());o.start(t);o.stop(t+d+.03)}
function bNs(t,d,v,fq){const s=ac.createBufferSource(),fl=ac.createBiquadFilter(),g=ac.createGain();s.buffer=nb;s.loop=true;fl.type='bandpass';fl.frequency.value=fq;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);s.connect(fl);fl.connect(g);g.connect(bbus());s.start(t,Math.random()*.5);s.stop(t+d+.03)}
function bStep(s,t,p){const bar=s>>3,e=s&7,odd=p&1;
 if(e==0)bDr(t,.55,115,45,.38);else if(e==4)bDr(t,.42,105,45,.3);else if(e==2||e==6)bDr(t,.24,150,62,.2);
 if(e==3||e==7)bNs(t,.09,.13,2100);else if(e==5)bNs(t,.06,.05,2600);
 if(s==30||s==31)bDr(t,.3,140,60,.16);
 if(e==0||e==2||e==3||e==4||e==6||e==7){const n=BBS[bar]+(e==3||e==7?12:0);bN(bF(n),t,.22,'triangle',.15,520,.01)}
 if(e==0)BCH[bar].forEach(n=>bN(bF(n),t,1.7,'triangle',.05,1200,.28));
 const m=BMEL[s];if(m>-90){bN(bF(m),t,.3,'sawtooth',.085,1900,.02);if(odd)bN(bF(m+12),t,.3,'sine',.035,3000,.02)}}
function bSched(){if(!BT.on||!ac||!nb)return;const cur=ac.currentTime,lim=cur+.4;if(BT.t0<cur-.1)BT.t0=cur+.05;
 while(BT.t0<lim){bStep(BT.step,BT.t0,BT.pass);BT.t0+=BSP;if(++BT.step>=32){BT.step=0;BT.pass++}}}
function bStart(){const g=bbus();BT.on=1;window.BTON=1;BT.step=0;BT.pass=0;BT.t0=ac.currentTime+.05;g.gain.cancelScheduledValues(ac.currentTime);g.gain.setTargetAtTime(1,ac.currentTime,.35)}
function bStop(){BT.on=0;window.BTON=0;if(BT.g&&BT.g.ctx===ac){BT.g.g.gain.cancelScheduledValues(ac.currentTime);BT.g.g.gain.setTargetAtTime(0,ac.currentTime,.9)}}
setInterval(()=>{try{bSched()}catch(e){}},90);
setInterval(()=>{try{
 if(!BT.en||!ac||!nb||muted||!inGame||paused||won){if(BT.on)bStop();return}
 const R2=380*380;let n=0,gn=0,md=1e9;
 for(let i=0;i<US.length;i++){const u=US[i];if(u.dead||!(u.atk>.2))continue;const dx=u.x-H.x,dy=u.y-H.y;if(dx*dx+dy*dy<R2)n++}
 if(PV.on&&PV.war)ghostTargets().forEach(g=>{if(g.hp<=0)return;const dx=g.x-H.x,dy=g.y-H.y,d2=dx*dx+dy*dy;if(d2<340*340){gn++;if(d2<md)md=d2}});
 const big=n>=8||(gn>=10&&md<220*220)||(window.CINK||0)>.5,t=now();
 if(big){BT.calm=t;if(!BT.on)bStart()}else if(BT.on&&t-BT.calm>6)bStop()
}catch(e){}},400);
const _pm2=pzMenu;
pzMenu=function(){_pm2();const p=document.querySelector('#pz .pn');if(!p)return;const q=[...p.querySelectorAll('button')].pop(),b=document.createElement('button');
 b.textContent=X.song?'🎶 Marching songs: On':'🎶 Marching songs: Off';b.onclick=function(){X.song=X.song?0:1;try{localStorage.setItem('cor_song',X.song?'1':'0')}catch(e){}b.textContent=X.song?'🎶 Marching songs: On':'🎶 Marching songs: Off'};p.insertBefore(b,q);const b2=document.createElement('button'),l2=()=>{b2.textContent=BT.en?'⚔ Battle theme: On':'⚔ Battle theme: Off'};l2();b2.onclick=function(){BT.en=BT.en?0:1;if(!BT.en&&BT.on)bStop();try{localStorage.setItem('cor_btheme',BT.en?'1':'0')}catch(e){}l2()};p.insertBefore(b2,q)};
})();
