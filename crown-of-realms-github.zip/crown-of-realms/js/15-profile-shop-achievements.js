(function(){
'use strict';
const G=f=>{try{return f()}catch(e){}},clamp=(v,a,b)=>v<a?a:v>b?b:v,KEY='cor_prof',CH='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const blank=()=>{let s='';for(let i=0;i<6;i++)s+=CH[Math.random()*CH.length|0];return{v:1,pid:s,name:'',av:'a_l0',title:'',crests:0,xp:0,own:[],eq:{unit:'u_0',kd:'k_0',lord:{},wp:{}},ach:{},L:{},wl:[],friends:[],req:[],out:[]}};
let P=(()=>{let o=null;try{o=JSON.parse(localStorage.getItem(KEY))}catch(e){}const b=blank();if(!o||o.v!=1||typeof o.pid!='string')return b;for(const k in b)if(o[k]===undefined)o[k]=b[k];return o})();
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(P))}catch(e){}};save();
const S={kills:0,built:0,recruits:0,conq:0,loots:0,merch:0,mounts:0,deaths:0,minutes:0,armyMax:0,allies:0,sec:0,started:0,done:0};
const SUM=['kills','built','recruits','conq','loots','merch','mounts','deaths','minutes'],MAXK=['armyMax','allies'];
const cul=()=>(window.HI|0),CUN=['Crusader','Shogun','Roman','Tibetan'];
/* ---------- level / rank ---------- */
const need=l=>100+l*45;
function lvInfo(xp){let l=1;while(l<99&&xp>=need(l)){xp-=need(l);l++}return{l,cur:xp,nd:need(l)}}
const LV=()=>lvInfo(P.xp).l;
const RANKS=[[1,'Peasant'],[3,'Squire'],[6,'Man-at-Arms'],[10,'Knight'],[15,'Banneret'],[21,'Baron'],[28,'Count'],[36,'Duke'],[45,'Prince'],[55,'King'],[70,'Emperor']];
const rankOf=l=>{let r=RANKS[0][1];for(const[x,n]of RANKS)if(l>=x)r=n;return r};
function addXP(n){const a=LV();P.xp+=Math.max(0,n|0);const b=LV();if(b>a){P.crests+=20*(b-a);if(inGame&&!S.done){toast('⬆ Level '+b+': '+rankOf(b)+' (+'+20*(b-a)+' 💠)');sfx('win')}}return b-a}
/* ---------- catalog ---------- */
const CAT={
unit:[{id:'u_0',n:'Standard Colours',price:0},
{id:'u_ember',n:'Ember Legion',c1:'#c0392b',c2:'#f3d27a',price:150,lv:1},
{id:'u_verd',n:'Verdant Guard',c1:'#2a8a4a',c2:'#e8e04a',price:150,lv:1},
{id:'u_ivory',n:'Ivory Host',c1:'#e8e8ee',c2:'#b01c1c',price:250,lv:3},
{id:'u_mid',n:'Midnight Order',c1:'#1a1a2e',c2:'#8ab0ff',price:250,lv:3},
{id:'u_viol',n:'Violet Coven',c1:'#7a3a9a',c2:'#f0c0f0',price:300,lv:5},
{id:'u_sun',n:'Sunforge Company',c1:'#d08a20',c2:'#2a1a05',price:300,lv:5},
{id:'u_frost',n:'Frostborne',c1:'#9ad0e8',c2:'#ffffff',price:400,lv:8},
{id:'u_obs',n:'Obsidian Elite',c1:'#222228',c2:'#e8b94a',price:600,lv:10},
{id:'u_gold',n:'Royal Gold Guard',c1:'#e8b94a',c2:'#7a1a1a',price:900,lv:14}],
lord:[],
kd:[{id:'k_0',n:'Standard Realm',price:0},
{id:'k_sand',n:'Sandstone Sultanate',st:['#d2a86a','#ecca90','#9a7440'],roof:'#2a8a9a',price:400,lv:3},
{id:'k_iron',n:'Ironhold Fortress',st:['#7a7a88','#a8a8b8','#55556a'],roof:'#8a2a2a',price:500,lv:5},
{id:'k_emer',n:'Emerald Keep',st:['#a8b8a0','#c8d8c0','#6a7a62'],roof:'#2a8a4a',price:500,lv:5},
{id:'k_frost',n:'Frostspire Citadel',st:['#c8d4e0','#e8f0f8','#8a9ab0'],roof:'#4a8ad0',price:650,lv:8},
{id:'k_obs',n:'Obsidian Bastion',st:['#3a3a48','#5a5a6c','#22222c'],roof:'#7a2a9a',price:800,lv:10},
{id:'k_royal',n:'Royal Gold Palace',st:['#e0c070','#f8e4a0','#a88a40'],roof:'#b01c1c',price:1100,lv:15}],
wp:[]};
const LS=[[['Templar Dawn','#f0ece0','#d4af37'],['Black Prince','#22222c','#b01c1c'],['Lionheart Azure','#2a4a9a','#e8c040']],
[['Ronin Ash','#4a4a55','#c8c8d0'],['Jade Shogun','#1f6a4a','#e8d070'],['Golden Tiger','#d8a020','#1a1a22']],
[['Praetorian Black','#2a2a30','#d8b040'],['Imperial Purple','#6a2a8a','#e8c050'],['Legate Silver','#c8ccd4','#8a1a14']],
[['Saffron Monk','#e08a1a','#7a1a1a'],['Snow Leopard','#e8eef4','#4a6a8a'],['Dragon Thunder','#2a6a8a','#e8b94a']]];
const WS=[['Pilgrim’s Blade','Templar Longsword','Lionheart’s Edge','Holy Avenger'],['Kaji Katana','Moonlit Katana','Crimson Tsurugi','Dragon-Fang Katana'],['Soldier’s Gladius','Legatus Gladius','Bronze Eagle Gladius','Gladius of Jove'],['Highland Sabre','Mountain Sabre','Thunder Sabre','Dragon-King Sabre']];
const WB=[['','#cfe0ff','#ffe27a','#fff6c0'],['','#bfe8ff','#ff6a6a','#8affc8'],['','#e0e0e8','#e8b060','#c8a0ff'],['','#d8f0ff','#ffe050','#ff9ae0']];
for(let c=0;c<4;c++){CAT.lord.push({id:'l'+c+'_0',cu:c,n:'Heraldic Colours',price:0,def:1});LS[c].forEach((s,i)=>CAT.lord.push({id:'l'+c+'_'+(i+1),cu:c,n:s[0],c1:s[1],c2:s[2],price:[300,450,600][i],lv:[2,5,9][i]}));
 for(let t=0;t<4;t++)CAT.wp.push({id:'w'+c+'_'+t,cu:c,tier:t,n:WS[c][t],bonus:[0,.05,.1,.15][t],bl:WB[c][t],price:[0,250,600,1100][t],lv:[1,3,8,15][t]})}
const ALLI=[].concat(CAT.unit,CAT.lord,CAT.kd,CAT.wp),findIt=id=>ALLI.find(x=>x.id==id);
const isOwn=it=>!it.price||P.own.includes(it.id);
const eqUnit=()=>findIt(P.eq.unit)||CAT.unit[0],eqKd=()=>findIt(P.eq.kd)||CAT.kd[0];
const eqLord=c=>findIt(P.eq.lord[c]||'l'+c+'_0'),curWp=()=>{const c=cul();return findIt(P.eq.wp[c]||'w'+c+'_0')};
const wpBonus=()=>{const w=curWp();return w?w.bonus:0};
window.MWBL=()=>{const w=curWp();return w&&w.bl||''};
/* ---------- portraits (rendered with the game's own soldier engine) ---------- */
const PCH={};
function portrait(key,o,cx,cy,w,h){if(PCH[key])return PCH[key];
 const k=document.createElement('canvas');k.width=64;k.height=64;const g=k.getContext('2d'),prev=Z;Z=g;
 try{Zman(Object.assign({x:32,y:54,f:1,sc:1,t:0,sd:1,mv:0,ph:0,fl:0,up:0,atk:-1,wp:-1,ride:0},o))}catch(e){}finally{Z=prev}
 const out=document.createElement('canvas');out.width=w;out.height=h;const q=out.getContext('2d');const bg=q.createLinearGradient(0,0,0,h);bg.addColorStop(0,'#3a2c54');bg.addColorStop(1,'#1a1226');q.fillStyle=bg;q.fillRect(0,0,w,h);q.drawImage(k,cx,cy,w,h,0,0,w,h);return PCH[key]=out.toDataURL()}
const lordO=(c,c1,c2)=>({st:ZHERO[c],col:c1,acc:c2,wep:'sword',wv:ZHW[c],jp:c==1,cape:c2,hs:1.05,sc:1.12});
const AV=[{id:'a_l0',n:'Crusader Lord',lord:0},{id:'a_l1',n:'Shogun Lord',lord:1},{id:'a_l2',n:'Roman Lord',lord:2},{id:'a_l3',n:'Tibetan Lord',lord:3},
{id:'a_knight',n:'Knight',u:'knight',col:'#8a1a2a',acc:'#c0c0c8',wep:'sword',lv:3},{id:'a_archer',n:'Archer',u:'archer',col:'#6a5a2a',acc:'#c8a050',lv:3},
{id:'a_farm',n:'Farmer',u:'farmer',col:'#6a8a3a',acc:'#e8d070',lv:5},{id:'a_miner',n:'Miner',u:'miner',col:'#5a5a6a',acc:'#c0c0c8',lv:5},{id:'a_build',n:'Builder',u:'builder',col:'#8a6a3a',acc:'#c8a050',lv:5},
{id:'a_saru',n:'Samurai',u:'saru',col:'#a82a2a',acc:'#1a1a22',wep:'sword',lv:10},{id:'a_legi',n:'Legionary',u:'legi',col:'#a02020',acc:'#d8b040',wep:'sword',lv:10},
{id:'a_brute',n:'Brute',u:'brute',col:'#5a3a6a',acc:'#c8a050',lv:12},{id:'a_tarc',n:'Highlander',u:'tarc',col:'#7a2a6a',acc:'#e8b94a',lv:15},{id:'a_crus',n:'Crusader',u:'crus',col:'#e8e8ee',acc:'#b01c1c',wep:'sword',lv:20},
{id:'a_king',n:'The Crowned',u:'lord',col:'#d4af37',acc:'#ffffff',wep:'sword',ach:'w1'},{id:'a_duel',n:'Duelist',u:'knight',col:'#2a2a30',acc:'#e8b94a',wep:'sword',ach:'pg'}];
const avOK=a=>a.ach?!!P.ach[a.ach]:(a.lv?LV()>=a.lv:1),avOf=id=>AV.find(a=>a.id==id)||AV[0];
function avUrl(id){const a=avOf(id);return G(()=>{if(a.lord!==undefined){const h=HS[a.lord];return portrait('A'+a.id,lordO(a.lord,h.c1,h.c2),14,22,36,36)}
 return portrait('A'+a.id,{st:ZMS[a.u]||ZMS.villager,col:a.col,acc:a.acc,wep:a.wep||null,cape:a.acc,sc:1},14,22,36,36)})||''}
/* ---------- kingdom skin sprites ---------- */
const BASE={keep:TX.keep,tower:TX.tower,wall:TX.wall},KSP={};
function recolor(src,map){const k=document.createElement('canvas');k.width=src.width;k.height=src.height;const g=k.getContext('2d');g.drawImage(src,0,0);const im=g.getImageData(0,0,k.width,k.height),d=im.data,m=new Map(map.map(([a,b])=>[parseInt(a.slice(1),16),parseInt(b.slice(1),16)]));
 for(let i=0;i<d.length;i+=4){if(!d[i+3])continue;const v=m.get(d[i]<<16|d[i+1]<<8|d[i+2]);if(v!==undefined){d[i]=v>>16;d[i+1]=v>>8&255;d[i+2]=v&255}}g.putImageData(im,0,0);return k}
function kdSpr(it){if(!it.st)return null;if(KSP[it.id])return KSP[it.id];const s=it.st,r=it.roof;
 return KSP[it.id]={keep:recolor(BASE.keep,[['#b8a07c',s[0]],['#d8c29e',s[1]],['#86694c',s[2]],['#4a7ac8',Zsh(r,1.35)],['#1e4380',Zsh(r,.7)]]),
  tower:recolor(BASE.tower,[['#bda07c',s[0]],['#d8c29e',s[1]],['#8a6e50',s[2]],['#2a5aa8',r]]),wall:recolor(BASE.wall,[['#bda07c',s[0]],['#d8c29e',s[1]],['#8a6e50',s[2]]])}}
let kdOn=0;
function applyKd(){const sp=kdSpr(eqKd());if(!sp&&!kdOn)return;kdOn=sp?1:0;
 PC.img=sp?sp.keep:BASE.keep;
 objs.forEach(o=>{if(o.k=='tower'&&!o.gh&&!o.kg)o.img=sp?sp.tower:BASE.tower});
 WALLS.forEach(w=>{const o=w.o;if(!o||w.gt)return;if(sp){if(o._oi===undefined)o._oi=o.img;o.img=sp.wall}else if(o._oi!==undefined){o.img=o._oi;o._oi=undefined}})}
/* ---------- hooks into the game ---------- */
const _zhs=Zhs;Zhs=function(){const h=_zhs(),s=eqLord(cul());return s&&s.c1?{c1:s.c1,c2:s.c2}:h};
const _du=drawU;drawU=function(u,x,y){const sk=eqUnit();if(sk.c1&&!u.team&&!u.kg){const a=PB.c1,b=PB.c2;PB.c1=sk.c1;PB.c2=sk.c2;try{_du(u,x,y)}finally{PB.c1=a;PB.c2=b}}else _du(u,x,y)};
const _hu=hurt;hurt=function(tg,dmg,from){if(!tg)return _hu(tg,dmg,from);
 if(from===H&&!PV.on&&!tg.gh)dmg*=1+wpBonus();
 const was=!tg.dead&&tg.hp>0,hp0=tg.hp;_hu(tg,dmg,from);
 if(inGame&&S.started&&!S.done){if(tg===H){if(H.hp>hp0)S.deaths++}else if(was&&(tg.team||tg.gh)&&(tg.dead||tg.hp<=0)&&from&&(from===H||from.team===0))S.kills++}};
const _cq=conquer;conquer=function(k){_cq(k);if(inGame&&!S.done)S.conq++};
const _bl=bld;bld=function(s){_bl(s);if(inGame&&S.started&&!S.done)S.built++};
const _mku=mku;mku=function(team,type,x,y,o){const u=_mku(team,type,x,y,o);if(team===0&&inGame&&S.started&&!S.done&&!o)S.recruits++;return u};
const _act=act;act=function(){const o=near,d0=o&&o.done;_act();if(o&&!d0&&o.done&&(o.k=='village'||o.k=='den')&&!S.done)S.loots++};
const _mb=merBuy;merBuy=function(i){const w=H.wt|0;_mb(i);if((H.wt|0)>w&&!S.done)S.merch++};
const _mn=mnt;mnt=function(){_mn();if(H.m&&!S.done)S.mounts=1};
/* ---------- achievements ---------- */
const V=k=>(P.L[k]||0)+(S[k]||0),A=k=>Math.max(P.L[k]||0,S[k]||0),Lk=k=>P.L[k]||0;
const ACH=[
{id:'fb',n:'First Blood',d:'Defeat your first foe',v:()=>V('kills'),g:1,c:10,x:20,t:'Newblood'},
{id:'k100',n:'Slayer',d:'Defeat 100 foes',v:()=>V('kills'),g:100,c:40,x:60,t:'Slayer'},
{id:'k1000',n:'Warlord',d:'Defeat 1,000 foes',v:()=>V('kills'),g:1000,c:200,x:300,t:'Warlord'},
{id:'b25',n:'Mason',d:'Raise 25 buildings',v:()=>V('built'),g:25,c:30,x:40,t:'Mason'},
{id:'b150',n:'Master Builder',d:'Raise 150 buildings',v:()=>V('built'),g:150,c:120,x:150,t:'Architect'},
{id:'r50',n:'Recruiter',d:'Recruit 50 soldiers',v:()=>V('recruits'),g:50,c:30,x:40,t:'Captain'},
{id:'a100',n:'The Horde',d:'Command an army of 100',v:()=>A('armyMax'),g:100,c:80,x:100,t:'Warchief'},
{id:'c1',n:'Conqueror',d:'Capture a rival kingdom',v:()=>V('conq'),g:1,c:60,x:80,t:'Conqueror'},
{id:'c10',n:'Overlord',d:'Capture 10 kingdoms',v:()=>V('conq'),g:10,c:250,x:300,t:'Overlord'},
{id:'ally',n:'Diplomat',d:'Ally with a rival kingdom',v:()=>A('allies'),g:1,c:30,x:40,t:'Diplomat'},
{id:'w1',n:'Crowned',d:'Win a solo reign',v:()=>Lk('swins'),g:1,c:100,x:120,t:'The Crowned'},
{id:'w5',n:'High King',d:'Win 5 solo reigns',v:()=>Lk('swins'),g:5,c:300,x:400,t:'High King'},
{id:'hell',n:'Hellbringer',d:'Win on Hell difficulty',v:()=>Lk('hell'),g:1,c:400,x:500,t:'Hellbringer'},
{id:'nd',n:'Untouchable',d:'Win without your hero ever falling',v:()=>Lk('nodeath'),g:1,c:150,x:200,t:'Untouchable'},
{id:'fast',n:'Swift Crown',d:'Win a solo reign in under 20 minutes',v:()=>Lk('fast'),g:1,c:150,x:200,t:'Swift'},
{id:'loot',n:'Plunderer',d:'Loot 10 villages or dens',v:()=>V('loots'),g:10,c:40,x:60,t:'Plunderer'},
{id:'mer',n:'Patron',d:'Buy from a travelling merchant',v:()=>V('merch'),g:1,c:30,x:40,t:'Patron'},
{id:'ride',n:'Horselord',d:'Ride a horse into battle',v:()=>V('mounts'),g:1,c:20,x:30,t:'Horselord'},
{id:'pg',n:'Duelist',d:'Win a PvP match',v:()=>Lk('pwins'),g:1,c:120,x:150,t:'Duelist'},
{id:'pg5',n:'Champion',d:'Win 5 PvP matches',v:()=>Lk('pwins'),g:5,c:350,x:450,t:'Champion'},
{id:'time',n:'Veteran',d:'Play for 300 minutes',v:()=>Math.floor(V('minutes')),g:300,c:150,x:200,t:'Veteran'},
{id:'l10',n:'Rising Star',d:'Reach level 10',v:LV,g:10,c:80,x:0,t:'Rising Star'},
{id:'l25',n:'Legend',d:'Reach level 25',v:LV,g:25,c:250,x:0,t:'Legend'},
{id:'fr1',n:'Companion',d:'Make a friend',v:()=>P.friends.length,g:1,c:30,x:40,t:'Companion'},
{id:'fr5',n:'Beloved',d:'Have 5 friends',v:()=>P.friends.length,g:5,c:100,x:120,t:'Beloved'},
{id:'shop',n:'Fashion of Kings',d:'Own 10 shop items',v:()=>P.own.length,g:10,c:100,x:100,t:'Dandy'}];
function chk(){const got=[];let again=1,n=0;
 while(again&&n++<3){again=0;ACH.forEach(a=>{if(P.ach[a.id])return;let v=0;try{v=a.v()}catch(e){}
  if(v>=a.g){P.ach[a.id]=Date.now();P.crests+=a.c;addXP(a.x);got.push(a);again=1;if(inGame&&!S.done)toast('🏆 '+a.n+' (+'+a.c+' 💠)')}})}
 if(got.length){save();updChip();if(open)render()}return got}
const titleTxt=()=>{const a=ACH.find(x=>x.id==P.title&&P.ach[x.id]);return a?a.t:''};
/* ---------- game completion rewards ---------- */
let RES=null;
function finish(){S.done=1;
 const win=PC.hp>0,pvp=!!PV.live,peers=pvp?[...MP.peers.values()]:[],bots=pvp&&peers.length&&peers.every(p=>p.bot),min=S.sec/60,ok=S.sec>=(pvp?60:120),dl=clamp(+(G(()=>localStorage.getItem('cor_lvl'))||1)|0,0,3),rows=[];
 let coins=0;const RKD={ok,win,pvp,bots,peers:peers.length,hum:peers.filter(p=>!p.bot).length,min,dl,kills:S.kills,conq:S.conq,deaths:S.deaths};
 if(ok){const kb=Math.min(win?80:40,Math.floor(S.kills/(win?3:5)));
  if(pvp){if(win){rows.push(['Last crown standing',150],['Rivals defeated ('+peers.length+')',peers.length*40])}else rows.push(['Fought to the end',30])}
  else if(win){rows.push(['Sole ruler of the continent',120]);if(S.conq)rows.push(['Kingdoms taken ('+S.conq+')',S.conq*50]);if(dl)rows.push([['','Pro','Expert','Hell'][dl]+' difficulty',[0,20,50,100][dl]]);if(!S.deaths)rows.push(['Hero never fell',30])}
  else{rows.push(['Castle lost',15]);const tb=Math.min(60,Math.floor(min*3));if(tb)rows.push(['Time survived',tb])}
  if(kb)rows.push(['Foes slain ('+S.kills+')',kb]);
  coins=rows.reduce((a,r)=>a+r[1],0);
  if(bots){coins=Math.round(coins*.6);rows.push(['Bot-only match (×0.6)',null])}}
 const xp=ok?Math.round(coins*.9)+(win?60:20):0,l0=lvInfo(P.xp).l;
 P.crests+=coins;
 if(ok){P.L.games=(P.L.games||0)+1;if(win){if(pvp)P.L.pwins=(P.L.pwins||0)+1;else{P.L.swins=(P.L.swins||0)+1;if(dl==3)P.L.hell=(P.L.hell||0)+1;if(!S.deaths)P.L.nodeath=(P.L.nodeath||0)+1;if(min<20)P.L.fast=(P.L.fast||0)+1;const h=cul();if(!P.wl.includes(h))P.wl.push(h)}}}
 SUM.forEach(k=>{P.L[k]=(P.L[k]||0)+S[k];S[k]=0});MAXK.forEach(k=>{P.L[k]=Math.max(P.L[k]||0,S[k])});
 addXP(xp);const newA=chk();save();updChip();
 RES={win,pvp,ok,coins,xp,rows,min,l0,l1:LV(),newA};try{RES.rk=window.RK&&RK.record(RKD)}catch(e){console.error(e)}
 setTimeout(()=>openMT('res'),1300)}
/* ---------- friends over PeerJS (needs both players online) ---------- */
const FR={pend:{},peer:null,ok:0,st:'Connecting…',on:{},inv:[],q:null,ld:0},PIDRE=/^[A-Z0-9]{6}$/;
const meMsg=(t,x)=>Object.assign({t,pid:P.pid,n:P.name||G(()=>RULER)||'Lord',av:P.av,lv:LV(),ti:titleTxt()},x||{});
const isFriend=pid=>P.friends.some(f=>f.pid==pid);
function peerJS(cb){if(window.Peer)return cb();if(FR.ld){FR.q.push(cb);return}FR.ld=1;FR.q=[cb];const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/peerjs@1.5.4/dist/peerjs.min.js';s.onload=()=>FR.q.forEach(f=>f());s.onerror=()=>{FR.st='Offline: friends need an internet connection';FR.ld=0;if(open)render()};document.head.appendChild(s)}
function startPresence(){if(FR.peer)return;try{const p=new Peer('corf-'+P.pid,{config:{iceServers:[{urls:'stun:stun.l.google.com:19302'},{urls:'stun:stun.cloudflare.com:3478'},{urls:['turn:openrelay.metered.ca:80','turn:openrelay.metered.ca:443','turn:openrelay.metered.ca:443?transport=tcp'],username:'openrelayproject',credential:'openrelayproject'}]}});FR.peer=p;
 p.on('open',()=>{FR.ok=1;FR.st='Online';pingAll();if(open)render()});
 p.on('connection',c=>{c.on('data',d=>onMsg(d,c))});
 p.on('disconnected',()=>{FR.ok=0;FR.st='Reconnecting…';try{p.reconnect()}catch(e){}});
 p.on('error',e=>{if(e.type=='unavailable-id'){FR.st='Reconnecting…';FR.ok=0;FR.peer=null;try{p.destroy()}catch(x){}if((FR.tries=(FR.tries||0)+1)<8)setTimeout(startPresence,3000+FR.tries*1500)}else if(e.type=='peer-unavailable'){const m=/corf-([A-Z0-9]{6})/.exec(e.message||'');if(m&&FR.pend[m[1]])FR.pend[m[1]](0)}else if(e.type=='network'||e.type=='server-error'||e.type=='socket-error'){FR.st='Network issue, retrying…';FR.ok=0;FR.peer=null;try{p.destroy()}catch(x){}setTimeout(startPresence,5000)}if(open)render()})}catch(e){FR.st='Friends unavailable'}}
function sendTo(pid,msg,cb){if(!FR.ok||!FR.peer){cb&&cb(0);return}let done=0,c;const fin=r=>{if(done)return;done=1;clearTimeout(to);delete FR.pend[pid];cb&&cb(r)};
 FR.pend[pid]=fin;const to=setTimeout(()=>{fin(0);try{c&&c.close()}catch(e){}},12000);
 try{c=FR.peer.connect('corf-'+pid,{serialization:'json',reliable:true})}catch(e){fin(0);return}
 c.on('open',()=>{try{c.send(msg)}catch(e){fin(0);return}
  if(msg.t=='pg'){c.on('data',d=>{onMsg(d,c);fin(1);setTimeout(()=>{try{c.close()}catch(e){}},300)})}else if(msg.t=='fr'){c.on('data',d=>onMsg(d,c));fin(1);setTimeout(()=>{try{c.close()}catch(e){}},4000)}else{fin(1);setTimeout(()=>{try{c.close()}catch(e){}},900)}});
 c.on('error',()=>fin(0))}
function pingAll(){if(!FR.ok)return;P.friends.map(f=>[f.pid,'pg']).concat(P.out.map(o=>[o,'fr'])).slice(0,30).forEach(([pid,t],i)=>setTimeout(()=>sendTo(pid,meMsg(t)),i*350))}
function addFriend(i){const f=P.friends.find(x=>x.pid==i.pid);if(f){Object.assign(f,{n:i.n,av:i.av,lv:i.lv,ti:i.ti})}else if(P.friends.length<50){P.friends.push({pid:i.pid,n:i.n,av:i.av,lv:i.lv,ti:i.ti});toast('👥 '+i.n+' is now your friend');sfx('recruit')}
 P.req=P.req.filter(r=>r.pid!=i.pid);P.out=P.out.filter(p=>p!=i.pid);save();chk();updChip();if(open)render()}
function onMsg(d,c){if(!d||typeof d.pid!='string'||!PIDRE.test(d.pid)||d.pid===P.pid)return;
 const i={pid:d.pid,n:esc(d.n||'Player').slice(0,14)||'Player',av:AV.some(a=>a.id==d.av)?d.av:'a_l0',lv:clamp(d.lv|0,1,99),ti:esc(d.ti||'').slice(0,20)};
 switch(d.t){
 case 'fr':if(isFriend(i.pid)||P.out.includes(i.pid)){addFriend(i);try{c.send(meMsg('fa'))}catch(e){}}
  else if(!P.req.some(r=>r.pid==i.pid)&&P.req.length<20){P.req.push(i);save();toast('📨 Friend request from '+i.n);sfx('horn');updChip();if(open)render()}break;
 case 'fa':if(P.out.includes(i.pid)||isFriend(i.pid))addFriend(i);break;
 case 'pg':{const f=isFriend(i.pid);if(f)addFriend(i);try{c.send(meMsg('po',{f:f?1:0}))}catch(e){}break}
 case 'po':FR.on[i.pid]=Date.now();if(isFriend(i.pid)||(d.f&&P.out.includes(i.pid)))addFriend(i);if(open&&tab=='fr')render();break;
 case 'fx':P.friends=P.friends.filter(f=>f.pid!=i.pid);P.req=P.req.filter(r=>r.pid!=i.pid);save();if(open)render();break;
 case 'iv':if(isFriend(i.pid)&&/^[A-Z0-9]{4,8}$/.test(d.code||'')){FR.inv=FR.inv.filter(v=>v.pid!=i.pid);FR.inv.push({pid:i.pid,n:i.n,code:d.code,t:Date.now()});toast('✉ '+i.n+' invites you to a PvP lobby');sfx('horn');updChip();if(open)render()}break}}
function reqFriend(code){code=String(code||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
 if(!PIDRE.test(code))return toast('A friend code has 6 letters/digits');if(code===P.pid)return toast('That is your own code');
 if(isFriend(code))return toast('Already friends');if(!FR.ok){if(!P.out.includes(code)){P.out.push(code);save()}if(!FR.peer)peerJS(startPresence);return toast('Not connected yet. Request saved and will send when online.')}
 toast('Sending request…');if(!P.out.includes(code)){P.out.push(code);save()}sendTo(code,meMsg('fr'),r=>{toast(r?'📨 Request sent. They must accept it.':'📨 Saved. It will be delivered when they open the game online.');if(open)render()})}
/* ---------- UI ---------- */
const root=document.createElement('div');root.id='pgm';document.body.appendChild(root);
let open=0,tab='prof',stab='unit';
function openMT(t,s){tab=t||'prof';if(s)stab=s;open=1;render();root.style.display='flex';if(tab=='fr')peerJS(()=>{if(!FR.peer)startPresence();else pingAll()})}
function closeMT(){open=0;root.style.display='none';updChip()}
addEventListener('keydown',e=>{if(open&&e.key=='Escape'){e.stopImmediatePropagation();closeMT()}},true);
const ks='onkeydown="event.stopPropagation()"';
function render(){const L=lvInfo(P.xp);let body='';
 if(tab=='res')body=resBody();else{
  const T=[['prof','👤 Profile'],['shop','🛒 Shop'],['ach','🏆 Deeds'],['fr','👥 Friends'+(P.req.length+FR.inv.length?' ('+(P.req.length+FR.inv.length)+')':'')]];
  body='<div class="pgt">'+T.map(([k,n])=>`<button class="pgb${tab==k?' on':''}" onclick="MT.tab('${k}')">${n}</button>`).join('')+'</div>'+(tab=='prof'?profBody(L):tab=='shop'?shopBody():tab=='ach'?achBody():frBody())}
 const sc=G(()=>root.querySelector('.pgcc').scrollTop)||0;
 root.innerHTML='<div class="pgp"><div class="pgh"><button class="pgb" onclick="MT.close()">◀ Back</button><b>👑 Royal Court</b><span>💠 '+P.crests+'</span></div><div class="pgcc">'+body+'</div></div>';
 G(()=>{root.querySelector('.pgcc').scrollTop=sc})}
function profBody(L){const st=(a,b)=>`<div>${a}</div><div style="text-align:right">${b}</div>`,lf=P.L;
 return `<div class="pgr"><img class="pgav" src="${avUrl(P.av)}"><div style="flex:1;min-width:0"><input class="pgin" id="pgn" maxlength="14" value="${esc(P.name)}" placeholder="Your name" oninput="MT.name(this.value)" ${ks}><div><b style="color:#e8b94a">${rankOf(L.l)}</b> · Level ${L.l}</div><div style="color:#8ee">${titleTxt()||'No title chosen'}</div></div></div>
 <div class="pgbar"><i style="width:${L.cur/L.nd*100|0}%"></i></div><small>${L.cur} / ${L.nd} XP to level ${L.l+1}</small>
 <div class="pgh2">Avatar</div><div class="pgg">${AV.map(a=>`<button class="${avOK(a)?'':'lk'}${P.av==a.id?' on':''}" onclick="MT.av('${a.id}')" title="${a.n}"><img src="${avUrl(a.id)}">${avOK(a)?'':'<em>'+(a.lv?'Lv '+a.lv:'🏆')+'</em>'}</button>`).join('')}</div>
 <div class="pgh2">Title</div><div class="pgg"><button class="pgb${P.title?'':' g'}" onclick="MT.title('')">None</button>${ACH.filter(a=>P.ach[a.id]).map(a=>`<button class="pgb${P.title==a.id?' g':''}" onclick="MT.title('${a.id}')">${a.t}</button>`).join('')}</div>
 <div class="pgh2">Statistics</div><div class="pgst">${st('Games finished',lf.games||0)}${st('Solo wins',lf.swins||0)}${st('PvP wins',lf.pwins||0)}${st('Foes slain',lf.kills||0)}${st('Buildings raised',lf.built||0)}${st('Kingdoms taken',lf.conq||0)}${st('Soldiers recruited',lf.recruits||0)}${st('Minutes played',Math.floor(lf.minutes||0))}${st('Deeds',Object.keys(P.ach).length+'/'+ACH.length)}${st('Shop items',P.own.length)}</div>
 <div class="pgh2">Friend code</div><div class="pgr"><b style="font-size:22px;letter-spacing:3px;color:#8ee">${P.pid}</b><button class="pgb" onclick="MT.copy()">Copy</button></div><small style="color:#c9b88a">Earn 💠 Crests by finishing a game (win or lose). Spend them in the Shop.</small>`}
const isEq=it=>(CAT.unit.includes(it)&&eqUnit()==it)||(CAT.kd.includes(it)&&eqKd()==it)||(CAT.lord.includes(it)&&eqLord(it.cu)==it)||(CAT.wp.includes(it)&&findIt(P.eq.wp[it.cu]||'w'+it.cu+'_0')==it);
function itImg(it,cat){if(cat=='unit')return `<img src="${portrait('U'+it.id,{st:ZMS.sword,col:it.c1||'#2a5aa8',acc:it.c2||'#e8b94a',wep:'sword',cape:it.c2||'#e8b94a',sc:1},12,20,40,36)}">`;
 if(cat=='lord'){const h=HS[it.cu];return `<img src="${portrait('L'+it.id,lordO(it.cu,it.c1||h.c1,it.c2||h.c2),14,22,36,36)}">`}
 if(cat=='kd'){const s=kdSpr(it);return `<img src="${(s?s.keep:BASE.keep).toDataURL()}">`}
 return `<div class="pgbl" style="background:linear-gradient(90deg,#555,${it.bl||'#c9d0da'})"></div>`}
function shopBody(){const T=[['unit','Unit Skins'],['lord','Lord Skins'],['kd','Kingdoms'],['wp','Weapons']],L=LV();
 const state=it=>{if(isEq(it))return '<button class="pgb" disabled>Equipped</button>';if(isOwn(it))return `<button class="pgb g" onclick="MT.eq('${it.id}')">Equip</button>`;
  if(L<(it.lv||1))return `<button class="pgb" disabled>🔒 Lv ${it.lv}</button>`;return `<button class="pgb${P.crests>=it.price?' g':''}" onclick="MT.buy('${it.id}')">💠 ${it.price}</button>`};
 const row=(it,cat,sub)=>`<div class="pgrow${isEq(it)?' on':''}">${itImg(it,cat)}<div class="t">${it.n}<small>${sub}</small></div>${state(it)}</div>`;
 let h='<div class="pgt">'+T.map(([k,n])=>`<button class="pgb${stab==k?' on':''}" onclick="MT.sub('${k}')">${n}</button>`).join('')+'</div>';
 if(stab=='unit')h+='<small style="color:#c9b88a">Recolours your whole army (and its banners).</small>'+CAT.unit.map(it=>row(it,'unit',it.c1?'Own it forever':'Default')).join('');
 else if(stab=='kd')h+='<small style="color:#c9b88a">Re-skins your keep, towers and walls.</small>'+CAT.kd.map(it=>row(it,'kd',it.st?'Keep · towers · walls':'Default')).join('');
 else{for(let c=0;c<4;c++){h+=`<div class="pgh2">${CUN[c]}${cul()==c?' (your lord)':''}</div>`;
   if(stab=='lord')h+=CAT.lord.filter(i=>i.cu==c).map(it=>row(it,'lord',it.def?'Default':'Armour & cloak')).join('');
   else h+=CAT.wp.filter(i=>i.cu==c).map(it=>row(it,'wp',(it.bonus?'+'+Math.round(it.bonus*100)+'% hero damage (solo)':'Standard')+' · '+(it.bl?'glowing blade':'plain steel'))).join('')}
  if(stab=='wp')h+='<small style="color:#c9b88a">In PvP weapons are cosmetic only, so matches stay fair.</small>'}
 return h}
function achBody(){return `<small style="color:#c9b88a">${Object.keys(P.ach).length} / ${ACH.length} deeds done. Each pays 💠 and XP and unlocks a title.</small>`+ACH.map(a=>{const d=!!P.ach[a.id];let v=0;try{v=Math.min(a.g,a.v())}catch(e){}
 return `<div class="pgrow${d?' on':' dn'}"><div style="font-size:24px;width:34px;text-align:center">${d?'🏆':'🔒'}</div><div class="t">${a.n}<small>${a.d}${d?'':' ('+v+'/'+a.g+')'}</small><small style="color:#8ee">+${a.c} 💠 · +${a.x} XP · Title: ${a.t}</small></div></div>`}).join('')}
function frBody(){const now=Date.now(),on=pid=>now-(FR.on[pid]||0)<75000;
 let h=`<div class="pgr"><small style="color:${FR.ok?'#8e8':'#e99'}">● ${FR.st}</small><small style="color:#c9b88a">Your code: <b style="color:#8ee">${P.pid}</b></small></div>
 <div class="pgr"><input class="pgin" id="pgf" maxlength="6" placeholder="FRIEND CODE" style="text-transform:uppercase;margin:0" ${ks}><button class="pgb g" onclick="MT.add()">Send request</button></div>
 <small style="color:#c9b88a">Both players need the game open and online. Share codes with friends you trust.</small>`;
 if(FR.inv.length){h+='<div class="pgh2">Lobby invites</div>'+FR.inv.map(v=>`<div class="pgrow"><div class="t">${esc(v.n)} invites you<small>Lobby ${v.code}. Joining restarts your game.</small></div><button class="pgb g" onclick="MT.join('${v.code}')">Join</button></div>`).join('')}
 if(P.req.length)h+='<div class="pgh2">Friend requests</div>'+P.req.map(r=>`<div class="pgrow"><img src="${avUrl(r.av)}"><div class="t">${esc(r.n)}<small>Lv ${r.lv} ${rankOf(r.lv)}</small></div><button class="pgb g" onclick="MT.acc('${r.pid}')">Accept</button><button class="pgb r" onclick="MT.dec('${r.pid}')">✕</button></div>`).join('');
 if(P.out.length)h+=`<small style="color:#c9b88a">Pending sent: ${P.out.join(', ')}</small>`;
 if(P.out.length)h+='<div class="pgh2">Pending ('+P.out.length+')</div>'+P.out.map(o=>`<div class="pgrow"><div class="t">${o}<small>Waiting for them to accept</small></div><button class="pgb r" onclick="MT.cx('${o}')">✕</button></div>`).join('');
 h+='<div class="pgh2">Friends ('+P.friends.length+')</div>'+(P.friends.length?P.friends.map(f=>{const o=on(f.pid),inv=MP.on&&!PV.live&&MP.code;return `<div class="pgrow"><img src="${avUrl(f.av)}"><div class="t">${esc(f.n)} <span style="color:${o?'#6e6':'#777'}">●</span><small>Lv ${f.lv} ${rankOf(f.lv)}${f.ti?' · '+esc(f.ti):''}</small></div>${inv?`<button class="pgb ${o?'g':'r'}" style="${o?'':'opacity:.7'}" onclick="MT.inv('${f.pid}')">Invite</button>`:''}<button class="pgb r" onclick="MT.rm('${f.pid}')">✕</button></div>`}).join(''):'<small style="color:#c9b88a">No friends yet.</small>');
 return h}
function resBody(){const R=RES;if(!R)return '';
 let h=`<div style="text-align:center"><div style="font-size:26px;color:#e8b94a">${R.win?'👑 Victory!':'💀 Defeat'}</div><small style="color:#c9b88a">${R.pvp?'PvP match':'Solo reign'} · ${Math.floor(R.min)} min</small></div>`;
 if(!R.ok)return h+'<p style="text-align:center">Too short to earn rewards. Play a little longer next time.</p><div style="text-align:center"><button class="pgb g" onclick="MT.close()">Continue</button></div>';
 h+='<div class="pgh2">Rewards</div>'+R.rows.map(r=>`<div class="pgrow"><div class="t">${r[0]}</div><b style="color:#8ee">${r[1]==null?'':'+'+r[1]}</b></div>`).join('')+`<div class="pgrow on"><div class="t"><b>Total</b></div><b style="color:#8ee">+${R.coins} 💠 · +${R.xp} XP</b></div>`;
 if(R.l1>R.l0)h+=`<div class="pgrow on"><div class="t">⬆ Level ${R.l1}: <b style="color:#e8b94a">${rankOf(R.l1)}</b><small>+${20*(R.l1-R.l0)} 💠 level bonus</small></div></div>`;
 if(R.rk&&window.RK)h+='<div class="pgh2">Ranking</div>'+RK.resRow(R.rk);
 if(R.newA.length)h+='<div class="pgh2">Deeds earned</div>'+R.newA.map(a=>`<div class="pgrow on"><div style="font-size:22px">🏆</div><div class="t">${a.n}<small>+${a.c} 💠 · title “${a.t}”</small></div></div>`).join('');
 return h+`<div style="text-align:center;margin-top:8px"><button class="pgb g" onclick="MT.tab('shop')">🛒 Visit the Shop</button> <button class="pgb" onclick="MT.close()">Continue</button></div>`}
window.MT={S:()=>S,P:()=>P,spend:n=>{if(P.crests<n)return 0;P.crests-=n;save();updChip();if(open)render();return 1},bal:()=>P.crests,close:closeMT,open:openMT,tab:t=>{tab=t;render();if(t=='fr')peerJS(()=>{if(!FR.peer)startPresence();else pingAll()})},sub:s=>{stab=s;render()},
 name:v=>{P.name=esc(v).slice(0,14);save();updChip()},av:id=>{const a=avOf(id);if(!avOK(a)){toast(a.ach?'Earn the deed to unlock this':'Reach level '+a.lv+' to unlock');return}P.av=id;save();render();updChip()},
 title:id=>{P.title=id;save();render()},copy:()=>{G(()=>navigator.clipboard.writeText(P.pid));toast('Friend code '+P.pid+' copied')},
 buy:id=>{const it=findIt(id);if(!it||isOwn(it))return;if(LV()<(it.lv||1))return toast('Reach level '+it.lv);if(P.crests<it.price){sfx('no');return toast('You need '+(it.price-P.crests)+' more 💠')}
  P.crests-=it.price;P.own.push(id);sfx('recruit');MT.eq(id);chk()},
 eq:id=>{const it=findIt(id);if(!it||!isOwn(it))return;if(CAT.unit.includes(it))P.eq.unit=id;else if(CAT.kd.includes(it)){P.eq.kd=id;applyKd()}else if(CAT.lord.includes(it))P.eq.lord[it.cu]=id;else P.eq.wp[it.cu]=id;save();if(open)render()},
 add:()=>reqFriend(G(()=>document.getElementById('pgf').value)),acc:pid=>{const r=P.req.find(x=>x.pid==pid);if(!r)return;addFriend(r);sendTo(pid,meMsg('fa'))},
 cx:pid=>{P.out=P.out.filter(o=>o!=pid);save();render()},dec:pid=>{P.req=P.req.filter(r=>r.pid!=pid);save();updChip();render()},rm:pid=>{P.friends=P.friends.filter(f=>f.pid!=pid);save();sendTo(pid,meMsg('fx'));render()},
 inv:pid=>{sendTo(pid,meMsg('iv',{code:MP.code}),r=>toast(r?'Invite sent':'Could not reach them'))},join:code=>{closeMT();mpGo(code,0)}};
/* ---------- title-screen chip, menu buttons, pause menu ---------- */
const chip=document.createElement('div');chip.id='pgchip';chip.onclick=()=>openMT('prof');$('mb').before(chip);
function updChip(){G(()=>{const L=lvInfo(P.xp);chip.innerHTML='<img src="'+avUrl(P.av)+'"><div style="flex:1;min-width:0"><b>'+esc(P.name||'Lord')+'</b> · Lv '+L.l+' '+rankOf(L.l)+'<br><small>💠 '+P.crests+'</small></div><i class="d" style="display:'+(P.req.length+FR.inv.length?'block':'none')+'"></i>'})}
[['b7','👤 Profile',()=>openMT('prof')],['b8','🛒 Royal Shop',()=>openMT('shop')],['b9','👥 Friends',()=>openMT('fr')]].forEach(([id,t,f])=>{const b=document.createElement('button');b.className='mb';b.id=id;b.textContent=t;b.onclick=f;$('mb').appendChild(b)});
const _pm=pzMenu;pzMenu=function(){_pm();const p=document.querySelector('#pz .pn');if(!p)return;const q=[...p.querySelectorAll('button')].pop();
 [['👤 Profile & Rewards',()=>openMT('prof')],['🛒 Royal Shop',()=>openMT('shop')]].forEach(([t,f])=>{const b=document.createElement('button');b.textContent=t;b.onclick=f;p.insertBefore(b,q)})};
/* ---------- timers ---------- */
setInterval(()=>{try{
 if(inGame&&!S.started){S.started=1;if(!P.name&&RULER){P.name=RULER;save()}applyKd()}
 if(S.started&&!S.done){if(!paused&&!won){S.sec+=.25;S.minutes=S.sec/60}S.armyMax=Math.max(S.armyMax,ARM.length);if(!MPI)S.allies=Math.max(S.allies,KG.filter(k=>k.rel==1&&!k.owned).length)}
 if(S.started&&won&&!S.done)finish()}catch(e){console.error(e)}},250);
setInterval(()=>{if(inGame&&!S.done&&S.started)chk()},3000);
setInterval(()=>{if(inGame)applyKd()},1000);
setInterval(()=>{updChip();if(FR.ok&&P.friends.length)pingAll()},45000);
if(!$('rl').value&&P.name)$('rl').value=P.name;
updChip();chk();
if(navigator.onLine!==false)setTimeout(()=>peerJS(startPresence),1800);
})();
