// ===== v4: Lords, difficulty, smart rival AI, gates & trebuchets, upkeep =====
(()=>{
const HS=[
{n:'Rachit',t:'Crusader',c1:'#e8e8ee',c2:'#b01c1c',h:'#9aa0aa',u:['crus','hcav'],d:'Crusader: Knights & Heavy Cavalry',ln:'Godfrey'},
{n:'Sajan',t:'Shogun',c1:'#a82a2a',c2:'#1a1a22',h:'#222',u:['saru','xbow'],d:'Shogun: Samurai & Crossbowmen',ln:'Takeda'},
{n:'Nigam',t:'Roman',c1:'#a02020',c2:'#d8b040',h:'#c8a030',u:['legi','jave'],d:'Roman: Elite Shield-Sword & Javelineers',ln:'Cassius'},
{n:'Eleanor',t:'Tibetan',c1:'#7a2a6a',c2:'#e8b94a',h:'#4a2a1a',u:['tarc','tlan'],d:'Tibetan: Elite Horse Archers',ln:'Tenzin'}];
const LV=[
{n:'Noob',inc:1,cap:100,ti:18,fm:0,ld:0,tr:0,gr:1.2,hp:.9,at:140,mn:10},
{n:'Pro',inc:1.3,cap:200,ti:11,fm:1,ld:1,tr:0,gr:1.7,hp:1.05,at:100,mn:9},
{n:'Expert',inc:2,cap:340,ti:6,fm:2,ld:1,tr:1,gr:2.6,hp:1.3,at:65,mn:9},
{n:'Hell',inc:3.4,cap:500,ti:3,fm:3,ld:1,tr:1,gr:3.6,hp:1.8,at:35,mn:10}];
let HI=0,LI=1;try{HI=+localStorage.getItem('cor_hero')||0;LI=+(localStorage.getItem('cor_lvl')||1)}catch(e){}
const U=(n,hp,dmg,rng,spd,cd,c,s,w,cost,x)=>Object.assign({n,hp,dmg,rng,spd,cd,c,s,w,cost},x||{});
Object.assign(UT,{
crus:U('Crusader Knight',115,13,16,44,.8,'#e8e8ee','#b01c1c','sword',{wood:10,stone:12,gold:22,food:5}),
hcav:U('Heavy Cavalry',140,17,18,92,.8,'#d8d8e0','#b01c1c','spear',{wood:15,stone:10,gold:38,food:7},{horse:1}),
saru:U('Samurai',85,16,16,58,.5,'#a82a2a','#1a1a22','sword',{wood:8,stone:10,gold:22,food:4}),
xbow:U('Crossbowman',32,13,110,48,1.6,'#3a3a5a','#c8a050','bow',{wood:16,stone:4,gold:12,food:3}),
legi:U('Legionary',105,11,15,50,.7,'#a02020','#d8b040','sword',{wood:8,stone:14,gold:20,food:4}),
jave:U('Javelineer',42,10,62,60,1.2,'#b05030','#d8b040','spear',{wood:12,stone:4,gold:14,food:3}),
tarc:U('Horse Archer',68,9,105,108,.8,'#7a2a6a','#e8b94a','bow',{wood:14,stone:2,gold:34,food:6},{horse:1}),
tlan:U('Highland Lancer',62,11,20,70,.8,'#5a3a7a','#e8b94a','spear',{wood:10,stone:4,gold:14,food:3}),
treb:U('Trebuchet',150,0,20,30,4,'#6a4a2a','#9a7a4a','none',{wood:45,stone:30,gold:40,food:2},{big:1.5}),
bguard:U('Bow Guard',72,11,140,50,1.3,'#2f6a5a','#c8c8d8','bow',{wood:16,stone:6,gold:18,food:3}),
queen:U('Queen',170,11,18,44,.7,'#8a2a6a','#e8c040','sword',{gold:150,food:30,stone:20},{queen:1}),
lord:U('Lord',240,20,18,40,.7,'#d4af37','#fff','sword',{},{big:1.3,horse:1})});
window.HS=HS;window.HI=HI;const SP=()=>[...new Set(HS[HI].u.concat((window.UNLK?window.UNLK():[]),['treb']))];
Object.keys(UT).forEach(k=>{if(!TYS.includes(k))TYS.push(k)});CLS.splice(CLS.indexOf('cguard')+1,0,'bguard');
// sprites
TX.gate=mk(14,16,r=>{r('#3a2410',0,0,14,16);r('#6a4a2a',1,2,12,14);r('#3a2410',6,2,2,14);r('#9a9aa5',2,5,3,1);r('#9a9aa5',9,5,3,1);r('#9a9aa5',2,11,3,1);r('#9a9aa5',9,11,3,1)});
TX.gateO=mk(14,16,r=>{r('#3a2410',0,0,3,16);r('#3a2410',11,0,3,16);r('#3a2410',0,0,14,3)});
const lordSpr=(h,i)=>[0,1].map(f=>mk(16,24,r=>{r(h.c2,3,8,10,12);r(h.c1,4,8,8,9);r('#e8c39a',5,2,6,6);r(h.h,4,0,8,3);
 if(i==0){r(h.c2,7,10,2,6);r(h.c2,5,12,6,2)}if(i==1){r(h.c2,3,0,2,3);r(h.c2,11,0,2,3)}if(i==2){r(h.c2,6,-0,4,2);r(h.c2,5,3,1,3);r(h.c2,10,3,1,3)}if(i==3){r('#e8e0c0',4,2,2,3);r('#e8e0c0',10,2,2,3)}
 r('#2a1a05',6,5,1,1);r('#2a1a05',9,5,1,1);r('#3a2a1a',4+f*3,17,3,6-f);r('#3a2a1a',9-f*3,17,3,5+f)}));
const BX=CX+66,BY=CX-6;let barr=null,st=[];
function applyHero(){const h=HS[HI];for(let i=CLS.length;i--;)if(['crus','hcav','saru','xbow','legi','jave','tarc','tlan','treb'].includes(CLS[i]))CLS.splice(i,1);
 CLS.push(...SP());cls=Math.min(cls,CLS.length-1);TX.hero=lordSpr(h,HI);
 TX.barr=window.bldSpr('barr',1,h);
 if(!barr){barr={k:'barr',img:TX.barr,x:BX,y:BY,w:44,h:36,dead:0,done:0};objs.push(barr)}else barr.img=TX.barr;
 st.forEach(u=>{u.dead=now();const i=ARM.indexOf(u);if(i>=0)ARM.splice(i,1)});st=[h.u[0],h.u[0],h.u[1]].map((t,i)=>mku(0,t,CX+30+i*8,CX+34))}
function yard(cx,cy,t){const h=HS[HI],x=BX-cx,y=BY-cy;if(x<-60||x>VW+60||y<-40||y>VH+60)return;
 c.fillStyle='#8a7048';c.fillRect(x-30,y+4,64,32);c.fillStyle='#7a6038';for(let i=0;i<8;i++)c.fillRect(x-28+i*8,y+8+(i%3)*9,4,2);
 [-24,26].forEach(d=>{c.fillStyle='#5a3a1e';c.fillRect(x+d,y+16,2,12);c.fillRect(x+d-4,y+19,10,2);c.fillStyle='#c8a050';c.fillRect(x+d-2,y+12,6,6)});
 const s=Math.sin(t*5)>0;[[-5,h.c1,0],[7,h.c2,1]].forEach(([d,col,i])=>{const px=Math.round(x+d+(i?-1:1)*(s?2:0));c.fillStyle='#e8c39a';c.fillRect(px,y+16,3,3);c.fillStyle=col;c.fillRect(px-1,y+19,5,6);c.fillStyle='#3a2a1a';c.fillRect(px,y+25,1,3);c.fillRect(px+2,y+25,1,3);c.fillStyle='#e8ecf2';c.fillRect(px+(i?-5:4),y+19+(s?-2:2),4,1)});
 [-32,36].forEach(d=>{c.fillStyle='#4a3020';c.fillRect(x+d,y+10,1,12);c.fillStyle=Math.sin(t*20+d)>0?'#f3a31a':'#e8501a';c.fillRect(x+d-1,y+7,3,4)});
 flag(x+14,y+4,{c1:h.c1,c2:h.c2,em:0},1.6);{const _k='Lord '+h.n+' Barracks';let _l=(window.__yl=window.__yl||{})[_k];if(!_l){_l=document.createElement('canvas');_l.width=140;_l.height=14;const _g=_l.getContext('2d');_g.font='bold 6px monospace';_g.textAlign='center';_g.fillStyle='#000';_g.fillText(_k,71,9);_g.fillStyle='#ffe9a8';_g.fillText(_k,70,8);window.__yl[_k]=_l}c.drawImage(_l,Math.round(x-70),Math.round(y-26))}}
const _gr=ground;ground=function(cx,cy,t){if(!isFinite(H.x+H.y)){H.x=CX;H.y=CX+40}
 US.concat(WK).forEach(u=>{if(!isFinite(u.x+u.y)){u.x=isFinite(u.hx)?u.hx:CX;u.y=isFinite(u.hy)?u.hy:CX+30;if(!isFinite(u.x+u.y)){u.x=CX;u.y=CX+30}}});
 _gr(cx,cy,t);yard(cx,cy,t)};
const _act=act;act=function(){const o=near;if(!o||won)return _act();const sp=SP().includes(CLS[cls]);
 if(o.k=='barr'){barrUI();return}
 if(o.k=='camp'&&sp){toast('Lord units & trebuchets train at the Barracks');return}_act()};
window.barrUI=function(msg){const e=$('ov'),h=HS[HI];paused=1;e.style.display='flex';
 e.innerHTML='<div style="max-height:90vh;overflow:auto;width:min(94vw,460px)"><h3>Lord '+h.n+' Barracks ('+ARM.length+'/'+LIM()+')</h3>'+(msg?'<p style="margin:2px;color:#e8b94a">'+msg+'</p>':'')+SP().map(t=>{const d=UT[t];return '<p style="margin:4px 0"><button onclick="barrBuy(\''+t+'\')">'+d.n+'</button> <small>'+Object.entries(d.cost).map(([k,v])=>v+' '+k).join(', ')+'</small></p>'}).join('')+'<button onclick="ovx()">Close</button></div>'};
window.barrBuy=function(t){const d=UT[t];if(ARM.length>=LIM())return barrUI('Army at full strength');if(!Object.entries(d.cost).every(([k,v])=>H[k]>=v)){sfx('no');return barrUI('Not enough resources for '+d.n)}
 for(const k in d.cost)H[k]-=d.cost[k];mku(0,t,barr.x,barr.y+20);sfx('recruit');hud();barrUI(d.n+' trained! You now have '+cnt(t))};

// ===== v9: culture buildings, wall builder, allies (gifts + troop requests) =====
const BK={brng:{n:'Archery Range',x:CX-72,y:CX-14,c:{wood:40,stone:25,gold:20},u:()=>['bow','bguard'].concat(HS[HI].u.filter(t=>UT[t].rng>=60&&!UT[t].horse))},
 bstb:{n:'Stable',x:CX+70,y:CX+34,c:{wood:50,stone:30,gold:30},u:()=>['cav'].concat(HS[HI].u.filter(t=>UT[t].horse&&t!='cav'))},
 bsge:{n:'Siege Workshop',x:CX-72,y:CX+30,c:{wood:70,stone:50,gold:40},u:()=>['ram','treb']}};
function bspr(k,built){return window.bldSpr(k,built,HS[HI])}
const BPL={};for(const k in BK){const b=BK[k],o={k:'bplot',pk:k,img:bspr(k,0),x:b.x,y:b.y,w:44,h:36,dead:0,done:0};objs.push(o);BPL[k]=o}
const bcost=t=>{const c={};for(const [k,v] of Object.entries(UT[t].cost||{}))c[k]=Math.max(1,Math.ceil(v*.85));return c};
function bUI(k,msg){const e=$('ov'),b=BK[k];paused=1;e.style.display='flex';
 e.innerHTML='<div style="max-height:90vh;overflow:auto;width:min(94vw,460px)"><h3>'+b.n+' ('+ARM.length+'/'+LIM()+')</h3>'+(msg?'<p style="margin:2px;color:#e8b94a">'+msg+'</p>':'')
 +b.u().map(t=>`<p style="margin:4px 0"><button onclick="bBuy('${k}','${t}')">${UT[t].n}</button> <small>${Object.entries(bcost(t)).map(([a,v])=>v+' '+a).join(', ')}</small></p>`).join('')+'<p style="font-size:9px">Specialist buildings train 15% cheaper than the camp.</p><button onclick="ovx()">Close</button></div>'}
function bBuy(k,t){const c=bcost(t),b=BK[k];if(ARM.length>=LIM())return bUI(k,'Army at full strength');
 if(!Object.entries(c).every(([a,v])=>H[a]>=v)){sfx('no');return bUI(k,'Not enough resources for '+UT[t].n)}
 for(const a in c)H[a]-=c[a];mku(0,t,b.x,b.y+20);sfx('recruit');hud();bUI(k,UT[t].n+' trained! You now have '+cnt(t))}
const _act2=act;act=function(){const o=near;if(!o||won)return _act2();
 if(o.k=='bplot'){const b=BK[o.pk];if(!Object.entries(b.c).every(([k,v])=>H[k]>=v)){sfx('no');toast(b.n+' costs '+Object.entries(b.c).map(([k,v])=>v+' '+k).join(', '));return}
  for(const k in b.c)H[k]-=b.c[k];o.k=o.pk;o.img=bspr(o.pk,1);sfx('recruit');toast(b.n+' built! Tap Train to recruit');hud();return}
 if(BK[o.k]){bUI(o.k);return}if(o.k=='merch'){merUI();return}_act2()};

// wall builder: hold the red button to lay walls ahead of you (2 stone each)
const CW=[];let BM=0,bmT=0;
const CG=[];window.cgOut=()=>CG.filter(g=>g.built).map(g=>[Math.round(g.x-CX),Math.round(g.y-CX)]);
function gateNew(x,y){const s={k:'wall',gt:1,cg:1,x,y,hp:150,mhp:150,built:1,cl:0};s.o={k:'wall',img:TX.gateO,x,y,w:14,h:16,dead:0,done:0};objs.push(s.o);GS.push(s);CG.push(s);return s}
function gateKill(b){b.built=0;let i=WALLS.indexOf(b);if(i>=0)WALLS.splice(i,1);i=GS.indexOf(b);if(i>=0)GS.splice(i,1);i=CG.indexOf(b);if(i>=0)CG.splice(i,1);i=objs.indexOf(b.o);if(i>=0)objs.splice(i,1)}
function gateAt(x,y){if(Math.hypot(x-CX,y-CX)>380)return bmWarn('Too far from your castle');
 if(CG.some(g=>g.built&&Math.abs(g.x-x)<6&&Math.abs(g.y-y)<6))return;
 if(H.stone<6){sfx('no');return bmWarn('A gate needs 6 stone')}
 H.stone-=6;gateNew(x,y);sfx('recruit');hud()}
function gateErase(x,y){let b=null,bd=10;CG.forEach(g=>{if(g.built){const d=Math.hypot(g.x-x,g.y-y);if(d<bd){bd=d;b=g}}});if(!b)return 0;gateKill(b);H.stone=Math.min(RESMAX,H.stone+3);sfx('mine');hud();return 1}
window.cgLoad=a=>{window.__cgLoaded=1;CG.slice().forEach(gateKill);(Array.isArray(a)?a:[]).forEach(e=>{if(Array.isArray(e)&&isFinite(e[0]+e[1]))gateNew(CX+e[0],CX+e[1])})};
function cwOut(){const L=[];CW.forEach(w=>{if(w)L.push([w.ci,Math.round(w.x-CX),Math.round(w.y-CX),Math.round(w.hp)])});return L}
function cwBreak(w){CW[w.ci]=null;const i=WALLS.indexOf(w);if(i>=0)WALLS.splice(i,1);const j=objs.indexOf(w.o);if(j>=0)objs.splice(j,1);sfx('hit',w.x,w.y)}
function cwAdd(x,y){let ci=CW.indexOf(null);if(ci<0)ci=CW.length;const w={k:'wall',cust:1,ci,x,y,hp:100,mhp:100,built:1};w.o={k:'wall',img:TX.wall,x,y,w:14,h:16,dead:0,done:0};CW[ci]=w;WALLS.push(w);objs.push(w.o)}
let bmMsg=0;function bmWarn(t){const n=now();if(n>bmMsg){bmMsg=n+1.5;toast(t)}}
function bmAt(x,y){
 if(BM==9)return gateAt(x,y);
 if(BM==2){if(gateErase(x,y))return;let b=null,bd=10;CW.forEach(w=>{if(w){const d=Math.hypot(w.x-x,w.y-y);if(d<bd){bd=d;b=w}}});if(b){cwBreak(b);H.stone=Math.min(RESMAX,H.stone+1);sfx('mine');hud()}return}
 if(Math.hypot(x-CX,y-CX)>380)return bmWarn('Too far from your castle');
 if(CW.some(w=>w&&Math.abs(w.x-x)<5&&Math.abs(w.y-y)<5))return;
 if(WALLS.some(w=>!w.cust&&Math.abs(w.x-x)<7&&Math.abs(w.y-y)<7))return;
 if(CW.filter(Boolean).length>=400)return bmWarn('Wall limit reached (400)');
 if(H.stone<2)return bmWarn('Walls cost 2 stone');H.stone-=2;cwAdd(x,y);sfx('chop');hud()}
function bmAct(){const t=now();if(t<bmT)return;bmT=t+.12;bmAt(Math.round((H.x+(H.fx||1)*14)/8)*8,Math.round((H.y+(H.fy||0)*10)/8)*8)}
/* touch / mouse drawing: drag a finger across the map to lay (or erase) a line of walls */
(function(){const cvs=$('gl');let drag=0,lp=null;
 const pt=e=>{const r=cvs.getBoundingClientRect();return[Math.round((Math.round(cam.x)+(e.clientX-r.left)/r.width*VW)/8)*8,Math.round((Math.round(cam.y)+(e.clientY-r.top)/r.height*VH)/8)*8]};
 const line=(a,b)=>{const n=Math.max(1,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/8));for(let k=1;k<=n;k++)bmAt(Math.round((a[0]+(b[0]-a[0])*k/n)/8)*8,Math.round((a[1]+(b[1]-a[1])*k/n)/8)*8)};
 cvs.addEventListener('pointerdown',e=>{if(!BM||paused||won||!inGame)return;e.preventDefault();drag=1;try{cvs.setPointerCapture(e.pointerId)}catch(x){}lp=pt(e);bmAt(lp[0],lp[1])});
 cvs.addEventListener('pointermove',e=>{if(!drag)return;const q=pt(e);line(lp,q);lp=q});
 ['pointerup','pointercancel'].forEach(n=>cvs.addEventListener(n,()=>{drag=0;lp=null}))})();
const _sw=swing;swing=function(){if(BM>=3&&BM<9&&!US.some(e=>e.team&&!e.dead&&!(e.kg&&e.kg.rel==1)&&Math.abs(e.x-H.x)<70&&Math.abs(e.y-H.y)<70)){bmAct();return}_sw()};
function syncCW(P,cw){P.cwm=P.cwm||new Map();const seen=new Set();
 (Array.isArray(cw)?cw.slice(0,400):[]).forEach(e=>{if(!Array.isArray(e))return;const i=e[0]|0,dx=+e[1],dy=+e[2],hp=+e[3];if(!isFinite(dx+dy+hp)||hp<=0)return;seen.add(i);let o=P.cwm.get(i);
  if(!o){o={k:'wall',img:TX.wall,x:P.lx+dx,y:P.ly+dy,w:14,h:16,dead:0,done:0,gh:1,pl:P,gk:'w',gi:1000+i,hp,mhp:100};P.cwm.set(i,o);objs.push(o)}else{o.hp=hp;o.x=P.lx+dx;o.y=P.ly+dy}});
 P.cwm.forEach((o,i)=>{if(!seen.has(i)){const j=objs.indexOf(o);if(j>=0)objs.splice(j,1);P.cwm.delete(i)}});
 P.gw=P.gw.filter(w=>w.gi<1000).concat([...P.cwm.values()])}

// allies: gifts, troop requests, send/recall troops
const AL={req:[]};
function alTick(){const b=$('al');if(!b)return;const L=[...MP.peers.values()],h=PV.live&&L.some(P=>!P.out&&P.tm===ME.tm),d=h?'':'none';if(b.style.display!==d)b.style.display=d;
 ARM.forEach(u=>{if(u.aid){const P=MP.peers.get(u.aid);if(!P||P.out){u.aid=null;u.hold=0}}})}
function alUI(){const e=$('ov'),L=[...MP.peers.values()].filter(P=>!P.out&&P.tm===ME.tm);paused=1;e.style.display='flex';
 e.innerHTML='<div style="width:min(94vw,440px);max-height:90vh;overflow:auto"><h3>🤝 Allies</h3>'
 +AL.req.map(r=>`<p style="margin:6px 0;color:#e8b94a">📣 ${esc(r.n)} asks for troops <button onclick="alSend('${r.id}');AL.req=AL.req.filter(q=>q.id!=='${r.id}');alUI()">Send 8</button> <button onclick="AL.req=AL.req.filter(q=>q.id!=='${r.id}');alUI()">Decline</button></p>`).join('')
 +(L.length?L.map(P=>`<p style="margin:8px 0"><b>${esc(P.n)}</b>${P.bot?' 🤖':''}<br>Give: <button onclick="alGive('${P.id}','wood')">50🪵</button> <button onclick="alGive('${P.id}','stone')">50🪨</button> <button onclick="alGive('${P.id}','food')">50🌾</button> <button onclick="alGive('${P.id}','gold')">25🪙</button><br><button onclick="alAsk('${P.id}')">📣 Ask for troops</button> <button onclick="alSend('${P.id}')">⚔ Send mine</button></p>`).join(''):'<p>No allies left.</p>')
 +'<button onclick="alRecall()">Recall my troops</button> <button onclick="ovx()">Close</button></div>'}
function alGive(id,r){const P=MP.peers.get(id),n=r=='gold'?25:50;if(!P||P.out)return;if(H[r]<n){sfx('no');toast('Not enough '+r);return}H[r]-=n;const m={t:'g',id:MP.id,to:id,r,n};if(P.bot&&MP.host)botD(m);else mpSend(m);sfx('loot');toast('Sent '+n+' '+r+' to '+P.n);hud();alUI()}
function alAsk(id){const P=MP.peers.get(id);if(!P||P.out)return;const m={t:'q',id:MP.id,to:id,n:RULER||'Ally'};if(P.bot&&MP.host)botD(m);else mpSend(m);toast('Asked '+P.n+' for troops')}
function alSend(id){const P=MP.peers.get(id);if(!P||P.out)return;const L=ARM.filter(u=>!u.dead&&!u.aid&&!u.gd&&!['ram','treb'].includes(u.type)).slice(0,8);if(!L.length){toast('No free troops to send');return}
 L.forEach((u,i)=>{u.aid=id;u.hold=1;u.hx=P.lx+((i%4)-1.5)*16;u.hy=P.ly+40+Math.floor(i/4)*16});toast(L.length+' troops sent to '+P.n);hud()}
function alRecall(){let n=0;ARM.forEach(u=>{if(u.aid){u.aid=null;u.hold=0;n++}});toast(n?n+' troops recalled':'No troops abroad')}
Object.assign(window,{bUI,bBuy,alUI,alGive,alAsk,alSend,alRecall,AL,alTick,syncCW,cwOut,cwBreak,cwAdd,CW});
const _brk=brk;brk=function(w){if(w.cust){cwBreak(w);return}_brk(w)};
const _snap=snap;snap=function(){const o=_snap();o.bk=Object.keys(BPL).filter(k=>BPL[k].k==k);o.cw=cwOut();o.cg=CG.filter(g=>g.built).map(g=>[Math.round(g.x-CX),Math.round(g.y-CX)]);o.dec=window.decOut?window.decOut():[];return o};
const _apS=applySave;applySave=function(S){_apS(S);(Array.isArray(S.bk)?S.bk:[]).forEach(k=>{const o=BPL[k];if(o){o.k=k;o.img=bspr(k,1)}});
 CW.slice().forEach(w=>{if(w)cwBreak(w)});CW.length=0;(Array.isArray(S.cw)?S.cw:[]).forEach(e=>{if(Array.isArray(e)&&isFinite(e[1]+e[2])){cwAdd(CX+e[1],CX+e[2]);CW[CW.length-1].hp=Math.max(1,+e[3]||100)}});setTimeout(()=>{try{window.cgLoad(S.cg);if(window.decLoad)window.decLoad(S.dec)}catch(e){}},0)};
(function(){const mk2=(id,tx,fn,hid)=>{const b=document.createElement('button');b.className='b';b.id=id;b.textContent=tx;if(hid)b.style.display='none';b.addEventListener('pointerdown',e=>{e.preventDefault();fn(b)});$('brow').appendChild(b)};
 mk2('bm','🧱 Build: Off',b=>{BM=(BM+1)%10;b.textContent='🧱 Build: '+['Off','Wall','Erase','House','Farm','Tower','Archery','Stable','Siege','Gate'][BM];toast(['Build mode off','Drag your finger on the map to draw walls (2 stone each)','Drag your finger over walls to remove them','House: walk to a spot, press Attack to place (10 wood, 4 stone)','Farm: walk to a spot, press Attack to place (4 wood)','Tower: needs your keep; press Attack to place (6 wood, 12 stone)','Archery Range: press Attack to place or move it here','Stable: press Attack to place or move it here','Siege Workshop: press Attack to place or move it here','Gate: tap or drag to place gates (6 stone each). Your army walks through; enemies are blocked when closed'][BM])});
 if(MPI)mk2('al','🤝 Allies',alUI,1)})();

// ---- upkeep ----
setInterval(()=>{if(!inGame||paused||won||!ARM.length)return;const n=ARM.length,nf=Math.ceil(n*.4),ng=Math.floor(n/6);
 if(H.food>=nf){H.food-=nf;if(H.food<nf*2)toast('Granary low: troops eat '+nf+' food every 20s')}
 else{H.food=0;const k=Math.max(1,Math.ceil(n*.12)),t=now();ARM.filter(u=>!u.gd).slice(-k).forEach(u=>{u.dead=t;ARM.splice(ARM.indexOf(u),1)});toast(k+' troops deserted: no food!');sfx('no')}hud()},20000);
// ---- gates & wall collision ----
const _bld=bld;bld=function(s){_bld(s);if(s.gt){s.hp=s.mhp=400;s.o.img=TX.gate}else if(s.k=='wall'&&!MPI)s.hp=s.mhp=150};
wpush=function(){let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;for(let i=0;i<WALLS.length;i++){const w=WALLS[i];if(w.x<x0)x0=w.x;if(w.x>x1)x1=w.x;if(w.y<y0)y0=w.y;if(w.y>y1)y1=w.y}if(x0>x1)return;x0-=14;x1+=14;y0-=14;y1+=14;ARM.concat([H]).forEach(u=>{if(u.x<x0||u.x>x1||u.y<y0||u.y>y1)return;WALLS.forEach(w=>{if(w.gt)return;if(Math.abs(u.x-w.x)>14||Math.abs(u.y-w.y)>14)return;const ex=u.x-w.x,ey=u.y-w.y,d=Math.hypot(ex,ey);if(d<9&&d>.1){u.x+=ex/d*(9-d);u.y+=ey/d*(9-d)}})})};
window.NB=SLOTS.length+5;const GS=[];let GM=0,gcl=0;WALLS.forEach(w=>{if(!MPI)w.hp=w.mhp=150});
for(let i=-2;i<=2;i++){const a=i*.047,s={k:'wall',gt:1,x:CX+Math.cos(a)*284,y:CX+Math.sin(a)*243,c:{stone:6}};SLOTS.push(s);bld(s);GS.push(s)}
const gb=$('gt');gb.onclick=()=>{GM=(GM+1)%3;toast(['Gate: AUTO (closes when enemies are near)','Gate: LOCKED CLOSED','Gate: LOCKED OPEN'][GM])};
setInterval(()=>{const gx=CX+284,gy=CX,en=US.some(u=>u.team&&!u.dead&&Math.hypot(u.x-gx,u.y-gy)<420&&(u.raid||!u.kg||u.kg.rel<0))||(PV.war&&ghostTargets().some(g=>Math.hypot(g.x-gx,g.y-gy)<330)),cl=GM==1?1:GM==2?0:en?1:0;
 GS.forEach(s=>{if(!s.built)return;const i=WALLS.indexOf(s);if(cl&&i<0)WALLS.push(s);if(!cl&&i>=0)WALLS.splice(i,1);s.o.img=cl?TX.gate:TX.gateO});
 if(cl!=gcl){gcl=cl;if(inGame||MPI)toast(cl?'🚪 Gate closed':'🚪 Gate opened')}gb.textContent='Gate: '+['Auto','Closed','Open'][GM]+(cl?' 🔒':' 🔓')},100);
KG.forEach((k,i)=>{k.hs=HS[(HI+1+i)%4];k.lv=1;const ang=Math.atan2(CX-(k.y-20),CX-k.x);
 for(let j=-2;j<=2;j++){const a=ang+j*.09,w={x:k.x+Math.cos(a)*100,y:k.y-20+Math.sin(a)*72,hp:220,mhp:220,kg:k,gt:1};w.o={k:'wall',img:TX.gate,x:w.x,y:w.y,w:14,h:16,dead:0,done:0};objs.push(w.o);KW.push(w)}});
function kcol(){KW.forEach(w=>{if(w.kg.owned||(w.gt&&w.kg.rel>=0))return;w.o.img=w.gt?TX.gate:w.o.img});ARM.concat([H]).forEach(u=>kwN(u.x,u.y).forEach(w=>{if(w.kg.owned||(w.gt&&w.kg.rel>=0))return;if(Math.abs(u.x-w.x)>12||Math.abs(u.y-w.y)>12)return;const ex=u.x-w.x,ey=u.y-w.y,d=Math.hypot(ex,ey);if(d<9&&d>.1){u.x+=ex/d*(9-d);u.y+=ey/d*(9-d)}}));KW.forEach(w=>{if(w.gt&&w.kg.rel>=0&&!w.kg.owned)w.o.img=TX.gateO})}
// ---- trebuchet ----
function trb(u,dt){u.cd-=dt;u.atk-=dt;u.hit-=dt;const tm=u.team;let tg=null,bd=235,kd='';
 if(!tm){if(PV.on){if(PV.war){const s=nearStruct(u.x,u.y,235);if(s){tg=s.e;bd=s.d;kd='p'}}}
  else{KW.forEach(w=>{if(w.kg.owned||w.kg.rel>0||(window.peaceOn&&peaceOn()))return;const d=Math.hypot(w.x-u.x,w.y-u.y)-(w.gt?40:0);if(d<bd){bd=d;tg=w;kd='w'}});if(!tg){const o=nearCap(u.x,u.y,235);if(o){tg=o;bd=Math.hypot(o.x-u.x,o.y-u.y);kd='c'}}}}
 else if(u.raid){WALLS.forEach(w=>{const d=Math.hypot(w.x-u.x,w.y-u.y)-(w.gt?40:0);if(d<bd){bd=d;tg=w;kd='W'}});if(!tg&&PC.hp>0&&Math.hypot(PC.x-u.x,PC.y-u.y)<235){tg=PC;kd='C'}}
 if(tg){if(u.cd<=0){u.cd=4.2;u.atk=.4;u.face=tg.x>=u.x?1:-1;sfx('hit',u.x,u.y);for(let i=0;i<4;i++)PS.push({x:u.x,y:u.y-14,vx:(tg.x-u.x)/.9+(i-1.5)*3,vy:(tg.y-u.y+14)/.9-40,l:.9,c:'#555'});
  ((tg,kd)=>setTimeout(()=>{if(u.dead||!tg||tg.hp===undefined)return;if(kd=='w'){if(tg.kg.rel>=0)decl(tg.kg,1);tg.hp-=55;FX.push({x:tg.x,y:tg.y-14,t:'-55',l:.8,c:'#fc6'});sfx('hit',tg.x,tg.y);if(tg.hp<=0)kbrk(tg)}
   else if(kd=='c')hitCastle(35,tg);else if(kd=='p')hurt(tg,60,u);else if(kd=='W'){tg.hp-=55;sfx('hit',tg.x,tg.y);if(tg.hp<=0)brk(tg)}else if(kd=='C'){window.LK=u.kg||window.LK;hitPC(35)}},800))(tg,kd)}return}
 let px=u.sx,py=u.sy,stop=6;if(tm){px=u.raid?CX:u.hx;py=u.raid?CX:u.hy;stop=u.raid?330:6}
 const dx=px-u.x,dy=py-u.y,d=Math.hypot(dx,dy);if(d>stop){const s=Math.min(30*dt,d);u.x+=dx/d*s;u.y+=dy/d*s;u.ph+=dt*10;if(Math.abs(dx)>2)u.face=dx>0?1:-1}}
// ---- smarter think: formations + wall chewing ----
const _th=think;think=function(u,dt,EN,TG){if(u.type=='treb'){trb(u,dt);return}
 if(!u.team&&!PV.on&&!MPI&&u.type!='ram'&&!u.gd&&UT[u.type].dmg&&siege(u,dt))return;
 if(u.team&&u.fm&&u.ld&&!u.ld.dead&&u.kg&&u.kg.rel==-1){const o=u.ld;if(Math.hypot(o.x-CX,o.y-CX)<260)u.fm=0;else{const dx=CX-o.x,dy=CX-o.y,m=Math.hypot(dx,dy)||1,fx=dx/m,fy=dy/m,i=u.si||0,rg=UT[u.type].rng>40,row=(i/5|0)+(rg?3:0),col=i%5-2,b=u.fm>=2?-Math.abs(col)*10-row*12:-row*12;
  u.hx=o.x+fx*b-fy*col*14;u.hy=o.y+fy*b+fx*col*14;u.raid=0;_th(u,dt,EN,TG);u.raid=1;return}}
 _th(u,dt,EN,TG);
 if(!u.team&&!PV.on)chew(u,dt)};
// ---- rival kingdom AI ----
function mkLord(k,L){const u=mku(1,'lord',k.x,k.y+34,{kg:k});u.mhp=u.hp=UT.lord.hp*L.hp;u.nm='Lord '+k.hs.ln;u.std=0;return u}
const _k=kAI;kAI=function(dt){_k(dt);if(!MPI)KG.forEach(k=>{if(k.owned&&!k.cv)conv(k);if(k.owned)own(k,dt)});if(MPI||won)return;const L=LV[LI],t=now();kcol();
 KG.forEach(k=>{if(k.owned)return;k.tt=9;k.wp=999;
  if(inGame&&!paused){const ARn=ARM.length;
   if(k.rel===0&&!(window.peaceOn&&peaceOn())){const a0=USK(k);if(k.ag==null)k.ag=t+L.at*(.8+Math.random()*.6);
    if(t>k.ag){if(a0.length>=L.mn){k.rel=-1;k.at=Math.min(k.at==null?L.at:k.at,20);k.ag=null;toast(k.name+' declares war on you!');sfx('horn');say(k.name+' has declared war upon us!')}else k.ag=t+15}}
   if(k.rel<0&&ARn>40){const x=Math.min(2,ARn/150);for(const a in k.r)k.r[a]=Math.min(RESMAX,k.r[a]+dt*.6*x)}}
  for(const a in k.r)k.r[a]=Math.min(RESMAX,k.r[a]+dt*(L.inc-1)*.6*(1+.12*k.lv+.15*(k.out?k.out.length:0)));
  k.cast.hp=Math.min(k.cast.mhp,k.cast.hp+dt*.4*k.lv);
  const al=USK(k);grow2(k,L,al,dt);
  if(L.ld&&(window.GT_?GT_():999)>240&&(!k.lord||k.lord.dead)){if(k.lord&&!k.lc){k.lc=t+70;k.lord=null}if(!k.lc||t>k.lc){k.lc=0;k.lord=mkLord(k,L)}}
  k.mt=(k.mt||5)-dt;
  if(k.mt<=0){k.mt=L.ti*1.1*(.8+Math.random()*.4)/(k.rel<0?1+Math.min(1,ARM.length/300):1);const pool=['pike','sword','bow','cguard','bguard','cav'].concat(k.hs.u,k.hs.u);
   if(L.tr&&k.rel<0&&al.filter(u=>u.type=='treb').length<1+(k.lv>>2))pool.push('treb','treb');
   const ty=pool[Math.random()*pool.length|0],d=UT[ty];
   if(al.filter(u=>u.type!='lord').length<(window.npcCap?npcCap(k):L.cap)&&Object.entries(d.cost).every(([a,v])=>k.r[a]>=v)){for(const a in d.cost)k.r[a]-=d.cost[a];const a=Math.random()*6.283,u=mku(1,ty,k.x+Math.cos(a)*50,k.y-10+Math.sin(a)*34,{kg:k});u.mhp=u.hp=u.mhp*L.hp}}
  k.gt=(k.gt||60)-dt*L.gr*.3;
  if(k.gt<=0&&k.lv<18&&k.r.wood>=50&&k.r.stone>=35&&k.r.gold>=50){k.r.wood-=50;k.r.stone-=35;k.r.gold-=50;k.gt=22;k.lv++;try{window.kBuild&&kBuild(k)}catch(e){}const hm=k.lv%2,a=Math.random()*6.283,r=125+Math.random()*60;
   objs.push({k:hm?'home':'farm',img:hm?TX.house:TX.farm,x:k.x+Math.cos(a)*r,y:k.y-20+Math.sin(a)*r*.75,w:hm?28:18,h:hm?24:10,dead:0,done:0});k.cast.mhp+=40;if(Math.hypot(H.x-k.x,H.y-k.y)<800)feed(k.name+' expands (Lv '+k.lv+')')}
  if(k.rel<0&&!(window.peaceOn&&peaceOn())){k.at=(k.at==null?L.at:k.at)-dt;const fr=al.filter(u=>!u.raid&&u.type!='lord'&&!u.ex);
   if(k.at<=0&&fr.length>=L.mn){k.at=L.at*(.8+Math.random()*.4)*Math.max(.35,1-ARM.length/600);const go=fr.slice(0,Math.ceil(fr.length*(ARM.length>fr.length*2?1:.75))),ld=L.ld&&k.lord&&!k.lord.dead?k.lord:null;
    go.forEach((u,i)=>{u.raid=1;u.si=i;if(ld){u.fm=L.fm;u.ld=ld}});if(ld)ld.raid=1;toast((ld?'Lord '+k.hs.ln+' of ':'')+k.name+' marches on your castle!');sfx('horn');say(k.name+' marches upon us!')}}})};
window.npcCap=function(k){const L=LV[LI],g=window.GT_?GT_():0,pw=ARM.length+WK.length*.5;return Math.max(6,Math.min(L.cap,Math.round(5+pw*[.6,.9,1.3,2.2][LI]+g/60*[2,3,5,10][LI])))};
// ---- menu ----
const hs=document.createElement('div');hs.id='hs';hs.style.cssText='margin:2px auto;max-width:96vw;font-size:11px;color:#f3e9d2;text-align:center';
const bt=(sel,fn,l)=>`<button class="mb" style="width:auto;font-size:11px;padding:3px 6px;margin:1px;${sel?'outline:2px solid #e8b94a':''}" onclick="${fn}">${l}</button>`;
function hsR(){hs.innerHTML='<div>'+HS.map((h,i)=>'<button class="mb" onclick="pickH('+i+')" style="width:auto;display:inline-block;vertical-align:top;margin:2px;padding:4px 7px;text-align:left;font-size:9px;line-height:1.5;'+(i==HI?'outline:2px solid #e8b94a;':'')+'"><b style="color:'+h.c1+'">'+h.n+'</b> <small>'+h.t+'</small><br>❤ 100 ⚔ 14<br><small>'+h.u.map(t=>UT[t]?UT[t].n:t).join(' · ')+'</small></button>').join('')+'</div><div><button class="mb" style="width:auto;font-size:11px;padding:5px 10px;margin:3px 0;border:2px solid #e8b94a" onclick="lhUI()">🛡 Lords &amp; Units — health, damage, wardrobe, skills</button></div><div>Rival AI: '+LV.map((l,i)=>bt(i==LI,'pickL('+i+')',l.n)).join('')+'</div><div>'+((MPI||PEND)?'Map: <b style="color:#e8b94a">'+MAPN[MAPI]+'</b>'+(MPI?' (set by the room host)':' (saved game)'):'Map: '+MAPN.map((m,i)=>bt(i==MAPI,'pickM('+i+')',m)).join(''))+'</div>'}
window.pickH=i=>{HI=i;window.HI=i;try{localStorage.setItem('cor_hero',i)}catch(e){}applyHero();hsR()};
window.pickL=i=>{LI=i;try{localStorage.setItem('cor_lvl',i)}catch(e){}hsR()};
window.pickM=i=>{if(MPI||PEND||i==MAPI)return;try{localStorage.setItem('cor_map',i);sessionStorage.setItem('cor_skipintro','1')}catch(e){}location.reload()};

// ---- army sieges castles/outposts/walls by itself ----
function chew(u,dt){const d=UT[u.type];if(d.rng>=30||!d.dmg)return 0;u.wc=(u.wc||0)-dt;if(u.wc>0)return 0;for(const w of KW){if(w.kg.owned||w.kg.rel>=0||Math.abs(w.x-u.x)>16||Math.abs(w.y-u.y)>16)continue;u.wc=d.cd;u.atk=.3;w.hp-=d.dmg*.7;sfx('hit',w.x,w.y);if(w.hp<=0)kbrk(w);return 1}return 0}
function killOut(p){const k=p.kg,i=k.out.indexOf(p);if(i>=0)k.out.splice(i,1);const j=objs.indexOf(p.o);if(j>=0)objs.splice(j,1);H.gold+=40;toast(k.name+' outpost destroyed! +40 gold');sfx('win')}
function siege(u,dt){const d=UT[u.type];let o=null,bd=330;const cp=nearCap(u.x,u.y,330);if(cp&&cp.kg&&cp.kg.rel<0){o=cp;bd=Math.hypot(cp.x-u.x,cp.y-u.y)}
 KG.forEach(k=>{if(k.owned||k.rel>=0||!k.out)return;k.out.forEach(p=>{const q=Math.hypot(p.x-u.x,p.y-u.y);if(q<bd){bd=q;o=p}})});
 if(!o)return 0;if(US.some(e=>e.team&&!e.dead&&!(e.kg&&e.kg.rel==1)&&Math.hypot(e.x-u.x,e.y-u.y)<110))return 0;
 u.cd-=dt;if(chew(u,dt))return 1;const stop=Math.max(16,d.rng*.8),dx=o.x-u.x,dy=o.y-u.y;
 if(bd>stop){const s=Math.min(d.spd*dt,bd-stop);u.x+=dx/bd*s;u.y+=dy/bd*s;u.ph+=dt*10;u.face=dx>0?1:-1}
 else if(u.cd<=0){u.cd=d.cd;u.atk=.3;u.face=dx>0?1:-1;if(o.ot){if(o.kg.rel>=0)decl(o.kg,1);o.hp-=d.dmg;sfx('hit',o.x,o.y);FX.push({x:o.x,y:o.y-30,t:'-'+d.dmg,l:.6,c:'#fff'});if(o.hp<=0)killOut(o)}else hitCastle(d.dmg*.5,o)}
 return 1}
// ---- rivals expand: outposts, scouts, expeditions ----
function grow2(k,L,al,dt){k.out=k.out||[];const t=now();
 al.forEach(u=>{if(u.ex&&!u.raid&&Math.hypot(u.x-H.x,u.y-H.y)>480){const dx=u.hx-u.x,dy=u.hy-u.y,d=Math.hypot(dx,dy);if(d>6){const s=Math.min(UT[u.type].spd*dt,d);u.x+=dx/d*s;u.y+=dy/d*s;u.ph+=dt*10;u.face=dx>0?1:-1}}});
 if(k.lv>=1){let sc=al.find(u=>u.sc&&!u.dead);if(!sc){const c=al.find(u=>!u.ex&&!u.raid&&UT[u.type].horse&&u.type!='lord');if(c){c.sc=1;c.ex=1;sc=c}}
  if(sc&&t>(k.sct||0)){k.sct=t+7;const a=Math.random()*6.283,r=300+Math.random()*1500;sc.hx=Math.max(200,Math.min(WD-200,k.x+Math.cos(a)*r));sc.hy=Math.max(200,Math.min(WD-200,k.y+Math.sin(a)*r))}}
 if(k.site){const S=k.site,es=S.es.filter(u=>!u.dead);if(es.length<2||t>S.to){k.site=null;es.forEach(u=>{u.ex=0;u.hx=k.x;u.hy=k.y})}
  else if(es.filter(u=>Math.hypot(u.x-S.x,u.y-S.y)<80).length>=Math.min(2,es.length)&&k.r.wood>=80&&k.r.stone>=60&&k.r.gold>=70){k.r.wood-=80;k.r.stone-=60;k.r.gold-=70;
   const o={k:'tower',img:TX.tower,x:S.x,y:S.y,w:16,h:36,dead:0,done:0,gt:1,kg:k};objs.push(o);const p={x:S.x,y:S.y,hp:320,mhp:320,kg:k,ot:1,o};k.out.push(p);k.site=null;
   if(Math.hypot(H.x-S.x,H.y-S.y)<900)feed(k.name+' founds an outpost!');}}
 else{k.xt=(k.xt||40)-dt*L.gr;if(k.xt<=0&&k.lv>=2&&k.out.length<Math.min(6,1+(k.lv>>1))&&k.r.wood>=80&&k.r.stone>=60&&k.r.gold>=70){k.xt=30;
   for(let i=0;i<10;i++){const a=Math.random()*6.283,r=380+Math.random()*260,x=k.x+Math.cos(a)*r,y=k.y+Math.sin(a)*r;
    if(x<250||y<250||x>WD-250||y>WD-250||Math.hypot(x-CX,y-CX)<500||KG.some(g=>g!==k&&Math.hypot(g.x-x,g.y-y)<400)||KG.some(g=>g.out&&g.out.some(p=>Math.hypot(p.x-x,p.y-y)<250)))continue;
    const es=al.filter(u=>!u.raid&&!u.ex&&u.type!='lord').slice(0,4);if(es.length<2)break;es.forEach(u=>{u.ex=1;u.hx=x+(Math.random()-.5)*40;u.hy=y+(Math.random()-.5)*40});k.site={x,y,es,to:t+120};break}}}
 k.ot=(k.ot||20)-dt;if(k.ot<=0&&k.out.length){k.ot=L.ti*2.5;const p=k.out[Math.random()*k.out.length|0],ty=['sword','bow','cguard'].concat(k.hs.u)[Math.random()*5|0],d=UT[ty];
  if(al.length<(window.npcCap?npcCap(k):L.cap)&&Object.entries(d.cost).every(([a,v])=>k.r[a]>=v)){for(const a in d.cost)k.r[a]-=d.cost[a];const u=mku(1,ty,p.x+(Math.random()-.5)*30,p.y+20,{kg:k});u.mhp=u.hp=u.mhp*L.hp;u.ex=1;u.hx=u.x;u.hy=u.y}}}
// ---- captured kingdoms: rebuild like your own ----
const BASE=SLOTS.filter(q=>!q.gt&&q.k!='keep');
if(!MPI)KG.forEach(k=>{const dx=k.x-CX,dy=k.y-20-CX;k.sl=[];let fr=null;BASE.forEach(q=>{const z={k:q.k,x:q.x+dx,y:q.y+dy,c:q.c,kg:k};if(q.ring)z.ring=1;if(q.req)z.req=fr;if(!fr&&q.k=='farm')fr=z;SLOTS.push(z);k.sl.push(z)})});
function conv(k){k.cv=1;KW.filter(w=>w.kg===k).forEach(kbrk);if(!k.sl.some(z=>z.built)){k.sl.filter(z=>z.ring).forEach(bld);k.sl.filter(z=>z.k=='home').slice(0,2).forEach(bld)}
 for(let i=0;i<2;i++)mkw('builder',k.x+i*10,k.y+34);toast('Builders rally to '+k.name+': rebuild it like your capital!')}
function own(k,dt){k.ia=(k.ia||0)+dt;if(k.ia>15){k.ia=0;let f=0,h=0;k.sl.forEach(z=>{if(z.built){if(z.k=='farm')f++;if(z.k=='home')h++}});H.food+=f*2;H.gold+=h}}

// ---- PvP: claim and rebuild a fallen player's base (local to you) ----
function capBase(P,lx,ly){if(!lx||!ly)return;const k={name:P.n+"'s fallen base",x:lx,y:ly+20,owned:1,cv:1,sl:[]},dx=lx-CX,dy=ly-CX;let fr=null;
 BASE.forEach(q=>{const z={k:q.k,x:q.x+dx,y:q.y+dy,c:q.c,kg:k};if(q.ring)z.ring=1;if(q.req)z.req=fr;if(!fr&&q.k=='farm')fr=z;SLOTS.push(z);k.sl.push(z)});
 k.sl.filter(z=>z.ring).forEach(bld);k.sl.filter(z=>z.k=='home').slice(0,2).forEach(bld);CB.push(k);
 for(let i=0;i<2;i++)mkw('builder',lx+i*10,ly+40);toast('You claim '+k.name+'! Builders are on their way.');say('Their land is ours now, my liege. We shall rebuild.',1)}
window.capBase=capBase;const CB=[];if(MPI){const _po=pOut;pOut=function(P,why){const lx=P.lx,ly=P.ly;_po(P,why);if(String(why).indexOf('eliminated')>=0&&PC.hp>0&&lx)capBase(P,lx,ly)};setInterval(()=>{if(inGame&&!paused)CB.forEach(k=>own(k,15))},15000)}
$('nr').after(hs);hsR();applyHero();
/* ===== free plots v2: houses/farms/towers/barracks anywhere, saved, PvP-synced; NPC lords build too ===== */
(function(){
const _b=bmAt,BD={3:['home',{wood:10,stone:4},26],4:['farm',{wood:4},20],5:['tower',{wood:6,stone:12},20]},CAP={home:24,farm:24,tower:10},BX=['brng','bstb','bsge'],OK=['home','farm','tower'];let pt=0;
function mkCP(k,x,y,wait){const q={k,x,y,c:{},cust:1};SLOTS.push(q);if(wait){q.c=wait;const z={farm:[18,10],home:[28,24],tower:[16,36]}[k],g=document.createElement('canvas'),im=TX[k];g.width=im.width;g.height=im.height;const gc2=g.getContext('2d');gc2.globalAlpha=.45;gc2.drawImage(im,0,0);q.gh={k:'decor',dec:1,img:g,x,y,w:z[0],h:z[1],dead:0,done:0};objs.push(q.gh)}else bld(q);return q}
window.cpOut=(all)=>{const L=SLOTS.filter(q=>q.cust&&q.built).sort((p,q)=>(p.auto|0)-(q.auto|0));return L.slice(0,all?160:60).map(q=>q.auto?[q.k,Math.round(q.x-CX),Math.round(q.y-CX),q.hp|0,1]:[q.k,Math.round(q.x-CX),Math.round(q.y-CX),q.hp|0])};
/* ---- builders keep the kingdom filled once the player's own plot limit is reached: same building type, tidy grid beside what the player built ---- */
const AUTO_MAX={home:36,farm:30},AUTO_SP={home:34,farm:28};
function autoFill(){
 if(!inGame||won||paused||window.GENM||window.WCS||!WK.some(w=>w.type=='builder'))return;
 for(const k of ['home','farm']){
  const own=SLOTS.filter(q=>q.cust&&!q.auto&&q.k==k);
  if(own.length<CAP[k])continue;                                   // the player can still plot more: leave it to them
  const auto=SLOTS.filter(q=>q.auto&&q.k==k);
  if(auto.length>=AUTO_MAX[k]||auto.some(q=>!q.built))continue;    // one at a time, tidy growth
  const cost=Object.assign({},BD[k==='home'?3:4][1]);if(!Object.entries(cost).every(([a,v])=>H[a]>=v))continue;
  const anchors=own.concat(auto).filter(q=>q.built);if(!anchors.length)continue;
  const sp=AUTO_SP[k],r=BD[k==='home'?3:4][2];
  const cx=anchors.reduce((t,q)=>t+q.x,0)/anchors.length,cy=anchors.reduce((t,q)=>t+q.y,0)/anchors.length;
  let best=null,bd=1e9;
  for(const a of anchors){for(let i=-2;i<=2;i++)for(let j=-2;j<=2;j++){if(!i&&!j)continue;
   const x=a.x+i*sp,y=a.y+j*sp;
   if(((x-CX)/430)**2+((y-CX)/360)**2>1||Math.hypot(x-PC.x,y-PC.y)<110)continue;
   if(SLOTS.some(q=>q.k!='wall'&&Math.hypot(q.x-x,q.y-y)<Math.max(r,sp-6))||WALLS.some(w=>Math.hypot(w.x-x,w.y-y)<14)||BX.some(z=>Math.hypot(BK[z].x-x,BK[z].y-y)<50))continue;
   const d=Math.hypot(x-cx,y-cy);if(d<bd){bd=d;best=[x,y]}}}
  if(best){const q=mkCP(k,Math.round(best[0]),Math.round(best[1]),cost);q.auto=1;return}
 }
}
setInterval(()=>{try{autoFill()}catch(e){}},4000);
window.syncCP=function(P,cp){P.cpm=P.cpm||new Map();const seen=new Set();
 (Array.isArray(cp)?cp.slice(0,160):[]).forEach(e=>{if(!Array.isArray(e))return;const k=e[0],dx=+e[1],dy=+e[2];if(!OK.includes(k)||!isFinite(dx+dy)||!(e[3]>0))return;const id=k+Math.round(dx)+'_'+Math.round(dy);seen.add(id);let o=P.cpm.get(id);
  if(!o){const z={farm:[18,10],home:[28,24],tower:[16,36]}[k];o={k,img:TX[k],x:P.lx+dx,y:P.ly+dy,w:z[0],h:z[1],dead:0,done:0};P.cpm.set(id,o);objs.push(o)}else{o.x=P.lx+dx;o.y=P.ly+dy}});
 P.cpm.forEach((o,id)=>{if(!seen.has(id)){const j=objs.indexOf(o);if(j>=0)objs.splice(j,1);P.cpm.delete(id)}})};
bmAt=function(x,y){if(BM<3||BM==9)return _b(x,y);
 const t=now();if(t<pt)return;pt=t+.7;
 if(Math.hypot(x-CX,y-CX)>570)return toast('Too far from your castle');
 if(BM>=6){const k=BX[BM-6],b=BK[k],o=BPL[k];
  if(SLOTS.some(q=>q.k!='wall'&&Math.hypot(q.x-x,q.y-y)<40)||BX.some(z=>z!=k&&Math.hypot(BK[z].x-x,BK[z].y-y)<46))return toast('Something is already there');
  if(o.k=='bplot'){if(!Object.entries(b.c).every(([a,v])=>H[a]>=v)){sfx('no');return toast(b.n+' costs '+Object.entries(b.c).map(([a,v])=>v+' '+a).join(', '))}for(const a in b.c)H[a]-=b.c[a];o.k=k;o.img=bspr(k,1)}
  b.x=o.x=x;b.y=o.y=y;sfx('recruit');hud();return toast(b.n+' placed here. Walk up and press the action button to train troops')}
 const [k,c,r]=BD[BM];
 if(k=='tower'&&!K1.built)return toast('Build your keep first');
 if(SLOTS.filter(q=>q.cust&&!q.auto&&q.k==k).length>=CAP[k])return toast('Limit reached ('+CAP[k]+')');
 if(SLOTS.some(q=>q.k!='wall'&&Math.hypot(q.x-x,q.y-y)<r)||WALLS.some(w=>Math.hypot(w.x-x,w.y-y)<10)||BX.some(z=>Math.hypot(BK[z].x-x,BK[z].y-y)<46))return toast('Something is already there');
 if(!Object.entries(c).every(([a,v])=>H[a]>=v)){sfx('no');return toast('Needs '+Object.entries(c).map(([a,v])=>v+' '+a).join(', '))}
 mkCP(k,x,y,Object.assign({},c));sfx('recruit');hud();toast(k+' plotted: a builder will raise it ('+Object.entries(c).map(([a,v])=>v+' '+a).join(', ')+')')};
/* saving */
const _s=snap;snap=function(){const o=_s();o.cp=cpOut(1);o.bp={};BX.forEach(k=>o.bp[k]=[Math.round(BK[k].x-CX),Math.round(BK[k].y-CX)]);return o};
const _a=applySave;applySave=function(S){_a(S);
 if(S.bp&&typeof S.bp=='object')BX.forEach(k=>{const e=S.bp[k];if(Array.isArray(e)&&isFinite(e[0]+e[1])){const b=BK[k],o=BPL[k];b.x=o.x=CX+e[0];b.y=o.y=CX+e[1]}});
 (Array.isArray(S.cp)?S.cp:[]).slice(0,160).forEach(e=>{if(Array.isArray(e)&&OK.includes(e[0])&&isFinite(e[1]+e[2])){const q=mkCP(e[0],CX+e[1],CX+e[2]);if(e[4])q.auto=1;if(e[3]>0)q.hp=e[3]}})};
/* NPC lords choose their own plots by situation */
const LB={tower:[{wood:6,stone:12,gold:0},16,36],farm:[{wood:4,stone:0,gold:0},18,10],home:[{wood:10,stone:4,gold:0},28,24],bar:[{wood:50,stone:30,gold:30},44,36]};
const _k2=kAI;kAI=function(dt){_k2(dt);if(MPI||won)return;const t=Znow();
 KG.forEach(k=>{if(k.owned||k.cast.hp<=0)return;k.cp=k.cp||[];if(k._bt===undefined)k._bt=t+90+Math.random()*60;
  const n=t2=>k.cp.filter(b=>b.t==t2).length,nb=n('bar');
  k.r.gold=Math.min(RESMAX,k.r.gold+n('home')*.08*dt);k.r.food=Math.min(RESMAX,k.r.food+n('farm')*.12*dt);
  if(nb&&k._sc>0)k._sc-=dt*nb*.4;
  k.cp.forEach(b=>{if(b.t!='tower'||k.rel>=0)return;b.ct=(b.ct||0)-dt;if(b.ct>0)return;let tg=null,bd=150;ARM.concat([H]).forEach(e=>{const d=Math.hypot(e.x-b.x,e.y-b.y);if(d<bd){bd=d;tg=e}});
   if(tg){b.ct=1.4;const sy=b.y-28,L=Math.hypot(tg.x-b.x,tg.y-8-sy)||1;AR.push({x:b.x,y:sy,vx:(tg.x-b.x)/L*230,vy:(tg.y-8-sy)/L*230,team:1,dmg:6,l:.9,from:{nm:'Tower'}});sfx('arrow',b.x,sy)}});
  if(t<k._bt||k.cp.length>=9)return;k._bt=t+60+Math.random()*60;
  const al=USK(k),war=k.rel==-1;let ty;
  if((war||al.length<8)&&n('tower')<5)ty='tower';else if(k.r.food<250&&n('farm')<5)ty='farm';else if(al.length>20&&nb<2)ty='bar';else ty=n('home')<8?'home':'farm';
  const [c,w,h]=LB[ty];if(!Object.entries(c).every(([a,v])=>k.r[a]>=v))return;
  for(let i=0;i<8;i++){const a=Math.random()*6.283,r=75+Math.random()*60,x=k.x+Math.cos(a)*r,y=k.y+Math.sin(a)*r*.8;
   if(k.cp.some(b=>Math.hypot(b.x-x,b.y-y)<38))continue;
   for(const a2 in c)k.r[a2]-=c[a2];
   const kind=ty=='bar'?(Math.random()<.5?'bstb':'brng'):ty,o=add(kind=='bstb'||kind=='brng'?'lordbld':kind,kind=='bstb'||kind=='brng'?bspr(kind,1):TX[kind],x,y,w,h);
   k.cp.push({t:ty,x,y,o});feed(k.name+' raises a '+({tower:'watchtower',farm:'farm',home:'house',bar:'barracks'}[ty]));break}})};
})();

})();
