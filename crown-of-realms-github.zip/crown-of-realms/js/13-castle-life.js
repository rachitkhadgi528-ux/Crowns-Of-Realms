/* ===== v9.8: lively castle: flickering torches, thorny rose brambles, night glow ===== */
(function(){
const bram=v=>mk(16,12,r=>{const A='#2a5a2a',B='#3f7a3a',T='#5a3a1e';r(A,1,5,14,7);r(B,2,4,12,6);r(B,4,2,8,4);for(let i=0;i<8;i++){r(T,1+i*2,(i%2)?3:6,1,1);r('#7a5a32',2+i*2,(i%2)?7:4,1,1)}
 [[3,5],[8,3],[12,6],[6,8],[10,9]].forEach(([x,y],i)=>{r(i%2?'#e0506a':'#f0d040',x,y,2,2);r('#fff',x,y,1,1)});r(T,0,10,3,1);r(T,13,10,3,1)});
const torch=f=>mk(8,20,r=>{r('#3a2a1a',3,8,2,12);r('#6a6a75',2,7,4,2);r('#4a4a55',2,19,4,1);const F=[['#f3a31a','#fff2a0',1],['#e8501a','#f3c04a',2],['#f3a31a','#ffe27a',0]][f];r('#e8501a',2,3,4,5);r(F[0],2+(F[2]==2?1:0),1+(f==1?0:1),3,6);r(F[1],3,4,2,3);if(f==1)r('#fff2a0',3,0,1,2)});
const TF=[0,1,2].map(torch),BR=[bram(),bram()],cl=[];
function add(img,x,y,w,h,fr){const o={k:'decor',img,x,y,w,h,dead:0,done:0,dec:1,fr,ph:Math.random()*5};objs.push(o);if(fr)cl.push(o);return o}
const by=PC.y;
[-13,13].forEach(d=>add(TF[0],PC.x+d,by+3,8,20,TF));
[[-27,5],[27,5],[-41,8],[41,8]].forEach(([d,y],i)=>add(BR[i&1],PC.x+d,by+y,16,12));
const T=[];cl.forEach(o=>{if(o.fr===TF)T.push(o)});
const _am=ambient;ambient=function(dt,cx,cy,b,dn){_am(dt,cx,cy,b,dn);const t=now();T.forEach(o=>{o.img=TF[((t*9+o.ph)|0)%3]})};
const _xn=window.xNight;window.xNight=function(lt,cx,cy){if(_xn)_xn(lt,cx,cy);const f=Math.sin(now()*17)*.08;T.forEach(o=>lt(o.x-cx,o.y-cy-14,34*(1+f),.85));lt(PC.x-cx-9,PC.y-cy-26,20,.45);lt(PC.x-cx+9,PC.y-cy-26,20,.45)};
/* narrator button on the story screen */
const sn=$('sn');if(sn){const _sv=setVoice;setVoice=function(v){_sv(v);sn.textContent=voiceOn?'🔊 Narrator: On':'🔇 Narrator: Off'};sn.addEventListener('click',()=>setVoice(!voiceOn))}
})();
