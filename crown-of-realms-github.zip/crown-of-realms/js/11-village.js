/* ===== v9.6: living medieval village — organic lanes and cottage clusters, varied house/farm/wall art,
   animated props (windmill, forge, well, stalls, laundry, torches, bell), animals, lit windows at night ===== */
(function(){
const TAU=6.2832,R=Math.random,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const sr=s=>{s|=0;return()=>{s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}};
function mkx(w,h,f){const k=document.createElement('canvas');k.width=w;k.height=h;const x=k.getContext('2d');f((col,a,b,ww,hh)=>{x.fillStyle=col;x.fillRect(a,b,ww,hh)},x);try{k.hd=hdify(k)}catch(e){}return k}
const X={night:0,nt:0,ev:0,sc:0,bell:0};

/* ---------- house art: six styles, each with a day and a lit-window version ---------- */
const HV=[
 {w:'#d8c8a8',w2:'#a88a68',b:'#7a5230',r:'#c8423a',r2:'#b8322a',e:'#8a2018',d:'#4a2a12',g:'#3a5a8a'},
 {w:'#e0d2a8',w2:'#b8a478',b:'#4a2e18',r:'#6e7c8c',r2:'#56626f',e:'#3e4852',d:'#3a2210',g:'#3a5a8a',tim:1},
 {w:'#a39d90',w2:'#7c776c',b:'#5a5448',r:'#cfaa55',r2:'#a98a3a',e:'#8a6c28',d:'#4a3016',g:'#2e4a6a',stone:1,thatch:1},
 {w:'#efe4c8',w2:'#c4b48c',b:'#7a5a38',r:'#3f8f7a',r2:'#2f7464',e:'#1f5648',d:'#5a3a1e',g:'#3a5a8a',flw:1},
 {w:'#c9a47a',w2:'#9a7650',b:'#5a3a1e',r:'#d98a3a',r2:'#bd6e22',e:'#8a4a14',d:'#3a2210',g:'#3a6a9a',shut:'#2e6aa8'},
 {w:'#b4623e',w2:'#8a4428',b:'#5a2c18',r:'#58484a',r2:'#443638',e:'#2e2426',d:'#2a1a10',g:'#3a5a8a',brick:1}];
function house(v,lit){const p=HV[v];return mkx(24,20,r=>{
 r(p.w2,3,9,18,11);r(p.w,3,9,17,10);r(p.b,3,9,18,1);
 if(p.stone)for(let j=0;j<4;j++)for(let i=0;i<5;i++)if((i+j)%2)r(p.b,3+i*4,10+j*3,2,1);
 if(p.brick)for(let j=0;j<5;j++)for(let i=0;i<5;i++)r(p.w2,3+i*4+(j&1)*2,11+j*2,3,1);
 if(p.tim){r(p.b,3,13,18,1);r(p.b,8,9,1,11);r(p.b,16,9,1,11);r(p.b,3,9,1,11);r(p.b,20,9,1,11)}
 for(let i=0;i<6;i++)r(i<3?p.r:p.r2,10-2*i,3+i,4+4*i,1);
 if(p.thatch)for(let i=0;i<6;i++){r(p.e,10-2*i+(i%2),3+i,1,1);r(p.e,13+2*i-(i%2),3+i,1,1);r(p.e,12+(i%3),3+i,1,1)}
 r(p.e,0,8,24,2);r(p.d,13,13,4,7);r(p.b,13,13,4,1);r('#d8b84a',16,17,1,1);
 const gl=lit?'#ffd45a':p.g;r(p.b,4,11,5,1);r(gl,5,12,3,3);if(lit){r('#fff1a0',6,13,1,1);r('#ffd45a',18,13,2,2)}else r(p.g,18,13,2,2);
 if(p.shut){r(p.shut,4,12,1,3);r(p.shut,8,12,1,3)}
 if(p.flw){r('#5a3a1e',4,15,5,1);r('#d8506a',5,14,1,1);r('#f0c040',7,14,1,1);r('#d8506a',8,14,1,1)}
 r('#9a9a9a',16,2,3,5);r('#6e6e6e',16,2,1,5);r('#555',15,1,5,1)})}
const HOUSE=HV.map((_,i)=>[house(i,0),house(i,1)]);

/* ---------- farms: four crops, four sway frames ---------- */
function farm(t,f){return mkx(18,10,r=>{r('#5a3a1e',0,0,18,10);r('#7a5230',1,1,16,8);
 for(let i=0;i<4;i++){const x=2+i*4;
  if(t==0){const s=[0,1,0,-1][(f+i)%4];r('#a88a2a',x,4,2,3);r('#c8a840',x+s,1,2,1);r('#e8cc5a',x+s,2,2,2)}
  else if(t==1){r('#4c9a3c',x,2,3,3);r('#8acb4a',x+(f&1),2,2,2);r('#6ab04a',x,5,3,2)}
  else if(t==2){r('#3a7a2a',x,6,2,1);r('#e8803a',x,4,2,2);r('#4c9a3c',x+((f+i)&1),1,2,3)}
  else{r('#3f8f3a',x,3,2,3);r(['#e0506a','#f0d040','#c070e0','#ffffff'][(i+f)%4],x+((f+i)&1),2,2,2)}}
 [0,17].forEach(x=>{r('#8a6a42',x,0,1,2);r('#8a6a42',x,8,1,2)})})}
const FARM=[0,1,2,3].map(t=>[0,1,2,3].map(f=>farm(t,f)));

/* ---------- walls: weathered stonework ---------- */
function wall(v){const P=[['#bda07c','#8a6e50','#d8c29e'],['#a8a49a','#7a766c','#c4c0b4'],['#bda07c','#8a6e50','#d8c29e'],['#c8a878','#947a52','#e0c898'],['#b4aa98','#807660','#d0c8b0']][v];
 return mkx(14,16,r=>{r(P[1],0,3,14,13);r(P[0],1,4,12,11);r(P[2],1,4,12,2);for(let i=0;i<3;i++)r(P[0],i*5,0,4,4);r(P[1],1,10,12,1);r(P[1],6,4,1,6);
  if(v==2){r('#5e8a46',2,5,2,1);r('#5e8a46',9,11,3,1);r('#6a9a50',5,14,2,1);r('#5e8a46',0,3,2,1);r('#4a7a3a',11,4,1,6)}
  if(v==4){r(P[1],3,11,1,3);r(P[1],4,13,2,1);r(P[1],10,6,1,3)}
  if(v==1){r(P[1],9,4,1,4);r(P[0],3,12,3,1)}})}
const WALLV=[0,1,2,3,4].map(wall);

/* ---------- decals: dirt lanes, packed earth, cobbled plaza ---------- */
function blob(w,h,pal,seed,edge){const g=sr(seed),k=document.createElement('canvas');k.width=w;k.height=h;const x=k.getContext('2d'),im=x.createImageData(w,h);
 for(let j=0;j<h;j++)for(let i=0;i<w;i++){const nx=(i+.5)/w*2-1,ny=(j+.5)/h*2-1,d=nx*nx+ny*ny;if(d>1)continue;if(d>edge&&g()<(d-edge)/(1-edge)*1.1)continue;
  const c=pal[g()*pal.length|0],q=parseInt(c.slice(1),16);const o=(j*w+i)*4;im.data[o]=q>>16;im.data[o+1]=q>>8&255;im.data[o+2]=q&255;im.data[o+3]=225}
 x.putImageData(im,0,0);return k}
const DIRT=[1,2,3,4,5].map(i=>blob(24,12,['#a98c5c','#9c8052','#b49a68','#8e7448','#a38658','#c0b090'],i*31,.45));
const COBB=[7,8].map(i=>blob(40,22,['#9a968c','#8a867c','#aaa69a','#7e7a70','#b4b0a4'],i*17,.6));

/* ---------- animated props ---------- */
const P={};
P.barrel=()=>[mkx(10,12,r=>{r('#4a3018',1,2,8,10);r('#8a5a2a',1,3,8,8);r('#a87038',2,3,2,8);r('#4a3018',1,5,8,1);r('#4a3018',1,9,8,1);r('#b88848',2,1,6,2)})];
P.crate=()=>[mkx(12,10,r=>{r('#5a3a1e',0,0,12,10);r('#9a6c3a',1,1,10,8);r('#5a3a1e',0,4,12,1);r('#5a3a1e',5,0,1,10)})];
P.wood=()=>[mkx(16,10,r=>{for(let j=0;j<3;j++)for(let i=0;i<4-(j&1);i++){const x=1+i*4+(j&1)*2,y=j*3;r('#6a4a2a',x,y,4,4);r('#d8b078',x+1,y+1,2,2)}})];
P.hay=()=>[mkx(18,14,r=>{for(let j=0;j<8;j++){const w=18-j*2,x=j;r(j%2?'#d8b84a':'#e8cc5a',x,6+j-(j>5?0:0),w,1)}r('#e8cc5a',3,3,12,4);r('#f0d870',5,1,8,3);r('#b89a30',2,11,14,1);r('#b89a30',6,4,1,1);r('#b89a30',11,6,1,1)})];
P.cart=()=>[mkx(26,16,r=>{r('#5a3a1e',2,4,22,2);r('#8a5a2a',3,6,20,6);r('#a87038',4,6,18,2);r('#3a2210',0,10,2,3);[5,19].forEach(x=>{r('#3a2210',x,9,5,5);r('#8a6a42',x+1,10,3,3);r('#3a2210',x+2,11,1,1)});r('#e8cc5a',5,2,8,3);r('#f0d870',7,1,4,2)})];
P.bush=()=>[0,1].map(f=>mkx(14,10,r=>{r('#2f6a30',1,3,12,7);r('#3f8a3a',2,2,10,6);r('#58a84a',4,2+f,4,3);[[3,5],[8,4],[10,7],[5,8]].forEach(([x,y],i)=>r(['#e0506a','#f0d040','#fff','#c070e0'][i],x+f*(i&1),y,1,1))}));
P.laundry=()=>[0,1,2].map(f=>mkx(30,18,r=>{r('#5a3a1e',1,2,2,16);r('#5a3a1e',27,2,2,16);r('#d8d0b8',3,3,24,1);
 [['#efe6cc',6,6],['#c8423a',12,5],['#3a5a8a',18,6],['#e8b94a',23,5]].forEach(([c,x,h],i)=>{const o=[0,1,0][(f+i)%3],l=[5,6,4,5][i]+o;r(c,x,4,4,l);r('#00000022',x,4+l-1,4,1)})}));
P.well=()=>[0,1].map(f=>mkx(18,22,r=>{r('#5a3a1e',2,3,2,12);r('#5a3a1e',14,3,2,12);r('#7a3a2a',0,1,18,3);r('#a8523a',1,0,16,2);r('#8a867c',2,13,14,8);r('#b4b0a4',3,13,12,4);r('#3a5a7a',5,14,8,2);r('#6a665c',2,19,14,2);r('#d8c8a0',9,4,1,4+f*2);r('#8a5a2a',8,8+f*2,3,3)}));
P.torch=()=>[0,1,2].map(f=>mkx(8,18,r=>{r('#5a3a1e',3,7,2,11);r('#3a2a1a',2,6,4,2);const F=[['#f3a31a','#fff2a0',1,3],['#e8501a','#f3c04a',2,4],['#f3a31a','#fff2a0',0,3]][f];r(F[0],2+(F[2]&1?0:1),1,3,5);r(F[1],3,3,2,3)}));
P.scare=()=>[0,1].map(f=>mkx(14,20,r=>{r('#5a3a1e',6,6,2,14);r('#5a3a1e',1,8,12,2);r('#d8b878',5,1,4,4);r('#2a1a10',6,2,1,1);r('#2a1a10',8,2,1,1);r('#a8423a',5,0,4,1);r('#c8a040',2,10,3,3);r('#c8a040',9,10,3,3);r('#8a2a2a',11+f,11,2,2)}));
P.stall=(v)=>{const C=[['#c8423a','#efe6cc'],['#2a5aa8','#efe6cc'],['#3f8f4a','#efe6cc'],['#d98a3a','#efe6cc']][v%4];return [0,1].map(f=>mkx(28,26,r=>{r('#5a3a1e',2,8,2,16);r('#5a3a1e',24,8,2,16);r('#7a5230',2,16,24,8);r('#a87038',3,16,22,2);r('#5a3a1e',2,22,24,2);
 for(let i=0;i<7;i++){r(i%2?C[0]:C[1],2+i*4,4,4,7);r(i%2?C[0]:C[1],2+i*4,11,4,1+((i+f)&1))}
 for(let i=0;i<5;i++)r([['#d8302a','#e8a030','#c89048','#8acb4a','#d8302a'],['#3a5a8a','#efe6cc','#c8423a','#e8b94a','#3a5a8a'],['#a8a8b0','#c8c8d0','#8a8a92','#d8b84a','#a8a8b0'],['#e8a030','#e8cc5a','#c89048','#d8302a','#e8a030']][v%4][i],4+i*4,14,3,2)}))};
P.forge=()=>[0,1,2,3].map(f=>mkx(32,28,r=>{r('#6a655a',2,12,24,16);r('#8a8478',3,12,22,15);for(let j=0;j<4;j++)for(let i=0;i<5;i++)if((i+j)%2)r('#6a655a',3+i*4+(j&1),13+j*4,2,1);
 for(let i=0;i<5;i++)r(i<2?'#7a4a2a':'#5a3a1e',1+i*2,8+i,26-i*4,1);r('#4a2e18',0,7,28,2);r('#6a655a',21,0,4,12);r('#4a4a44',20,0,6,1);
 r('#1a1008',5,16,9,12);r(['#e8501a','#f3a31a','#ff7a2a','#f0c040'][f],6,20,7,8);r('#fff2a0',8+(f&1),23,3,3);
 r('#3a3a44',20,24,7,2);r('#5a5a66',21,22,5,2);r('#3a2210',28,20,3,8);r('#3a5a8a',28,19,3,1)}));
P.chapel=()=>[0,1].map(f=>mkx(40,50,r=>{const D='#8a8070',L='#c8b8a0';r(D,2,26,24,24);r(L,3,26,22,23);
 for(let i=0;i<9;i++){const w=(3+i*1.5)|0;r(i%2?'#a8423a':'#b8322a',14-w,16+i,w*2,1)}r('#8a2018',0,25,28,2);
 r(D,27,12,11,38);r(L,28,12,9,37);r('#2a1a14',30,18,5,9);r('#e8b94a',32+(f?1:0),21,2,3);r(D,27,28,11,1);
 for(let i=0;i<9;i++){const w=1+i;r(i<5?'#2a5aa8':'#2a4a8a',32-w,2+i,w*2+1,1)}r('#e8b94a',32,0,1,4);r('#e8b94a',31,1,3,1);
 r('#3a2210',10,36,7,14);r('#5a3a1e',11,37,5,13);r('#6a8aba',5,32,2,6);r('#6a8aba',21,32,2,6);r('#ffd45a00',5,32,2,6);r('#6a8aba',12,28,3,4)}));
P.mill=()=>Array.from({length:8},(_,f)=>mkx(38,50,r=>{
 for(let j=0;j<30;j++){const w=18-(j*.28)|0,x=19-(w>>1);r(j%6<1?'#8a8478':'#b4aa98',x,20+j,w,1);r('#8a8478',x,20+j,2,1)}
 for(let i=0;i<7;i++)r('#7a3a2a',19-(2+i*1.3|0),12+i,(2+i*1.3|0)*2,1);r('#5a2018',9,19,20,2);r('#3a2210',16,40,6,10);r('#6a8aba',17,28,3,4);
 const a0=f/8*TAU/4;for(let k=0;k<4;k++){const a=a0+k*TAU/4,ca=Math.cos(a),sa=Math.sin(a);
  for(let s=2;s<=17;s++){const px=19+ca*s,py=17+sa*s;r('#6a4a2a',px|0,py|0,1,1);if(s>6)for(let q=1;q<=4;q++)r(q==4?'#d8d0b8':'#efe6cc',(px-sa*q)|0,(py+ca*q)|0,1,1)}}
 r('#3a2a1a',18,16,3,3)}));
const PR={};const prop=(n,v)=>{const key=n+(v==null?'':v);return PR[key]||(PR[key]=(P[n])(v))};

/* ---------- domestic animals (hook into the existing animal list) ---------- */
function dlegs(a,x,y,col,n){const l=Math.round(Math.sin(a.ph)*1.5);c.fillStyle=col;c.fillRect(x-n,y-2,1,2+l);c.fillRect(x+n-1,y-2,1,2-l)}
const DRAW={
 dog:(a,x,y)=>{const f=a.face;c.fillStyle='#8a5a2a';c.fillRect(x-4,y-6,8,4);c.fillRect(x+f*4-1,y-8,3,4);c.fillStyle='#4a2e18';c.fillRect(x+f*4,y-8,1,2);c.fillRect(x-f*5,y-7+Math.round(Math.sin(a.ph*2)),2,1);dlegs(a,x,y,'#6a4220',3)},
 cat:(a,x,y)=>{const f=a.face;c.fillStyle='#c8c0b0';c.fillRect(x-3,y-5,6,3);c.fillRect(x+f*3-1,y-7,3,3);c.fillStyle='#8a8070';c.fillRect(x+f*3,y-8,1,1);c.fillRect(x-f*4,y-8+Math.round(Math.sin(a.ph)),1,4);dlegs(a,x,y,'#a8a090',2)},
 goose:(a,x,y)=>{const f=a.face;c.fillStyle='#f4f0e8';c.fillRect(x-4,y-6,8,4);c.fillRect(x+f*4-1,y-11,2,6);c.fillRect(x+f*4-1,y-12,3,2);c.fillStyle='#e8a030';c.fillRect(x+f*5,y-11,2,1);c.fillRect(x-1,y-2,1,2);c.fillRect(x+1,y-2,1,2);c.fillStyle='#c8c4b8';c.fillRect(x-f*4,y-6,2,2)},
 pig:(a,x,y)=>{const f=a.face;c.fillStyle='#e8a0a0';c.fillRect(x-5,y-7,10,5);c.fillRect(x+f*5-1,y-7,3,4);c.fillStyle='#c87878';c.fillRect(x+f*6,y-5,2,2);c.fillRect(x-f*6,y-6,1,2);dlegs(a,x,y,'#c87878',4)},
 cow:(a,x,y)=>{const f=a.face;c.fillStyle='#f0ece0';c.fillRect(x-7,y-11,14,7);c.fillRect(x+f*7-2,y-12,5,6);c.fillStyle='#2a2420';c.fillRect(x-4,y-11,4,3);c.fillRect(x+2,y-8,4,3);c.fillRect(x+f*8,y-12,1,5);c.fillStyle='#e8d8a0';c.fillRect(x+f*7-1,y-14,1,2);c.fillRect(x+f*9-1,y-14,1,2);c.fillStyle='#e0a0a0';c.fillRect(x+f*9,y-8,1,2);dlegs(a,x,y,'#d8d4c8',5);c.fillRect(x-5,y-4,1,3);c.fillRect(x+4,y-4,1,3)}};
const _da=drawAn;
drawAn=function(a,x,y){if(a.dom&&DRAW[a.t]){c.fillStyle='rgba(0,0,0,.3)';c.fillRect(x-5,y-1,10,2);DRAW[a.t](a,x,y);return}_da(a,x,y)};
function critters(b,n,rg){const L=[['goose',3],['dog',1],['pig',2],['cat',1],['cow',2]];let k=0;
 L.forEach(([t,q])=>{const m=Math.max(1,Math.round(q*n));for(let i=0;i<m;i++){const x=b.cx+(rg()-.5)*200,y=b.cy+(rg()-.3)*150;mkan(t,x,y);const a=AN[AN.length-1];a.dom=1;a.hp=10}})}

/* ---------- planning a village (relative coordinates, deterministic per seed) ---------- */
const BS=[];let OBS=null;
function obstacles(){if(OBS)return OBS;OBS=[];SLOTS.forEach(s=>{if(s.kg||s.gt||s.k=='wall')return;OBS.push([s.x-CX,s.y-CX,s.k=='keep'?40:s.k=='tower'?16:s.k=='farm'?17:19])});
 OBS.push([0,0,16],[0,-56,38],[-72,-14,24],[70,34,24],[-72,30,24],[66,-6,24]);return OBS}
function qd(x,y){return Math.hypot(x/189,y/162)}
function lane(pts,step,wig,rg,ph){const out=[];for(let i=0;i<pts.length-1;i++){const[x0,y0]=pts[i],[x1,y1]=pts[i+1],L=Math.hypot(x1-x0,y1-y0)||1,n=Math.max(1,Math.round(L/step)),nx=-(y1-y0)/L,ny=(x1-x0)/L;
  for(let j=0;j<n;j++){const t=j/n,w=Math.sin(out.length*.5+ph)*wig;out.push([x0+(x1-x0)*t+nx*w,y0+(y1-y0)*t+ny*w,nx,ny])}}return out}
function plan(seed,trees){
 const rg=sr(seed),ph=rg()*6,ob=obstacles(),lots=[],decals=[],props=[];
 const ring=(q,n,amp)=>{const o=[];for(let i=0;i<=n;i++){const a=i/n*TAU;o.push([Math.cos(a)*189*q+(rg()-.5)*amp,Math.sin(a)*162*q+(rg()-.5)*amp])}return o};
 const lanes=[
  lane([[189,2],[150,-10],[108,10],[62,-8],[26,-28],[6,-40]],12,7,rg,ph),           // gate street to the keep
  lane(ring(.74,22,12),12,3,rg,ph+1),                                              // inner ring lane
  lane([[4,-30],[12,30],[-8,74],[6,118],[4,150]],12,6,rg,ph+2),                    // south street
  lane([[189,2],[250,16],[300,-6],[322,2],[400,6]],12,5,rg,ph+3),                  // road to the outer gate
  lane(ring(1.38,34,16),13,4,rg,ph+4),                                             // outer lane between the walls
  lane([[-100,-4],[-60,-14],[-20,2]],12,5,rg,ph+5)];                               // west lane
 const bad=(x,y,rad)=>{const q=qd(x,y);if(Math.abs(q-1)<.1||Math.abs(Math.hypot(x/320,y/270)-1)<.08)return 1;if(Math.hypot(x/330,y/280)>1.1)return 1;
  for(const[o1,o2,r] of ob)if(Math.hypot(x-o1,y-o2)<r+rad)return 1;for(const t of trees)if(Math.abs(t[0]-x)<10&&Math.abs(t[1]-y)<10)return 1;return 0};
 lanes.forEach((L,li)=>{L.forEach((p,i)=>{const outer=li==3||li==4||qd(p[0],p[1])>1.1;
   if(!(li==4&&i%2))for(let k=0;k<2;k++){const dx=(rg()-.5)*5,dy=(rg()-.5)*4;if(!bad(p[0]+dx,p[1]+dy,3)||li==0||li==3)decals.push({x:p[0]+dx,y:p[1]+dy,v:rg()*5|0,o:outer})}
   if(i%2==0&&li!=3&&li!=5||(li==3&&i%3==0)||(li==5&&i%3==1))[-1,1].forEach(sd=>{if(rg()<.2)return;const off=(15+rg()*8)*sd,x=p[0]+p[2]*off+(rg()-.5)*5,y=p[1]+p[3]*off+(rg()-.5)*5;
    if(bad(x,y,13))return;if(lots.some(l=>Math.hypot(l.x-x,l.y-y)<21))return;lots.push({x,y,v:rg()*6|0,s:.88+rg()*.3,o:outer,d:Math.hypot(x,y+20)+rg()*22})})})});
 lots.sort((a,b)=>a.d-b.d);
 // props attached to cottages
 lots.forEach(l=>{if(rg()<.7){const k=['barrel','crate','wood','hay','bush','laundry','cart','bush','barrel'][rg()*9|0],ox=(rg()<.5?-1:1)*(15+rg()*4),oy=5+rg()*6,x=l.x+ox,y=l.y+oy;
   if(!bad(x,y,6)&&!lots.some(q=>q!==l&&Math.hypot(q.x-x,q.y-y)<14)&&!props.some(q=>Math.hypot(q.x-x,q.y-y)<9))props.push({n:k,x,y,own:l,v:rg()*4|0,o:l.o})}});
 // civic landmarks, found by searching outward from a preferred spot
 const civ=(n,v,x0,y0,rad,outer)=>{for(let r=0;r<70;r+=7)for(let a=0;a<TAU;a+=1.05){const x=x0+Math.cos(a)*r,y=y0+Math.sin(a)*r*.8;
   if(!bad(x,y,rad)&&!lots.some(l=>Math.hypot(l.x-x,l.y-y)<rad+12)&&!props.some(q=>Math.hypot(q.x-x,q.y-y)<rad+8)){props.push({n,x,y,v,civ:1,o:outer});return}}};
 civ('well',0,-26,16,12,0);civ('stall',0,24,12,16,0);civ('stall',1,-8,-24,16,0);civ('stall',2,50,-20,16,0);civ('forge',0,-104,52,22,0);civ('chapel',0,-118,-76,26,1);civ('mill',0,262,-84,26,1);civ('stall',3,-90,-30,16,0);
 [[-24,-58],[22,-48],[120,4],[-76,6],[-6,108],[200,6],[260,10]].forEach(([x,y],i)=>{if(!bad(x,y,4))props.push({n:'torch',x,y,v:0,o:i>4,lamp:1})});
 SLOTS.forEach(s=>{if(s.kg||s.k!='farm')return;const x=s.x-CX-11,y=s.y-CX-6;if(Math.hypot(s.x-CX,s.y-CX)>150&&!bad(x,y,3))props.push({n:'scare',x,y,v:0,o:1,idx:1})});
 return{lots,decals,props,lanes}}

/* ---------- placing it in the world ---------- */
const DEC=[],ANIM=[],HOUSES=[],LIGHTS=[],SM=[],TWR=[];
function put(o){o.dec=1;o.dead=0;o.done=0;objs.push(o);DEC.push(o);return o}
function placeProp(b,p){const fr=prop(p.n,p.v),im=fr[0],o=put({k:'decor',img:im,x:b.cx+p.x,y:b.cy+p.y,w:im.width,h:im.height,fr:fr.length>1?fr:null,fs:p.n=='mill'?5:p.n=='forge'?7:p.n=='torch'?9:p.n=='laundry'?2.4:p.n=='well'?.8:p.n=='chapel'?0:2,ph:Math.random()*8,n:p.n});
 if(p.n=='forge'){o.w=im.width;o.sm=1}
 if(p.n=='torch')o.lt=[0,-12,34,.85];if(p.n=='forge')o.lt=[-6,-8,46,.9];if(p.n=='stall'&&p.v==1)o.lt=[0,-14,26,.55];if(p.n=='well')o.lt=[0,-8,22,.3];
 if(o.fr)ANIM.push(o);if(o.lt)LIGHTS.push(o);if(p.n=='forge'||p.n=='chapel'||p.n=='mill')b.has[p.n]=o;
 const R2={barrel:5,crate:6,wood:8,hay:8,cart:12,well:9,stall:13,forge:16,chapel:20,mill:15,scare:3,bush:6,laundry:12}[p.n];if(R2)o.blk=R2;return o}
function placeLot(b,l){const o=put({k:'decor',img:HOUSE[l.v][0],x:b.cx+l.x,y:b.cy+l.y,w:Math.round(28*l.s),h:Math.round(24*l.s),vi:l.v,lit:Math.hypot(l.x,l.y)%1<.72});o.vd=HOUSE[l.v][0];o.vl=HOUSE[l.v][1];o.blk=14;o.smk=(l.x*7+l.y)%1>-.4;HOUSES.push(o);return o}
function homesOf(b){if(b.kind=='me')return SLOTS.filter(q=>!q.kg&&q.k=='home'&&q.built).length;
 if(b.kind=='kg')return b.k.sl.filter(z=>z.k=='home'&&z.built).length+(b.k.owned?2:0);
 let n=0;objs.forEach(o=>{if(o.gh&&o.pl===b.P&&o.k=='home'&&!o.dead)n++});return n}
function keepOf(b){return b.kind=='me'?!!K1.built:b.kind=='kg'?1:homesOf(b)>=2}
function mkBase(kind,cx,cy,seed,ref){
 const trees=[];objs.forEach(o=>{if(o.k=='tree'&&Math.abs(o.x-cx)<420&&Math.abs(o.y-cy)<360)trees.push([o.x-cx,o.y-cy])});
 const b={kind,cx,cy,k:kind=='kg'?ref:null,P:kind=='pv'?ref:null,pl:plan(seed,trees),np:0,nl:0,nd:0,has:{},ready:0};b.dd=b.pl.decals;BS.push(b);
 // lanes first (always visible), then cottages and props grow with the village
 b.pl.decals.forEach(d=>{d.o2=null});return b}
function grow(b){return;const homes=homesOf(b),keep=keepOf(b),tgt=0*Math.min(b.pl.lots.length,keep?12+homes*5+8:3+homes*3),L=b.pl.lots;
 while(b.nl<tgt){const l=L[b.nl++];placeLot(b,l);}
 b.pl.props.forEach(p=>{if(p.done)return;if(p.own&&!p.own.placed&&L.indexOf(p.own)>=b.nl)return;if(p.o&&!keep)return;p.done=1;placeProp(b,p)});
 b.pl.lots.forEach((l,i)=>{if(i<b.nl)l.placed=1});
 b.pl.decals.forEach(d=>{if(d.done||(d.o&&!(keep&&homes>=2)))return;d.done=1;const im=DIRT[d.v];put({k:'decor',img:im,x:b.cx+d.x,y:b.cy+d.y+6,sy:b.cy+d.y-9000,w:24,h:12,nsh:1})});
 if(!b.plz){b.plz=1;const im=COBB[0];put({k:'decor',img:im,x:b.cx,y:b.cy+11,sy:b.cy-8000,w:46,h:24,nsh:1});put({k:'decor',img:COBB[1],x:b.cx+2,y:b.cy-36,sy:b.cy-8000,w:40,h:20,nsh:1})}
 if(!b.an){b.an=1;critters(b,b.kind=='me'?1.5:.7,sr(b.cx^b.cy))}}
function sweep(t,cx,cy){
 if(t<X.sc)return;X.sc=t+.8;
 if(!BS.some(b=>b.kind=='me'))mkBase('me',CX,CX,SEED^0x51ED,null);
 if(!MPI&&typeof KG!='undefined')KG.forEach((k,i)=>{if(!BS.some(b=>b.k===k))mkBase('kg',k.x,k.y-20,SEED+i*977,k)});
 if(PV.live||MP.peers.size)MP.peers.forEach(P=>{if(!P.out&&P.lx!==undefined&&!BS.some(b=>b.P===P))mkBase('pv',P.lx,P.ly,h32(P.id||P.n||'p'),P)});
 BS.forEach(b=>{if(Math.abs(b.cx-cx)<760&&Math.abs(b.cy-cy)<640)grow(b)});
 // assign art variants to every home / farm / wall / tower
 objs.forEach(o=>{if(o.xv||o.dec)return;if(o.k=='home'||o.k=='farm'||o.k=='wall'||o.k=='tower'){o.xv=1;const h=Math.abs(Math.sin(o.x*12.9898+o.y*78.233)*43758.5453)%1;
  if(o.k=='home'){const v=(h*6)|0;o.vd=HOUSE[v][0];o.vl=HOUSE[v][1];o.img=X.night?o.vl:o.vd;o.lit=h>.15;HOUSES.push(o)}
  else if(o.k=='farm'){o.fr=FARM[(h*4)|0];o.fs=2.2;o.ph=h*9;o.img=o.fr[0];ANIM.push(o)}
  else if(o.k=='wall')o.img=WALLV[(h*5)|0];
  else if(o.k=='tower')TWR.push(o)}});
 SLOTS.forEach(s=>{if(s.o&&s.o.k=='tower')s.o.sl=s})}

/* ---------- patches that need the world draw loop ---------- */
const _amb=ambient;
ambient=function(dt,cx,cy,b,dn){_amb(dt,cx,cy,b,dn);try{vtick(dt,cx,cy,dn)}catch(e){console.error(e)}};
function vtick(dt,cx,cy,dn){if(!inGame)return;const t=now();sweep(t,cx,cy);
 const nt=dn<.62?1:0;if(nt!==X.night){X.night=nt;HOUSES.forEach(o=>{if(o.vd)o.img=nt&&o.lit?o.vl:o.vd})}
 const vis=o=>o.x>cx-70&&o.x<cx+VW+70&&o.y>cy-30&&o.y<cy+VH+120;
 ANIM.forEach(o=>{if(vis(o))o.img=o.fr[((t*o.fs+o.ph)|0)%o.fr.length]});
 if(dt>0){
  HOUSES.forEach(o=>{if(!vis(o)||o.k=='home'||!o.smk)return;smoke(Math.round(o.x-cx),Math.round(o.y-cy),{k:'home',h:o.h,x:o.x})});
  DEC.forEach(o=>{if(o.n=='forge'&&vis(o)){smoke(Math.round(o.x-cx+1),Math.round(o.y-cy),{k:'home',h:o.h+0,x:o.x});if(Math.random()<dt*7)PS.push({x:o.x-7+Math.random()*6,y:o.y-9,vx:(Math.random()-.5)*26,vy:-22-Math.random()*20,l:.45,c:Math.random()<.5?'#ffb030':'#ffe27a'})}});
  TWR.forEach(o=>{if(!vis(o)||o.dead)return;const pl=o.pl||(o.sl&&o.sl.kg&&!o.sl.kg.owned?o.sl.kg:PB);flag(Math.round(o.x-cx),Math.round(o.y-cy)-o.h+4,pl,1.2)});
  // sound of the village: bell, hammer, hens
  if(t>X.ev&&ac&&sb&&nb&&!muted){X.ev=t+9+Math.random()*16;let best=null,bd=420;BS.forEach(b=>{const d=Math.hypot(b.cx-H.x,b.cy-H.y);if(d<bd){bd=d;best=b}});
   if(best){const v=1-bd/420,r=Math.random(),fo=best.has.forge,ch=best.has.chapel;
    if(ch&&r<.3){X.bell=t+3.2;ch.bellT=t;[0,.9,1.8].forEach((d,i)=>setTimeout(()=>{tn(392,1.1,'sine',.05*v);tn(784,.7,'sine',.018*v)},d*1000))}
    else if(fo&&r<.75){[0,.28,.6,.88,1.3].forEach(d=>setTimeout(()=>{ns(.05,.14*v,'highpass',2600);tn(1600+Math.random()*300,.06,'triangle',.03*v)},d*1000))}
    else{tn(680,.12,'square',.012*v,420);setTimeout(()=>tn(520,.16,'square',.012*v,380),160)}}}
  const ch=BS.map(b=>b.has.chapel).find(Boolean);if(ch&&ch.fr)ch.fs=t<X.bell?5:0}}
/* night lights (called from the night overlay) */
window.xNight=function(lt,cx,cy){const t=now(),fl=Math.sin(t*17)*.08+Math.sin(t*7.3)*.06;
 LIGHTS.forEach(o=>{if(o.x>cx-80&&o.x<cx+VW+80&&o.y>cy-60&&o.y<cy+VH+100)lt(o.x-cx+o.lt[0],o.y-cy+o.lt[1],o.lt[2]*(1+fl),o.lt[3])});
 let _hn=0;HOUSES.forEach(o=>{if(_hn>14||!o.lit||o.x<cx-60||o.x>cx+VW+60||o.y<cy-30||o.y>cy+VH+80)return;_hn++;lt(o.x-cx,o.y-cy-7,22,.42)})};
window.xVil={BS,DEC};
})();
