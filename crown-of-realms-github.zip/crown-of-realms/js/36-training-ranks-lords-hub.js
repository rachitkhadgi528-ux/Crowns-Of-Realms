/* ===== v19: Training Ground, ranks & skills, Lords hub, wardrobe, army commands, ministers, peace treaties, banner logo ===== */
(function(){try{
const LS=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}},SV=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const T=()=>now(),$$=id=>document.getElementById(id);
const SKD={pike:['Brace','def'],cguard:['Shield Wall','def'],legi:['Testudo','def'],crus:['Holy Resolve','def'],sword:['Duelist','crit'],knight:['Cleave','crit'],saru:['Iaido Strike','crit'],bow:['Volley','rng'],xbow:['Bolt Pierce','rng'],jave:['Pilum Throw','rng'],tarc:['Rapid Shot','rng'],cav:['Charge','chg'],hcav:['Trample','chg'],tlan:['Lance Charge','chg']};
const KD={def:'−10% damage taken per skill level',crit:'12% chance of ×2 damage per skill level',rng:'15% chance of a double shot per skill level',chg:'+25% first-strike damage per level (every 6s)'};
const RN=['','Veteran','Veteran','Elite','Elite','Champion','Champion','Legend','Legend','Legend'],STN={d:'Damage',a:'Shield',s:'Skill'};
const rk=u=>u.tl?u.tl.d+u.tl.a+u.tl.s:0,rname=r=>RN[Math.min(9,r)]||'';
/* ---- Royal armoury items (💠 Crests) with perks ---- */
const RYI=[{id:'gild',t:'armor',n:'Gilded Plate',c:60,d:'−10% damage taken',p:{a:.10},col:['#f2d26a','#8a5a10']},{id:'frost',t:'armor',n:'Frostmail',c:90,d:'−15% damage taken',p:{a:.15},col:['#bfe4ff','#2a4a8a']},{id:'shadow',t:'armor',n:'Shadow Cloak',c:110,d:'−8% damage taken, +30 health',p:{a:.08,h:30},col:['#2a2a36','#7a1a8a']},{id:'dragon',t:'armor',n:'Dragonscale',c:160,d:'−20% damage taken, +20 health',p:{a:.20,h:20},col:['#2a8a4a','#e8b94a']},
{id:'sun',t:'weapon',n:'Sunblade',c:70,d:'+15% hero damage',p:{d:.15}},{id:'storm',t:'weapon',n:'Stormaxe',c:130,d:'+25% hero damage',p:{d:.25}},{id:'reaper',t:'weapon',n:'Reaper Scythe',c:180,d:'+35% hero damage',p:{d:.35}},
{id:'dawn',t:'horse',n:'Warhorse of Dawn',c:80,d:'+25 health',p:{h:25}},{id:'night',t:'horse',n:'Nightmare Charger',c:140,d:'+40 health, +5% damage',p:{h:40,d:.05}}];
const RY={own:LS('cor_ry',{}).own||{},eq:LS('cor_ry',{}).eq||{},p:{a:0,d:0},hb:0};
function ryCalc(){let a=0,d=0,h=0;Object.values(RY.eq).forEach(id=>{const it=RYI.find(x=>x.id==id);if(!it)return;a+=it.p.a||0;d+=it.p.d||0;h+=it.p.h||0});RY.p={a:Math.min(.4,a),d};H.mhp+=h-RY.hb;H.hp=Math.min(H.mhp,H.hp+Math.max(0,h-RY.hb));RY.hb=h;
 const ar=RYI.find(x=>x.id==RY.eq.armor);if(ar&&ar.col){const h0=HS[HI];h0.c1=ar.col[0];h0.c2=ar.col[1];try{applyHero()}catch(e){}}}
window.ryBuy=id=>{const it=RYI.find(x=>x.id==id);if(!it)return;if(!RY.own[id]){if(!MT.spend(it.c))return toast('Not enough 💠 Crests');RY.own[id]=1}RY.eq[it.t]=RY.eq[it.t]==id?'':id;SV('cor_ry',{own:RY.own,eq:RY.eq});ryCalc();tgUI('royal')};
/* ---- ranks, damage, shield, skills (solo + PvP: applied to every hit your units make/take) ---- */
const _hu=hurt;hurt=function(tg,dmg,from){try{
 if(tg&&!tg.gh&&tg.kg&&tg.kg.treaty>T()&&from&&(from===H||from.team===0))return;
 if(from&&from.tl){const t=from.tl,k=(SKD[from.type]||[])[1];dmg*=1+.12*t.d;if(k=='crit'&&t.s&&Math.random()<.12*t.s)dmg*=2;else if(k=='rng'&&t.s&&Math.random()<.15*t.s)dmg*=2;else if(k=='chg'&&t.s&&T()>(from._ch||0)){from._ch=T()+6;dmg*=1+.25*t.s}}
 if(from&&from.team===0&&from!==H&&form>0)dmg*=1.06;
 if(from===H&&RY.p.d)dmg*=1+RY.p.d;
 if(tg&&tg.tl){const t=tg.tl;dmg*=Math.max(.35,1-.08*t.a);if((SKD[tg.type]||[])[1]=='def'&&t.s)dmg*=1-.1*t.s}
 if(tg===H&&RY.p.a)dmg*=1-RY.p.a}catch(e){}return _hu(tg,dmg,from)};
function bump(u,st){u.tl=u.tl||{d:0,a:0,s:0};if(u.tl[st]>=3)return 0;u.tl[st]++;if(st=='a'){u.mhp=Math.round(u.mhp*1.1);u.hp=Math.round(u.hp*1.1)}const n=rname(rk(u));u.nm=(n?n+' ':'')+(UT[u.type]?UT[u.type].n:u.type);return 1}
const _du=drawU;drawU=function(u,x,y){const r=u.tl?rk(u):0;if(!r)return _du(u,x,y);const s=1+Math.min(.3,.035*r);c.save();c.translate(x,y);c.scale(s,s);c.translate(-x,-y);_du(u,x,y);c.restore();
 const sc=(UT[u.type]&&UT[u.type].big||1)*s,hy=y-27*sc;c.fillStyle=r>=5?'#ff5a3a':'#ffd24a';for(let i=0;i<Math.min(5,Math.ceil(r/2));i++)c.fillRect(x-6+i*3,hy,2,2);
 if(r>=3||US.length<260){c.font='bold 5px monospace';c.textAlign='center';c.fillStyle='#000';c.fillText(rname(r),x+.5,hy-2.5);c.fillStyle=r>=5?'#ffb090':'#ffe9a8';c.fillText(rname(r),x,hy-3)}};
/* ---- training queue ---- */
const TQ=[];window.tgQ=()=>'In training: '+TQ.map(q=>UT[q.type].n+' '+STN[q.st]+' '+Math.max(0,Math.ceil(q.end-T()))+'s').join(' · ');
const cost=(n,l,st)=>Math.round(n*(12+8*l)*(st=='s'?1.4:1));
window.tgTrain=(type,st)=>{const us=ARM.filter(u=>!u.dead&&!u.trn&&u.type==type&&(!u.tl||u.tl[st]<3));if(!us.length)return toast('Nothing left to train');if(TQ.length>=4)return toast('Training yard is full (4 batches)');
 us.sort((a,b)=>(a.tl?a.tl[st]:0)-(b.tl?b.tl[st]:0));const n=Math.min(25,us.length),l=us[0].tl?us[0].tl[st]:0,cs=cost(n,l,st);if(H.gold<cs)return toast('Need '+cs+' 🪙 gold');H.gold-=cs;
 let pk=0;us.slice(0,n).forEach(u=>{pk+=bump(u,st)});sfx('win');toast('✔ '+pk+' '+UT[type].n+' trained · '+STN[st]);tgUI('train')};
setInterval(()=>{try{for(let i=TQ.length;i--;){const b=TQ[i];if(T()<b.end)continue;TQ.splice(i,1);window.__tgDirty=1;let k=0;US.forEach(u=>{if(b.ids.indexOf(u.uid)>=0){u.trn=0;if(!u.dead)k+=bump(u,b.st)}});if(k){toast('✔ '+k+' '+UT[b.type].n+' promoted · '+STN[b.st]);sfx('win')}}
 {const ov=$$('ov');if(ov&&ov.style.display=='flex'&&ov.dataset.tg&&ov.querySelector('#tgroot')){const q=ov.querySelector('#tgq');if(q&&TQ.length)q.textContent=tgQ();if(window.__tgDirty&&!window.__tgDown&&Date.now()-(window.__tgT||0)>1500){window.__tgDirty=0;tgUI(ov.dataset.tg)}}}}catch(e){}},1000);
/* NPC kingdoms also train over time */
setInterval(()=>{try{if(!inGame||paused)return;const tr=Math.min(LI>=3?6:LI>=2?4:3,((window.GT_?GT_():0)/(LI>=3?120:LI>=2?180:240))|0);if(!tr)return;US.forEach(u=>{if(u.team&&u.kg&&!u.dead&&!u.tl){u.tl={d:tr,a:tr>>1,s:tr>1?1:0};if(u.tl.a){u.mhp=Math.round(u.mhp*1.1);u.hp=u.mhp}}})}catch(e){}},15000);
/* ---- ministers (captured kingdoms) ---- */
const owned=()=>(window.KG||[]).filter(k=>k.owned);
window.minHire=i=>{const k=KG[i];if(!k||!k.owned||k.min)return;if(H.gold<150)return toast('Need 150 🪙 gold');H.gold-=150;k.min={mode:'def',tax:0,aid:0};toast('Minister appointed in '+k.name);tgUI('min')};
window.minMode=(i,m)=>{const k=KG[i];if(k&&k.min){k.min.mode=m;tgUI('min')}};
function aid(k,n){if(ARM.length+n>500)n=Math.max(0,500-ARM.length);for(let i=0;i<n;i++)mku(0,i%3?'sword':'bow',H.x+Math.random()*60-30,H.y+Math.random()*40+20);if(n){toast('👑 '+k.name+' sends '+n+' soldiers to your side');sfx('horn')}}
window.minHelp=i=>{const k=KG[i];if(!k||!k.min)return;if(T()<(k.min.cd||0))return toast('The minister needs '+Math.ceil(k.min.cd-T())+'s');k.min.cd=T()+60;aid(k,6);tgUI('min')};
setInterval(()=>{try{if(!inGame||paused||won)return;owned().forEach(k=>{if(!k.min)return;const t=60+((window.GT||0)/60|0)*4;H.gold+=t;k.min.tax+=t});toast('💰 Minister tax collected')}catch(e){}},30000);
setInterval(()=>{try{if(!inGame||paused||won)return;owned().forEach(k=>{if(!k.min||!k.cast)return;const m=k.min.mode,cx=k.cast.x,cy=k.cast.y;
 if(m=='def'){const hostile=US.some(u=>u.team&&!u.dead&&u.kg!==k&&(!u.kg||u.kg.rel<0)&&Math.abs(u.x-cx)<500&&Math.abs(u.y-cy)<400),mine=US.filter(u=>u.kg===k&&u.team&&!u.dead).length;if(hostile&&mine<12){for(let i=0;i<3;i++)mku(1,'guard',cx+Math.random()*60-30,cy+50,{kg:k});toast('🛡 '+k.name+' raises defenders')}}
 else if(US.some(u=>u.team&&!u.dead&&(!u.kg||u.kg.rel<0)&&Math.abs(u.x-H.x)<520&&Math.abs(u.y-H.y)<420)&&T()>(k.min.cd||0)){k.min.cd=T()+60;aid(k,4)}})}catch(e){}},9000);
/* ---- peace treaties (5-minute lock) ---- */
const PCH={200:.35,500:.65,1000:.92};
function sign(k,msg){k.rel=0;k.treaty=T()+300;US.forEach(u=>{if(u.kg===k&&u.raid&&!u.dead)u.dead=T()});toast(msg||'🕊 Peace signed with '+k.name+' — no war for 5:00');sfx('win')}
window.peaceOffer=(i,g)=>{const k=KG[i];if(!k||k.rel>=0)return;if(T()<(k.pcd||0))return toast('They refuse to talk for '+Math.ceil(k.pcd-T())+'s');if(H.gold<g)return toast('Need '+g+' 🪙 gold');
 if(Math.random()<PCH[g]){H.gold-=g;sign(k)}else{H.gold-=Math.floor(g/4);k.pcd=T()+40;toast(k.name+' scorns your offer and keeps the tribute')}tgUI('peace')};
const _dc2=decl;decl=function(k,auto){if(k&&k.treaty>T()){if(!decl.t2||T()-decl.t2>4){decl.t2=T();toast('🕊 Treaty holds: '+Math.ceil(k.treaty-T())+'s left')}return}if(k&&k.treaty){k.treaty=0;toast('The treaty with '+k.name+' has ended')}return _dc2(k,auto)};
function propose(){if(!inGame||paused||PV.live||$$('pcb')||$$('ov').style.display=='flex')return;const ks=(window.KG||[]).filter(k=>k.rel<0&&!k.owned&&T()>(k.pcd||0)&&window.peaceReady&&peaceReady(k));if(!ks.length||Math.random()>.3)return;const k=ks[Math.random()*ks.length|0],tb=100+(Math.random()*200|0),d=document.createElement('div');d.id='pcb';window.__pmT=GT_();
 d.style.cssText='position:fixed;left:50%;bottom:calc(120px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:30;background:#2a2036;border:3px solid #e8b94a;padding:8px 12px;font-size:10px;text-align:center;max-width:70vw';
 d.innerHTML='🕊 <b>'+k.name+'</b> asks for peace and offers <b>'+tb+' 🪙</b> tribute.<br><button class="b" style="position:static;margin:4px" id="pca">Accept</button><button class="b" style="position:static;margin:4px" id="pcr">Refuse</button>';document.body.appendChild(d);
 const cl=()=>{d.remove()};$$('pca').onclick=()=>{H.gold+=tb;sign(k);cl()};$$('pcr').onclick=()=>{k.pcd=T()+90;cl()};setTimeout(cl,20000)}
setInterval(()=>{try{propose()}catch(e){}},40000);
/* ---- army commands in formation ---- */
window.ARMCMD='';
window.armyCmd=function(){const m=window.ARMCMD;if(!m)return;
 if(m=='retreat'){ARM.forEach(u=>{if(u.gd||u.hold||u.dead)return;u.sx=CX+(u.sx-H.x)*.6;u.sy=CX+20+(u.sy-H.y)*.6});if(Math.hypot(H.x-CX,H.y-CX)<260){window.ARMCMD='';cmdUI()}return}
 let b=null,bd=900;US.forEach(u=>{if(!u.team||u.dead||(u.kg&&u.kg.rel>=0))return;const d=Math.hypot(u.x-H.x,u.y-H.y);if(d<bd){bd=d;b=u}});
 if(!b){window.ARMCMD='';cmdUI();toast('No enemy in sight — army follows you');return}
 const gx=b.x-H.x,gy=b.y-H.y,l=Math.hypot(gx,gy)||1,st=Math.min(l-30,l);ARM.forEach(u=>{if(u.gd||u.hold||u.dead)return;u.sx+=gx/l*st;u.sy+=gy/l*st})};
function cmdUI(){const a=$$('cmA'),r=$$('cmR');if(a)a.style.outline=window.ARMCMD=='attack'?'2px solid #ffd24a':'';if(r)r.style.outline=window.ARMCMD=='retreat'?'2px solid #ffd24a':''}
const cp=document.createElement('div');cp.id='cmdp';cp.style.cssText='position:fixed;left:max(8px,env(safe-area-inset-left,0px));top:calc(152px + env(safe-area-inset-top,0px));z-index:6;display:none;gap:4px';
cp.innerHTML='<button class="b" id="cmA" style="position:static;padding:4px 6px;font-size:8px;background:#8a2a1a;color:#fff">⚔ Charge</button><button class="b" id="cmR" style="position:static;padding:4px 6px;font-size:8px;background:#2a4a8a;color:#fff">🏳 Retreat</button>';document.body.appendChild(cp);
const cmd=(m)=>e=>{e.preventDefault();window.ARMCMD=window.ARMCMD==m?'':m;cmdUI();toast(window.ARMCMD=='attack'?'⚔ Army charges in formation!':window.ARMCMD=='retreat'?'🏳 Army falls back in formation':'Army follows you')};
$$('cmA').addEventListener('pointerdown',cmd('attack'));$$('cmR').addEventListener('pointerdown',cmd('retreat'));
setInterval(()=>{try{cp.style.display=(inGame&&!won&&!PV.live?'flex':(inGame&&!won?'flex':'none'))}catch(e){}},500);
/* ---- banner logo: kingdom emblem on the player's banners ---- */
const _fl=flag;flag=function(x,yb,b,s){_fl(x,yb,b,s);try{const h0=HS[HI];if(b&&b.c1===h0.c1&&b.c2===h0.c2&&window.KNAME){const h=Math.round(14*s),w=Math.max(3,Math.round(9*s*.9)),hh=Math.max(3,Math.round(6*s*.9));c.save();c.font='bold '+Math.max(4,hh-1)+'px monospace';c.textAlign='center';c.fillStyle=h0.c2==='#ffffff'?'#000':'#ffe9a8';c.fillText(String(KNAME).charAt(0).toUpperCase(),x+1+w/2,yb-h+hh-1);c.restore()}}catch(e){}};
/* ---- Training Ground UI (replaces the shop) ---- */
const oldShop=window.shopHub;window.oldShopX=oldShop;
window.shopHub=function(){tgUI('train')};
['touchstart','touchmove','wheel','pointerdown'].forEach(ev=>addEventListener(ev,()=>{window.__tgT=Date.now()},{passive:true,capture:true}));addEventListener('pointerdown',()=>{window.__tgDown=1},{passive:true,capture:true});['pointerup','pointercancel','touchend','touchcancel'].forEach(ev=>addEventListener(ev,()=>{window.__tgDown=0;window.__tgT=Date.now()},{passive:true,capture:true}));
window.tgUI=function(tab){if(!inGame)return;tab=tab||'train';const e=$$('ov');const _sc=(e.dataset.tg==tab&&e.style.display=='flex'&&e.firstElementChild)?e.firstElementChild.scrollTop:0;e.style.display='flex';e.dataset.tg=tab;
 const tabs=[['train','⚔ Train'],['min','👑 Ministers'],['peace','🕊 Peace'],['decor','\u{1F3DB} Decor'],['royal','✦ Royal']].map(([k,l])=>'<button style="'+(k==tab?'outline:2px solid #e8b94a':'')+'" onclick="tgUI(\''+k+'\')">'+l+'</button>').join(' ');
 let b='';
 if(tab=='train'){const g={};ARM.forEach(u=>{if(u.dead||!UT[u.type]||UT[u.type].w=='none'||UT[u.type].dmg===undefined)return;(g[u.type]=g[u.type]||[]).push(u)});
  b+='<p style="font-size:9px">🪙 '+(H.gold|0)+' · Army '+ARM.length+'/500 · Training is instant: up to 25 troops per tap.</p>';
  Object.keys(g).forEach(t=>{const us=g[t],d=UT[t],sk=SKD[t];b+='<div style="border:2px solid #4b3a63;padding:4px;margin:4px 0;font-size:9px"><b>'+d.n+' ×'+us.length+'</b> · ❤'+d.hp+' ⚔'+d.dmg+(sk?'<br>✦ '+sk[0]+': '+KD[sk[1]]:'')+'<br>';
   ['d','a','s'].forEach(st=>{if(st=='s'&&!sk)return;const m=us.filter(u=>!u.trn&&(!u.tl||u.tl[st]<3)),lv=us.reduce((a,u)=>a+(u.tl?u.tl[st]:0),0),mx=Math.min(25,m.length),l0=m.length?Math.min.apply(null,m.map(u=>u.tl?u.tl[st]:0)):3;
    b+='<button '+(m.length?'':'disabled')+' onclick="tgTrain(\''+t+'\',\''+st+'\')" style="margin:2px;font-size:9px">'+STN[st]+' ('+lv+'/'+us.length*3+') '+(m.length?'🪙'+cost(mx,l0,st):'max')+'</button>'});b+='</div>'});
  if(!Object.keys(g).length)b+='<p>No troops yet — recruit some at the barracks first.</p>';
  if(TQ.length)b+='<p id="tgq" style="font-size:9px;color:#e8b94a">'+tgQ()+'</p>';
  b+='<p><button onclick="tgOld()" style="font-size:9px">🛒 Supplies, Armoury &amp; Decorations</button></p>'}
 else if(tab=='min'){const ks=owned();b+='<p style="font-size:9px">Ministers govern captured kingdoms: tax every 30s, raise defenders or send troops to you.</p>';if(!ks.length)b+='<p>Capture a kingdom first.</p>';
  ks.forEach(k=>{const i=KG.indexOf(k);b+='<div style="border:2px solid #4b3a63;padding:4px;margin:4px 0;font-size:9px"><b>'+k.name+'</b><br>'+(k.min?'Minister: '+(k.min.mode=='def'?'🛡 Defence':'⚔ Aid you')+' · tax earned 🪙'+k.min.tax+'<br><button onclick="minMode('+i+',\'def\')">🛡 Defend castle</button><button onclick="minMode('+i+',\'atk\')">⚔ Aid me</button><button onclick="minHelp('+i+')">📣 Ask help now</button>':'<button onclick="minHire('+i+')">Appoint minister 🪙150</button>')+'</div>'})}
 else if(tab=='peace'){const now_=T();if(PV.live)b+='<p style="font-size:9px">Online ceasefire (5:00, both sides): offer tribute to a player.</p>'+[...MP.peers.values()].filter(q=>!q.out).map(q=>'<div style="font-size:9px">'+(q.n||q.nm||'Player')+' '+[100,300,600].map(g=>'<button onclick="pvOffer(\''+q.id+'\','+g+')">🪙'+g+'</button>').join('')+'</div>').join('')+'<p style="display:none"></p>';
  const ws=(window.KG||[]).filter(k=>k.rel<0&&!k.owned),ts=(window.KG||[]).filter(k=>k.treaty>now_);
  ts.forEach(k=>{const s=Math.ceil(k.treaty-now_);b+='<p style="font-size:9px;color:#6ecf8a">🕊 Treaty with '+k.name+': '+(s/60|0)+':'+('0'+s%60).slice(-2)+' left</p>'});
  if(!ws.length)b+='<p style="font-size:9px">You are not at war with anyone.</p>';
  ws.forEach(k=>{const i=KG.indexOf(k);b+='<div style="border:2px solid #4b3a63;padding:4px;margin:4px 0;font-size:9px"><b>'+k.name+'</b> — at war<br>Offer tribute:<br>'+[200,500,1000].map(g=>'<button onclick="peaceOffer('+i+','+g+')">🪙'+g+' ('+(PCH[g]*100|0)+'%)</button>').join('')+'</div>'});
  b+='<p style="font-size:8px">Once signed, neither side can declare war for 5 minutes.</p>'}
 else if(tab=='decor'){b+=window.decBody?decBody():''}
 else{b+='<p style="font-size:9px">💠 '+MT.bal()+' Crests · tap to buy, tap again to equip/unequip (one per slot). Perks apply in solo and PvP.</p>';
  ['armor','weapon','horse'].forEach(sl=>{b+='<p style="font-size:9px;color:#e8b94a;margin:4px 0">'+sl.toUpperCase()+'</p>';RYI.filter(x=>x.t==sl).forEach(it=>{b+='<button onclick="ryBuy(\''+it.id+'\')" style="margin:2px;font-size:9px;'+(RY.eq[sl]==it.id?'outline:2px solid #6ecf8a':'')+'">'+it.n+' · '+it.d+' · '+(RY.own[it.id]?(RY.eq[sl]==it.id?'✔ equipped':'owned'):'💠'+it.c)+'</button><br>'})})}
 e.innerHTML='<div id="tgroot" style="width:min(94vw,460px)"><div class="xh"><h3>⚔ Training Ground</h3><button onclick="ovx()">✕ Close</button></div><p>'+tabs+'</p>'+b+'</div>';if(_sc&&e.firstElementChild)e.firstElementChild.scrollTop=_sc};
window.tgOld=()=>{try{ovx();oldShop()}catch(e){}};
setInterval(()=>{try{const s=$$('shb');if(s&&s.textContent!='⚔'){s.textContent='⚔';s.title='Training Ground'}}catch(e){}},700);
/* ---- Lords hub on the main screen ---- */
const WD=LS('cor_ward',{h:{},u:{}}),SW=['#e8e8ee','#b01c1c','#2a4a8a','#2a8a4a','#e8b94a','#7a2a6a','#1a1a22','#d8d8a0'];
function wardApply(){HS.forEach((h,i)=>{const w=WD.h[i];if(w){h.c1=w[0];h.c2=w[1]}});Object.keys(WD.u).forEach(t=>{if(UT[t]){UT[t].c=WD.u[t][0];UT[t].s=WD.u[t][1]}})}
window.lhWear=(k,a,col)=>{if(k=='h'){const w=WD.h[HI]||[HS[HI].c1,HS[HI].c2];w[a]=col;WD.h[HI]=w;HS[HI].c1=w[0];HS[HI].c2=w[1];try{applyHero()}catch(e){}}else{const d=UT[k],w=WD.u[k]||[d.c,d.s||d.c];w[a]=col;WD.u[k]=w;d.c=w[0];d.s=w[1]}SV('cor_ward',WD);lhUI()};
window.lhUI=function(){let e=$$('lh');if(!e){e=document.createElement('div');e.id='lh';e.style.cssText='position:fixed;inset:0;z-index:99990;background:#000d;display:flex;align-items:center;justify-content:center;font:9px/1.5 "Press Start 2P",monospace;color:#f3e9d2;overflow:auto';document.body.appendChild(e)}const _ps=[e.scrollTop,e.firstElementChild?e.firstElementChild.scrollTop:0];e.style.display='flex';
 const h=HS[HI],sw=(k,a)=>SW.map(c=>'<span onclick="lhWear(\''+k+'\','+a+',\''+c+'\')" style="display:inline-block;width:18px;height:18px;margin:1px;background:'+c+';border:2px solid '+((k=='h'?(a?h.c2:h.c1):(a?UT[k].s:UT[k].c))==c?'#ffd24a':'#000')+'"></span>').join('');
 const ut=[...new Set([...h.u,'pike','sword','bow','cav'])].filter(t=>UT[t]),mh=H.mhp||100;
 let b='<div style="width:min(96vw,560px);background:#2a2036;border:4px solid #e8b94a;padding:8px;max-height:96vh;overflow:auto"><div style="display:flex;justify-content:space-between"><b style="color:#e8b94a;font-size:11px">🛡 Lords &amp; Units</b><button class="mb" style="width:auto;padding:2px 8px;font-size:10px" onclick="document.getElementById(\'lh\').style.display=\'none\'">✕</button></div>';
 b+=HS.map((x,i)=>'<button class="mb" style="width:auto;font-size:10px;padding:3px 6px;margin:2px;'+(i==HI?'outline:2px solid #e8b94a':'')+'" onclick="pickH('+i+')">'+x.n+'</button>').join('');
 b+='<div style="border:2px solid #4b3a63;padding:4px;margin:4px 0"><b style="color:'+h.c1+'">'+h.n+' the '+h.t+'</b><br>❤ Health '+mh+' · ⚔ Damage 14 (+gear)<br>'+h.d+'<br>Wardrobe — armour: '+sw('h',0)+'<br>trim/cape: '+sw('h',1)+'</div>';
 ut.forEach(t=>{const d=UT[t],sk=SKD[t],bar=(v,m,c)=>'<span style="display:inline-block;width:'+Math.min(100,v/m*100)+'px;height:6px;background:'+c+'"></span>';
  b+='<div style="border:2px solid #4b3a63;padding:4px;margin:4px 0"><b>'+d.n+'</b> ❤'+d.hp+' '+bar(d.hp,150,'#d33')+' ⚔'+d.dmg+' '+bar(d.dmg,16,'#e93')+(d.rng?' ◎'+d.rng:'')+'<br>'+(sk?'✦ <b style="color:#ffd24a">'+sk[0]+'</b>: '+KD[sk[1]]+'<br>':'')+'Outfit: '+sw(t,0)+'<br>Trim: '+sw(t,1)+'</div>'});
 b+='<small>Train troops at the ⚔ Training Ground in your camp for Damage, Shield and Skill ranks (Veteran → Legend).</small></div>';e.innerHTML=b;e.scrollTop=_ps[0];if(e.firstElementChild)e.firstElementChild.scrollTop=_ps[1]};
const _pk=window.pickH;window.pickH=function(i){_pk(i);if($$('lh')&&$$('lh').style.display=='flex')lhUI()};
window.WARD=WD;wardApply();try{applyHero()}catch(e){}
/* more armoury designs: each draws on the lord when equipped */
const NI=[{id:'wing',t:'armor',n:'Angel Wings',c:200,d:'−18% damage taken, wings & halo',p:{a:.18},vis:'wing'},{id:'horn',t:'armor',n:'Viking Horned Helm',c:120,d:'−12% damage taken, +20 health',p:{a:.12,h:20},vis:'horn'},{id:'crown',t:'armor',n:'Sun King Crown',c:150,d:'−10% damage, +15 health',p:{a:.1,h:15},vis:'crown'},
{id:'flame',t:'weapon',n:'Flame Greatsword',c:150,d:'+30% hero damage, burning blade',p:{d:.3},vis:'flame'},{id:'ice',t:'weapon',n:'Frost Lance',c:150,d:'+28% hero damage, icy tip',p:{d:.28},vis:'ice'},{id:'halb',t:'weapon',n:'Royal Halberd',c:110,d:'+20% hero damage',p:{d:.2},vis:'halb'},
{id:'gold',t:'horse',n:'Golden Barding',c:170,d:'+50 health, gilded horse',p:{h:50},vis:'gbard'},{id:'ghost',t:'horse',n:'Ghost Steed',c:190,d:'+35 health, +8% damage',p:{h:35,d:.08},vis:'ghost'}];
NI.forEach(i=>{if(!RYI.some(x=>x.id==i.id))RYI.push(i)});
const R=(x,y,w,h,col)=>{c.fillStyle=col;c.fillRect(Math.round(x),Math.round(y),w,h)};
function gearVis(x,y,sc){const e=RY.eq,g=id=>(RYI.find(z=>z.id==e[id])||{}).vis,a=g('armor'),w=g('weapon'),h=g('horse'),t=now();
 if(a=='wing'){R(x-15*sc,y-22*sc,7*sc,3*sc,'#f4f4ff');R(x-13*sc,y-19*sc,5*sc,3*sc,'#d8d8f0');R(x+8*sc,y-22*sc,7*sc,3*sc,'#f4f4ff');R(x+8*sc,y-19*sc,5*sc,3*sc,'#d8d8f0');R(x-4*sc,y-31*sc,8*sc,1.5*sc,'#ffe66a')}
 if(a=='horn'){R(x-7*sc,y-28*sc,3*sc,5*sc,'#f4ecd0');R(x+4*sc,y-28*sc,3*sc,5*sc,'#f4ecd0');R(x-8*sc,y-30*sc,2*sc,3*sc,'#f4ecd0');R(x+6*sc,y-30*sc,2*sc,3*sc,'#f4ecd0')}
 if(a=='crown'){R(x-5*sc,y-30*sc,10*sc,2*sc,'#ffd24a');for(let i=0;i<3;i++)R(x-5*sc+i*4*sc,y-33*sc,2*sc,3*sc,'#ffd24a')}
 const hx=x+9*sc,hy=y-14*sc,fl=Math.sin(t*9)*1.5;
 if(w=='flame'){R(hx,hy-14*sc,2*sc,14*sc,'#ff6a1a');R(hx-sc,hy-16*sc+fl,sc*2,3*sc,'#ffd24a');R(hx+sc,hy-18*sc-fl,sc*2,3*sc,'#ff3a0a')}
 if(w=='ice'){R(hx,hy-18*sc,2*sc,18*sc,'#9ad8ff');R(hx-sc,hy-22*sc,4*sc,4*sc,'#e8faff')}
 if(w=='halb'){R(hx,hy-20*sc,sc,20*sc,'#8a6a3a');R(hx-3*sc,hy-22*sc,7*sc,4*sc,'#c8ccd8')}
 if(h=='gbard'){R(x-9*sc,y-5*sc,18*sc,3*sc,'#ffd24a');R(x-9*sc,y-2*sc,18*sc,sc,'#a87a10')}
 if(h=='ghost'){c.save();c.globalAlpha=.35;R(x-10*sc,y-8*sc,20*sc,8*sc,'#bfe4ff');c.restore()}}
/* trained look + banner bearers */
const _d=drawU;drawU=function(u,x,y){_d(u,x,y);try{const sc=(UT[u.type]&&UT[u.type].big||1);
 if(u===H&&(RY.eq.armor||RY.eq.weapon||RY.eq.horse))gearVis(x,y,sc);
 const r=u.tl?u.tl.d+u.tl.a+u.tl.s:0;
 if(r){const A=u.tl.a,D=u.tl.d;
  if(A>=1){R(x-7*sc,y-20*sc,3*sc,3*sc,'#c8ccd8');R(x+4*sc,y-20*sc,3*sc,3*sc,'#c8ccd8')}
  if(A>=2)R(x-4*sc,y-17*sc,8*sc,3*sc,'#9aa0b0');
  if(A>=3)R(x-5*sc,y-26*sc,10*sc,2*sc,'#ffd24a');
  if(r>=4)R(x-1*sc,y-30*sc,2*sc,5*sc,r>=7?'#ff4a2a':'#d02a2a');
  if(D>=1)R(x+6*sc,y-17*sc,sc,6*sc,D>=3?'#ffe08a':'#e8ecf8');
  if(r>=7){c.save();c.globalAlpha=.3+.2*Math.sin(now()*6);R(x-8*sc,y-30*sc,16*sc,30*sc,'#ffd24a');c.restore()}}
 if(form>0&&u.team===0&&u!==H&&!u.dead&&window.bearerDraw){try{bearerDraw(u,x,y,sc,R)}catch(e){}}
}catch(e){}};
/* roads change with the age; treaties also stop NPC attacks on you */
window.RDP=[['#a48a5c','#957b50'],['#8e8a80','#7c786e'],['#a8a8ae','#76767e']];
const _h2=hurt;hurt=function(tg,dmg,from){try{if(from&&!from.gh&&from.kg&&from.kg.treaty>now()&&tg&&(tg===H||tg.team===0))return}catch(e){}return _h2(tg,dmg,from)};
/* PvP peace offers: both sides get a 5:00 ceasefire */
window.pvOffer=(id,g)=>{if(H.gold<g)return toast('Need '+g+' 🪙 gold');mpSend({t:'pc',id:MP.id,to:id,k:'o',g});toast('🕊 Peace offer sent')};
const _mr=mpRecv;mpRecv=function(m,from){try{if(m&&m.t=='pc'&&m.id!==MP.id&&m.to===MP.id){const g=m.g|0;
 if(m.k=='o'){const d=document.createElement('div');d.style.cssText='position:fixed;left:50%;bottom:120px;transform:translateX(-50%);z-index:30;background:#2a2036;border:3px solid #e8b94a;padding:8px 12px;font-size:10px;text-align:center';d.innerHTML='🕊 A rival lord offers <b>'+g+' 🪙</b> for 5:00 of peace.<br><button class="b" style="position:static;margin:4px" id="pva">Accept</button><button class="b" style="position:static;margin:4px" id="pvr">Refuse</button>';document.body.appendChild(d);
  document.getElementById('pva').onclick=()=>{H.gold+=g;PV.peaceEnd=now()+300;mpSend({t:'pc',id:MP.id,to:m.id,k:'y',g});toast('🕊 Ceasefire for 5:00');d.remove()};document.getElementById('pvr').onclick=()=>{mpSend({t:'pc',id:MP.id,to:m.id,k:'n'});d.remove()};setTimeout(()=>d.remove(),20000)}
 else if(m.k=='y'){H.gold=Math.max(0,H.gold-g);PV.peaceEnd=now()+300;toast('🕊 Peace agreed — no war for 5:00');sfx('win')}
 else if(m.k=='n')toast('They refused your offer')}}catch(e){}return _mr(m,from)};
/* horse barding by age */
const _zh=Zhorse;Zhorse=function(X,Y,f,ph,sad,mv,coat,capc){_zh(X,Y,f,ph,sad,mv,coat,capc);try{const a=window.AGE_?AGE_():0,P=Zpen(Math.round(X),Math.round(Y),f,0),R=P.R,by=-13+(mv?-Math.round(Math.abs(Math.sin(ph))*1.4):0);
 R(capc||'#8a2a1a',-4,by-1,8,5);R('#e8c860',-4,by+4,8,1);if(a>=1)R('#6a4a2a',-6,by-2,12,1);
 if(a>=2){R('#c8ccd8',-7,by-3,14,2);R('#9aa0b0',-7,by+5,14,2);R('#ffd24a',-1,by-3,2,2)}}catch(e){}};
}catch(e){console.error('v19 patch',e)}})();
