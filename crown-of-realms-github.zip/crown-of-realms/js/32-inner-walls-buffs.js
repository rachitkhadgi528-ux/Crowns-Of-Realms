/* ===== v16: inner walls + gates, 60s battle buffs, generals, armoury shop, scouts ===== */
(function(){try{
const G=window.GEAR={own:{},eq:{}};let bfT=0,innerDone=0,lastT=0;
const gold=()=>H.gold|0,T=()=>now();
/* 1. inner walls with gate gaps (builders raise them like the outer ring) */
function addInner(){if(innerDone||typeof SLOTS=='undefined'||typeof K1=='undefined')return;innerDone=1;
 for(let i=0;i<64;i++){const gate=i%16==15||i%16==0||i%16==1;if(gate)continue;const a=i/64*6.283;
  SLOTS.push({k:'wall',x:CX+Math.cos(a)*150,y:CX+Math.sin(a)*126,c:{stone:2},req:K1,inner:1})}
 [0,16,32,48].forEach(i=>{const a=(i+.5)/64*6.283;objs.push({k:'tower',img:TX.gateO,x:CX+Math.cos(a)*150,y:CX+Math.sin(a)*126,w:14,h:16,dead:0,done:0,deco:1})})}
/* 2. 60s buffs that refresh while hero or soldiers are fighting */
const _sw=swing;swing=function(){const o=H.wb,b=T()<bfT?.3:0,w=G.eq.w?G.eq.w.d:0,h=H.m&&G.eq.h?G.eq.h.d:0;H.wb=(o||0)+b+w+h;try{_sw()}finally{H.wb=o}};
function fighting(){const _n=performance.now();if(_n-(fighting._t||0)<400)return fighting._v;fighting._t=_n;return fighting._v=US.some(e=>e.team&&!e.dead&&!(e.kg&&e.kg.rel>=0)&&(Math.abs(e.x-H.x)<110&&Math.abs(e.y-H.y)<110||ARM.some(a=>Math.abs(e.x-a.x)<60&&Math.abs(e.y-a.y)<60)))}
/* 3. captured lords become your generals (solo + PvP) */
try{const seen=new Set();setInterval(()=>{try{(window.PRIS||[]).forEach(p=>{if(seen.has(p.id)||p.cid!=='me'||p.id==='self')return;seen.add(p.id);const g=mku(0,UT.lord?'lord':'cguard',H.x+20,H.y+10);g.nm='General '+p.name;g.hp=g.mhp=Math.max(g.mhp,400);g.gen=1;toast('⚔ '+p.name+' swears fealty and becomes your General')})}catch(e){}},700)}catch(e){console.error('general patch',e)}
/* 4. scouts: explore the map and reveal rival kingdoms / players */
window.sendScout=function(){if(!inGame)return;if(H.gold<15)return toast('A scout costs 15 gold');H.gold-=15;toast('🧭 Scout rides out to explore…');
 setTimeout(()=>{try{let r;if(typeof MPI!='undefined'&&MPI){const P=[...MP.peers.values()].find(p=>!p.known&&!p.out);if(P){discP(P);r=P.n}}else{const k=KG.find(k=>!k.known&&!k.owned);if(k){discK(k);r=k.name}}toast(r?'🧭 Scout found '+r+' and revealed the map':'🧭 Scout found nothing new')}catch(e){}},6000)};
/* 5. armoury: weapons, armour, unit armour, horses, horse armour, banners */
const C={Weapons:[['Iron Sword',120,.1],['Steel Longsword',300,.2],['War Axe',420,.28],['Flamberge',800,.4]],
 Armour:[['Leather Jerkin',100,30],['Chainmail Hauberk',320,70],['Plate Cuirass',700,130],['Gilded Full Plate',1200,200]],
 'Unit Armour':[['Padded Gambeson',250,.1],['Mail Coats',600,.25],['Plate Harness',1200,.45]],
 Horses:[['Palfrey',150,.05],['Courser',400,.12],['Destrier',900,.22]],
 'Horse Armour':[['Cloth Caparison',150,25],['Mail Barding',450,60],['Plate Barding',1000,110]],
 Banners:[['Small Pennon',60,1],['Heraldic Standard',180,2],['Great Banner',420,3],['Royal Gonfalon',900,4]]};
const K={Weapons:'w',Armour:'a','Unit Armour':'ua',Horses:'h','Horse Armour':'ha',Banners:'b'},E={Weapons:'🗡',Armour:'🛡','Unit Armour':'⚔',Horses:'🐎','Horse Armour':'🏇',Banners:'🚩'};
let tabN='Weapons';
window.armUI=function(){if(!inGame)return;const e=$('ov');e.style.display='flex';let h='<div style="width:min(94vw,520px)"><div class="xh"><h3>⚒ Armoury</h3><button onclick="ovx()">✕ Close</button></div><p style="font-size:9px">🪙 '+gold()+'</p><div>'+Object.keys(C).map(t=>'<button onclick="armTab(\''+t+'\')" style="'+(t==tabN?'background:#8a6a2a':'')+'">'+E[t]+' '+t+'</button>').join(' ')+'</div>';
 C[tabN].forEach((it,i)=>{const id=K[tabN]+i,own=G.own[id],on=G.eq[K[tabN]]&&G.eq[K[tabN]].id==id;h+='<p style="font-size:9px">'+E[tabN]+' <b>'+it[0]+'</b> · '+(tabN=='Banners'?['','small','medium','large','royal'][it[2]]+' banner \u00b7 carried by your army in formation \u00b7 morale regen':tabN=='Weapons'||tabN=='Horses'||tabN=='Unit Armour'?'+'+Math.round(it[2]*100)+'%':'+'+it[2]+' HP')+' <button onclick="armBuy(\''+tabN+'\','+i+')">'+(on?'Equipped':own?'Equip':'Buy '+it[1])+'</button></p>'});
 e.innerHTML=h+'<small>Weapons and gear work in solo and PvP.</small></div>'};
window.armTab=t=>{tabN=t;armUI()};
window.armBuy=function(t,i){const it=C[t][i],k=K[t],id=k+i;if(!G.own[id]){if(H.gold<it[1]){sfx('no');return toast('Not enough gold')}H.gold-=it[1];G.own[id]=1;sfx('recruit')}
 G.eq[k]={id,d:it[2],n:it[0]};if(k=='a'||k=='ha'){applyHP()}toast('Equipped '+it[0]);hud();armUI()};
function applyHP(){const b=100+(G.eq.a?G.eq.a.d:0)+(G.eq.ha&&H.m?G.eq.ha.d:0);if(H.mhp!=b&&!H.hpBase){H.mhp=b;H.hp=Math.min(H.hp,H.mhp)}}
/* tick: buffs, unit armour, banner regen, weapon name on HUD */
setInterval(()=>{try{if(!inGame||paused)return;addInner();const t=T(),dt=t-(lastT||t);lastT=t;
 if(fighting()){if(t>=bfT)toast('🔥 Battle buffs active for 60s: +30% damage, regen');bfT=t+60}
 const on=t<bfT,ua=G.eq.ua?G.eq.ua.d:0,bn=G.eq.b?G.eq.b.d:0;
 ARM.forEach(u=>{if(!u._ga){u._ga=1;if(ua){u.mhp*=1+ua;u.hp*=1+ua}}if(on&&u.hp<u.mhp)u.hp=Math.min(u.mhp,u.hp+u.mhp*(.01+.005*bn)*dt)});
 if(on&&H.hp<H.mhp)H.hp=Math.min(H.mhp,H.hp+H.mhp*.01*dt);applyHP()}catch(e){}},500);
/* buttons */
[['arm','⚒ Armoury',()=>armUI()],['scout','🧭 Explore',()=>sendScout()]].forEach(([id,tx,fn])=>{const b=document.createElement('button');b.className='b';b.id=id;b.textContent=tx;b.addEventListener('pointerdown',ev=>{ev.preventDefault();fn()});$('brow').appendChild(b)});
}catch(e){console.error('v16 patch',e)}})();
