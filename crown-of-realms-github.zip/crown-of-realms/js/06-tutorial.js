/* ===== Tutorial for new players ===== */
(function(){
const LS='cor_tut_seen';let seen=0;try{seen=localStorage.getItem(LS)?1:0}catch(e){}
const mark=()=>{try{localStorage.setItem(LS,'1')}catch(e){}};
const el=document.createElement('div');el.id='tut';document.body.appendChild(el);
let on=0,i=0,ok=0,offered=0,fl={},bs={},mv=null,mini=0;
const mp=()=>!!(MPI||PV.live);
const ARW=['→','↘','↓','↙','←','↖','↑','↗'];
const dirTo=(x,y)=>{const dx=x-H.x,dy=y-H.y,a=Math.atan2(dy,dx);return ARW[((Math.round(a/(Math.PI/4))%8)+8)%8]+' about '+Math.round(Math.hypot(dx,dy)/8)+' steps'};
function nearest(k){let b=null,bd=1e9;for(const o of objs){if(o.k!==k||o.dead)continue;const d=Math.hypot(o.x-H.x,o.y-H.y);if(d<bd){bd=d;b=o}}return b}
const goto_=(k,nm)=>()=>{if(near&&near.k==k)return 'Close enough! Tap the gold button now.';const o=k=='camp'?camp:nearest(k);return o?'Nearest '+nm+': '+dirTo(o.x,o.y):''};
const need=t=>{const d=UT[t].cost||{};return Object.entries(d).filter(([k,v])=>H[k]<v).map(([k,v])=>(v-H[k])+' more '+k)};
const wc=t=>WK.filter(w=>w.type==t).length;
const recHint=t=>()=>{if(!(near&&near.k=='camp'))return 'Walk to the campfire: '+dirTo(camp.x,camp.y);const n=need(t);return n.length?'Not enough yet: you need '+n.join(', ')+'. Chop trees and mine rocks first.':'Tap the gold Recruit button!'};
const S=[
{t:'Move your hero',x:'Drag the joystick at the bottom-left to walk around. On a keyboard use W A S D.',hi:['joy'],enter(){mv=[H.x,H.y]},chk:()=>Math.hypot(H.x-mv[0],H.y-mv[1])>50},
{t:'Chop a tree',x:'Walk up to a tree. When the gold button says Chop, tap it (keyboard: Space). Wood is needed for almost everything.',hi:['act'],hint:goto_('tree','tree'),chk:()=>fl.tree},
{t:'Mine a rock',x:'Rocks give stone, which builds walls and trains soldiers. Stand next to one and tap the gold Mine button.',hi:['act'],hint:goto_('rock','rock'),chk:()=>fl.rock},
{t:'Swing your sword',x:'Tap the red Attack button (keyboard: F). Use it on bandits, wolves and wild deer. Deer and rabbits drop food.',hi:['atk'],chk:()=>fl.atk},
{t:'Your resources',x:'Top-left shows your health ❤, wood 🪵, stone 🪨, food 🌾 and gold 🪙, with a labelled count of every worker type and soldier type below. Gold comes from defeating enemies and looting.',hi:['hud']},
{t:'Return to the campfire',x:'The campfire at the centre of your base is home. Stand beside it to heal and to recruit people.',hi:['act','mm'],hint:goto_('camp','campfire'),chk:()=>near&&near.k=='camp'},
{t:'Pick a unit: Builder',x:'Tap the Train button at the bottom until it reads Train: Builder. Builders raise farms, homes and stone walls for you.',hi:['cls'],chk:()=>CLS[cls]=='builder'},
{t:'Recruit a Builder',x:'Stay beside the campfire and tap the gold Recruit button.',hi:['act'],enter(){bs.b=wc('builder')},hint:recHint('builder'),chk:()=>wc('builder')>bs.b},
{t:'Now pick: Farmer',x:'Tap Train again until it reads Train: Farmer. Farmers grow the food your soldiers eat.',hi:['cls'],chk:()=>CLS[cls]=='farmer'},
{t:'Recruit a Farmer',x:'Tap the gold Recruit button at the campfire.',hi:['act'],enter(){bs.f=wc('farmer')},hint:recHint('farmer'),chk:()=>wc('farmer')>bs.f},
{t:'How your workers help',x:'Builders automatically raise farm plots, homes and walls using your wood and stone, so keep gathering. Farmers need farm plots to make food. Woodcutters and Miners gather resources for you.',hi:['hud']},
{t:'Pick a soldier: Pike',x:'Tap Train until it reads Train: Pike. Soldiers cost wood, stone and food. Swords, bows, cavalry and C.Guards are in the same list.',hi:['cls'],chk:()=>CLS[cls]=='pike'},
{t:'Recruit a soldier',x:'Tap the gold Recruit button at the campfire. Your soldiers follow you and fight beside you.',hi:['act'],enter(){bs.p=ARM.length},hint:recHint('pike'),chk:()=>ARM.length>bs.p},
{t:'Formations',x:'Tap the Form button to change formation. Column is balanced, Wall makes your pikes take 30% less damage, and Ring cuts damage to everyone by 15%. Legion, Phalanx and Cohort line your army up by unit type and march it in step. Troops > Guard castle or Roam freely lets them relax at home, and the Messenger button rallies your allies against a main enemy.',hi:['frm']},
{t:'Command your troops',x:'Tap Troops to pick All units or just one type (Pike, Bow...), then choose Follow me, Hold here or Send ahead. Held troops stay on their spot and defend it.',hi:['tpb']},
{t:'Hunt and loot',x:'Defeat the guards at villages and wolf dens, then tap Loot for gold, wood and stone. Dens can hold a Legendary Sword that makes your side hit harder.'},
{t:'Ride a horse',x:'Your horse waits near camp. Stand beside it and tap Mount to move much faster and hit 35% harder. Tap again to dismount.',hi:['mnt']},
{t:'Defend your base',hi:['gt'],x:()=>mp()?'Rival lords can attack once the peace ends. Keep your hero and C.Guards at home. A Keep unlocks towers, an outer wall and a bigger army. The Gate button closes your gate automatically when enemies are near, or lock it open or closed.':'Raiders attack your camp every few minutes. A Keep (20 wood, 25 stone, 30 gold, raised by Builders) unlocks towers, an outer wall, more homes and a bigger army. The Gate button closes your gate automatically when enemies are near, or lock it open or closed.'},
{t:'How to win',hi:[],x:()=>mp()?'Everyone is safe for the first 7 minutes, so build your economy and army. Then war begins: train Battering Rams, march on rival castles, break their walls and destroy their keep. The last castle standing wins!':'Your goal: break the gates of Malric\u2019s castle in the northeast and claim the Crown of Realms. Train Battering Rams, march with your army and strike. Send a Messenger to explore and find rival kingdoms, then to declare war or make alliances. Trade lets you exchange goods, and Banner changes your colours.',hi2:['msg','tr','bn']},
{t:'Pause and save',x:'Tap II (or press P) to pause. Solo games can be saved and loaded there, and you can replay this tutorial any time.',hi:['pb']},
{t:'You are ready, my liege!',x:'Gather, build, recruit, then conquer. Good luck!'}
];
function hl(a){document.querySelectorAll('.th').forEach(e=>e.classList.remove('th'));(a||[]).forEach(id=>{const e=$(id);if(e&&e.style.display!='none')e.classList.add('th')})}
function render(){const s=S[i],last=i==S.length-1;ok=0;el.className='';el.style.display='block';el.dataset.m=mini?1:0;
 el.innerHTML='<div class="tp">'+(i+1)+' / '+S.length+'</div><b>'+s.t+'</b><p>'+(typeof s.x=='function'?s.x():s.x)+'</p><p class="tk" id="tuth"></p><div class="tbtn"><button class="mb ts" onclick="tutMin()">Hide \u25be</button>'+(s.chk?'<button class="mb ts" onclick="tutNext()">Skip step</button>':'<button class="mb" onclick="tutNext()">'+(last?'Finish ✔':'Next ▸')+'</button>')+(last?'':'<button class="mb ts" onclick="tutEnd()">End tutorial</button>')+'</div>';
 hl((s.hi||[]).concat(s.hi2||[]));if(s.enter)s.enter()}
window.tutMin=function(){mini=1;el.dataset.m=1};el.addEventListener('pointerdown',e=>{if(mini&&on&&!e.target.closest('button')){mini=0;el.dataset.m=0}});
window.tutNext=function(){if(!on)return;if(i>=S.length-1)return tutEnd(1);i++;render()};
window.tutStart=function(){on=1;mini=0;i=0;fl={};bs={};offered=1;mark();$('pz').style.display=='flex'&&pzx();render()};
window.tutEnd=function(fin){on=0;mini=0;el.style.display='none';hl([]);if(fin)toast('Good luck, my liege!')};
window.tutNo=function(){el.style.display='none'};
window.tutOpen=function(){pzx();tutStart()};
function offer(){if(on||!inGame)return;mark();el.className='';el.style.display='block';el.innerHTML='<b>New here, my liege?</b><p>Take a quick guided tour: moving, gathering, recruiting workers and soldiers, and how to win.</p><div><button class="mb" onclick="tutStart()">🎓 Start tutorial</button><button class="mb ts" onclick="tutNo()">No thanks</button></div>'}
/* hooks */
const _act=act;act=function(){const o=near;_act();if(on&&o&&!won){if(o.k=='tree')fl.tree=1;if(o.k=='rock')fl.rock=1}};
$('atk').addEventListener('pointerdown',()=>{fl.atk=1});addEventListener('keydown',e=>{if(e.key=='f'||e.key=='j')fl.atk=1});
const _pm=pzMenu;pzMenu=function(){_pm();const p=document.querySelector('#pz .pn');if(p){const q=[...p.querySelectorAll('button')].pop(),b=document.createElement('button');b.textContent='🎓 Tutorial';b.setAttribute('onclick','tutOpen()');p.insertBefore(b,q)}};
$('b6').onclick=()=>{if(window.speechSynthesis){const p=new SpeechSynthesisUtterance(' ');p.volume=0;speechSynthesis.speak(p)}aud();if(ac&&ac.state=='suspended')ac.resume();$('ttl').style.display='none';begin();tutStart()};
setInterval(()=>{
 if(!offered&&inGame&&!seen&&!PEND){offered=1;setTimeout(offer,1500)}
 if(el.style.display=='block')el.style.visibility=($('ov').style.display=='flex'||$('pz').style.display=='flex')?'hidden':'visible';
 if(!on)return;if(won)return tutEnd();
 if(!mp())nextRaid=Math.max(nextRaid,now()+30);
 const s=S[i];if(ok)return;
 if(s.chk&&s.chk()){ok=1;el.className='ok';$('tuth').textContent='✔ Well done!';setTimeout(()=>{if(on&&ok)tutNext()},1000)}
 else if(s.hint){const h=$('tuth');if(h)h.textContent=s.hint()}
},250);
})();
