/* v9-3: Bannerlord-style banner designer */
(()=>{
const PAT=['Plain','Split H','Split V','Diagonal','Quarters','Stripes','Checks','Saltire','Border','Bend','Chevron'],
SIG=['None','Cross','Diamond','Star','Circle','Crown','Tower','Sword','Moon','Mountain','Fleur'],
COL=['#b01c1c','#e8b94a','#2a5aa8','#2a8a4a','#7a2a6a','#f3ecd8','#1a1a22','#e07a1e','#2aa8a0','#8a5a2a','#d84a8a','#6a8aa8'];
const old=x=>x.em==4||(x.p===undefined&&x.s===undefined),oldB=banner,oldC=bcv;
window.bnCustom=()=>{try{const j=JSON.parse(localStorage.getItem('cor_banner')||'null');return j&&j.c1?j:null}catch(e){return null}};
banner=function(g,x,y,b,w,h){
 if(old(b)){oldB(g,x,y,b,w,h);return}
 const p=b.p|0,s=b.s|0;g.save();g.beginPath();g.rect(x,y,w,h);g.clip();g.translate(x,y);
 g.fillStyle=b.c1;g.fillRect(0,0,w,h);g.fillStyle=b.c2;
 const R=(a,c,d,e)=>g.fillRect(a,c,d,e),Q=q=>{g.beginPath();q.forEach((v,i)=>g[i?'lineTo':'moveTo'](v[0]*w,v[1]*h));g.fill()};
 if(p==1)R(0,h/2,w,h/2);else if(p==2)R(w/2,0,w/2,h);else if(p==3)Q([[1,0],[1,1],[0,1]]);
 else if(p==4){R(0,0,w/2,h/2);R(w/2,h/2,w/2,h/2)}else if(p==5){for(let i=1;i<6;i+=2)R(0,i*h/6,w,h/6)}
 else if(p==6){for(let i=0;i<4;i++)for(let j=0;j<4;j++)if((i+j)&1)R(i*w/4,j*h/4,w/4,h/4)}
 else if(p==7){g.strokeStyle=b.c2;g.lineWidth=Math.max(1,w/6);g.beginPath();g.moveTo(0,0);g.lineTo(w,h);g.moveTo(w,0);g.lineTo(0,h);g.stroke()}
 else if(p==8){const t=Math.max(1,w/8);R(0,0,w,t);R(0,h-t,w,t);R(0,0,t,h);R(w-t,0,t,h)}
 else if(p==9)Q([[0,.15],[.15,0],[1,.85],[.85,1]]);else if(p==10)Q([[0,.5],[.5,.15],[1,.5],[1,.8],[.5,.45],[0,.8]]);
 g.fillStyle=b.c3||'#f3ecd8';const cx=w/2,cy=h/2,u=Math.min(w,h)/2*.6,A=(x0,y0,r)=>{g.beginPath();g.arc(x0,y0,r,0,6.2832);g.fill()},T=q=>{g.beginPath();q.forEach((v,i)=>g[i?'lineTo':'moveTo'](cx+v[0]*u,cy+v[1]*u));g.fill()};
 if(s==1){R(cx-u*.18,cy-u,u*.36,u*2);R(cx-u*.7,cy-u*.35,u*1.4,u*.36)}
 else if(s==2)T([[0,-1],[.8,0],[0,1],[-.8,0]]);
 else if(s==3){const q=[];for(let i=0;i<10;i++){const r=i&1?.42:1,a=-1.5708+i*.6283;q.push([Math.cos(a)*r,Math.sin(a)*r])}T(q)}
 else if(s==4)A(cx,cy,u*.8);
 else if(s==5)T([[-1,.6],[-1,-.5],[-.5,0],[0,-.7],[.5,0],[1,-.5],[1,.6]]);
 else if(s==6){R(cx-u*.6,cy-u*.3,u*1.2,u*1.3);for(let i=-1;i<2;i++)R(cx+i*u*.5-u*.15,cy-u*.8,u*.3,u*.5)}
 else if(s==7){R(cx-u*.12,cy-u,u*.24,u*1.6);R(cx-u*.6,cy+u*.2,u*1.2,u*.2);R(cx-u*.12,cy+u*.4,u*.24,u*.5)}
 else if(s==8){A(cx,cy,u*.9);g.fillStyle=b.c1;A(cx+u*.4,cy-u*.15,u*.75)}
 else if(s==9)T([[-1,.8],[-.2,-.5],[.3,.2],[.6,-.2],[1,.8]]);
 else if(s==10){A(cx,cy-u*.3,u*.4);R(cx-u*.12,cy,u*.24,u*.9);A(cx-u*.5,cy+u*.2,u*.25);A(cx+u*.5,cy+u*.2,u*.25)}
 g.restore()};
bcv=function(b){if(old(b))return oldC(b);const k=[b.c1,b.c2,b.c3,b.p,b.s].join();if(!BC[k]){const e=document.createElement('canvas');e.width=30;e.height=21;banner(e.getContext('2d'),0,0,b,30,21);BC[k]=e}return BC[k]};
bpv=function(){const e=$('bpc');if(!e)return;const g=e.getContext('2d');g.clearRect(0,0,120,84);banner(g,0,0,PB,120,84);try{localStorage.setItem('cor_banner',JSON.stringify({c1:PB.c1,c2:PB.c2,c3:PB.c3,p:PB.p,s:PB.s,em:PB.em}))}catch(e){}};
window.bnSet=(k,v)=>{PB[k]=v;if(PB.em==4)PB.em=0;if(PB.p===undefined)PB.p=0;if(PB.s===undefined)PB.s=0;bpv()};
window.bnRnd=()=>{const r=a=>a[Math.random()*a.length|0];bnSet('c1',r(COL));PB.c2=r(COL);PB.c3=r(COL);PB.p=Math.random()*PAT.length|0;PB.s=Math.random()*SIG.length|0;bnUI()};
bnUI=function(){paused=1;const o=$('ov'),ks='onkeydown="event.stopPropagation()" style="user-select:text;-webkit-user-select:text;font:inherit;width:150px"';o.style.display='flex';
 if(PB.p===undefined){PB.p=0;PB.s=PB.em==1?1:PB.em==2?2:0}if(!PB.c3)PB.c3='#f3ecd8';
 const sw=k=>COL.map(c=>'<i onclick="bnSet(\''+k+'\',\''+c+'\')" style="display:inline-block;width:20px;height:20px;margin:1px;background:'+c+';border:2px solid #fff8"></i>').join('')+'<input type="color" value="'+PB[k]+'" oninput="bnSet(\''+k+'\',this.value)" style="width:28px;height:24px;padding:0">',
 bt=(a,k)=>a.map((n,i)=>'<button onclick="bnSet(\''+k+'\','+i+')">'+n+'</button>').join(' ');
 o.innerHTML='<div style="max-height:92vh;overflow:auto"><h3>Your Banner</h3><p>Realm <input maxlength="18" value="'+esc(KNAME)+'" oninput="rn(this.value)" '+ks+'></p><p>Ruler <input maxlength="14" value="'+esc(RULER)+'" oninput="rr(this.value)" '+ks+'></p><canvas id="bpc" width="120" height="84" style="image-rendering:pixelated;width:120px;height:84px"></canvas><p>Background '+sw('c1')+'</p><p>Pattern '+bt(PAT,'p')+'</p><p>Pattern colour '+sw('c2')+'</p><p>Symbol '+bt(SIG,'s')+'</p><p>Symbol colour '+sw('c3')+'</p><p><button onclick="bnRnd()">🎲 Random</button> <button onclick="nepalSet()">Nepal</button></p><button onclick="ovx()">Done</button></div>';bpv()};
{const s=bnCustom();if(s)Object.assign(PB,s)}

})();
