/* ===== v23: Ranks & Leaderboards (PvP rank tiers, solo boards per AI level, live match standings) ===== */
(function(){'use strict';
/* ONE-TIME SETUP: paste your Firebase Realtime Database URL between the quotes so every player shares one global board.
   Empty = boards work locally only. Rules to publish in Firebase are in the notes you were given with this file. */
const RANK_SERVER='https://crown-of-realms-88b1a-default-rtdb.asia-southeast1.firebasedatabase.app';
const G=f=>{try{return f()}catch(e){}},DN=['Noob','Pro','Expert','Hell'],CT=['Squire','Knight','Warlord','Overlord'];
const TI=[[0,'Bronze','🥉','#cd8b4a'],[300,'Silver','🥈','#c0c8d0'],[700,'Gold','🥇','#ffd24a'],[1200,'Platinum','💠','#6fe3d6'],[1800,'Diamond','💎','#6fb7ff'],[2500,'Master','🔮','#c07bff'],[3300,'Grandmaster','🔥','#ff6a4a'],[4200,'Crown Champion','👑','#ffe27a']];
const esc=s=>String(s==null?'':s).replace(/[<>&"']/g,'');
function tier(rp){let i=0;TI.forEach((t,j)=>{if(rp>=t[0])i=j});const t=TI[i],n=TI[i+1];let d='';if(n){const w=(n[0]-t[0])/3;d=' '+['III','II','I'][Math.min(2,Math.floor((rp-t[0])/w))]}return{i,n:t[1]+d,e:t[2],c:t[3],lo:t[0],hi:n?n[0]:0,nx:n?n[1]:''}}
const K='cor_rk',blank=()=>({rp:0,g:0,w:0,l:0,sw:[0,0,0,0],best:[null,null,null,null],h:[]});
let D=G(()=>JSON.parse(localStorage.getItem(K)))||blank();for(const k in blank())if(D[k]===undefined)D[k]=blank()[k];
const sv=()=>G(()=>localStorage.setItem(K,JSON.stringify(D)));
const prof=()=>G(()=>MT.P())||{},pid=()=>String(prof().pid||'').replace(/[^A-Z0-9]/g,''),nm=()=>esc(prof().name||G(()=>RULER)||'Lord').slice(0,14)||'Lord';
const lvl=()=>{let x=prof().xp|0,l=1;while(l<99&&x>=100+l*45){x-=100+l*45;l++}return l};
const base=()=>{let v=String(RANK_SERVER||G(()=>localStorage.getItem('cor_lburl'))||'').trim();if(!v)return'';if(!/^https?:/i.test(v))v='https://'+v;try{return new URL(v).origin}catch(e){return''}};
const ft=(u,o)=>{const c=new AbortController(),t=setTimeout(()=>c.abort(),8000);return fetch(u,Object.assign({signal:c.signal},o)).finally(()=>clearTimeout(t))};
let LAST=null,lastSig='',PE=0;
/* ---- scoring ---- */
const score=r=>{const c=(r.conq|0)*100;if(r.win)return 1000+Math.max(0,1500-Math.round(r.min*50))+c+Math.min(500,r.kills|0)*2+(r.deaths?0:200);return c+Math.min(300,r.kills|0)+Math.round(r.min*5)};
function record(r){if(!r||!r.ok)return null;const o={pvp:!!r.pvp,dl:r.dl|0};
 if(r.pvp){const b=r.bots,x=Math.max(0,r.peers-1);let d=r.win?(b?8:Math.min(40,24+4*x+(r.hum?4:0))):(b?0:-(14+2*x));if(!b&&D.g<5&&d<0)d=Math.round(d/2);
  o.a=D.rp;D.rp=Math.max(0,D.rp+d);o.b=D.rp;o.d=o.b-o.a;if(!b){D.g++;r.win?D.w++:D.l++}}
 else{o.sc=score(r);const old=D.best[o.dl];o.nb=!old||o.sc>old.sc;if(o.nb)D.best[o.dl]={sc:o.sc,min:Math.round(r.min*10)/10,k:r.kills|0,t:Date.now()};if(r.win)D.sw[o.dl]=(D.sw[o.dl]|0)+1}
 D.h.unshift({t:Date.now(),pvp:o.pvp,win:!!r.win,d:o.d,sc:o.sc,dl:o.dl});D.h.length=Math.min(D.h.length,20);sv();LAST=o;push();return o}
/* ---- server (Firebase Realtime Database REST) ---- */
function push(){const b=base(),id=pid();if(!b||!id)return Promise.resolve();const n=nm(),lv=lvl(),W=[];
 if(D.g>0||D.rp>0)W.push(['pvp',{n,rp:D.rp,w:D.w,g:D.g,lv,t:Date.now()}]);D.best.forEach((x,d)=>{if(x)W.push(['s'+d,{n,sc:x.sc,min:x.min,k:x.k,lv,t:x.t}])});
 const sig=JSON.stringify(W.map(w=>[w[0],w[1].n,w[1].rp,w[1].sc]));if(!W.length||sig===lastSig)return Promise.resolve();lastSig=sig;
 return Promise.all(W.map(w=>ft(b+'/rk/'+w[0]+'/'+id+'.json',{method:'PUT',body:JSON.stringify(w[1])}).then(r=>{if(!r.ok){PE=r.status;throw 0}PE=0}).catch(()=>{lastSig=''}))).then(()=>0)}
const CA={};
function need(key,f){const c=CA[key]||(CA[key]={rows:G(()=>JSON.parse(localStorage.getItem('cor_rkc_'+key)))||[],t:0});if(c.busy||Date.now()-c.t<20000)return c;
 if(!base()){c.err='none';return c}c.busy=1;
 const U=base()+'/rk/'+key+'.json';c.code=0;push().then(()=>ft(U+'?orderBy=%22'+f+'%22&limitToLast=100')).then(r=>r.ok?r:ft(U)).then(r=>{if(!r.ok){c.code=r.status;throw 0}return r.json()}).then(o=>{c.rows=Object.keys(o||{}).map(k=>Object.assign({pid:k},o[k])).filter(x=>x&&typeof x.n=='string'&&isFinite(x[f])).sort((a,b)=>b[f]-a[f]);c.err=0;G(()=>localStorage.setItem('cor_rkc_'+key,JSON.stringify(c.rows)))}).catch(()=>{c.err='net'}).finally(()=>{c.busy=0;c.t=Date.now();repaint()});return c}
/* ---- live match standings ---- */
function live(){if(!G(()=>inGame))return null;const R=[],s=G(()=>MT.S())||{},pv=G(()=>PV.live),alive=G(()=>PC.hp>0);
 R.push({n:nm(),tr:G(()=>ARM.length)|0,st:alive?'🛡 You':'⚰ Fallen',me:1,dead:!alive});
 if(pv)G(()=>MP.peers.forEach(P=>{let n=0;P.gu.forEach(g=>{if(g.hp>0)n++});R.push({n:esc(P.n||'Rival').slice(0,14),tr:n,st:P.out?'⚰ Fallen':P.tm===ME.tm?'🤝 Ally':(P.bot?'🤖 Rival':'⚔ Rival'),dead:!!P.out})}));
 else G(()=>KG.forEach(k=>R.push({n:(k.known||k.owned?esc(k.name).slice(0,16):'Unknown realm'),tr:null,st:k.owned?'🏰 Yours':k.dfd?'⚰ Fallen':'⚔ Rival',dead:!!(k.dfd||k.owned)})));
 R.sort((a,b)=>(a.dead-b.dead)||((b.tr|0)-(a.tr|0))||(b.me?1:0)-(a.me?1:0));return{R,k:s.kills|0,pv:!!pv}}
/* ---- UI ---- */
const ST={tab:'pvp',d:Math.max(0,Math.min(3,+G(()=>localStorage.getItem('cor_lvl'))||0))};
function rows(key,f,sub,val,mine){const c=need(key,f),me=pid();let h='<ol>',R=c.rows,i0=R.findIndex(r=>r.pid==me);
 if(!R.length)h+='<li><span>'+(c.busy?'Loading…':'No lords ranked yet. Be the first!')+'</span></li>';
 R.forEach((r,i)=>{h+='<li class="'+(i?'':'r1 ')+(r.pid==me?'me2':'')+'"><b>'+(i<3?['👑','🥈','🥉'][i]:i+1)+'</b><span>'+esc(r.n)+'<small>'+sub(r)+'</small></span><em>'+val(r)+'</em></li>'});
 if(mine)h+='<li class="pin me2"><b>'+(i0>=0?'#'+(i0+1):'—')+'</b><span>'+nm()+' (you)<small>'+(i0>=0?'Your global rank':base()?'Outside the top 100':'Not on a global board yet')+'</small></span><em>'+val(mine)+'</em></li>';
 const msg=c.err=='none'?'📴 Global board not connected — showing local data':c.err=='net'?(c.code==401||c.code==403||PE==401||PE==403?'🔒 Server rules block access — publish the new rules in Firebase':c.code==404||PE==404?'❓ Database not found — check the URL in ⚙':'📴 Can’t reach server ('+(c.code||'network')+') — showing last saved ranks'):PE?'⚠ Your score could not be uploaded (HTTP '+PE+')':c.busy?'⏳ Updating…':'🌐 Live · top 100';
 return '<p class="st">'+msg+'</p>'+h+'</ol>'}
function paint(el){const c=el.querySelector('.rkc');if(!c)return;const L=live();if(ST.tab=='live'&&!L)ST.tab='pvp';const T=ST.tab;
 const tabs=[['pvp','⚔ PvP'],['solo','🏰 Solo']].concat(L?[['live','📜 Match']]:[]);
 let h='<header><span>👑 Ranks</span><span><button onclick="RK.ref()" aria-label="Refresh">↻</button>'+(el.dataset.o?'<button onclick="RK.srv()" aria-label="Server">⚙</button><button onclick="RK.close()" aria-label="Close">✕</button>':'')+'</span></header><nav>'+tabs.map(t=>'<button class="'+(T==t[0]?'on':'')+'" onclick="RK.go(\''+t[0]+'\')">'+t[1]+'</button>').join('')+'</nav>';
 if(T=='pvp'){const t=tier(D.rp),pc=t.hi?Math.min(100,(D.rp-t.lo)/(t.hi-t.lo)*100):100;
  h+='<section class="me" style="border-color:'+t.c+'"><span class="bd">'+t.e+'</span><span><b style="color:'+t.c+'">'+t.n+'</b> · '+D.rp+' RP<i class="bar"><u style="width:'+pc+'%"></u></i><small>'+(t.nx?(t.hi-D.rp)+' RP to '+t.nx:'Highest tier')+' · '+D.w+'W '+D.l+'L'+(D.g<5?' · placement '+D.g+'/5':'')+'</small></span></section>';
  h+=rows('pvp','rp',r=>{const q=tier(r.rp);return q.e+' '+q.n+' · Lv '+(r.lv|0)},r=>(r.rp|0)+' RP',{rp:D.rp})}
 else if(T=='solo'){const d=ST.d,b=D.best[d],w=D.sw.reduce((a,x,i)=>x>0?i:a,-1);
  h+='<nav>'+DN.map((n,i)=>'<button class="'+(i==d?'on':'')+'" onclick="RK.go(\'solo\','+i+')">'+n+'</button>').join('')+'</nav>';
  h+='<section class="me" style="border-color:#e8b94a"><span class="bd">🏰</span><span><b style="color:#ffd24a">'+(w>=0?CT[w]:'Peasant')+'</b> · '+DN[d]+'<small>'+(b?'Best '+b.sc+' · '+b.min+' min · '+b.k+' kills · '+(D.sw[d]|0)+' wins':'No score on '+DN[d]+' yet')+'</small></span></section>';
  h+=rows('s'+d,'sc',r=>(r.min||0)+' min · '+(r.k|0)+' kills · Lv '+(r.lv|0),r=>r.sc|0,b?{sc:b.sc}:null)}
 else{h+='<section class="me" style="border-color:#6ee"><span class="bd">'+(L.pv?'⚔':'🏰')+'</span><span><b>'+(L.pv?'PvP match':'Solo campaign')+'</b><small>Your kills: '+L.k+' · Army: '+(L.R.find(r=>r.me)||{}).tr+'</small></span></section><p class="st">Standings update every second</p><ol>'+L.R.map((r,i)=>'<li class="'+(i||r.dead?'':'r1 ')+(r.me?'me2 ':'')+(r.dead?'dead':'')+'"><b>'+(i==0&&!r.dead?'👑':i+1)+'</b><span>'+r.n+'<small>'+r.st+'</small></span><em>'+(r.tr==null?'':'⚔ '+r.tr)+'</em></li>').join('')+'</ol>'}
 const sc=c.querySelector('ol'),y=sc?sc.scrollTop:0,pt=c.dataset.k==T+ST.d;c.innerHTML=h;c.dataset.k=T+ST.d;const n=c.querySelector('ol');if(n&&pt)n.scrollTop=y}
const repaint=()=>document.querySelectorAll('.rkx').forEach(paint);
function mk(o){const e=document.createElement('div');e.className='rkx';if(o)e.dataset.o=1;const c=document.createElement('section');c.className='rkc';e.append(c);return e}
let ov=null;
function open(t){close();if(t)ST.tab=t;ov=document.createElement('div');ov.id='rk';const e=mk(1);ov.append(e);document.body.append(ov);paint(e);push()}
function close(){if(ov){ov.remove();ov=null}}
window.RK={record,tier,open,close,toggle:t=>ov?close():open(t),
 go(t,d){ST.tab=t;if(d!=null)ST.d=d;repaint()},ref(){Object.keys(CA).forEach(k=>CA[k].t=0);repaint()},
 srv(){const v=prompt('Firebase Realtime Database URL (https://…firebaseio.com or …firebasedatabase.app)',base());if(v!==null){G(()=>localStorage.setItem('cor_lburl',v.trim()));lastSig='';RK.ref()}},
 panel(btns){const e=mk(0);e.style.cssText='height:min(92dvh,720px);max-width:min(96vw,500px);padding:0;border:3px solid #e8b94a;background:#120c1c;overflow:hidden';
  if(LAST){ST.tab=LAST.pvp?'pvp':'solo';if(!LAST.pvp)ST.d=LAST.dl}else ST.tab='pvp';
  const f=document.createElement('footer');(btns||[]).forEach(b=>f.append(b));e.append(f);paint(e);return e},
 resRow(o){if(!o)return'';if(o.pvp){const a=tier(o.a),b=tier(o.b);return '<div class="pgrow on"><div class="t">⚔ PvP rank: '+b.e+' <b style="color:'+b.c+'">'+b.n+'</b><small>'+(o.d>=0?'+':'')+o.d+' RP ('+o.a+' → '+o.b+')'+(b.i>a.i?' · ⬆ PROMOTED!':b.i<a.i?' · ⬇ Demoted':'')+'</small></div></div>'}
  return '<div class="pgrow on"><div class="t">🏰 '+DN[o.dl]+' score <b style="color:#ffd24a">'+o.sc+'</b><small>'+(o.nb?'⭐ New personal best!':'Best: '+D.best[o.dl].sc)+'</small></div></div>'}};
setInterval(()=>{if(ST.tab=='live'&&document.querySelector('.rkx'))repaint()},1000);
setTimeout(push,4000);
})();
