/* ===== v19: visible gear tiers, decorations, auto-decorate ===== */
(function(){try{
const G=window.GEAR;
/* armour tier recolours the hero's tunic; weapon tier colours the blade */
const _zh=Zhs;Zhs=function(){const h=_zh();try{const a=G.eq.a?+G.eq.a.id.slice(1):-1;if(a<0)return h;const t=[['#8a5a2a',h.c2],['#8793a3',h.c2],['#d5dce8',h.c2],['#e3b93a','#a01828']][a];return{c1:t[0],c2:t[1]}}catch(e){return h}};
const _bl=window.MWBL;window.MWBL=function(){try{const w=G.eq.w?+G.eq.w.id.slice(1):-1;if(w>=0)return['#b4bac4','#eef3fa','#f2c45a','#ff7a2a'][w]}catch(e){}return _bl?_bl():''};
/* glow ring under the hero: stronger for better gear */
const _p2=window.PRL;window.PRL=function(L,cx,cy){if(_p2)_p2(L,cx,cy);try{const a=G.eq.a?+G.eq.a.id.slice(1):-1,w=G.eq.w?+G.eq.w.id.slice(1):-1,tr=Math.max(a,w);if(tr>=1)L.push({k:'pris',p:{aura:tr,init:1},x:H.x,y:H.y-2})}catch(e){}};
const _dp2=window.drawPris;window.drawPris=function(p,x,y,t){if(p.aura!==undefined){const k=Math.min(3,p.aura),col=['#b8c0cc','#9fc4ff','#7fe6ff','#ffd24a'][k],rx=[11,13,15,17][k],pu=Math.sin(t*4);c.save();c.globalAlpha=.18+.07*pu;c.fillStyle=col;c.beginPath();c.ellipse(x,y+1,rx,rx*.38,0,0,6.2832);c.fill();c.globalAlpha=.55+.2*pu;c.strokeStyle=col;c.lineWidth=k>=2?2:1;c.beginPath();c.ellipse(x,y+1,rx,rx*.38,0,0,6.2832);c.stroke();if(k==3){c.globalAlpha=.8;c.fillStyle='#fff6c0';for(let i=0;i<4;i++){const a=t*2+i*1.57;c.fillRect(Math.round(x+Math.cos(a)*rx),Math.round(y+1+Math.sin(a)*rx*.38),1,1)}}c.restore();return}return _dp2(p,x,y,t)};
/* decorations */
const DEC=[];
const DT={
 lamp:{n:'Lamp Post',c:{stone:4,gold:4},w:8,h:20,draw:r=>{r('#2a2218',3,6,2,14);r('#3a3226',2,18,4,2);r('#ffd25a',1,1,6,6);r('#fff3b0',3,2,2,3);r('#2a2218',1,0,6,1)}},
 fountain:{n:'Fountain (heals you nearby)',c:{stone:20,gold:20},w:26,h:18,draw:r=>{r('#8d8f98',1,8,24,9);r('#6f7280',1,15,24,2);r('#4aa8e0',3,9,20,5);r('#8fd4ff',6,10,6,1);r('#8d8f98',11,2,4,8);r('#8fd4ff',12,0,2,3);r('#6f7280',9,2,8,1)}},
 statue:{n:'Statue',c:{stone:25,gold:30},w:14,h:26,draw:r=>{r('#7d808a',2,20,10,6);r('#9a9da8',4,9,6,11);r('#b4b7c2',5,3,4,6);r('#9a9da8',2,10,2,7);r('#9a9da8',10,10,2,7);r('#d8c07a',6,0,2,3)}},
 garden:{n:'Garden',c:{wood:6,gold:5},w:22,h:12,draw:r=>{r('#5a3a1e',0,4,22,8);r('#3f8a3a',1,5,20,6);[[3,6,'#f06a8a'],[8,8,'#ffe05a'],[13,6,'#ffffff'],[17,8,'#8ab4ff']].forEach(q=>{r(q[2],q[0],q[1],2,2)})}},
 well:{n:'Well',c:{wood:8,stone:10},w:16,h:18,draw:r=>{r('#5a3a1e',2,2,2,9);r('#5a3a1e',12,2,2,9);r('#a03020',1,0,14,3);r('#8d8f98',2,9,12,8);r('#3a6a9a',4,10,8,3)}},
 stall:{n:'Market Stall (+2 gold / 12s)',c:{wood:15,gold:20},w:20,h:16,draw:r=>{r('#5a3a1e',1,7,2,9);r('#5a3a1e',17,7,2,9);r('#c8a060',2,11,16,3);for(let i=0;i<6;i++)r(i%2?'#fff':'#c03a2a',1+i*3,3,3,5);r('#e8b030',5,9,3,2);r('#a03020',11,9,3,2)}},
 dummy:{n:'Training Dummy',c:{wood:5},w:12,h:18,draw:r=>{r('#5a3a1e',5,6,2,12);r('#c8a060',2,6,8,3);r('#d8b878',3,1,6,5);r('#a03020',3,9,6,4)}}
};
function decPlace(k,x,y,free){const d=DT[k];if(!d)return 0;if(!free){for(const a in d.c)if(H[a]<d.c[a])return 0;for(const a in d.c)H[a]-=d.c[a]}
 const o={k:'tower',img:d.img||(d.img=mk(d.w,d.h,d.draw)),x,y,w:d.w,h:d.h,dead:0,done:0,deco:1};objs.push(o);DEC.push({t:k,x,y,o});return 1}
window.decOut=()=>DEC.map(d=>[d.t,Math.round(d.x-CX),Math.round(d.y-CX)]);
window.decLoad=a=>{window.__decLoaded=1;DEC.slice().forEach(d=>{const i=objs.indexOf(d.o);if(i>=0)objs.splice(i,1)});DEC.length=0;(Array.isArray(a)?a:[]).forEach(e=>{if(Array.isArray(e)&&DT[e[0]]&&isFinite(e[1]+e[2]))decPlace(e[0],CX+e[1],CX+e[2],1)})};
/* PvP: rivals see this lord's decorations and gates too */
window.syncDG=function(P,dc,cg){P.dgm=P.dgm||new Map();const seen=new Set();
 (Array.isArray(dc)?dc.slice(0,120):[]).forEach(e=>{if(!Array.isArray(e))return;const d=DT[e[0]],dx=+e[1],dy=+e[2];if(!d||!isFinite(dx+dy))return;const id='d'+e[0]+Math.round(dx)+'_'+Math.round(dy);seen.add(id);let o=P.dgm.get(id);
  if(!o){o={k:'tower',img:d.img||(d.img=mk(d.w,d.h,d.draw)),x:P.lx+dx,y:P.ly+dy,w:d.w,h:d.h,dead:0,done:0};P.dgm.set(id,o);objs.push(o)}else{o.x=P.lx+dx;o.y=P.ly+dy}});
 (Array.isArray(cg)?cg.slice(0,40):[]).forEach(e=>{if(!Array.isArray(e))return;const dx=+e[0],dy=+e[1];if(!isFinite(dx+dy))return;const id='g'+Math.round(dx)+'_'+Math.round(dy);seen.add(id);let o=P.dgm.get(id);
  if(!o){o={k:'wall',img:TX.gateO,x:P.lx+dx,y:P.ly+dy,w:14,h:16,dead:0,done:0};P.dgm.set(id,o);objs.push(o)}else{o.x=P.lx+dx;o.y=P.ly+dy}});
 P.dgm.forEach((o,id)=>{if(!seen.has(id)){const j=objs.indexOf(o);if(j>=0)objs.splice(j,1);P.dgm.delete(id)}})};
window.dgOut=()=>({dc:window.decOut?decOut():[],cg:window.cgOut?cgOut():[]});
window.decList=()=>DEC;const DEC_MAX=100,DA={n:0};try{DA.n=Math.max(0,Math.min(DEC_MAX,+localStorage.getItem('cor_decauto')||0))}catch(e){}
window.decBody=function(){const cost=c=>Object.entries(c).map(([a,v])=>v+' '+a).join(', '),bu=WK.filter(w=>w.type=='builder').length;
 let b='<p style="font-size:9px">Decorations: <b>'+DEC.length+' / '+DEC_MAX+'</b>. Bought pieces are placed in free spots around your castle.</p>'
 +'<p style="font-size:9px">\u{1F477} Builders auto-build up to: <button onclick="decTgt(-10)">\u221210</button> <button onclick="decTgt(-1)">\u22121</button> <b>'+DA.n+'</b> <button onclick="decTgt(1)">+1</button> <button onclick="decTgt(10)">+10</button><br><small>'+(bu?bu+' builders will raise them over time (keeps 80 of each resource in reserve).':'Recruit builders at your camp to auto-build.')+'</small></p>';
 b+=Object.keys(DT).map(k=>'<p style="font-size:9px;margin:5px 0"><b>'+DT[k].n+'</b> <small>'+cost(DT[k].c)+'</small><br><button onclick="decBuy(\''+k+'\',1)">Buy \u00d71</button> <button onclick="decBuy(\''+k+'\',5)">\u00d75</button> <button onclick="decBuy(\''+k+'\',10)">\u00d710</button> <button onclick="decHere(\''+k+'\')">Place here</button></p>').join('');
 return b+'<p><button onclick="decAuto()">\u2728 Beautify camp now</button> <button onclick="decUndo()">Remove last (50% back)</button></p>'};
window.decUI=function(){if(!inGame)return;if(window.tgUI)tgUI('decor')};
window.decTgt=d=>{DA.n=Math.max(0,Math.min(DEC_MAX,DA.n+d));try{localStorage.setItem('cor_decauto',DA.n)}catch(e){}sfx('recruit');decUI()};
function decSpot(){const big=K1.built?1:0;for(let i=0;i<400;i++){const a=Math.random()*6.283,r=60+Math.random()*(big?300:150),x=CX+Math.cos(a)*r,y=CX+Math.sin(a)*r*.85;if(!SLOTS.some(q=>q.built&&Math.hypot(q.x-x,q.y-y)<34)&&!WALLS.some(w=>Math.hypot(w.x-x,w.y-y)<14)&&!DEC.some(d=>Math.hypot(d.x-x,d.y-y)<22)&&Math.hypot(x-H.x,y-H.y)>14)return[x,y]}return null}
window.decBuy=(k,n)=>{let done=0;for(let i=0;i<n;i++){if(DEC.length>=DEC_MAX){toast('Decoration limit ('+DEC_MAX+') reached');break}const s=decSpot();if(!s){toast('No free room left');break}if(!decPlace(k,s[0],s[1])){toast('Not enough resources');break}done++}
 if(done){sfx('recruit');toast(done+' \u00d7 '+DT[k].n.split(' (')[0]+' built')}else sfx('no');hud();decUI()};
const DK=['garden','lamp','well','dummy','statue','stall','fountain'];let dki=0,dtn=0;
setInterval(()=>{try{if(!inGame||paused||won||DA.n<=DEC.length||DEC.length>=DEC_MAX)return;const bu=WK.filter(w=>w.type=='builder').length;if(!bu)return;let made=0;const per=Math.max(1,Math.min(3,bu>>1));
 for(let j=0;j<DK.length&&made<per;j++){const k=DK[dki++%DK.length],c=DT[k].c;if(!Object.keys(c).every(a=>H[a]-c[a]>=80))continue;const s=decSpot();if(!s)break;if(decPlace(k,s[0],s[1])){made++;if(DEC.length>=DA.n)break}}
 if(made){hud();if(Date.now()-dtn>20000){dtn=Date.now();toast('\u{1F477} Builders raised '+made+' decoration'+(made>1?'s':''))}}}catch(e){}},6000);
window.decHere=k=>{const x=H.x+(H.face||1)*16,y=H.y+4;if(Math.hypot(x-CX,y-CX)>430){sfx('no');return toast('Too far from your castle')}
 if(DEC.some(d=>Math.hypot(d.x-x,d.y-y)<12)){sfx('no');return toast('Something is already here')}
 if(!decPlace(k,x,y)){sfx('no');return toast('Not enough resources')}sfx('recruit');toast(DT[k].n.split(' (')[0]+' built');hud();decUI()};
window.decUndo=()=>{const d=DEC.pop();if(!d)return;const i=objs.indexOf(d.o);if(i>=0)objs.splice(i,1);const c=DT[d.t].c;for(const a in c)H[a]=Math.min(RESMAX,H[a]+Math.floor(c[a]/2));sfx('mine');hud();decUI()};
window.decAuto=function(){const big=K1.built?1:0,want=Math.max(4,Math.min(30,Math.round(WK.length*.6+ARM.length/12+big*6)));const keys=['lamp','garden','well','statue','fountain','stall','dummy','lamp','garden'];let n=0,tries=0;
 const free=(x,y)=>!SLOTS.some(q=>q.built&&Math.hypot(q.x-x,q.y-y)<34)&&!WALLS.some(w=>Math.hypot(w.x-x,w.y-y)<14)&&!DEC.some(d=>Math.hypot(d.x-x,d.y-y)<22)&&Math.hypot(x-H.x,y-H.y)>14;
 while(n<want&&tries<600){tries++;const a=Math.random()*6.283,r=60+Math.random()*(big?210:130),x=CX+Math.cos(a)*r,y=CX+Math.sin(a)*r*.85;if(!free(x,y))continue;if(!decPlace(keys[n%keys.length],x,y))break;n++}
 toast(n?'✨ '+n+' decorations raised':'Not enough resources, or no room');sfx(n?'win':'no');hud();decUI()};
/* stalls earn gold (solo only), fountains heal the hero */
setInterval(()=>{try{if(!inGame||paused||MPI)return;const n=DEC.filter(d=>d.t=='stall').length;if(n)H.gold=Math.min(RESMAX,H.gold+n*2)}catch(e){}},12000);
setInterval(()=>{try{if(!inGame||paused)return;if(H.hp<H.mhp&&DEC.some(d=>d.t=='fountain'&&Math.hypot(d.x-H.x,d.y-H.y)<48))H.hp=Math.min(H.mhp,H.hp+3)}catch(e){}},1000);
/* fallback restore for saved games */
setTimeout(()=>{try{if(PEND){if(!window.__decLoaded&&Array.isArray(PEND.dec))window.decLoad(PEND.dec);if(!window.__cgLoaded&&Array.isArray(PEND.cg))window.cgLoad(PEND.cg)}}catch(e){}},1500);
}catch(e){console.error('v19 patch',e)}})();
