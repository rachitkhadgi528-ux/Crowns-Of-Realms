/* ===== v-final3: NPC lords keep pace with the player + exit from spectate ===== */
(function(){
const _k=kAI;kAI=function(dt){_k(dt);if(MPI||won)return;
 const pa=ARM.filter(u=>!u.dead).length,tg=0;
 KG.forEach(k=>{if(k.owned||k.cast.hp<=0)return;k._sc=(k._sc||0)-dt;if(k._sc>0)return;
  const al=USK(k);if(al.length>=tg)return;
  k._sc=Math.max(1.5,7-pa/30);
  const n=1+Math.floor((tg-al.length)/25);
  for(let i=0;i<n;i++){const ty=['pike','sword','bow','cguard','cav'][Math.floor(Math.random()*5)],a=Math.random()*6.283;
   mku(1,ty,k.x+Math.cos(a)*50,k.y-10+Math.sin(a)*34,{kg:k})}
 })};
const bar=document.createElement('div');bar.id='spb';
bar.style.cssText='position:fixed;top:6px;left:50%;transform:translateX(-50%);z-index:60;display:none;gap:6px;background:rgba(20,12,4,.88);border:1px solid #e8b94a;border-radius:8px;padding:5px 8px;font:12px monospace;color:#e8b94a;align-items:center';
bar.innerHTML='👁 Spectating <button class="b" style="position:static;min-width:0;padding:4px 8px" id="spn">🔁 New match</button><button class="b" style="position:static;min-width:0;padding:4px 8px" id="spx">🚪 Exit</button>';
document.body.appendChild(bar);
const go=()=>{if(window.MP&&MP.on)mpLeave();else reloadToMenu()};
$('spn').onclick=go;$('spx').onclick=()=>{try{sessionStorage.removeItem('cor_mp')}catch(e){}go()};
const _o=ovx;ovx=function(){_o();if(won){bar.style.display='flex';paused=0}};
setInterval(()=>{if(!won)bar.style.display='none'},1000);
})();
