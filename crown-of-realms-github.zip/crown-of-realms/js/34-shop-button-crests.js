/* ===== v18: Shop button (solo + PvP), 💠 Crests in the HUD, supply items ===== */
(function(){try{
const T=()=>now();let rage=0;const used={};
const PERM=(()=>{try{return JSON.parse(localStorage.getItem('cor_perm')||'{}')||{}}catch(e){return{}}})(),CD={},saveP=()=>{try{localStorage.setItem('cor_perm',JSON.stringify(PERM))}catch(e){}};
const cl_=(r,n)=>{H[r]=Math.min(RESMAX,H[r]+n)};
const IT=[{id:'hp',n:'\u2764 Healing Draught',d:'Full health for your hero. Free to use every 90s.',c:25,cd:90,f:()=>{H.hp=H.mhp}},
{id:'rage',n:'\u{1F525} Rage Elixir',d:'+40% hero damage for 90s. Free to use every 3 min.',c:40,cd:180,f:()=>{rage=T()+90}},
{id:'crate',n:'\u{1F4E6} Supply Crate',d:'+150 wood, stone, food and +100 gold. Free every 7 min.',c:30,cd:420,f:()=>{cl_('wood',150);cl_('stone',150);cl_('food',150);cl_('gold',100)}},
{id:'tonic',n:'\u{1F9EA} Army Tonic',d:'Heals your whole army. Free to use every 2.5 min.',c:35,cd:150,f:()=>{ARM.forEach(u=>{u.hp=u.mhp})}}];
const _s2=swing;swing=function(){const o=H.wb;if(T()<rage)H.wb=(o||0)+.4;try{_s2()}finally{H.wb=o}};
window.shopHub=function(){if(!inGame)return;const e=$('ov');e.style.display='flex';
 e.innerHTML='<div style="width:min(94vw,440px)"><div class="xh"><h3>\u{1F6D2} Shop</h3><button onclick="ovx()">\u2715 Close</button></div>'
 +'<p style="font-size:9px">\u{1FA99} Gold '+(H.gold|0)+' \u00b7 \u{1F4A0} Crests '+MT.bal()+'</p>'
 +'<p><button onclick="armUI()">\u2694 Armoury \u00b7 gold</button><br><small>Weapons, armour, horses, banners</small></p>'
 +'<p><button onclick="decUI()">\u{1F3DB} Decorations</button><br><small>Buy decorations and set builder auto-build</small></p>'
 +'<p><button onclick="ovx();MT.open(\'shop\')">\u{1F451} Royal Court \u00b7 \u{1F4A0}</button><br><small>Unit skins, lord skins, kingdoms, weapons</small></p>'
 +'<p style="font-size:9px;color:#e8b94a">Permanent upgrades \u00b7 \u{1F4A0} Crests (buy once, keep forever)</p>'
 +IT.map(it=>{const own=PERM[it.id],w=Math.max(0,Math.ceil((CD[it.id]||0)-T()));return '<p style="font-size:9px;margin:6px 0"><b>'+it.n+'</b><br>'+it.d+'<br><button onclick="itBuy(\''+it.id+'\')">'+(own?(w?'Ready in '+w+'s':'\u2714 Use now'):'\u{1F4A0} '+it.c+' \u00b7 unlock forever')+'</button></p>'}).join('')
 +'<small>Earn \u{1F4A0} Crests by finishing matches and deeds. Crest purchases are never used up.</small></div>'};
window.itBuy=function(id){const it=IT.find(x=>x.id==id);if(!it)return;
 if(!PERM[id]){if(!MT.spend(it.c)){sfx('no');return toast('Not enough \u{1F4A0} Crests')}PERM[id]=1;saveP();sfx('win');toast(it.n+' unlocked forever')}
 else{const w=Math.ceil((CD[id]||0)-T());if(w>0){sfx('no');return toast('Ready in '+w+'s')}it.f();CD[id]=T()+it.cd;sfx('recruit');toast(it.n+' used')}
 hud();(window.oldShopX||window.shopHub)()};
const _hd=hud;hud=function(){_hd();try{const r=$('hud').querySelector('.hr');if(!r)return;let s=r.querySelector('.cbal');if(!s){s=document.createElement('span');s.className='cbal';r.appendChild(s)}s.textContent='💠'+MT.bal()}catch(e){}};
const b=document.createElement('button');b.className='b';b.id='shb';b.textContent='🛒';b.title='Shop';
b.style.cssText='top:calc(6px + env(safe-area-inset-top,0px));right:calc(max(8px,env(safe-area-inset-right,0px)) + 202px);width:34px;height:34px;padding:0;font-size:14px;background:#7a4a1a;color:#fff;z-index:6;display:none;align-items:center;justify-content:center';
b.addEventListener('pointerdown',ev=>{ev.preventDefault();shopHub()});document.body.appendChild(b);
setInterval(()=>{try{b.style.display=(inGame&&!won)?'flex':'none';if(inGame){const L=[$('nv'),$('pb')].filter(e=>e&&e.offsetParent!==null||e&&getComputedStyle(e).display!=='none');let l=1e9;L.forEach(e=>{const r=e.getBoundingClientRect();if(r.width>0&&r.left<l)l=r.left});if(l<1e9){const R=Math.round(innerWidth-l+6);if(b._r!==R){b._r=R;b.style.right=R+'px'}}}}catch(e){}},500);
/* after a map change the page reloads: skip the intro straight to the menu */
try{if(sessionStorage.getItem('cor_skipintro')){sessionStorage.removeItem('cor_skipintro');[400,1200,2400].forEach(t=>setTimeout(()=>{try{const g=document.getElementById('igate');if(g)g.click();const k=document.getElementById('isk');if(k)k.click()}catch(e){}},t))}}catch(e){}
}catch(e){console.error('v18 patch',e)}})();
