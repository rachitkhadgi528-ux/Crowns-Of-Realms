window.RESMAX=10000;window.reloadToMenu=function(){try{sessionStorage.setItem('cor_skipintro','1')}catch(e){}location.reload()};try{if(sessionStorage.getItem('cor_skipintro')){var _st=document.createElement('style');_st.textContent='#intro,#igate,#rp{display:none!important}#ttl{animation:none!important;opacity:1!important}';document.documentElement.appendChild(_st)}}catch(e){}

/* ===== Crown of Realms mobile hardening (head, runs before game scripts) ===== */
(function(){var C=null,N=-1,F=0;window.__mmList=function(){if(C&&N===objs.length&&(++F&127))return C;F=0;N=objs.length;C=objs.filter(function(o){var k=o.k;return k=='village'||k=='den'||k=='capital'||k=='camp'});return C}})();
(function(){
 try{
  // track every AudioContext so we can suspend them when the app is backgrounded
  var A=window.AudioContext||window.webkitAudioContext;
  if(A&&!window.__acs){
   var L=window.__acs=[];
   var W=function(a,b){var c=new A(a,b);L.push(c);if(L.length>12){L=window.__acs=L.filter(function(x){return x.state!=='closed'})}return c};
   W.prototype=A.prototype;window.AudioContext=W;window.webkitAudioContext=W;
  }
 }catch(e){}
 var was=[];
 function hide(){
  try{(window.__acs||[]).forEach(function(c){if(c.state==='running'){was.push(c);c.suspend()}})}catch(e){}
  try{window.speechSynthesis&&speechSynthesis.cancel()}catch(e){}
 }
 function show(){
  try{was.splice(0).forEach(function(c){if(c.state==='suspended')c.resume()})}catch(e){}
  wl();
 }
 document.addEventListener('visibilitychange',function(){document.hidden?hide():show()});
 addEventListener('pagehide',hide);
 // keep the screen awake while playing
 var lock=null;
 function wl(){
  try{
   if(!navigator.wakeLock||document.hidden||lock)return;
   navigator.wakeLock.request('screen').then(function(l){lock=l;l.addEventListener('release',function(){lock=null})}).catch(function(){});
  }catch(e){}
 }
 ['pointerdown','touchstart','click'].forEach(function(ev){addEventListener(ev,wl,{passive:true})});
 // never let a stray error / rejected promise freeze the UI thread's error overlay
 addEventListener('unhandledrejection',function(e){try{e.preventDefault()}catch(_){}});
})();
