/* keep scroll position when a popup panel re-renders itself (Shop, Armoury, etc.) */
(function(){try{const e=document.getElementById('ov');if(!e)return;const d=Object.getOwnPropertyDescriptor(Element.prototype,'innerHTML');
Object.defineProperty(e,'innerHTML',{configurable:true,get(){return d.get.call(this)},set(v){let sc=null,h=null;try{h=(this.querySelector('h3')||{}).textContent;sc=[this.scrollTop].concat([].map.call(this.children,c=>c.scrollTop))}catch(_){}
d.set.call(this,v);try{const h2=(this.querySelector('h3')||{}).textContent;if(sc&&h&&h===h2){this.scrollTop=sc[0];[].forEach.call(this.children,(c,i)=>{c.scrollTop=sc[i+1]||0})}}catch(_){}}})}catch(err){console.error('scrollfix',err)}})();
