/* ===== cinematic battle camera: frames the fight, slow drift, letterbox bars ===== */
(function(){
window.CINK=0;window.CINC={x:0,y:0};let on=1;try{on=localStorage.getItem('cor_cin')!=='0'}catch(e){}
const mk=(top)=>{const d=document.createElement('div');d.style.cssText='position:fixed;left:0;right:0;'+(top?'top':'bottom')+':0;height:0;background:#000;z-index:1;pointer-events:none';document.body.appendChild(d);return d},bt=mk(1),bb=mk(0);
const btn=document.createElement('button');btn.style.cssText='position:fixed;left:16px;z-index:20;font:bold 13px monospace;padding:4px 8px;background:#2c2250;color:#f3e9d2;border:3px solid #4b3d86;display:none';document.body.appendChild(btn);
const lab=()=>{btn.textContent='🎬 '+(on?'Auto':'Off')};lab();
btn.onclick=()=>{on=!on;try{localStorage.setItem('cor_cin',on?'1':'0')}catch(e){}lab();toast('Cinematic camera: '+(on?'auto in big battles':'off'))};
let tgt=0,hold=0,last=performance.now();setInterval(()=>{try{for(const q of document.querySelectorAll('button')){if(q.textContent.startsWith('🔍')){btn.style.display=inGame&&!won?'block':'none';break}}}catch(e){}},500);
setInterval(()=>{try{
 if(!on||!inGame||paused||won||window.SPEC||window.WCS){tgt=0;return}
 let n=0,sx=0,sy=0,md=1e9;const R2=340*340;
 const add=u=>{const dx=u.x-H.x,dy=u.y-H.y,d2=dx*dx+dy*dy;if(d2<R2){n++;sx+=u.x;sy+=u.y;if(d2<md)md=d2}};
 if(PV.on){if(PV.war)ghostTargets().forEach(g=>{if(g.hp>0)add(g)})}
 else for(let i=0;i<US.length;i++){const u=US[i];if(u.dead||!u.team)continue;if(u.kg&&u.kg.rel>=0&&!u.raid)continue;add(u)}
 if(n>=10&&md<220*220){hold=performance.now()+3500;CINC.tx=(sx+H.x)/(n+1);CINC.ty=(sy+H.y)/(n+1)}
 tgt=performance.now()<hold?1:0}catch(e){}},250);
(function f(){requestAnimationFrame(f);const n=performance.now(),dt=Math.min(.1,(n-last)/1000);last=n;
 const k=window.CINK+(tgt-window.CINK)*Math.min(1,dt*(tgt?1.4:.9));window.CINK=k<.003?0:k;
 if(window.CINK===0&&!tgt){CINC.x=H.x;CINC.y=H.y}else if(CINC.tx!==undefined){const m=Math.min(1,dt*2.2);CINC.x+=(CINC.tx-CINC.x)*m;CINC.y+=(CINC.ty-CINC.y)*m}
 const h=(window.CINK*6).toFixed(2)+'vh';bt.style.height=bb.style.height=h;
})()})();
