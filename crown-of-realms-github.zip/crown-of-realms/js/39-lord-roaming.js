/* ===== v21: lord roaming + expansion, peace pacing, banner bearers ===== */
(function(){try{
/* peace offers follow the war: not at the start, only after a war has lasted a while */
setInterval(()=>{try{if(!window.KG)return;const g=GT_();KG.forEach(k=>{if(k.rel<0){if(!k.warT)k.warT=g||1}else k.warT=0})}catch(e){}},2000);
window.peaceReady=function(k){try{const g=GT_();if(g<720)return false;const w=k.warT?g-k.warT:0;if(w<240)return false;if(g-(window.__pmT||-1e9)<300)return false;const losing=(k.cast&&k.cast.hp<k.cast.mhp*.75)||(window.USK&&USK(k).length<4);return !!losing||w>=480}catch(e){return false}};
/* NPC castles keep building homes and farms as they level up */
window.kBuild=function(k){if(!k.sl||k.owned)return;const z=k.sl.find(q=>!q.built&&!q.cl&&(q.k=='farm'||q.k=='home')&&(!q.req||q.req.built));if(z)bld(z)};
/* NPC lords leave the castle with an escort, explore, loot villages, then come home */
setInterval(()=>{try{if(!inGame||paused||MPI||won||PV.live)return;const g=GT_();if(g<150)return;const t=now();
 KG.forEach(k=>{if(k.owned||!k.cast)return;const L=k.lord;if(!L||L.dead){k.rm=null;return}
  if(L.raid||L.fm){k.rm=null;return}
  let r=k.rm;
  if(!r){if(t<(k.rmN||0))return;if(k.rel<0&&k.at!=null&&k.at<30)return;
   let x=0,y=0,ok=0;const vs=objs.filter(o=>o.k=='village'&&!o.done&&Math.hypot(o.x-k.x,o.y-k.y)<1500&&Math.hypot(o.x-CX,o.y-CX)>500);
   if(vs.length&&Math.random()<.5){const o=vs[Math.random()*vs.length|0];x=o.x;y=o.y+30;ok=1}
   else for(let i=0;i<12&&!ok;i++){const a=Math.random()*6.283,d=350+Math.random()*1200;x=k.x+Math.cos(a)*d;y=k.y+Math.sin(a)*d;if(x>250&&y>250&&x<7200-250&&y<7200-250&&Math.hypot(x-CX,y-CX)>500)ok=1}
   if(!ok){k.rmN=t+30;return}
   const es=(window.USK?USK(k):[]).filter(u=>!u.raid&&!u.ex&&!u.dead&&u.type!='lord').slice(0,3+Math.min(5,k.lv>>1));
   if(es.length<2){k.rmN=t+30;return}
   r=k.rm={x,y,t0:t,ph:0,es};L.ex=1;L.hx=x;L.hy=y;es.forEach((u,i)=>{u.ex=1;u.hx=x+(i%3-1)*22;u.hy=y+14+(i/3|0)*18});
   if(Math.hypot(H.x-k.x,H.y-k.y)<1000&&window.feed)feed('Lord '+(k.hs?k.hs.ln:'')+' rides out to explore');return}
  const d=Math.hypot(L.x-r.x,L.y-r.y);
  if(r.ph==0&&(d<50||t-r.t0>110)){r.ph=1;r.t1=t;objs.forEach(o=>{if(o.k=='village'&&!o.done&&Math.hypot(o.x-L.x,o.y-L.y)<90&&(!o.grp||o.grp.l.every(u=>u.dead))){o.done=1;k.r.gold=Math.min(RESMAX,k.r.gold+70);k.r.wood=Math.min(RESMAX,k.r.wood+15)}})}
  else if(r.ph==1&&t-r.t1>18){r.ph=2;L.hx=k.x;L.hy=k.y+34;r.es.forEach(u=>{if(!u.dead){u.hx=k.x+(Math.random()-.5)*60;u.hy=k.y+30}})}
  else if(r.ph==2&&(Math.hypot(L.x-k.x,L.y-k.y)<90||t-r.t0>260)){L.ex=0;L.hx=k.x;L.hy=k.y+34;r.es.forEach(u=>{u.ex=0});k.rm=null;k.rmN=t+45+Math.random()*60}
 })}catch(e){}},2500);
/* banner bearers in formation: the player's own design, a little bigger than a normal flag */
window.bearerDraw=function(u,x,y,sc,R){if(((u.uid|0)%18)!==0)return;const b=(window.getPB&&getPB())||{c1:'#2a5aa8',c2:'#e8b94a',em:1};R(x+9*sc,y-34*sc,sc,24*sc,'#6a4a2a');flag(x+9*sc,y-12*sc,b,.9)};
/* mobile: compact buttons in the Training Ground / shop panels */
const st=document.createElement('style');st.textContent='@media (max-width:760px){#ov button{padding:6px 8px;font-size:9px;margin:2px 1px}#ov p{margin:4px 0}}';document.head.appendChild(st);
}catch(e){console.error('v21 patch',e)}})();
