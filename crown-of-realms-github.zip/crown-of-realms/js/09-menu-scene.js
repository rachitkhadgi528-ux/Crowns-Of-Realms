/* ===== animated menu scene: carved frame, torchlit hall, marching soldiers, the chosen lord ===== */
(function(){
const m=$('mbg'),W=560,Hh=266,SC=1.5;m.width=W*SC;m.height=Hh*SC;const g=m.getContext('2d');
const crest=document.createElementNS('http://www.w3.org/2000/svg','svg');crest.setAttribute('viewBox','0 0 30 36');
crest.innerHTML='<path d="M2 2h26v18c0 8-6 13-13 16C8 33 2 28 2 20z" fill="#efe9d8" stroke="#2a1308" stroke-width="2"/><path d="M13 5h4v8h8v4h-8v13h-4V17H5v-4h8z" fill="#b01c1c"/>';
$('ttl').querySelector('h1').prepend(crest);
const bgc=document.createElement('canvas');bgc.width=W*SC;bgc.height=Hh*SC;const b=bgc.getContext('2d');b.scale(SC,SC);
const star=(x,y,r,col)=>{b.fillStyle=col;b.beginPath();for(let i=0;i<16;i++){const a=i*Math.PI/8,rr=i%2?r*.55:r;b.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr)}b.closePath();b.fill()};
(function paint(){
 let gr=b.createLinearGradient(0,0,0,Hh);gr.addColorStop(0,'#6a5232');gr.addColorStop(1,'#3a2a18');b.fillStyle=gr;b.fillRect(0,0,W,Hh);
 for(let i=0;i<1400;i++){b.fillStyle=hs(i,7)>.5?'#ffffff0d':'#0000001a';b.fillRect(hs(i,1)*W,hs(i,2)*Hh,1+hs(i,3)*2,1+hs(i,4)*2)}
 // inner hall
 const x0=16,y0=16,x1=W-16,y1=Hh-16;gr=b.createLinearGradient(0,y0,0,y1);gr.addColorStop(0,'#1d140c');gr.addColorStop(1,'#0c0805');b.fillStyle=gr;b.fillRect(x0,y0,x1-x0,y1-y0);
 for(let r=0;r<9;r++)for(let c=0;c<18;c++){const bx=x0+c*24+(r&1?12:0)-12,by=y0+r*20;b.strokeStyle='#00000055';b.strokeRect(bx,by,24,20);if(hs(r,c)>.7){b.fillStyle='#ffffff08';b.fillRect(bx+1,by+1,22,18)}}
 // arched doorway
 const dx0=398,dx1=494,dy=206;gr=b.createLinearGradient(0,60,0,dy);gr.addColorStop(0,'#f6ecd0');gr.addColorStop(1,'#bfa670');
 b.fillStyle='#2a1d10';b.beginPath();b.moveTo(dx0-8,dy);b.lineTo(dx0-8,100);b.arc(446,100,56,Math.PI,0);b.lineTo(dx1+8,dy);b.fill();
 b.fillStyle=gr;b.beginPath();b.moveTo(dx0,dy);b.lineTo(dx0,100);b.arc(446,100,48,Math.PI,0);b.lineTo(dx1,dy);b.fill();
 b.fillStyle='#00000040';for(let r=0;r<6;r++)for(let c=0;c<7;c++){b.beginPath();b.arc(dx0+8+c*13+(r&1?6:0),70+r*22,3.2,0,6.3);b.fill()}
 // pillars
 for(const px of[372,500]){const pg=b.createLinearGradient(px,0,px+20,0);pg.addColorStop(0,'#4a3820');pg.addColorStop(.5,'#9a7a48');pg.addColorStop(1,'#4a3820');b.fillStyle=pg;b.fillRect(px,30,20,dy-24);b.fillStyle='#b8985c';b.fillRect(px-4,26,28,8);b.fillRect(px-4,dy-4,28,8)}
 // floor, tiles and carpet
 b.fillStyle='#241d18';b.fillRect(x0,dy,x1-x0,y1-dy);
 for(let i=-12;i<=12;i++){b.strokeStyle='#ffffff10';b.beginPath();b.moveTo(446+i*14,dy);b.lineTo(446+i*60,y1);b.stroke()}
 for(let r=1;r<5;r++){b.strokeStyle='#ffffff10';const yy=dy+r*r*3.2;b.beginPath();b.moveTo(x0,yy);b.lineTo(x1,yy);b.stroke()}
 b.fillStyle='#8a1c1c';b.beginPath();b.moveTo(426,dy);b.lineTo(468,dy);b.lineTo(300,y1);b.lineTo(120,y1);b.fill();b.strokeStyle='#d9a84a';b.lineWidth=2;b.beginPath();b.moveTo(426,dy);b.lineTo(120,y1);b.moveTo(468,dy);b.lineTo(300,y1);b.stroke();b.lineWidth=1;
 // carved frame
 b.fillStyle='#4a361d';b.fillRect(0,0,W,16);b.fillRect(0,Hh-16,W,16);b.fillRect(0,0,16,Hh);b.fillRect(W-16,0,16,Hh);
 for(let x=8;x<W;x+=22){star(x,8,6.5,'#241608');star(x,8,3.4,'#9a7a44');star(x,Hh-8,6.5,'#241608');star(x,Hh-8,3.4,'#9a7a44')}
 for(let y=8;y<Hh;y+=22){star(8,y,6.5,'#241608');star(8,y,3.4,'#9a7a44');star(W-8,y,6.5,'#241608');star(W-8,y,3.4,'#9a7a44')}
 b.strokeStyle='#d0a868';b.lineWidth=1.5;b.strokeRect(16,16,W-32,Hh-32);b.strokeStyle='#241608';b.lineWidth=2;b.strokeRect(1,1,W-2,Hh-2);b.lineWidth=1;
 gr=b.createRadialGradient(W/2,Hh/2,Hh*.35,W/2,Hh/2,W*.62);gr.addColorStop(0,'#0000');gr.addColorStop(1,'#000a');b.fillStyle=gr;b.fillRect(0,0,W,Hh)})();
// sprite helpers (the game's own soldier engine, scaled up)
const SW=64,spr=document.createElement('canvas');spr.width=spr.height=SW;const sg=spr.getContext('2d');
function render(o){sg.clearRect(0,0,SW,SW);const prev=Z;Z=sg;try{Zman(o)}finally{Z=prev}}
function blit(x,y,sc,tint){if(tint){sg.globalCompositeOperation='source-atop';sg.fillStyle=tint;sg.fillRect(0,0,SW,SW);sg.globalCompositeOperation='source-over'}g.imageSmoothingEnabled=false;g.drawImage(spr,0,0,SW,SW,x-SW/2*sc,y-(SW-10)*sc,SW*sc,SW*sc)}
const MARCH=[{x:420,d:0,col:'#2a4a8a',acc:'#a8324a',ty:'pike',w:'spear'},{x:446,d:1.7,col:'#2a4a8a',acc:'#e8b94a',ty:'sword',w:'sword'},{x:472,d:3.1,col:'#2a6a4a',acc:'#c8a050',ty:'pike',w:'spear'}];
function flame(x,y,t){const f=Math.sin(t*17+x)*1.2,gr=g.createRadialGradient(x,y,1,x,y,46+f*3);gr.addColorStop(0,'#ffb04acc');gr.addColorStop(1,'#ff6a1a00');g.fillStyle=gr;g.fillRect(x-50,y-50,100,100);
 g.fillStyle='#e8501a';g.beginPath();g.moveTo(x-4,y);g.quadraticCurveTo(x-5,y-8,x+f,y-15-f);g.quadraticCurveTo(x+5,y-8,x+4,y);g.fill();g.fillStyle='#ffd070';g.beginPath();g.moveTo(x-2,y);g.quadraticCurveTo(x-2,y-5,x+f*.5,y-9);g.quadraticCurveTo(x+2,y-5,x+2,y);g.fill();g.fillStyle='#3a2410';g.fillRect(x-1,y,2,12)}
let T0=performance.now()/1000;
function frame(){const mn=$('menu');if(!mn||mn.style.display=='none')return;requestAnimationFrame(frame);
 const t=performance.now()/1000-T0,h=(window.HS&&HS[window.HI|0])||{c1:'#e8e8ee',c2:'#b01c1c',h:'#aaa'},hi=window.HI|0;
 g.setTransform(1,0,0,1,0,0);g.drawImage(bgc,0,0);g.setTransform(SC,0,0,SC,0,0);
 // marching soldiers pass through the lit doorway (dark silhouettes)
 g.save();g.beginPath();g.rect(399,60,94,150);g.clip();
 MARCH.forEach(s=>{const ph=t*7+s.d,lp=((t*.22+s.d*.31)%1),px=s.x+Math.sin(lp*6.28)*0,mv=1;
  render({x:32,y:54,f:-1,sc:1,t:t,sd:Math.round(s.d*3),mv:1,ph:ph,fl:0,col:s.col,acc:s.acc,st:ZMS[s.ty],up:0,atk:-1,wep:s.w,wp:-1,cape:s.acc});blit(px,206,2.1,'rgba(14,10,6,.55)')});
 g.restore();
 // torches on the pillars
 flame(382,92,t);flame(510,92,t);
 // waving banner
 for(let i=0;i<22;i++){const wy=Math.sin(t*4+i*.5)*2.2*(i/22);g.fillStyle=h.c1;g.fillRect(40+i,34+wy,1,50-i*.6);g.fillStyle=h.c2;g.fillRect(40+i,58+wy-i*.3,1,5)}g.fillStyle='#d8b060';g.fillRect(36,30,32,3);
 // chosen lord: idle breathing, periodic sword salute/slash
 const P=t%8,atk=P<1.3?P/1.3:-1;
 g.fillStyle='rgba(0,0,0,.45)';g.beginPath();g.ellipse(430,236,38,8,0,0,6.3);g.fill();
 render({x:32,y:54,f:-1,sc:1.12,t:t,sd:hi*5+2,mv:0,ph:0,fl:0,col:h.c1,acc:h.c2,st:ZHERO[hi]||ZHERO[0],up:0,atk:atk,wep:'sword',jp:hi==1,wv:ZHW[hi],ride:0,cape:h.c2,wp:-1,hs:1.05});blit(430,236,5.3);
 // drifting dust in the torchlight
 for(let i=0;i<26;i++){const px=(hs(i,5)*W+t*(4+hs(i,6)*6))%W,py=(hs(i,8)*Hh-t*(3+hs(i,9)*4)+Hh*4)%Hh;g.fillStyle='rgba(255,220,150,'+(.15+.15*Math.sin(t*2+i))+')';g.fillRect(px,py,1.4,1.4)}}
requestAnimationFrame(frame);
})();
