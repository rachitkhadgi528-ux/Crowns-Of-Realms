window.AGE_=window.AGE_||function(){return 0};window.GT_=window.GT_||function(){return 0};window.RDP=window.RDP||[['#a48a5c','#957b50'],['#8e8a80','#7c786e'],['#a8a8ae','#76767e']];
window.onerror=function(m,s,l){var d=document.createElement('div');d.style.cssText='position:fixed;left:8px;right:8px;bottom:8px;z-index:30;background:#a8324a;color:#fff;padding:8px;border:3px solid #000;font:9px/1.5 monospace';d.textContent='Error: '+m+' (line '+l+')';document.body.appendChild(d)};
const $=q=>document.getElementById(q),WD=7200,CX=3600;
const ME={bx:CX,by:CX,s:0},PV={on:0,live:0,war:0,n:0,peaceEnd:0},PAL=[['#2a5aa8','#e8b94a',1],['#c0392b','#f3e9d2',0],['#2a8a4a','#e8e04a',3],['#7a3a9a','#f0c0f0',2],['#d08a20','#2a1a05',0],['#2a9aa8','#ffffff',1]];let UID=0;
const toSh=(x,y)=>[x-CX+ME.bx,y-CX+ME.by],toLo=(x,y)=>[x-ME.bx+CX,y-ME.by+CX];
const PEND=(()=>{try{const i=localStorage.getItem('cor_pend');if(!i)return null;localStorage.removeItem('cor_pend');const S=JSON.parse(localStorage.getItem('cor_save_'+i));return S&&S.v==1&&typeof S.seed=='number'?S:null}catch(e){return null}})();
function h32(q){let h=2166136261;for(let i=0;i<q.length;i++){h^=q.charCodeAt(i);h=Math.imul(h,16777619)}return h|0}
const MPI=PEND?null:(()=>{try{const m=(location.hash.match(/r=([A-Za-z0-9]{4,8})/)||[])[1];if(m)return{code:m.toUpperCase(),host:0};const q=sessionStorage.getItem('cor_mp');if(q){const o=JSON.parse(q);if(o&&/^[A-Z0-9]{4,8}$/.test(o.code))return o}}catch(e){}return null})();
const SEED=PEND?PEND.seed|0:MPI?h32(MPI.code):((Date.now()^(Math.random()*4294967296))|0);
let rs=SEED;const BP=((SEED>>>0)%6000)/100;function rnd(){rs|=0;rs=rs+0x6D2B79F5|0;let t=Math.imul(rs^rs>>>15,1|rs);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}
const hs=(i,j)=>{const n=Math.sin(i*127.1+j*311.7)*43758.5453;return n-Math.floor(n)};
const MAPN=['Verdant Realms','Frostmarch','Scorched Dunes','Murkfen','Four Corners'],MAPLC=['X','A','B','C','D'];
const MAPI=(()=>{try{let i=0;if(PEND)i=PEND.map|0;else if(MPI)i=Math.max(0,MAPLC.indexOf(String(MPI.code).slice(-1)));else i=+localStorage.getItem('cor_map')||0;return i>=0&&i<MAPN.length?i:0}catch(e){return 0}})();
function bio(px,py){const x=(px-CX)/13.3,z=(py-CX)/13.3,n=Math.sin(x*.05+z*.03+BP)*8;
 if(MAPI==0)return z+n>38?'desert':z+n<-38?'snow':x+n>34?'swamp':'forest';
 if(Math.hypot(x,z)<46)return 'forest';
 if(MAPI==1)return z+n>58?'forest':'snow';
 if(MAPI==2)return z+n<-58?'swamp':'desert';
 if(MAPI==3)return z+n>62?'desert':x+n<-58?'forest':'swamp';
 return x+n>0?(z+n>0?'desert':'swamp'):(z+n>0?'forest':'snow')}
const ht=(px,py)=>{const x=(px-CX)/8.9,z=(py-CX)/8.9;return(Math.sin(x*.07)*2.2+Math.cos(z*.06)*2.2+Math.sin((x+z)*.17)*.7)*Math.min(1,Math.hypot(x,z)/14)};
const BR={forest:[[48,112,46],[66,134,54]],swamp:[[85,102,58],[63,90,64]],desert:[[210,176,106],[199,162,92]],snow:[[230,238,244],[211,224,234]]};
const TN={forest:[40,90,60,.1],swamp:[60,80,60,.18],desert:[255,200,120,.12],snow:[200,225,255,.14]};
const cv=$('gl'),c=cv.getContext('2d');let VH=216,VW=384;let GQ='retro',GS=1;try{GQ=localStorage.getItem('cor_gq3')||'retro'}catch(e){}
if(window.PERF===undefined&&((navigator.hardwareConcurrency||8)<=4||(navigator.deviceMemory||8)<=3))window.PERF=1;
function size(){VW=Math.round(VH*innerWidth/innerHeight);const mx=((window.matchMedia&&matchMedia('(pointer:coarse)').matches)?2:3)-(window.PERF?1:0);GS=GQ=='hd'?Math.max(window.PERF?1:2,Math.min(mx,Math.round(innerHeight*(devicePixelRatio||1)/VH))):1;cv.width=VW*GS;cv.height=VH*GS;cv.style.imageRendering=GQ=='hd'?'auto':'pixelated';if(GQ!='hd')GS=window.PERF?1:2;cv.width=VW*GS;cv.height=VH*GS;const m=$('mbg');if(m)m.style.imageRendering=GQ=='hd'?'auto':'pixelated'}size();addEventListener('resize',size);const gc=document.createElement('canvas'),gx=gc.getContext('2d');const GR=(()=>{const k=document.createElement('canvas');k.width=k.height=128;const x=k.getContext('2d'),im=x.createImageData(128,128);for(let i=0;i<im.data.length;i+=4){const v=60+Math.random()*135|0;im.data[i]=im.data[i+1]=im.data[i+2]=v;im.data[i+3]=255}x.putImageData(im,0,0);return k})();function shd(x,y,w){c.fillStyle='rgba(25,14,0,.34)';c.beginPath();c.ellipse(x+w*.2,y-1,w*.55,w*.17,0,0,6.2832);c.fill()}function post(cx,cy){c.save();c.globalCompositeOperation='soft-light';let g=c.createLinearGradient(0,0,VW,VH);g.addColorStop(0,'rgba(255,224,165,.6)');g.addColorStop(1,'rgba(80,95,160,.5)');c.fillStyle=g;c.fillRect(0,0,VW,VH);c.globalCompositeOperation='source-over';g=c.createRadialGradient(VW/2,VH/2,VH*.42,VW/2,VH/2,VW*.62);g.addColorStop(0,'rgba(10,6,0,0)');g.addColorStop(1,'rgba(10,6,0,.5)');c.fillStyle=g;c.fillRect(0,0,VW,VH);c.setTransform(1,0,0,1,0,0);c.globalCompositeOperation='overlay';c.globalAlpha=.13;const pt=c.createPattern(GR,'repeat');if(pt.setTransform)pt.setTransform(new DOMMatrix([1,0,0,1,-(cx*GS)%128,-(cy*GS)%128]));c.fillStyle=pt;c.fillRect(0,0,cv.width,cv.height);c.restore()}

const lc=document.createElement('canvas'),lx=lc.getContext('2d');

/* ===== fine-pixel detail: every sprite also gets a 2x hand-shaded version (EPX smoothing, outline, rim light, bevel, grain) drawn crisp at 2x density ===== */
const _hdLum=(r,g,b)=>r*.3+g*.59+b*.11;
function hdify(k){const w=k.width,h=k.height;if(w<4||h<4||w*h>40000)return null;let src;try{src=k.getContext('2d').getImageData(0,0,w,h)}catch(e){return null}
 const u=new Uint32Array(src.data.buffer),W=w*2,H=h*2,o=new Uint32Array(W*H),g=(x,y)=>x<0||y<0||x>=w||y>=h?0:u[y*w+x];
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const P=u[y*w+x],A=g(x,y-1),B=g(x+1,y),C=g(x-1,y),D=g(x,y+1);let e0=P,e1=P,e2=P,e3=P;
  if(C==A&&C!=D&&A!=B)e0=A;if(A==B&&A!=C&&B!=D)e1=B;if(D==C&&D!=B&&C!=A)e2=C;if(B==D&&B!=A&&D!=C)e3=D;
  const i=y*2*W+x*2;o[i]=e0;o[i+1]=e1;o[i+W]=e2;o[i+W+1]=e3}
 const solid=(x,y)=>x>=0&&y>=0&&x<W&&y<H&&((o[y*W+x]>>>24)>=128),out=new Uint32Array(W*H),d8=new Uint8ClampedArray(out.buffer);
 for(let y=0;y<H;y++)for(let x=0;x<W;x++){const i=y*W+x,p=o[i],a=p>>>24;if(!a){continue}
  let r=p&255,gg=(p>>8)&255,b=(p>>16)&255,f=1.07-.14*(y/H);
  const hs=((x*374761393+y*668265263)^(x*y*2246822519))>>>0,nz=((hs>>>13)&15)/15-.5;f+=nz*.085;
  if(a>=200){const edge=!solid(x,y-1)||!solid(x,y+1)||!solid(x-1,y)||!solid(x+1,y);
   if(edge){if(_hdLum(r,gg,b)>62)f*=.6}
   else{if(!solid(x-2,y)||!solid(x,y-2)||!solid(x-1,y-1))f*=1.2;else if(!solid(x+2,y)||!solid(x,y+2)||!solid(x+1,y+1))f*=.8;
    const R=o[i+1],Dn=o[i+W];if(R&&((R>>>24)>=128)&&R!==p&&_hdLum(R&255,(R>>8)&255,(R>>16)&255)<_hdLum(r,gg,b)-26)f*=.9}}
  const j=i*4;d8[j]=Math.max(0,Math.min(255,r*f));d8[j+1]=Math.max(0,Math.min(255,gg*f));d8[j+2]=Math.max(0,Math.min(255,b*f));d8[j+3]=a}
 const hc=document.createElement('canvas');hc.width=W;hc.height=H;hc.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(d8.buffer),W,H),0,0);return hc}
const _di=CanvasRenderingContext2D.prototype.drawImage;
CanvasRenderingContext2D.prototype.drawImage=function(im,a,b,c2,d,e,f,g,h){const n=arguments.length;if(this===c&&GS>=2){const H=im&&im.hd;if(H){if(n==3)return _di.call(this,H,a,b,im.width,im.height);if(n==5)return _di.call(this,H,a,b,c2,d);if(n==9)return _di.call(this,H,a*2,b*2,c2*2,d*2,e,f,g,h)}}if(n==3)return _di.call(this,im,a,b);if(n==5)return _di.call(this,im,a,b,c2,d);if(n==9)return _di.call(this,im,a,b,c2,d,e,f,g,h);return _di.apply(this,arguments)};
function mk(w,h,f){const k=document.createElement('canvas');k.width=w;k.height=h;const x=k.getContext('2d');f((col,a,b,ww,hh)=>{x.fillStyle=col;x.fillRect(a,b,ww,hh)});try{k.hd=hdify(k)}catch(e){}return k}
const pine=sn=>mk(16,24,r=>{r('#5a3a1e',7,18,2,6);for(let i=0;i<4;i++){const w=4+i*3,y=2+i*4;r(i%2?'#2d6a3a':'#357a42',8-(w>>1),y,w,5);if(sn)r('#fff',8-(w>>1),y,w,2)}});
const TX={pine:pine(0),spine:pine(1),
dead:mk(16,22,r=>{r('#5b5648',7,6,3,16);r('#5b5648',3,8,5,2);r('#5b5648',10,4,4,2);r('#5b5648',2,5,2,4);r('#5b5648',13,2,2,4);r('#3f5a40',4,18,8,3)}),
cact:mk(12,20,r=>{r('#3f8a3f',5,2,3,18);r('#3f8a3f',1,8,4,2);r('#3f8a3f',1,5,2,5);r('#3f8a3f',8,10,4,2);r('#3f8a3f',10,6,2,6)}),
rock:mk(12,8,r=>{r('#7a7a85',2,2,8,6);r('#9a9aa5',3,1,5,3);r('#5a5a65',1,5,2,3)}),
house:mk(24,20,r=>{r('#7a5230',3,9,18,11);for(let i=0;i<6;i++)r('#a8324a',10-2*i,3+i,4+4*i,1);r('#a8324a',2,9,20,2);r('#2a1a05',10,13,4,7);r('#f3d27a',5,12,3,3)}),
cave:mk(20,14,r=>{r('#5a5a65',0,3,20,11);r('#7a7a85',3,0,14,4);r('#0a0710',6,5,8,9)}),
castle:mk(48,40,r=>{const S='#7a7a88',D='#55556a',K='#0a0710';r(D,8,16,32,24);r(S,9,16,30,22);for(let i=0;i<6;i++)r(S,9+i*5,12,3,4);r(D,17,2,14,16);r(S,18,2,12,15);for(let i=0;i<3;i++)r(S,18+i*5,0,3,3);r('#a8324a',22,5,4,6);[0,38].forEach(x=>{r(D,x,8,10,32);r(S,x+1,8,8,31);for(let i=0;i<3;i++)r(S,x+i*4,4,3,4);r(K,x+4,14,2,4);r(K,x+4,24,2,4);r('#a8324a',x+3,0,4,4)});r(K,20,26,8,14);r('#6a4a2a',21,27,6,13);for(let i=0;i<3;i++)r(K,22+i*2,27,1,13);for(let y=18;y<40;y+=4){r(D,10,y,8,1);r(D,30,y,8,1)}}),
ruin:mk(48,40,r=>{r('#55556a',0,28,48,12);r('#7a7a88',4,24,10,8);r('#7a7a88',30,26,12,10);r('#3a3a48',16,30,14,10);r('#e8501a',22,24,3,4)}),
wall:mk(14,16,r=>{r('#55556a',0,3,14,13);r('#8a8a98',1,4,12,11);for(let i=0;i<3;i++)r('#8a8a98',i*5,0,4,4);r('#55556a',1,9,12,1);r('#55556a',6,4,1,5)}),
farm:mk(18,10,r=>{r('#5a3a1e',0,0,18,10);r('#7a5230',1,1,16,8);for(let i=0;i<4;i++){r('#4c9a3c',2+i*4,2,2,4);r('#8acb4a',2+i*4,1,2,2)}}),
fire:mk(8,10,r=>{r('#e8501a',1,4,6,6);r('#f3a31a',2,2,4,8);r('#fff2a0',3,5,2,4)}),
hero:[0,1].map(f=>mk(16,24,r=>{r('#a8324a',3,8,10,12);r('#2a4a8a',4,8,8,9);r('#e8c39a',5,2,6,6);r('#e8b94a',5,0,6,3);r('#e8b94a',5,0,1,1);r('#e8b94a',10,0,1,1);r('#2a1a05',6,5,1,1);r('#2a1a05',9,5,1,1);r('#3a2a1a',4+f*3,17,3,6-f);r('#3a2a1a',9-f*3,17,3,5+f)}))};
// units
const UT={pike:{n:'Pike',hp:45,dmg:7,rng:24,spd:58,cd:.8,c:'#2a4a8a',s:'#a8324a',w:'spear',cost:{wood:10,stone:5,food:3}},
sword:{n:'Sword',hp:60,dmg:10,rng:15,spd:64,cd:.6,c:'#2a4a8a',s:'#e8b94a',w:'sword',cost:{wood:8,stone:8,gold:10,food:3}},
bow:{n:'Bow',hp:28,dmg:7,rng:95,spd:52,cd:1.1,c:'#2a6a4a',w:'bow',cost:{wood:14,stone:2,food:3}},
bandit:{n:'Bandit',hp:40,dmg:7,rng:15,spd:52,cd:.8,c:'#7a3a2a',w:'sword',gold:3},
guard:{n:'Guard',hp:55,dmg:8,rng:24,spd:48,cd:.9,c:'#4a5a6a',s:'#7a9ab0',w:'spear',gold:5},
archer:{n:'Archer',hp:28,dmg:6,rng:95,spd:46,cd:1.3,c:'#6a5a2a',w:'bow',gold:4},
brute:{n:'Brute',hp:150,dmg:16,rng:20,spd:42,cd:1.2,c:'#5a3a6a',w:'club',big:1.5,gold:12},
wolf:{n:'Wolf',hp:28,dmg:6,rng:11,spd:88,cd:.7,c:'#8a8a95',w:'bite',gold:3},
knight:{n:'Knight',hp:90,dmg:11,rng:16,spd:46,cd:.8,c:'#8a1a2a',s:'#c0c0c8',w:'sword',gold:10},
builder:{n:'Builder',hp:30,c:'#8a6a3a',s:'#c8a050',w:'none',cost:{wood:10,gold:10}},farmer:{n:'Farmer',hp:30,c:'#6a8a3a',s:'#e8d070',w:'none',cost:{wood:6,gold:8}},ram:{n:'Ram',hp:140,dmg:0,rng:18,spd:34,cd:1,c:'#6a4a2a',w:'none',cost:{wood:30,stone:10,gold:20}},
cav:{n:'Cavalry',hp:80,dmg:12,rng:17,spd:100,cd:.7,c:'#2a4a8a',s:'#e8b94a',w:'spear',horse:1,cost:{wood:15,stone:5,gold:25,food:5}},
cutter:{n:'Woodcutter',hp:35,c:'#7a4a2a',s:'#d8a050',w:'none',cost:{wood:4,gold:6}},miner:{n:'Miner',hp:35,c:'#5a5a6a',s:'#c0c0c8',w:'none',cost:{wood:6,gold:8}},cguard:{n:'C.Guard',hp:85,dmg:9,rng:22,spd:56,cd:.8,c:'#3a5a8a',s:'#c8c8d8',w:'spear',cost:{wood:12,stone:10,gold:15,food:3}},villager:{n:'Villager',hp:30,c:'#8a5a6a',w:'none'},child:{n:'Child',hp:20,c:'#6a7ab0',w:'none',big:.75}};
const NM=['Fiona','Lian','Rylo','Anan','Kael','Mira','Dax','Sena','Tor','Edda'],CLS=['pike','sword','bow','cguard','builder','farmer','cutter','miner','ram','cav'],FRM=['Column','Wall','Ring'],FD={Column:'balanced',Wall:'pikes −30% dmg',Ring:'all −15% dmg'};
const WK=[],WALLS=[],SLOTS=[],US=[],ARM=[],PS=[],AR=[],FX=[],PK=[],FEED=[];let gear=0,cls=0,form=0,won=0,lastFeed=0,nextRaid=60,atkHeld=0;
const now=()=>performance.now()/1000;const FS={x:1,y:0};function smx(dt){const k=Math.min(1,dt*4),fx=H.fx||0,fy=H.fy||0;FS.x+=(fx-FS.x)*k;FS.y+=(fy-FS.y)*k;const l=Math.hypot(FS.x,FS.y)||1;FS.x/=l;FS.y/=l;return FS.x}
function mku(team,type,x,y,o){const d=UT[type],u={uid:++UID,team,type,x,y,hx:x,hy:y,sx:x,sy:y,hp:d.hp,mhp:d.hp,cd:Math.random()*.6,face:1,atk:0,hit:0,dead:0,ph:Math.random()*6,raid:o&&o.raid,kg:o&&o.kg,std:Math.random()<.3,nm:team?d.n:NM[Math.floor(Math.random()*NM.length)]+' ('+d.n+')'};US.push(u);if((type=='cguard'||type=='bguard')&&!team){const a=Math.random()*6.283;u.gd=1;u.hx=CX+Math.cos(a)*225;u.hy=CX+Math.sin(a)*180}if(!team)ARM.push(u);return u}
const objs=[];let sieged=0,ct=0;
for(let i=0;i<6;i++){const a=i/6*6.283+.5;SLOTS.push({k:'farm',x:CX+Math.cos(a)*42,y:CX+Math.sin(a)*34+8,c:{wood:4}})}
for(let i=0;i<4;i++){const a=.8+i*1.57;SLOTS.push({k:'home',x:CX+Math.cos(a)*74,y:CX+Math.sin(a)*60,c:{wood:8,stone:3}})}
for(let i=0;i<138;i++){if(i<4||i>134)continue;const a=i/138*6.283;SLOTS.push({k:'wall',x:CX+Math.cos(a)*284,y:CX+Math.sin(a)*243,c:{stone:2},ring:1})}
const K1={k:'keep',x:CX,y:CX-56,c:{wood:20,stone:25,gold:30}};SLOTS.push(K1);
for(let i=0;i<4;i++){const a=.785+i*1.571;SLOTS.push({k:'tower',x:CX+Math.cos(a)*291,y:CX+Math.sin(a)*250,c:{wood:6,stone:12},req:K1})}
for(let i=0;i<4;i++){const a=.3+i*1.571;SLOTS.push({k:'farm',x:CX+Math.cos(a)*348,y:CX+Math.sin(a)*294,c:{wood:4},req:K1})}
for(let i=0;i<6;i++){const a=.5+i*1.047;SLOTS.push({k:'home',x:CX+Math.cos(a)*393,y:CX+Math.sin(a)*333,c:{wood:10,stone:4},req:K1})}
for(let i=0;i<233;i++){if(i<4||i>229)continue;const a=i/233*6.283;SLOTS.push({k:'wall',x:CX+Math.cos(a)*480,y:CX+Math.sin(a)*405,c:{stone:2},req:K1,t0:i*4})}
function mkw(type,x,y){const d=UT[type],u={type,x,y,hp:d.hp,mhp:d.hp,face:1,atk:0,hit:0,ph:Math.random()*6,t:0,nm:NM[Math.floor(Math.random()*NM.length)]+' ('+d.n+')'};WK.push(u);return u}
function wgo(w,x,y,dt){const dx=x-w.x,dy=y-w.y,d=Math.hypot(dx,dy);if(d>3){const s=Math.min(66*dt,d);w.x+=dx/d*s;w.y+=dy/d*s;w.ph+=dt*10;if(Math.abs(dx)>1)w.face=dx>0?1:-1}return d}
const T0=now();const aff=q=>Object.entries(q.c).every(([k,v])=>H[k]>=v);
function wk(w,dt){let s=w.s;
 if(w.type=='builder'){
  if(s&&s.built)s=w.s=null;
  if(!s){s=SLOTS.find(q=>q.cust&&!q.built&&!q.cl&&aff(q))||SLOTS.find(q=>(q.k=='wall'||q.k=='keep')&&!q.built&&!q.cl&&(!q.kg||q.kg.owned)&&(!q.req||q.req.built)&&(!q.t0||now()-T0>=q.t0)&&aff(q));if(s){s.cl=1;w.s=s;w.t=0}}
  if(!s){const t=RP.p[RP.i];if(t&&H.stone>=1){if(wgo(w,t[0],t[1]+4,dt)<5){w.t+=dt;if(w.t>2.6){w.t=0;H.stone--;RD.push({x:t[0],y:t[1]});RP.i++;sfx('mine',t[0],t[1])}}return}wgo(w,CX+WK.indexOf(w)*14-30,CX+26,dt);return}
  if(wgo(w,s.x,s.y+4,dt)<5){w.t+=dt;if(w.t>({wall:7,farm:12,home:25,keep:60,tower:30}[s.k]||10)){if(aff(s)){for(const k in s.c)H[k]-=s.c[k];w.s=null;bld(s);sfx('mine',s.x,s.y);toast({wall:'A wall segment is raised',farm:'A new farm plot is ready',home:'A new family moves in',tower:'A watchtower is complete'}[s.k]||'Construction complete')}else{s.cl=0;w.s=null}}}
 }else{
  if(w.type=='cutter'||w.type=='miner'){gather(w,dt);return}const P=SLOTS.filter(q=>q.k=='farm'&&q.built&&!q.kg);if(!P.length){wgo(w,CX+WK.indexOf(w)*14-30,CX+26,dt);return}
  if(!s||!s.built)s=w.s=P[WK.indexOf(w)%P.length];
  if(wgo(w,s.x,s.y+5,dt)<5){w.t+=dt;if(w.t>2){w.t=0;const _f=Math.round(4*(window.YM?YM():1));H.food+=_f;FX.push({x:w.x,y:w.y-20,t:'+'+_f+' food',l:1,c:'#9c6'})}}}}
function decl(k,auto){if(k.rel<0)return;if(window.GENM||window.FALLEN)return;if((window.peaceOn&&peaceOn())){if(!decl.t||now()-decl.t>4){decl.t=now();toast('Peace holds: no war can start yet')}return}k.rel=-1;toast(auto?k.name+' declares war on you!':'You declared war on '+k.name);sfx('horn')}
const _uskC=new Map();let _uskT=0;function USK(k){const t=performance.now();if(t-_uskT>250){_uskT=t;_uskC.clear()}let l=_uskC.get(k);if(!l){l=US.filter(u=>u.kg===k&&u.team&&!u.dead);_uskC.set(k,l)}return l}
function conquer(k){k.owned=1;k.rel=1;k.cast.hp=k.cast.mhp;US.forEach(u=>{if(u.kg===k&&u.team&&!u.dead)u.dead=now()});toast(k.name+' is now yours!');sfx('win');say(k.name+' bows to your crown, my liege.',1)}
function hitCastle(n,o){if(!o||o.hp<=0)return;if(o.pl)sendD(o.pl,'c',0,n);else if(o.kg.rel>=0)decl(o.kg,1);o.hp-=n;sfx('hit',o.x,o.y);FX.push({x:o.x+(Math.random()-.5)*30,y:o.y-20,t:'-'+(n|0),l:.7,c:'#fff'});for(let i=0;i<5;i++)PS.push({x:o.x+(Math.random()-.5)*40,y:o.y-10,vx:(Math.random()-.5)*50,vy:-Math.random()*50,l:.6,c:'#8a8a98'});if(o.hp<=0&&!o.pl)conquer(o.kg)}
function hitPC(n){if(PC.hp<=0||won)return;PC.hp-=n;sfx('hit',PC.x,PC.y);FX.push({x:PC.x+(Math.random()-.5)*30,y:PC.y-30,t:'-'+(n|0),l:.7,c:'#f77'});for(let i=0;i<4;i++)PS.push({x:PC.x+(Math.random()-.5)*30,y:PC.y-10,vx:(Math.random()-.5)*50,vy:-Math.random()*50,l:.6,c:'#8a8a98'});if(PC.hp<=0)over()}
function over(){if(won)return;won=1;sfx('horn');say('The castle has fallen. All is lost.',1);if(PV.live)mpSend({t:'e',id:MP.id,by:window.LAT||'',hi:window.HI|0});$('ov').innerHTML=PV.live?'<div><h3>💀 Your castle has fallen</h3><p>You are eliminated. You can keep watching.</p><button onclick="ovx()">Spectate</button> <button onclick="mpLeave()">Leave</button></div>':'<div><h3>💀 Your castle has fallen</h3><p>Game over. A new realm awaits.</p><button onclick="reloadToMenu()">New Reign</button></div>';$('ov').style.display='flex'}
function nearCap(x,y,d){let b=null,bd=d;CAPS.forEach(o=>{if(o.hp>0&&o.kg.rel<1&&!o.kg.owned){const q=Math.hypot(o.x-x,o.y-y);if(q<bd){bd=q;b=o}}});if(!PV.war)return b;MP.peers.forEach(P=>{const o=P.ck;if(P.out||P.tm===ME.tm||!o||o.hp<=0)return;const q=Math.hypot(o.x-x,o.y-y);if(q<bd){bd=q;b=o}});return b}
function castle(dt){CAPS.forEach(o=>{if(o.hp<=0||o.kg.owned||o.kg.rel>=0)return;o.ct=(o.ct||0)-dt;if(o.ct>0)return;let tg=null,bd=170;ARM.concat([H]).forEach(e=>{const d=Math.hypot(e.x-o.x,e.y-o.y);if(d<bd){bd=d;tg=e}});
 if(tg){o.ct=1.1;if(!sieged){sieged=1;toast('The siege begins!');say('The siege begins! Beware the castle archers, my liege!')}
  [-34,34].forEach(ox=>{const sx=o.x+ox,sy=o.y-66,L=Math.hypot(tg.x-sx,tg.y-sy)||1;AR.push({x:sx,y:sy,vx:(tg.x-sx)/L*200,vy:(tg.y-sy)/L*200,team:1,dmg:5,l:1.1,from:{nm:'Castle'}});sfx('arrow',sx,sy)})}})}
function cfx(o,x,y){if(o.hp>0&&o.hp<o.mhp){c.fillStyle='#a8142a';c.fillRect(x-24,y-o.h-6,48,3);c.fillStyle='#e8b94a';c.fillRect(x-24,y-o.h-6,(48*o.hp/o.mhp)|0,3)}
 if(o.hp<o.mhp*.5){const q=now();c.fillStyle='rgba(70,70,70,.6)';c.fillRect(x-20+(q*6%5),y-o.h+12-(q*12%16),3,3);c.fillRect(x+14,y-o.h+20-(q*9%14),3,3)}}
function ram(u,dt){let px=u.sx,py=u.sy,sg=0;const o=nearCap(H.x,H.y,340);if(o){px=o.x;py=o.y+6;sg=1}
 if(!sg){const g=gateWP(u,px,py);if(g){px=g[0];py=g[1]}}const dx=px-u.x,dy=py-u.y,dist=Math.hypot(dx,dy),stop=sg?14:2;
 if(dist>stop){const v=Math.min((sg?34:Math.max(34,Math.min(110,dist*3)))*dt,dist-stop+.01);u.x+=dx/dist*v;u.y+=dy/dist*v;u.ph+=dt*10;if(Math.abs(dx)>2)u.face=dx>0?1:-1}
 else if(sg&&u.cd<=0){u.cd=1;u.atk=.25;hitCastle(30,o)}}
function add(k,img,x,y,w,h){const o={k,img,x,y,w,h,dead:0,done:0};objs.push(o);return o}
const rp=()=>50+rnd()*(WD-100),far=(x,y,d)=>Math.hypot(x-CX,y-CX)>d;
function pack(x,y,types,rad,w){if(MPI)return{types:[],x,y,rad:rad||18,w,rt:0,l:[]};const p={types,x,y,rad:rad||18,w,rt:0,l:[]};spawn(p);PK.push(p);return p}
function spawn(p){p.l=p.types.map((ty,i)=>mku(1,ty,p.x+Math.cos(i*2.4)*(p.rad+i*1.5),p.y+Math.sin(i*2.4)*(p.rad+i*1.5)))}
for(let i=0;i<8000;i++){const x=rp(),y=rp();if(!far(x,y,330))continue;const b=bio(x,y);
 if(b=='forest')add('tree',TX.pine,x,y,16,24);else if(b=='snow')add('tree',TX.spine,x,y,16,24);else if(b=='swamp')add('tree',TX.dead,x,y,16,22);else if(rnd()<.6)add('tree',TX.cact,x,y,12,20);else add('rock',TX.rock,x,y,12,8)}
for(let i=0;i<1100;i++){const x=rp(),y=rp();if(far(x,y,330))add('rock',TX.rock,x,y,12,8)}
function poi(k,img,w,h,types){let x,y;do{x=rp();y=rp()}while(!far(x,y,450));const o=add(k,img,x,y,w,h);o.grp=pack(x,y+20,types,16);return o}
for(let i=0;i<48;i++)poi('village',TX.house,36,30,['guard','guard','guard','archer']);
for(let i=0;i<26;i++)poi('den',TX.cave,30,21,['wolf','wolf','wolf','brute']);

const BT={forest:['bandit','bandit','archer'],swamp:['wolf','wolf','brute'],desert:['bandit','archer','archer','bandit'],snow:['wolf','brute','wolf','wolf']};
pack(CX+780,CX-165,['bandit','bandit'],14,1);
for(let i=0;i<135;i++){let x,y;do{x=rp();y=rp()}while(!far(x,y,640));pack(x,y,BT[bio(x,y)],16,1)}
const camp=add('camp',TX.fire,CX,CX,16,20);
/* v20: extra trees & rocks near the camp so cutters/miners keep up with the 10000 storage cap (own RNG: world layout/saves unchanged) */
{let s=987654321;const q=()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296};
 for(let i=0;i<420;i++){const a=q()*6.283,r=345+q()*395,x=CX+Math.cos(a)*r,y=CX+Math.sin(a)*r*.85;if(x<60||y<60||x>WD-60||y>WD-60)continue;
  if(i%2){const b=bio(x,y);if(b=='forest')add('tree',TX.pine,x,y,16,24);else if(b=='snow')add('tree',TX.spine,x,y,16,24);else if(b=='swamp')add('tree',TX.dead,x,y,16,22);else add('tree',TX.cact,x,y,12,20)}else add('rock',TX.rock,x,y,12,8)}}
const H={x:CX,y:CX+40,face:1,fr:0,ft:0,fx:1,fy:0,wood:60,stone:40,gold:50,food:30,m:0,hp:100,mhp:100,hero:1,cd:0,atk:0,hit:0,nm:'You'},hist=[],cam={x:H.x-VW/2,y:H.y-VH/2};
const cnt=t=>ARM.filter(u=>u.type==t).length,LIM=()=>500;
function hset(e,s){if(e._hs!==s){e._hs=s;e.innerHTML=s}}
function hud(){const wl=K1.built?60:40,wt=t=>WK.filter(w=>w.type==t).length;hset($('hud'),`<div class="hr"><span>❤${Math.max(0,H.hp|0)}</span><span>🪵${H.wood}</span><span>🪨${H.stone}</span><span>🌾${H.food|0}</span><span>🪙${H.gold}</span></div><div class="hr"><b>Workers ${WK.length}/${wl}</b><span>👷Builders ${wt('builder')}</span><span>🌾Farmers ${wt('farmer')}</span><span>🪓Cutters ${wt('cutter')}</span><span>⛏Miners ${wt('miner')}</span></div><div class="hr"><b>Army ${ARM.length}/${LIM()}</b>${ARM.some(u=>u.hold)?'<span>Holding '+ARM.filter(u=>u.hold).length+'</span>':''}<span>🛡Pike ${cnt('pike')}</span><span>🗡Sword ${cnt('sword')}</span><span>🏹Bow ${cnt('bow')}</span><span>🐎Cav ${cnt('cav')}</span><span>💂Guard ${cnt('cguard')}</span><span>🐏Ram ${cnt('ram')}</span>${Object.entries(ARM.reduce((a,u)=>{if(!['pike','sword','bow','cav','cguard','ram'].includes(u.type))a[u.type]=(a[u.type]||0)+1;return a},{})).map(([t,n])=>'<span>'+((UT[t]&&UT[t].n)||t)+' '+n+'</span>').join('')}</div><div class="hr">${H.wb?'<span>🗡'+H.wn+'</span>':''}<span>👪Villagers ${CT.filter(u=>!u.kg).length}</span><span>🏰${KNAME} ${Math.max(0,PC.hp|0)}</span><span>${MPI?pvTxt():'👑'+KG.filter(k=>k.owned).length+'/'+KG.length}</span></div>`);
 $('cls').textContent='Train: '+UT[CLS[cls]].n+' ('+(['builder','farmer','cutter','miner'].includes(CLS[cls])?WK.filter(w=>w.type==CLS[cls]).length:cnt(CLS[cls]))+')';$('frm').textContent='Form: '+FRM[form];if(window.tbl)tbl()}
setInterval(()=>hud(),600);
let tt;function toast(t){const e=$('toast');e.textContent=t;e.style.display='block';clearTimeout(tt);tt=setTimeout(()=>e.style.display='none',2400)}
function feed(t){FEED.unshift(t);FEED.length=Math.min(FEED.length,4);lastFeed=now();$('feed').innerHTML=FEED.join('<br>')}
function hurt(tg,dmg,from){if(tg.gh){if(tg.hp>0)gdmg(tg,dmg);return}if(tg.dead)return;if(tg.kg&&tg.team&&tg.kg.rel>=0&&from&&(from===H||from.team===0))decl(tg.kg,1);let m=1;if(!tg.team){if(form==1&&tg.type=='pike')m=.7;if(form==2)m=.85}
 dmg=Math.max(1,Math.round(dmg*m));tg.hp-=dmg;tg.hit=.15;sfx('hit',tg.x,tg.y);if(tg.hero)sfx('hurt');FX.push({x:tg.x,y:tg.y-22,t:'-'+dmg,l:.7,c:tg.team?'#fff':'#f77'});
 for(let i=0;i<4;i++)PS.push({x:tg.x,y:tg.y-8,vx:(Math.random()-.5)*60,vy:-Math.random()*40,l:.45,c:'#a8142a'});splat(tg,tg.hp<=0);
 if(tg.hp<=0){sfx('kill',tg.x,tg.y);feed(from.nm+' killed '+tg.nm);if(tg.hero&&window.GENM&&window.genRespawn){genRespawn()}else if(tg.hero){H.x=CX;H.y=CX+40;H.hp=H.mhp;H.gold=Math.floor(H.gold*.7);H.m=0;HR.on=1;HR.x=CX+34;HR.y=CX+58;toast('You fell! Back at camp, lost 30% gold');say('You have fallen. Rise again, my liege.')}
  else{tg.dead=now();if(!tg.team){ARM.splice(ARM.indexOf(tg),1)}else{const g=UT[tg.type].gold||2;H.gold+=g;FX.push({x:tg.x,y:tg.y-30,t:'+'+g+'g',l:1,c:'#e8b94a'})}}}}
function swing(){if(H.cd>0||won)return;H.cd=.4;H.atk=.25;sfx('swing');const dm=14*(1+.15*gear+(H.wb||0))*(H.m?1.35:1);
 US.forEach(u=>{if(u.team&&!u.dead&&!(u.kg&&u.kg.rel==1)){const dx=u.x-H.x,dy=u.y-H.y,d=Math.hypot(dx,dy);if(d<36&&(dx*H.fx+dy*H.fy>-5))hurt(u,dm,H)}});gswing(dm);hunt(dm);{const o=nearCap(H.x,H.y,60);if(o&&Math.hypot(o.x-H.x,o.y+4-H.y)<42)hitCastle(dm*.4,o)}KW.slice().forEach(w=>{if(w.kg.rel<1&&!w.kg.owned&&!(window.peaceOn&&peaceOn())&&Math.hypot(w.x-H.x,w.y-H.y)<24){w.hp-=dm;if(w.hp<=0)kbrk(w)}})}
const K={w:0,a:0,s:0,d:0};let jx=0,jy=0,jid=null;
addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(k in K)K[k]=1;if(k==' '||k=='e')act();if(k=='f'||k=='j')atkHeld=1});addEventListener('keyup',e=>{const k=e.key.toLowerCase();if(k in K)K[k]=0;if(k=='f'||k=='j')atkHeld=0});
const jel=$('joy');function jm(e){const r=jel.getBoundingClientRect();let x=(e.clientX-r.left-60)/50,y=(e.clientY-r.top-60)/50;const m=Math.hypot(x,y);if(m>1){x/=m;y/=m}jx=x;jy=y;$('knob').style.transform=`translate(${x*36}px,${y*36}px)`}
jel.addEventListener('pointerdown',e=>{jid=e.pointerId;jel.setPointerCapture(jid);jm(e)});jel.addEventListener('pointermove',e=>{if(e.pointerId==jid)jm(e)});
['pointerup','pointercancel'].forEach(n=>jel.addEventListener(n,()=>{jid=null;jx=jy=0;$('knob').style.transform=''}));
$('act').addEventListener('pointerdown',e=>{e.preventDefault();act()});
$('atk').addEventListener('pointerdown',e=>{e.preventDefault();atkHeld=1;swing()});['pointerup','pointercancel','pointerleave'].forEach(n=>$('atk').addEventListener(n,()=>atkHeld=0));
$('cls').addEventListener('pointerdown',e=>{e.preventDefault();cls=(cls+1)%CLS.length;hud()});$('frm').addEventListener('pointerdown',e=>{e.preventDefault();form=(form+1)%FRM.length;hud()});
let near=null;
function act(){const o=near;if(!o||won)return;
 if(o.k=='tree'){H.wood+=15;o.dead=now();sfx('chop');toast('+15 wood')}
 else if(o.k=='rock'){H.stone+=15;o.dead=now();sfx('mine');toast('+15 stone')}
 else if(o.k=='camp'){const t=CLS[cls],d=UT[t];const wk_=['builder','farmer','cutter','miner'].includes(t);if(wk_?WK.length>=(K1.built?60:40):ARM.length>=LIM())toast(wk_?'Your workforce is full':'Your army is at full strength');else if(Object.entries(d.cost).every(([k,v])=>H[k]>=v)){for(const k in d.cost)H[k]-=d.cost[k];wk_?mkw(t,H.x,H.y):mku(0,t,H.x,H.y);sfx('recruit');toast(d.n+' recruited. You now have '+(wk_?WK.filter(w=>w.type==t).length:cnt(t)))}else toast((sfx('no'),d.n)+' costs '+Object.entries(d.cost).map(([k,v])=>v+' '+k).join(', '))}
 else if(o.k=='village'){o.done=1;H.gold+=70;H.wood+=15;sfx('loot');toast('Village looted: +70 gold, +15 wood')}
 else if(o.k=='den'){o.done=1;H.stone+=30;H.gold+=40;sfx('loot');if(Math.random()<.55){gear++;toast('Legendary Sword! Your side hits 15% harder')}else toast('Den looted: +30 stone, +40 gold')}
 hud()}
let muted=0,ac,o1,o2,lf,cb='',sb,nb;const AP={forest:[220,'triangle',.4],swamp:[65,'triangle',3],desert:[98,'sine',.15],snow:[330,'sine',.25]};
function aud(){if(ac)return;try{ac=new(window.AudioContext||window.webkitAudioContext)();const gn=ac.createGain();gn.gain.value=.012;const lg=ac.createGain();lg.gain.value=.008;o1=ac.createOscillator();o2=ac.createOscillator();lf=ac.createOscillator();o1.connect(gn);o2.connect(gn);lf.connect(lg);lg.connect(gn.gain);gn.connect(ac.destination);sb=ac.createGain();sb.gain.value=.2;const lp=ac.createBiquadFilter();lp.type='lowpass';lp.frequency.value=3000;sb.connect(lp);lp.connect(ac.destination);nb=ac.createBuffer(1,ac.sampleRate,ac.sampleRate);const nd=nb.getChannelData(0);for(let i=0;i<nd.length;i++)nd[i]=Math.random()*2-1;snd(cb||'forest')}catch(e){}}
function snd(b){cb=b;if(!ac)return;const a=AP[b];o1.type=a[1];o1.frequency.setTargetAtTime(a[0],ac.currentTime,.5);o2.frequency.setTargetAtTime(a[0]*1.5,ac.currentTime,.5);lf.frequency.value=a[2]}
const CT=[],CV=[],HR={x:CX+34,y:CX+58,face:1,on:1},FN=['Ashby','Brook','Cole','Dunn','Fenn'],GN=['Edric','Maud','Tom','Wynn','Hugh','Elsa','Piers','Nell','Gwen','Bran','Ida','Joss'];
const LF=['Supper is almost ready, love.','Did you feed the hens today?','Our little one grows so fast.','Mind the walls, dear.','Pray the bandits stay away.'],LN=['Fine day for harvest, neighbour!','I heard wolves howling last night.','The new walls make me feel safer.','Our crops are doing well.','Bandits again? Gods help us.','The king’s army keeps us safe.'],LC=['Look, a horse!','Can I be a knight too?','Tell the story again, Papa!'];
const cas=rf=>mk(48,40,r=>{const M='#bda07c',L='#d8c29e',D='#8a6e50',K='#2a1a14';r(M,8,18,32,22);r(L,8,18,32,2);r(D,8,38,32,2);for(let y=22;y<38;y+=4)r(D,9,y,30,1);for(let i=0;i<6;i++)r(L,9+i*5,16,3,2);
 r(M,17,7,14,12);r(L,17,7,2,12);r(D,29,7,2,12);for(let i=0;i<7;i++)r(rf,23-i,i,2+i*2,1);r(K,23,11,2,3);
 const tw=(cx,top,h)=>{r(M,cx-4,top+6,8,h);r(L,cx-4,top+6,2,h);r(D,cx+2,top+6,2,h);for(let i=0;i<6;i++)r(rf,cx-1-i,top+i,2+i*2,1);r(K,cx-1,top+12,2,3);r(K,cx-1,top+22,2,3)};tw(6,6,28);tw(41,0,34);
 r(K,20,28,8,12);r('#5a3a22',21,29,6,11);r(K,23,29,1,11);r(K,25,29,1,11)});
const oak=()=>mk(16,24,r=>{r('#4a301a',7,17,3,7);r('#245a2c',1,9,14,10);r('#245a2c',3,5,10,6);r('#2f7436',2,8,12,8);r('#2f7436',4,3,8,8);r('#4a9a48',4,5,6,5);r('#6cba5c',5,4,3,3);r('#6cba5c',9,9,3,2);r('#6cba5c',3,10,3,2)});
function rpl(k,img){const old=TX[k];TX[k]=img;objs.forEach(o=>{if(o.img===old)o.img=img})}
rpl('pine',oak());rpl('castle',cas('#b8322a'));
rpl('house',mk(24,20,r=>{r('#a88a68',3,9,18,11);r('#d8c8a8',3,9,17,10);r('#7a5230',3,9,18,1);r('#7a5230',11,9,1,11);for(let i=0;i<6;i++)r(i<3?'#c8423a':'#b8322a',10-2*i,3+i,4+4*i,1);r('#8a2018',0,8,24,2);r('#4a2a12',13,13,4,7);r('#3a5a8a',5,12,3,3);r('#3a5a8a',18,12,3,3)}));
rpl('wall',mk(14,16,r=>{r('#8a6e50',0,3,14,13);r('#bda07c',1,4,12,11);r('#d8c29e',1,4,12,2);for(let i=0;i<3;i++)r('#bda07c',i*5,0,4,4);r('#8a6e50',1,10,12,1);r('#8a6e50',6,4,1,6)}));
function keepSpr(rf){return mk(48,40,r=>{const M='#b8a07c',L='#d8c29e',D='#86694c',K='#1a1210',V='#3f7a3a',V2='#2a5a2a',V3='#5a9a4a',W='#f3c04a',G='#e8b94a',rl='#4a7ac8',rd='#1e4380';
 r(M,8,18,32,22);r(L,8,18,32,2);for(let y=21;y<38;y+=3){r(D,9,y,30,1);for(let x=((y/3|0)&1)?12:15;x<38;x+=6)r(D,x,y+1,1,2)}r(D,8,38,32,2);
 for(let i=0;i<6;i++){r(M,9+i*5,15,3,3);r(L,9+i*5,15,3,1);r(D,11+i*5,15,1,3)}
 r(M,16,6,16,13);r(L,16,6,2,13);r(D,30,6,2,13);for(let y=9;y<18;y+=3)r(D,17,y,13,1);r(L,15,5,18,1);
 for(let i=0;i<7;i++){r(rf,23-i,i,2+i*2,1);r(rl,23-i,i,2,1);r(rd,24+i,i,1,1)}r(G,23,0,2,1);
 r(K,22,9,4,7);r(W,23,10,2,5);r(K,23,12,2,1);r(L,21,8,6,1);
 const tw=(x0,top)=>{const h=40-top-7;r(M,x0,top+7,11,h);r(L,x0,top+7,2,h);r(D,x0+9,top+7,2,h);for(let y=top+10;y<38;y+=3){r(D,x0,y,11,1);for(let x=x0+((y/3|0)&1?2:5);x<x0+10;x+=5)r(D,x,y+1,1,2)}
  r(L,x0-1,top+6,13,1);for(let i=0;i<7;i++){r(rf,x0+5-i,top+i-1,2+i*2,1);r(rl,x0+5-i,top+i-1,2,1);r(rd,x0+6+i,top+i-1,1,1)}r(G,x0+5,top-2,1,2);
  r(K,x0+4,top+11,3,5);r(W,x0+5,top+12,1,3);r(K,x0+5,top+22,1,4);r(K,x0+5,top+30,1,4)};
 tw(1,8);tw(36,8);
 for(let j=0;j<18;j++){const x=1+((j*5)%4),y=39-j*1.6|0;r(j&1?V:V2,x,y,2+(j%3),2);if(j%4==0)r(V3,x+1,y,1,1);if(j==5||j==11)r('#e0506a',x+2,y,1,1)}
 for(let j=0;j<14;j++){const x=44-((j*3)%4),y=39-j*1.7|0;r(j&1?V2:V,x-2,y,2+(j%3),2);if(j%4==1)r(V3,x-1,y,1,1);if(j==4||j==9)r('#e0506a',x-1,y,1,1)}
 r(D,12,22,4,1);r(rf,12,23,4,9);r(G,13,25,2,5);r(G,12,27,4,1);r(D,12,32,1,1);r(D,15,32,1,1);
 r(D,32,22,4,1);r(rf,32,23,4,9);r(G,33,25,2,5);r(G,32,27,4,1);r(D,32,32,1,1);r(D,35,32,1,1);
 r(K,18,21,3,5);r(W,19,22,1,3);r(L,17,20,5,1);r(K,28,21,3,5);r(W,29,22,1,3);r(L,27,20,5,1);
 r(L,18,27,12,13);r(K,20,29,8,11);r(K,21,28,6,1);r('#5a3a22',21,30,6,10);r(K,23,30,1,10);r(K,25,30,1,10);r('#8a8a95',22,34,1,1);r('#8a8a95',26,34,1,1);r('#8a8a95',22,37,1,1);r('#8a8a95',26,37,1,1);
 r('#6a6a75',21,29,6,1);r('#6a6a75',21,31,6,1);r(D,18,38,12,2);r(L,17,37,14,1);
 r(V2,8,38,6,2);r(V,10,37,4,1);r(V2,34,38,5,2);r(V3,36,37,2,1);r('#d8506a',11,37,1,1);r('#d8506a',37,37,1,1);r(V2,15,39,3,1);r(V2,31,39,3,1)})}
TX.keep=keepSpr('#2a5aa8');TX.tower=mk(16,36,r=>{const M='#bda07c',L='#d8c29e',D='#8a6e50',rf='#2a5aa8';r(M,4,10,8,26);r(L,4,10,2,26);r(D,10,10,2,26);for(let i=0;i<7;i++)r(rf,7-i,3+i,2+i*2,1);r(rf,7,0,2,4);r('#2a1a14',7,18,2,3);r('#2a1a14',7,28,2,3)});
const AN=[];function mkan(t,x,y){AN.push({t,x,y,hx:x,hy:y,tx:x,ty:y,face:1,ph:Math.random()*6,wt:Math.random()*3,hp:t=='deer'?20:6,d:0})}
for(let i=0;i<900&&AN.length<90;i++){const x=50+Math.random()*(WD-100),y=50+Math.random()*(WD-100);if(far(x,y,300)&&bio(x,y)=='forest')mkan(i%3?'deer':'rabbit',x,y)}
for(let i=0;i<6;i++)mkan('sheep',CX+60+Math.random()*50,CX+70+Math.random()*25);for(let i=0;i<6;i++)mkan('hen',CX-45-Math.random()*40,CX+50+Math.random()*25);
function anim(dt){AN.forEach(a=>{if(a.d){if(now()-a.d>90){a.d=0;a.hp=a.t=='deer'?20:6;a.x=a.hx;a.y=a.hy}return}const sc=a.t=='sheep'||a.t=='hen'||a.dom,dh=Math.hypot(H.x-a.x,H.y-a.y);
 if(!sc&&dh<70){const dx=a.x-H.x,dy=a.y-H.y,v=(a.t=='deer'?85:75)*dt/(dh||1);a.x=Math.max(10,Math.min(WD-10,a.x+dx*v));a.y=Math.max(10,Math.min(WD-10,a.y+dy*v));a.ph+=dt*14;a.face=dx>0?1:-1;return}
 if(a.wt>0){a.wt-=dt;return}const dx=a.tx-a.x,dy=a.ty-a.y,d=Math.hypot(dx,dy);
 if(!(d>2)){a.wt=1+Math.random()*4;a.tx=a.hx+(Math.random()-.5)*(sc?50:120);a.ty=a.hy+(Math.random()-.5)*(sc?30:80);return}
 const v=Math.min((a.t=='deer'?28:a.t=='rabbit'?35:14)*dt,d);a.x+=dx/d*v;a.y+=dy/d*v;a.ph+=dt*9;if(Math.abs(dx)>1)a.face=dx>0?1:-1})}
function hunt(dm){AN.forEach(a=>{if(a.d||(a.t!='deer'&&a.t!='rabbit'))return;if(Math.hypot(a.x-H.x,a.y-H.y)<(H.m?46:38)){a.hp-=dm;if(a.hp<=0){a.d=now();const f=a.t=='deer'?6:2;H.food+=f;FX.push({x:a.x,y:a.y-14,t:'+'+f+' food',l:1,c:'#9c6'});sfx('kill',a.x,a.y)}else sfx('hit',a.x,a.y)}})}
function drawAn(a,x,y){const f=a.face,l=Math.round(Math.sin(a.ph)*1.5);c.fillStyle='rgba(0,0,0,.3)';c.fillRect(x-5,y-1,10,2);
 if(a.t=='deer'){c.fillStyle='#a8703a';c.fillRect(x-6,y-9,12,5);c.fillRect(x+f*5-1,y-15,4,9);c.fillStyle='#e8d0a0';c.fillRect(x-5,y-5,10,1);c.fillRect(x-f*6,y-9,2,2);c.fillStyle='#d8c8a0';c.fillRect(x+f*5,y-18,1,3);c.fillRect(x+f*7,y-18,1,3);c.fillStyle='#a8703a';c.fillRect(x-5,y-4,1,4+l);c.fillRect(x-2,y-4,1,4-l);c.fillRect(x+2,y-4,1,4+l);c.fillRect(x+5,y-4,1,4-l)}
 else if(a.t=='rabbit'){c.fillStyle='#b8a890';c.fillRect(x-3,y-5,6,4);c.fillRect(x+f*3-1,y-8,3,3);c.fillRect(x+f*3-1,y-11,1,3);c.fillStyle='#fff';c.fillRect(x-f*4,y-4,2,2)}
 else if(a.t=='sheep'){c.fillStyle='#f0ece0';c.fillRect(x-5,y-8,10,6);c.fillRect(x-4,y-9,8,2);c.fillStyle='#3a3030';c.fillRect(x+f*5-1,y-8,3,3);c.fillRect(x-4,y-2,1,2+l);c.fillRect(x+3,y-2,1,2-l)}
 else{c.fillStyle='#f3e9d2';c.fillRect(x-3,y-5,6,4);c.fillRect(x+f*3-1,y-8,2,3);c.fillStyle='#d83a2a';c.fillRect(x+f*3,y-9,1,1);c.fillStyle='#e8a030';c.fillRect(x+f*4,y-7,1,1)}}
function turr(dt,EN){SLOTS.forEach(q=>{if(q.k!='tower'||!q.built)return;q.ct=(q.ct||0)-dt;if(q.ct>0)return;let tg=null,bd=150;EN.forEach(e=>{const d=Math.hypot(e.x-q.x,e.y-q.y);if(d<bd){bd=d;tg=e}});if(tg){q.ct=1.2;const sx=q.x,sy=q.y-28,L=Math.hypot(tg.x-sx,tg.y-8-sy)||1;AR.push({x:sx,y:sy,vx:(tg.x-sx)/L*230,vy:(tg.y-8-sy)/L*230,team:0,dmg:7,l:.9,from:{nm:'Tower'}});sfx('arrow',sx,sy)}})}
TX.home=TX.house;
function bld(s){if(s.gh){const j=objs.indexOf(s.gh);if(j>=0)objs.splice(j,1);s.gh=null}const z={wall:[14,16],farm:[18,10],home:[28,24],keep:[56,48],tower:[16,36]}[s.k];s.built=1;s.cl=0;s.o={k:s.k,img:TX[s.k],x:s.x,y:s.y,w:z[0],h:z[1],dead:0,done:0};objs.push(s.o);s.hp=s.mhp=s.k=='wall'?(MPI?100:60):200;if(s.k=='wall')WALLS.push(s);if(s.k=='home')fam(s)}
function fam(s){const f=FN[Math.floor(Math.random()*FN.length)],g=[...GN].sort(()=>Math.random()-.5);['villager','villager','child'].forEach((ty,i)=>{const d=UT[ty];CT.push({type:ty,x:s.x+i*6-6,y:s.y+8,hx:s.x,hy:s.y+14,hp:d.hp,mhp:d.hp,face:1,atk:0,hit:0,ph:0,wt:Math.random()*3,cd:Math.random()*6,bt:0,bub:'',cv:null,fm:s,nm:g[i]+' '+f})})}
function cits(dt){CV.slice().forEach(v=>{v.t-=dt;if(v.t>0)return;if(v.n>=4){v.a.cv=v.b.cv=null;v.a.cd=v.b.cd=10+Math.random()*10;CV.splice(CV.indexOf(v),1)}else{const sp=v.n%2?v.b:v.a;sp.bub=v.l[v.n];sp.bt=2.6;v.n++;v.t=2.8}});
 CT.forEach(u=>{u.bt-=dt;u.cd-=dt;
  if(u.cv){const o=u.cv.a===u?u.cv.b:u.cv.a;u.face=o.x>=u.x?1:-1;return}
  if(u.cd<=0&&Math.hypot(H.x-u.x,H.y-u.y)<34){u.cd=14;u.bub=u.kg?(u.kg.rel<0?'Death to the invader!':'Glory to '+u.kg.name+'!'):Math.random()<.5?'Long live the king!':'I am '+u.nm+', my liege.';u.bt=2.8;u.face=H.x>=u.x?1:-1;return}
  for(const o of CT){if(o!==u&&!o.cv&&u.cd<=0&&o.cd<=0&&Math.hypot(o.x-u.x,o.y-u.y)<24){const P=u.kg?(u.kg.fe>now()?['Long live the '+u.kg.cu.f+'!','Music and dancing!','Join the feast, traveller!']:u.kg.cu.l):o.fm===u.fm?(u.type=='child'||o.type=='child'?LF.concat(LC):LF):LN,v={a:u,b:o,n:0,t:.2,l:[0,1,2,3].map(()=>P[Math.floor(Math.random()*P.length)])};u.cv=o.cv=v;CV.push(v);return}}
  if(u.wt>0){u.wt-=dt;return}
  const tx=u.tx===undefined?u.x:u.tx,ty=u.ty===undefined?u.y:u.ty,dx=tx-u.x,dy=ty-u.y,d=Math.hypot(dx,dy);
  if(d<3){u.wt=1.5+Math.random()*3.5;u.tx=u.hx+(Math.random()-.5)*110;u.ty=u.hy+(Math.random()-.5)*60;return}
  const sp=Math.min(20*dt,d);u.x+=dx/d*sp;u.y+=dy/d*sp;u.ph+=dt*8;if(Math.abs(dx)>1)u.face=dx>0?1:-1})}
let BUBR=[],_hr=null,_hrT=0;
function hudR(){const n=performance.now();if(n-_hrT>400){_hrT=n;_hr=[];const k=VW/innerWidth;['hud','brow','bn','dp','tr','gt','mpb','tc'].forEach(i=>{const e=document.getElementById(i);if(!e||e.style.display=='none')return;const r=e.getBoundingClientRect();if(r.width>4&&r.height>4)_hr.push([r.left*k-2,r.top*k-2,r.right*k+2,r.bottom*k+2])});const m=document.getElementById('mm');if(m){const r=m.getBoundingClientRect();_hr.push([r.left*k,r.top*k,r.right*k,r.bottom*k])}}return _hr}
function bub(u,x,y){c.font='7px monospace';c.textAlign='center';const w=c.measureText(u.bub).width+8,bx=Math.max(w/2+2,Math.min(VW-w/2-2,x)),by=y-36;
 {const r=[bx-w/2-1,by-11,bx+w/2+1,by+4];if(BUBR.length>=3)return;if(BUBR.some(q=>r[0]<q[2]&&r[2]>q[0]&&r[1]<q[3]&&r[3]>q[1]))return;if(hudR().some(q=>r[0]<q[2]&&r[2]>q[0]&&r[1]<q[3]&&r[3]>q[1]))return;BUBR.push(r)}
 c.fillStyle='#000';c.fillRect(bx-w/2-1,by-11,w+2,13);c.fillStyle='#f3e9d2';c.fillRect(bx-w/2,by-10,w,11);c.fillRect(x-1,by+1,3,3);c.fillStyle='#2a1a05';c.fillText(u.bub,bx,by-2)}
// ===== CHARACTER ENGINE v2 : articulated humans, horses, beasts =====
// sprite cache: each pose is rendered once to a tiny offscreen canvas, then blitted
let Z=c,ZT=null;const Znow=()=>ZT===null?now():ZT,ZC=new Map(),ZW=64,ZH=64;
let CR=0,ZF=0,ZB=0,ZU=null;const ZCAP=2600;let ZBMAX=12;
function Zevict(){let n=0;const lim=ZF-90;for(const [q,v] of ZC){if(v._f<lim){ZC.delete(q);v.width=v.height=0;n++}}
 if(ZC.size>ZCAP*.85){let m=0;for(const [q,v] of ZC){ZC.delete(q);v.width=v.height=0;if(++m>=700)break}}}
function Zspr(key,fn,x,y,tq){let k=ZC.get(key),u=ZU;ZU=null;
 if(k){k._f=ZF}else{
  if(u&&ZB>=ZBMAX&&u._sp&&u._sp.width){k=u._sp}
  else{ZB++;k=document.createElement('canvas');k.width=ZW;k.height=ZH;const g=k.getContext('2d'),p=Z;Z=g;ZT=tq===undefined?null:tq/3;try{fn(ZW>>1,ZH-10)}finally{Z=p;ZT=null}if(ZC.size>ZCAP)Zevict();k._f=ZF;ZC.set(key,k)}}
 if(u)u._sp=k;
 const sm=c.imageSmoothingEnabled;c.imageSmoothingEnabled=false;c.drawImage(k,Math.round(x)-(ZW>>1),Math.round(y)-(ZH-10));c.imageSmoothingEnabled=sm}
const _Zc={};
function Zsh(col,k){if(!col||col[0]!='#')return col||'#888';const key=col+k;let r=_Zc[key];if(r)return r;let h=col.slice(1);if(h.length==3)h=h[0]+h[0]+h[1]+h[1]+h[2]+h[2];const n=parseInt(h,16);let R=n>>16&255,G=n>>8&255,B=n&255;if(k>1){const q=Math.min(1,k-1);R+=(255-R)*q;G+=(255-G)*q;B+=(255-B)*q}else{R*=k;G*=k;B*=k}return _Zc[key]='#'+(((1<<24)|((R|0)<<16)|((G|0)<<8)|(B|0)).toString(16).slice(1))}
function Zpen(X,Y,f,fl){X=Math.round(X);Y=Math.round(Y);const C=q=>fl?Zsh(q,1.9):q;
 return{R(col,ax,ay,w,h){w=Math.max(1,Math.round(w));h=Math.max(1,Math.round(h));Z.fillStyle=C(col);Z.fillRect(f>0?X+Math.round(ax):X-Math.round(ax)-w,Y+Math.round(ay),w,h)},
 L(col,ax,ay,bx,by,w){w=Math.max(1,Math.round(w||1));const n=Math.max(1,Math.ceil(Math.max(Math.abs(bx-ax),Math.abs(by-ay)))),o=w>>1;Z.fillStyle=C(col);for(let i=0;i<=n;i++){const px=Math.round(ax+(bx-ax)*i/n),py=Math.round(ay+(by-ay)*i/n);Z.fillRect(f>0?X+px-o:X-px+o-w,Y+py-o,w,w)}}}}
function Zkf(p,K){for(let i=1;i<K.length;i++){if(p<=K[i][0]){const q=(p-K[i-1][0])/((K[i][0]-K[i-1][0])||1),e=q*q*(3-2*q);return K[i-1].slice(1).map((v,j)=>v+(K[i][j+1]-v)*e)}}return K[K.length-1].slice(1)}
const ZSKIN=['#f0c9a0','#e3b48a','#c98f63','#9a6a44'],ZHAIR=['#2a1a0a','#5a3a1a','#a8742a','#d0b878','#8a8a8a','#7a2a1a'];
const ZKS={sword:[[0,-1.1,1.0,0,1],[.28,-2.5,-2.2,-.9,.9],[.6,.75,.3,2.3,1.1],[1,-1.1,1.0,0,1]],
 club:[[0,-.7,.9,0,1],[.4,-2.7,-2.4,-1.2,1],[.68,1.15,.5,3,1.1],[1,-.7,.9,0,1]],
 spear:[[0,-1.35,1.1,0,1],[.3,-.08,.5,-1.8,.8],[.55,-.04,0,2.8,1.35],[1,-1.35,1.1,0,1]],
 tool:[[0,-1.0,.9,0,1],[.5,-2.7,-2.5,-1,1],[.66,1.0,.6,2.4,1.05],[.78,.9,.6,2.2,1],[1,-1.0,.9,0,1]]};
const ZMS={pike:{a:'mail',h:'kettle',tab:1},sword:{a:'mail',h:'nasal',tab:1,sh:'kite'},bow:{a:'leath',h:'hood'},bandit:{a:'leath',h:'band',mask:1},guard:{a:'mail',h:'cone',tab:1,sh:'round'},archer:{a:'leath',h:'cap',fth:1},brute:{a:'fur',h:'none'},knight:{a:'plate',h:'great',tab:1,pl:1,sh:'kite'},cguard:{a:'plate',h:'cone',tab:1,sh:'kite'},builder:{a:'cloth',h:'cap',tool:'hammer',apr:'#7a5a3a'},farmer:{a:'cloth',h:'straw',tool:'hoe'},cutter:{a:'cloth',h:'band',tool:'axe',vest:'#5a6a3a'},miner:{a:'cloth',h:'mhelm',tool:'pick',vest:'#3a3a44'},villager:{a:'cloth',h:'hood2'},child:{a:'cloth',h:'hair'},cav:{a:'mail',h:'nasal',tab:1,sh:'kite'},crus:{a:'plate',h:'great',tab:1,cross:1,sh:'kite'},hcav:{a:'plate',h:'great',tab:1,cross:1,pl:1,sh:'kite'},saru:{a:'lamel',h:'kabuto'},xbow:{a:'leath',h:'cap',xb:1},legi:{a:'mail',h:'galea',tab:1,sh:'scutum'},jave:{a:'leath',h:'cap'},tarc:{a:'leath',h:'fur'},tlan:{a:'leath',h:'fur',sh:'round'},bguard:{a:'mail',h:'cone',tab:1},lord:{a:'plate',h:'crown',tab:1,pl:1,sh:'kite',cape:1}};
const ZHERO=[{a:'plate',h:'great',tab:1,cross:1,pl:1,sh:'kite',cape:1,hv:1},{a:'lamel',h:'kabuto',cape:0,sh:0,hv:1},{a:'plate',h:'galea',tab:1,sh:'scutum',cape:1,hv:1},{a:'leath',h:'fur',tab:0,sh:'round',cape:1,vest:'#6a3a1e',hv:1}],ZHW=['long','katana','gladius','sabre'];
function Zhs(){try{return HS[HI]}catch(e){return{c1:'#e8e8ee',c2:'#b01c1c'}}}
function Zhi(){try{return HI}catch(e){return 0}}
function Zman(o){
 const X=o.x,Y=o.y,f=o.f,sc=o.sc||1,t=o.t,sd=o.sd|0,mv=o.mv,ph=o.ph,fl=o.fl,col=o.col,acc=o.acc,st=o.st,up=o.up,P=Zpen(X,Y,f,fl),R=P.R,L=P.L,s=Math.sin(ph),atk=o.atk,wep=o.wep,tool=o.tool,wp=o.wp;
 const skin=ZSKIN[sd%4],skD=Zsh(skin,.8),hair=ZHAIR[(sd*5+1)%6],dress=o.dress;
 let wa=-1.1,aa=1.1,lean=mv?.8:0,ext=1,sw=0;
 if(wep=='spear')wa=-1.35;else if(wep=='club')wa=-.7;else if(wep=='sword')wa=-1.1;
 let kk=null;
 if(atk>=0&&wep&&wep!='bow'&&wep!='xb')kk=Zkf(atk,ZKS[wep]||ZKS.sword);else if(wp>=0&&tool)kk=Zkf(wp,ZKS.tool);
 if(kk){wa=kk[0];aa=kk[1];lean+=kk[2];ext=kk[3];sw=1}
 if(!kk&&mv){wa+=s*.07}
 if(o.fl)lean-=1.4;
 if(tool=='hoe'&&wp>=0)lean+=1.3;
 const hipH=o.ride?o.ride:7*sc,bob=o.ride?(o.hb||0):(mv?-Math.abs(s)*1.1:0),hy=Math.round(-hipH+bob),T=Math.round(6*sc),br=(!mv&&!o.ride&&Math.sin(t*2.4+sd)>.55)?1:0,sy=hy-T-br;
 const A=st.a,tun=col,tunD=Zsh(col,.72),tunL=Zsh(col,1.25);
 const steel='#aab2be',steelD='#6c7482',steelL='#e6ebf2',mail='#8d95a2',mailD='#68707d';
 const baseC=A=='mail'?mail:A=='plate'?steel:A=='leath'?'#6a4a2a':A=='fur'?skin:tun;
 const baseD=Zsh(baseC,.72);
 const legC=(A=='plate'||A=='mail')?'#5e6672':A=='lamel'?Zsh(col,.55):A=='leath'?'#3d2c1c':(o.legc||'#4a3b2c'),boot='#2a1c10';
 const aw=Math.max(2,Math.round(2*sc)),armL=5.6*sc;
 const upC=(A=='mail'||A=='plate')?(A=='plate'?steel:mail):A=='fur'?skin:A=='lamel'?tunD:tun;
 const foC=A=='plate'?steelL:A=='mail'?mailD:A=='leath'?'#5a3a1e':A=='lamel'?tunD:(st.sl?tun:skin);
 const cxT=(i)=>lean*(1-i/Math.max(1,T))+.5;
 const rowW=(i)=>Math.max(3,Math.round(sc*(5.2+(1-i/Math.max(1,T-1))*1.8)));
 // ---- shield-side helper
 const drawShield=()=>{const sh=st.sh;if(!sh)return;const hv=st.hv?1.5:1,fw=sc*hv,bx=lean+(st.hv?.5:2)*sc,by=sy+(st.hv?-.5:1)+(mv?Math.sin(ph*2)*.4:0),OL='#1c120a',h1=Math.max(1,Math.ceil(fw));
  if(sh=='kite'){const fld=st.cross?'#ecece4':acc,em=st.cross?'#b01c1c':Zsh(acc,1.6),W=[5,5,5,5,4,4,3,2,1];
   W.forEach((w,i)=>{const ww=Math.max(1,Math.round(w*fw)),yy=by+i*fw,xx=bx+(5*fw-ww)/2;R(OL,xx-1,yy,ww+2,h1);R(fld,xx,yy,ww,h1);R(Zsh(fld,.72),xx,yy,1,h1)});R(OL,bx+2*fw-1,by+W.length*fw,2,1);
   if(st.cross){R(em,bx+2*fw,by+.5*fw,Math.max(1,Math.round(fw*.9)),Math.round(7*fw));R(em,bx+.6*fw,by+2.4*fw,Math.round(4*fw),Math.max(1,Math.round(fw*.9)))}else{R(em,bx+fw,by+.5*fw,Math.round(3*fw),1);R(steelL,bx+2*fw,by+2.4*fw,2,2)}}
  else if(sh=='round'){const D=Math.round(6*fw);R(OL,bx-1,by,D+2,D+1);R('#5a3a1e',bx,by+.5,D,D);R(acc,bx+1,by+1.5,D-2,D-2);R(tun,bx+fw*1.2,by+2.5*fw,Math.round(2.4*fw),Math.round(2.4*fw));R('#e8ecf2',bx+D/2-1,by+D/2,2,2);R(Zsh(acc,1.5),bx+1,by+1.5,D-2,1)}
  else if(sh=='scutum'){const W5=Math.round(5.5*fw),H8=Math.round(8.5*fw);R(OL,bx-1,by-1,W5+2,H8+2);R('#7a1a14',bx,by,W5,H8);R(tun,bx+1,by+1,W5-2,H8-2);R(acc,bx+1,by+1,W5-2,1);R(acc,bx+1,by+H8-2,W5-2,1);R(acc,bx+W5/2-.5,by+2,1,Math.round(H8*.55));R('#f0d870',bx+W5/2-1.5,by+H8/2-1.5,3,3);R('#fff2a0',bx+W5/2-.5,by+H8/2-.5,1,1)}};
 // ---- cape (behind)
 if(st.cape&&!up){const cl=Math.round(10*sc);for(let j=0;j<cl;j++){const k=j/cl,wv=mv||o.ride&&o.mv?(2+Math.sin(t*10-j*.7)*1.3+k*3):Math.sin(t*1.6-j*.5)*.5*k;R(j%3==2?Zsh(o.cape||acc,.8):(o.cape||acc),lean*(1-j/(cl+2))-2.5-k*1.5-wv,sy+1+j,3.2,1)}}
 if(up&&st.sh)drawShield();
 // ---- far arm
 const fsx=lean-1.8*sc,fsy=sy+1;
 const arm=(sx,sy2,ang,len,upc,foc,bend)=>{bend=bend||.9;const hx=sx+Math.cos(ang)*len,hy2=sy2+Math.sin(ang)*len,mx=(sx+hx)/2-Math.sin(ang)*bend,my=(sy2+hy2)/2+Math.cos(ang)*bend;L(upc,sx,sy2,mx,my,aw);L(foc,mx,my,hx,hy2,aw);R(skin,hx-1,hy2-1,Math.max(2,aw),Math.max(2,aw));return[hx,hy2]};
 let farAng=1.57-(mv?s*.62:0);if(o.talk)farAng=-.5+Math.sin(t*7+sd)*.45;
 const bowing=wep=='bow'&&!st.xb;
 if(!st.sh&&!bowing&&!st.xb)arm(fsx,fsy,farAng,armL,Zsh(upC,.8),Zsh(foC,.8),.9);
 else if(st.sh&&!up){/*shield arm hidden behind shield*/}
 // ---- legs
 const leg=(i)=>{if(o.ride){const kx=3.2*sc+(i?-.4:0),ky=hy+3.3*sc,fx=2.6*sc+(i?-.3:0),fy=hy+7.4*sc;if(i)return;L(legC,0,hy,kx,ky,aw);L(Zsh(legC,.9),kx,ky,fx,fy,aw);R(boot,fx-1,fy,3,2);R('#8a8f98',fx-1.5,fy+1.5,4,1);return}
  const p=ph+i*Math.PI,swn=mv?Math.sin(p)*3.3*sc:(i?-1.3:1.3)*sc,lf=mv?Math.max(0,Math.cos(p))*2.3*sc:0;let fx=swn,fy=-lf;if(sw||wp>=0){fx=(i?-2.2:2.4)*sc;fy=0}
  const hx0=i?-.6:.6,kx=(hx0+fx)/2+(1+(mv?.6:0))*sc,ky=(hy+fy)/2,lc=i?Zsh(legC,.82):legC;
  if(dress){R(Zsh(skin,.9),fx-.5,fy-3,2,3);R(boot,fx-.5,fy-1.4,3,2);return}
  L(lc,hx0,hy,kx,ky,aw);L(i?Zsh(lc,.92):lc,kx,ky,fx,fy-1.5,aw);if(A=='plate')R(steelL,kx-.5,ky-.5,2,1);R(boot,fx-1,fy-2,Math.round(3.4*sc),2);R(Zsh(boot,1.6),fx-1,fy-2,1,1)};
 leg(1);
 // ---- torso
 for(let i=0;i<T;i++){const w=rowW(i),cx=cxT(i),lx=cx-w/2;R(baseC,lx,sy+i,w,1);R(baseD,lx,sy+i,Math.max(1,Math.round(w*.28)),1);
  if(A=='mail'||A=='lamel'){if(A=='mail')for(let k=((i&1)?0:1);k<w;k+=2)R(Zsh(mail,1.22),lx+k,sy+i,1,1)}
  if(A=='plate'){R(steelL,lx+Math.round(w*.62),sy+i,1,1);R(steelD,lx,sy+i,1,1)}
  if(A=='leath'){R(tun,lx,sy+i,w,i<2?2:0.001);if(i==1)R('#c8a870',cx,sy+i,1,1)}
  if(A=='lamel'){if(i%2==0)R(tunD,lx,sy+i,w,1);else R(acc,lx+1,sy+i,1,1)}}
 if(A=='fur'){R('#5a3a1e',lean-3.2*sc,sy,6.8*sc,2);R('#7a5a3a',lean-3.2*sc,sy,6.8*sc,1);for(let k=0;k<4;k++)R('#3a2410',lean-2.5*sc+k*1.6*sc,sy+2,1,1)}
 const hw0=rowW(Math.max(0,T-1)),ccx=cxT(T-1);
 if(st.tab){const sk=Math.round(3*sc);for(let i=1;i<T;i++){const w=rowW(i)-2,cx=cxT(i);R(tun,cx-w/2+.5,sy+i,w,1);R(tunD,cx-w/2+.5,sy+i,1,1)}
  for(let j=0;j<sk;j++){const sx2=mv?Math.sin(ph+j)*.7:0,w=hw0+1;R(j==sk-1?acc:(j&1?tunD:tun),ccx-w/2+.5+sx2,hy+j,w-1,1)}
  if(!up){if(st.cross){R(acc,ccx+.5,sy+1,1,Math.max(3,T-2));R(acc,ccx-1,sy+2,3,1)}else{R(acc,ccx+.5,sy+1,1,T-1);R(Zsh(acc,1.3),ccx+.5,sy+1,1,1)}}}
 if(st.apr){for(let i=2;i<T+3;i++){const cx=cxT(Math.min(i,T-1));R(st.apr,cx-1,sy+i,Math.round(3.8*sc),1)}R(Zsh(st.apr,.7),lean+1,hy+2,1,2)}
 if(st.vest){for(let i=0;i<T-1;i++){const cx=cxT(i),w=rowW(i)-1;R(st.vest,cx-w/2+.5,sy+i,w,1);if(i>0)R(Zsh(st.vest,1.3),cx+.5,sy+i,1,1)}}
 if(A=='cloth'&&!st.vest&&!st.apr){R(tunL,cxT(0)-1.5,sy,3,1);if(dress||sd%3==0)R(Zsh(acc||tun,1.1),cxT(Math.round(T/2))-2,hy-3,5,1)}
 if(dress){const dl=Math.round(5*sc);for(let j=0;j<dl;j++){const w=hw0+1+Math.round(j*.55),sx2=mv?Math.sin(ph+j*.3)*(.6+j*.15):0;R(j==dl-1?Zsh(tun,1.3):(j&1?tun:tunD),ccx-w/2+sx2,hy+j,w,1)}}
 // belt
 if(!dress||true){const w=hw0;R('#2a1a0c',ccx-w/2,hy-1,w,1);if(!up)R('#e8c050',ccx+w/2-2,hy-1,1,1)}
 if(A=='fur'){const lw=Math.round(5*sc);for(let j=0;j<3;j++)R(j&1?'#5a3a1e':'#7a5a3a',ccx-lw/2+(mv?Math.sin(ph+j)*.6:0),hy+j,lw,1)}
 if(A=='lamel'){for(let j=0;j<3;j++){const w=hw0+2;R(j&1?acc:tunD,ccx-w/2+(mv?Math.sin(ph+j)*.6:0),hy+j,w,1)}}
 if(A=='leath'||(A=='mail'&&!st.tab)){for(let j=0;j<2;j++){const w=hw0+1;R(j?tunD:tun,ccx-w/2+(mv?Math.sin(ph+j)*.5:0),hy+j,w,1)}}
 // ---- near leg
 leg(0);
 // ---- pauldrons / sode
 const nsx=lean+1.7*sc;
 if(A=='plate'){R(steelL,nsx-1.5,sy-.5,3.4*sc,2);R(steel,nsx-1.5,sy+1.3,3.4*sc,1);R(steelL,lean-2.8*sc-.5,sy-.5,3*sc,2)}
 if(A=='lamel'){R(tunD,lean-3.6*sc,sy-.5,3.4*sc,3);R(acc,lean-3.6*sc,sy+2,3.4*sc,1);R(tun,nsx-1,sy-.5,3.8*sc,3);R(acc,nsx-1,sy+2,3.8*sc,1)}
 if(A=='mail')R(Zsh(mail,1.2),nsx-1,sy-.5,3*sc,1);
 // ---- head
 const hs=o.hs||1,hw=Math.round(5*sc*hs),hh=Math.round(5*sc*hs),hl=Math.round(lean+(1-hw/2)+.3*sc),ht=sy-hh+1;
 R(skD,hl+hw/2-1,sy-1,2,2);
 R(skin,hl,ht,hw,hh);R(skD,hl,ht,1,hh);R(Zsh(skin,1.1),hl+hw-2,ht+hh-3,1,1);
 if(!up){const ex=hl+hw-2;if((st.hv||st.h=='crown')&&st.h!='great'){const bw=Zsh(hair,.8);R(bw,ex-1,ht+Math.round(hh*.3),3,1);R('#f4efe0',ex-1,ht+Math.round(hh*.45),1,1);R(Zsh(skin,.75),hl+hw,ht+Math.round(hh*.7),1,1);R(Zsh(skin,.55),hl+hw-2,ht+hh-1,2,1);if(sd%2==0)R(hair,hl+1,ht+hh-1,hw,2);if(sd%3==0)R('#a85a50',hl+2,ht+1,1,3);R(acc||'#d8b040',hl+1,ht-2,hw-2,1)}if(!(st.h=='great'))R('#1a1008',ex,ht+Math.round(hh*.45),1,1);R(Zsh(skin,.95),hl+hw,ht+Math.round(hh*.55),1,1);if(sd%7==0)R(hair,hl+hw-3,ht+hh-2,3,2);if(sd%9==1&&st.h!='great'&&!st.mask)R(hair,hl+1,ht+hh-1,hw-1,1)}
 else R(hair,hl,ht,hw,hh);
 if(st.h!='kabuto'&&st.h!='great'&&st.h!='galea'&&st.h!='none')R(hair,hl-.5,ht,2,hh-1);
 if(dress&&!st.xx){R(hair,hl-1,ht-1,hw,2);R(hair,hl-1.5,ht+1,2,hh+2)}
 const H=st.h,hx=hl,hz=ht;
 if(H=='kettle'){R(steelD,hx-1.5,hz+.5,hw+3.5,1);R(steel,hx-.5,hz-1.5,hw+1,2.5);R(steelL,hx+.5,hz-1.5,2,1)}
 else if(H=='nasal'){R(steel,hx-.5,hz-1.5,hw+1,3);R(steelL,hx+.5,hz-1.5,2,1);R(steelD,hx-1,hz+1,1.5,3);if(!up)R(steel,hx+hw-1,hz+1.5,1,3)}
 else if(H=='cone'){R(steel,hx-.5,hz-.5,hw+1,2);R(steel,hx+.5,hz-1.5,hw-1,1);R(steelL,hx+1.5,hz-2.5,1.5,1);R(mailD,hx-1.5,hz+1.5,2,3.5);if(!up)R(steel,hx+hw-1,hz+1.5,1,2.5)}
 else if(H=='great'){R(steel,hx-.5,hz-1.5,hw+1,hh+1.5);R(steelD,hx-.5,hz-1.5,1,hh+1.5);R(steelL,hx+hw-1.5,hz-1.5,1,hh);R(steelL,hx+.5,hz-1.5,hw-2,1);if(!up){R('#14141c',hx+hw-3,hz+1.6,3,1);R('#3a4048',hx+hw-2,hz+2.6,1,2)}if(st.pl){const w=Math.round(3*sc);for(let j=0;j<w+2;j++)R(j%2?Zsh(acc,.8):acc,hx-1-j-(mv?Math.sin(t*9-j)*.8:0),hz-3+Math.min(j,2)*.5+(mv?Math.sin(t*9-j)*.6:0),1.5,2)}}
 else if(H=='hood'){R('#3f6a3a',hx-1,hz-1,hw+1.5,hh-1.5);R('#2f5a2a',hx-2,hz+1,2.5,hh+1);R('#4f7a48',hx,hz-1,hw-1,1)}
 else if(H=='band'){R(acc,hx-.5,hz,hw+1,1.5);R(acc,hx-2.5,hz+.5,2.5,1);R(Zsh(acc,.7),hx-3,hz+1.5,1.5,1);if(st.mask&&!up)R('#2a1a1a',hx+1,hz+hh-2,hw,2)}
 else if(H=='cap'){R('#5a3a2a',hx-.5,hz-1,hw+1.5,2);R('#7a5238',hx,hz-1,hw-1,1);R('#3a2418',hx+hw,hz+.5,2,1);if(st.fth)R('#3a9a4a',hx-1.5,hz-3,1,3.5),R('#7ada8a',hx-1.5,hz-3,1,1)}
 else if(H=='straw'){R('#e0c060',hx-3,hz+.2,hw+6,1);R('#c8a840',hx-.5,hz-1.5,hw+1.5,2);R('#8a4a2a',hx-.5,hz-.2,hw+1.5,1);R('#f0d880',hx+1,hz-1.5,2,1)}
 else if(H=='mhelm'){R('#b8962e',hx-.5,hz-1.5,hw+1.5,2.5);R('#e8c850',hx,hz-1.5,hw-1,1);const fl2=Math.sin(t*14+sd)>-.2;R(fl2?'#ffd070':'#ff9a30',hx+hw,hz-1,2,2)}
 else if(H=='hood2'){const hc=Zsh(tun,sd%2?1.3:.9);R(hc,hx-.5,hz-1,hw+1,2);R(Zsh(hc,.8),hx-1.5,hz+1,2,hh);if(sd%2)R(Zsh(hc,1.2),hx,hz-1.5,hw-1,1)}
 else if(H=='hair'){R(hair,hx-.5,hz-1,hw+1,2.5);R(hair,hx-1,hz,1.5,hh-1);R(Zsh(hair,1.4),hx+1,hz-1,2,1)}
 else if(H=='kabuto'){R('#1e1e28',hx-1,hz-1.5,hw+2,2.5);R('#2c2c3a',hx,hz-1.5,hw-1,1);R('#1e1e28',hx-2.5,hz+1,2.5,4);R('#3a3a4a',hx-2.5,hz+2,2.5,1);R('#e8b94a',hx+.5,hz-4,1,2.5);R('#e8b94a',hx+hw-1.5,hz-4,1,2.5);R('#e8b94a',hx+1.5,hz-2.5,hw-3,1);if(!up)R(acc,hx+hw-2,hz+hh-2,2,2)}
 else if(H=='galea'){R(steel,hx-.5,hz-1.5,hw+1,2.5);R(steelL,hx+.5,hz-1.5,2,1);R(steel,hx+hw-1,hz+1.5,1,2.5);R(steelD,hx-1.5,hz+.5,1.5,3);R(acc,hx+.5,hz-4,hw-1,2);R(Zsh(acc,.75),hx-.5,hz-3,hw+1,1);R(Zsh(acc,1.3),hx+1,hz-4,2,1)}
 else if(H=='fur'){R('#7a5a3a',hx-1.5,hz-1.5,hw+3,3);R('#a07a50',hx-.5,hz-2,hw+1,1);R('#5a3a1e',hx-1.5,hz+1.5,1.5,3.5);R('#5a3a1e',hx+hw,hz+1.5,1.5,3);R(acc,hx+1,hz-3,2,1.5)}
 else if(H=='crown'){R(steel,hx-.5,hz-.5,hw+1,2.5);R(steelD,hx-.5,hz-.5,1,2.5);R('#ffd44a',hx-.5,hz-2,hw+1.5,1.5);for(let k=0;k<3;k++)R('#ffe680',hx+k*2-.5,hz-3.5,1,1.5);R('#e83a3a',hx+2,hz-2,1,1);if(!up)R(steel,hx+hw-1,hz+1.5,1,3)}
 else if(H=='none'){R(skin,hx,hz-.5,hw,1);R(hair,hx+hw-3,hz+hh-2.5,3.5,3);R(Zsh(hair,.8),hx+hw-4,hz+hh-1.5,2,2);R('#c8c0a0',hx+hw-.5,hz+hh-.5,1.5,1.5)}
 // ---- shield (front) drawn after head so it overlaps chest
 if(!up)drawShield();
 // ---- near arm + weapon
 const nax=lean+1.4*sc,nay=sy+1;
 const hand=(ang,len)=>arm(nax,nay,ang,len,upC,foC,.9);
 if(bowing||st.xb){
  let pull=0,rel=0,aimA=-.05;if(atk>=0){pull=atk<.62?(atk/.62):0;rel=atk>=.62?1-(atk-.62)/.38:0}
  if(st.xb){const hx2=lean+2.4*sc-(rel*1.6),hy2=sy+3.3;arm(fsx,fsy,Math.atan2(hy2+.5-fsy,hx2+3.4-fsx),armL*1.0,Zsh(upC,.85),Zsh(foC,.85),.5);
   L('#6a4a2a',hx2-3,hy2,hx2+6,hy2,2);R('#8a6a3a',hx2-3.5,hy2-1,3,2);const lim=rel>0?-1:0;L('#3a3a44',hx2+4,hy2-4,hx2+5+lim,hy2,1);L('#3a3a44',hx2+5+lim,hy2,hx2+4,hy2+4,1);L('#e0d8b0',hx2+4,hy2-4,hx2+(rel>0?4:1),hy2,1);L('#e0d8b0',hx2+(rel>0?4:1),hy2,hx2+4,hy2+4,1);if(pull>.01||atk<0){R('#cfd4dc',hx2+1,hy2-1.5,5,1);R('#e6ebf2',hx2+6,hy2-1.5,1,1)}
   arm(nax,nay,Math.atan2(hy2+.5-nay,hx2-nax),armL*.9,upC,foC,.5)}
  else{const bx=lean+(atk>=0?5.6:3.4)*sc,by=sy+(atk>=0?2.4:5.4);const ar=hand(Math.atan2(by-nay,bx-nax),armL);
   const bx2=ar[0],by2=ar[1],big=6.2*sc;L('#b08840',bx2+.5,by2-big,bx2+2.6,by2-big*.5,1);L('#b08840',bx2+2.6,by2-big*.5,bx2+3,by2,1);L('#b08840',bx2+3,by2,bx2+2.6,by2+big*.5,1);L('#b08840',bx2+2.6,by2+big*.5,bx2+.5,by2+big,1);L('#6a4a22',bx2+3,by2-1,bx2+3,by2+1,1);
   const px=atk>=0?bx2+.5-pull*4.2+(rel?Math.sin(t*60)*.6:0):bx2+.5;L('#e8e8e0',bx2+.5,by2-big,px,by2,1);L('#e8e8e0',px,by2,bx2+.5,by2+big,1);
   if(atk>=0){if(!rel){L('#e8e0c0',px,by2,bx2+8,by2,1);R('#d8dde6',bx2+8,by2-.5,2,1);R('#c04040',px,by2-.5,2,1)}arm(fsx,fsy,Math.atan2(by2-fsy,px-fsx),armL*1.1,Zsh(upC,.85),Zsh(foC,.85),.7)}}}
 else if(wep=='spear'||wep=='sword'||wep=='club'||tool){
  const e=ext,hnd=hand(aa,armL*(wep=='spear'?e:Math.min(1.1,e)));const hx2=hnd[0],hy2=hnd[1],ca=Math.cos(wa),sa=Math.sin(wa);
  if(wep=='spear'){const bk=7*sc,ln=17*sc,tx=hx2+ca*ln,ty=hy2+sa*ln;L('#8a6a3a',hx2-ca*bk,hy2-sa*bk,tx,ty,1);L('#5a4020',hx2-ca*bk,hy2-sa*bk+1,tx,ty+1,1);L('#eef2f8',tx,ty,tx+ca*3.5,ty+sa*3.5,2);R('#fff',tx+ca*3.5,ty+sa*3.5,1,1);
   for(let k=0;k<4;k++)R(k&1?acc:Zsh(acc,1.2),tx-ca*(1+k)-k*.2-1.2+(Math.sin(t*9+k)*.5),ty-sa*(1+k)+1.3+k*.5+(Math.sin(t*9+k)*.5),1.2,1.2)}
  else if(wep=='sword'){const jp=o.jp,wv=o.wv,ln=({long:12.8,katana:13.2,gladius:8.2,sabre:11.4}[wv]||(jp?11.5:10))*sc,tx=hx2+ca*ln,ty=hy2+sa*ln,bl=o.bl||(o.gold?'#ffe27a':(wv=='katana'?'#e8edf4':(jp?'#d8dde6':'#c9d0da'))),px2=-sa,py2=ca;
   if(atk>=0&&atk>.24&&atk<.78){const pa=wa-1.0,pa2=wa-.55;for(const[q,al]of[[pa,.16],[pa2,.3]]){Z.globalAlpha=al;L('#fff',hx2+Math.cos(q)*ln*.45,hy2+Math.sin(q)*ln*.45,hx2+Math.cos(q)*ln,hy2+Math.sin(q)*ln,1);Z.globalAlpha=1}}
   const gx=hx2+ca*1.6,gy=hy2+sa*1.6;
   if(wv=='katana'){const mx=hx2+ca*ln*.55+px2*.8,my=hy2+sa*ln*.55+py2*.8,ex=tx+px2*1.8,ey=ty+py2*1.8;L('#3a2a22',hx2-ca*3.5,hy2-sa*3.5,hx2+ca*1.2,hy2+sa*1.2,1);L(bl,hx2+ca*1.2,hy2+sa*1.2,mx,my,1);L(bl,mx,my,ex,ey,1);L('#fff',mx,my-1,ex,ey-1,1);L('#d8a838',gx+sa*1.8,gy-ca*1.8,gx-sa*1.8,gy+ca*1.8,1);R('#c0392b',hx2-ca*3-.5,hy2-sa*3-.5,1.5,1.5)}
   else if(wv=='gladius'){L('#7a828e',hx2,hy2,tx,ty,2);L(bl,hx2+ca,hy2+sa,tx,ty,1);L('#f4f7fb',hx2+ca*2,hy2+sa*2-1,tx-ca,ty-1-sa,1);L('#b8903a',gx+sa*2.2,gy-ca*2.2,gx-sa*2.2,gy+ca*2.2,1);R('#8a1a14',hx2-ca*2-.5,hy2-sa*2-.5,2,2)}
   else if(wv=='sabre'){const mx=hx2+ca*ln*.55-px2*.6,my=hy2+sa*ln*.55-py2*.6,ex=tx-px2*1.6,ey=ty-py2*1.6;L(bl,hx2,hy2,mx,my,1);L(bl,mx,my,ex,ey,1);L('#fff',mx,my-1,ex,ey-1,1);L('#d4a038',gx+sa*2.4,gy-ca*2.4,gx-sa*2.4,gy+ca*2.4,1);R('#d4a038',hx2-ca*2-.5,hy2-sa*2-.5,1.5,1.5);R('#7a2a6a',hx2-ca*1.5,hy2-sa*1.5,1,1)}
   else if(wv=='long'){L(bl,hx2,hy2,tx,ty,1);L('#f4f7fb',hx2+ca*1.5,hy2+sa*1.5-1,tx,ty-1,1);L('#7a828e',hx2,hy2+1,tx-ca*2,ty+1-sa*2,1);L('#e8b94a',gx+sa*3.4,gy-ca*3.4,gx-sa*3.4,gy+ca*3.4,1);R('#e8b94a',hx2-ca*2.4-.5,hy2-sa*2.4-.5,2,2)}
   else{L(bl,hx2,hy2,tx,ty,1);L('#f4f7fb',hx2+ca*1.5,hy2+sa*1.5-1,tx,ty-1,1);L('#7a828e',hx2,hy2+1,tx-ca*2,ty+1-sa*2,1);L(jp?'#1a1a22':'#e8b94a',gx+sa*2.4,gy-ca*2.4,gx-sa*2.4,gy+ca*2.4,1);R('#e8b94a',hx2-ca*2-.5,hy2-sa*2-.5,1.5,1.5)}}
  else if(wep=='club'){const ln=11*sc,tx=hx2+ca*ln,ty=hy2+sa*ln;L('#6a4a2a',hx2-ca*2,hy2-sa*2,tx,ty,Math.round(2*sc));L('#4a3018',tx-ca*3,ty-sa*3,tx+ca*2,ty+sa*2,Math.round(4.2*sc));R('#c8ccd4',tx+ca*1-1,ty+sa*1-3,1,1);R('#c8ccd4',tx+ca*1+1,ty+sa*1+2,1,1);R('#c8ccd4',tx-ca*2-1,ty-sa*2-2,1,1)}
  else if(tool){const ln=(tool=='hoe'?10:8)*sc,tx=hx2+ca*ln,ty=hy2+sa*ln,px=-sa,py=ca;L('#8a6a3a',hx2-ca*2,hy2-sa*2,tx,ty,1);
   if(tool=='hammer'){L('#8c939e',tx-px*2.3,ty-py*2.3,tx+px*2.3,ty+py*2.3,2);R('#c8ccd4',tx-1,ty-1,1,1)}
   else if(tool=='axe'){L('#6a4a22',tx,ty,tx+ca*.5,ty+sa*.5,2);L('#8c939e',tx+px*.5,ty+py*.5,tx+px*3.8,ty+py*3.8,2);L('#e6ebf2',tx+px*3.8,ty+py*3.8,tx+px*4.2+ca*1.4,ty+py*4.2+sa*1.4,1)}
   else if(tool=='pick'){L('#8c939e',tx-px*4.2+ca*1.4,ty-py*4.2+sa*1.4,tx+px*4.2+ca*1.4,ty+py*4.2+sa*1.4,2);L('#e6ebf2',tx-px*4.2+ca*1.4,ty-py*4.2+sa*1.4,tx-px*4.6+ca*2.4,ty-py*4.6+sa*2.4,1)}
   else{L('#8c939e',tx,ty,tx+ca*2.2+px*2.4,ty+sa*2.2+py*2.4,2)}
   if(wp>.66&&wp<.9){const q=(wp-.66)/.24,cc=tool=='axe'?['#c8985a','#e0b878']:tool=='hoe'?['#6a4a2a','#8a6a40']:['#ffe27a','#fff2b0'];for(let k=0;k<4;k++){R(cc[k&1],7+q*(3+k*1.5)-1,-3-Math.sin(q*3.1)*(2+k)+q*3,1,1)}}}
 }else{
  // unarmed / civilians
  const ang=1.57+(mv?s*.62:0)+(o.talk?-1.9+Math.sin(t*6+sd)*.4:0);
  if(o.carry=='plank'){const hnd=hand(.3,armL*.9);L('#a07a48',hnd[0]-9,hnd[1]-3,hnd[0]+5,hnd[1]-5,2);L('#7a5a30',hnd[0]-9,hnd[1]-2,hnd[0]+5,hnd[1]-4,1)}
  else hand(ang,armL)}
 return{hy,sy}}
function Zhorse(X,Y,f,ph,sad,mv,coat,capc){const t=Znow();X=Math.round(X);Y=Math.round(Y);coat=coat||'#6a4326';const P=Zpen(X,Y,f,0),R=P.R,L=P.L,dk=Zsh(coat,.62),lt=Zsh(coat,1.28),g=mv?ph:0,
 bob=mv?-Math.round(Math.abs(Math.sin(g))*1.4):0,by=-13+bob,idle=!mv;
 R('rgba(0,0,0,.28)',-9,-1,18,3);
 const lg=(hx,k,front,far)=>{const p=g+k,sw=mv?Math.sin(p)*4:(front?(k?.8:-.8):(k?-.6:.6)),lf=mv?Math.max(0,Math.cos(p))*3.2:0,fx=hx+sw,fy=-lf,kx=(hx+fx)/2+(front?1.2:-1.2),ky=(by+7+fy)/2,c1=far?dk:coat;L(c1,hx,by+6,kx,ky+1,2);L(c1,kx,ky+1,fx,fy-1.5,2);R('#1c1208',fx-1,fy-2,3,2);if(!far)R(lt,hx-1,by+5,2,1)};
 lg(-6,.6,0,1);lg(5.5,Math.PI+.6,1,1);
 // body
 R(coat,-9,by,18,7);R(lt,-8,by,16,2);R(dk,-8,by+5,16,2);R(dk,-9,by+2,2,3);R(coat,5,by-1,4,8);
 // tail
 const tw=mv?Math.sin(t*12)*1.6:Math.sin(t*2)*.8;for(let j=0;j<6;j++)R(j&1?'#2a1a0e':'#3a2410',-10-j*.9-(mv?j*.4:0),by+1+j*.9+tw*(j/5)*(j&1?1:.6),2,1.6);
 // neck + head
 const hb=sad?Math.sin(t*1.5)*1.4:(idle?Math.sin(t*1.2)*.6:0);
 for(let j=0;j<7;j++)R(j<3?coat:lt,6+j*.9-(sad?-j*.2:0),by-1-j*(sad?.2:1.1)+(sad?j*.6:0),4,2);
 const hy=sad?by+4+hb:by-8+(mv?Math.sin(g*1)*.5:0)+hb,hx=sad?14:12.6;R(coat,hx-1,hy,5,4);R(lt,hx-1,hy,5,1);R(dk,hx+3,hy+2,2,3);R('#1a1008',hx+1.5,hy+1,1,1);R(coat,hx-1,hy-1.2,1.4,1.6);
 // mane
 for(let j=0;j<6;j++)R(j&1?'#2a1a0e':'#3a2410',5+j*.9-1.2,by-2-j*(sad?.2:1.1)+(sad?j*.6:0)-(mv?Math.sin(t*14+j)*.4:0),1.8,2.4);
 // blanket / caparison
 if(capc){R(capc,-4,by+.5,10,6);R(Zsh(capc,1.4),-4,by+.5,10,1);R(Zsh(capc,.7),-4,by+5.5,10,1);const wv=mv?Math.sin(t*10)*.6:0;R(Zsh(capc,.85),-4+wv,by+6.5,10,1)}
 if(sad){R('#a8324a',-3,by-.5,8,3);R('#7a2038',-3,by+2,8,1)}
 else{R('#4a2a14',-2,by-1.5,5,2);R('#2a1608',-2,by-2.5,1,1);R('#2a1608',2,by-2.5,1,1);R('#d8b050',5.5,by+3.5,1,1)}
 // near legs
 lg(-5,Math.PI,0,0);lg(6.5,0,1,0);
 // bridle
 R('#2a1608',hx+2.2,hy+.6,1,2);R('#e8c050',hx+3.2,hy+2,1,1)}
function Zwolf(X,Y,f,ph,mv,atk,col,fl){const t=Znow();const P=Zpen(X,Y,f,fl),R=P.R,L=P.L,dk=Zsh(col,.6),lt=Zsh(col,1.3),s=mv?Math.sin(ph*1.4):0,by=-8-(mv?Math.abs(Math.cos(ph*1.4))*1.2:0);
 R('rgba(0,0,0,.28)',-8,-1,16,3);
 const lg=(hx,k,far)=>{const p=ph*1.4+k,sw=mv?Math.sin(p)*3.4:(k?1:-1),lf=mv?Math.max(0,Math.cos(p))*2.6:0,fx=hx+sw,fy=-lf;L(far?dk:col,hx,by+4,fx,fy-1,2);R('#1a1410',fx-1,fy-1.5,3,1.5)};
 lg(-5,.5,1);lg(5,Math.PI+.5,1);
 R(col,-8,by,14,5);R(lt,-7,by,12,1.5);R(dk,-7,by+4,12,1);
 for(let j=0;j<5;j++)R(j&1?dk:col,-10-j*.8,by-1+j*.7+(mv?Math.sin(t*10+j):Math.sin(t*3+j)*.5),2,1.5);
 const jaw=atk>=0?1:0;
 R(col,5,by-2,6,5);R(lt,5,by-2,6,1);R(col,9,by-.5,4,2.5);R(dk,9,by+1.5+jaw*1.5,4,1);R(dk,5,by-3.5,1.5,2);R(dk,8,by-3.5,1.5,2);R('#e22',9,by-.8,1,1);if(jaw){R('#fff',10,by+1,1,1.4);R('#fff',12,by+1,1,1.4)}
 R(col,-9,by-1.5,2,2);
 lg(-4,Math.PI,0);lg(6,0,0)}
function Zdead(X,Y,f,col,acc,sd,alpha){const P=Zpen(X,Y,f,0),R=P.R;Z.globalAlpha=alpha;R('rgba(0,0,0,.35)',-8,-1,16,3);R('#7a1010',-3,-3,7,3);R('#a8142a',-1,-2,5,2);
 R('#2a1c10',-8,-3,4,2);R(col,-4,-5,8,4);R(Zsh(col,.7),-4,-2,8,1);R(ZSKIN[sd&3],4,-5,4,4);R(ZHAIR[(sd*5+1)%6],4,-5,2,2);R('#9aa0aa',4,-6,3,2);R('#8a6a3a',-6,-8,1,6);R('#cfd4dc',-6,-9,1,1);R(acc||'#c8a050',0,-7,4,2);Z.globalAlpha=1}
function Zram(X,Y,f,ph,atk,fl,mv){const P=Zpen(X,Y,f,fl),R=P.R,L=P.L,sh=atk>0?-Math.sin((1-atk/.25)*Math.PI)*5:0,t=Znow();
 R('rgba(0,0,0,.3)',-14,-1,28,3);
 R('#3a2410',-12,-8,24,3);R('#5a3a1e',-11,-17,22,9);R('#7a5230',-11,-17,22,2);for(let i=0;i<6;i++)R(i&1?'#8a5e38':'#6a4426',-10+i*3.6,-14,3,5);R('#a8324a',-11,-17,22,2);R('#c85a6a',-11,-17,22,1);
 R('#5a3a1e',-12,-19,2,3);R('#5a3a1e',10,-19,2,3);
 for(let i=0;i<4;i++)R('#3a2410',-8+i*5,-8,1,3);L('#6a4a2a',-8+sh,-7,10+sh,-6,2);R('#4a3018',-9+sh,-8.5,19,3);R('#9aa0aa',9+sh,-10,4,6);R('#c8ccd4',10+sh,-9.5,2,1);R('#6a707a',12+sh,-8,2,3);
 const r=ph*.6;for(const wx of[-8,6]){R('#2a2030',wx,-4,6,5);R('#4a4058',wx+1,-4,4,1);R('#6a6078',wx+2+Math.round(Math.cos(r)),-2.5+Math.round(Math.sin(r)),1,1)}
 // crew feet under the roof
 for(const k of[0,1,2]){const px=-9+k*8,sw=mv?Math.sin(ph*1.3+k*2)*2:0;R('#3a2a1c',px+sw,-3,2,3);R('#1c1208',px+sw,-1,3,1)}
 }
function Ztreb(X,Y,f,atk,fl){const P=Zpen(X,Y,f,fl),R=P.R,L=P.L,p=atk>0?1-atk/.25:-1,t=Znow();
 R('rgba(0,0,0,.3)',-16,-1,32,4);
 for(const wx of[-14,8]){R('#3a2410',wx,-8,7,7);R('#5a3a1e',wx+1,-7,5,5);R('#2a1608',wx+3,-5,1,1)}
 R('#5a3a1e',-12,-11,24,3);R('#7a5230',-12,-11,24,1);
 L('#6a4a2a',-8,-11,-2,-31,3);L('#6a4a2a',8,-11,2,-31,3);L('#4a3018',-8,-11,2,-31,1);L('#4a3018',8,-11,-2,-31,1);R('#3a2410',-4,-33,8,3);
 const a=p<0?-.35+Math.sin(t*.8)*.04:(p<.4?-.35-p/.4*.9:-1.25+(p-.4)/.6*3.2),ax=Math.cos(a),ay=Math.sin(a);
 const px=0,py=-31;L('#8a6a3a',px-ax*-8,py-ay*-8-0,px+ax*20*-1,py+ay*20*-1,2);
 L('#8a6a3a',px+ax*18,py+ay*18,px-ax*8,py-ay*8,2);R('#3a3a44',px-ax*8-2.5,py-ay*8-2,5,6);R('#6a6a78',px-ax*8-2,py-ay*8-1.5,4,2);
 R('#a8324a',px+ax*18-1,py+ay*18-1,3,3);if(p>.4&&p<.7)R('#6a4a2a',px+ax*18+4,py+ay*18-6,3,3);
 for(let k=0;k<2;k++)R('#8a5a3a',-4+k*6,-12-(Math.abs(Math.sin(t*3+k))>.8?1:0),2,2)}
function drawHorse(x,y,f,ph,sad,mv,coat,capc){Zhorse(x,y,f,ph,sad,mv===undefined?ph!==0:mv,coat,capc)}
const ZCOAT={hcav:'#8e8e98',lord:'#1c1814',tarc:'#8a5a2a',cav:'#6a4326'},ZVIL=['#8a5a6a','#5a7a8a','#8a7a4a','#6a8a5a','#7a5a8a','#a06a4a'];
function mnt(){if(won)return;if(H.m){H.m=0;HR.x=H.x;HR.y=H.y;HR.face=H.face;HR.on=1;toast('You dismount');sfx('loot')}else if(Math.hypot(HR.x-H.x,HR.y-H.y)<34){H.m=1;HR.on=0;toast('You mount your horse');sfx('recruit')}else toast('Your horse waits near the camp');$('mnt').textContent=H.m?'Dismount':'Mount'}
$('mnt').addEventListener('pointerdown',e=>{e.preventDefault();mnt()});addEventListener('keydown',e=>{if(e.key=='h')mnt()});
// ===== v2 systems =====
const CU=[{n:'Harvest Folk',f:'Harvest Moon Feast',col:'#e8a030',l:['The harvest was bountiful!','Sweet ale for all!','Our granaries overflow.']},{n:'Iron Clans',f:'Festival of Blades',col:'#d04040',l:['Glory in battle!','Sharpen your steel!','Our forges never sleep.']},{n:'Sun Merchants',f:'Golden Fair',col:'#f0d040',l:['Finest silks, best prices!','Coin is king.','The caravans return tomorrow.']},{n:'Star Mystics',f:'Night of Lanterns',col:'#8ab0ff',l:['The stars foretold your coming.','Mind the old rites.','Light a lantern for the dead.']},{n:'Forest Wardens',f:'Greenleaf Dance',col:'#60c060',l:['The oaks whisper tonight.','Never fell a sacred tree.','Dance with us at dusk!']}],stall=cl=>mk(18,14,r=>{r('#5a3a1e',1,6,2,8);r('#5a3a1e',15,6,2,8);r('#c8a060',2,9,14,3);for(let i=0;i<6;i++)r(i%2?'#fff':cl,1+i*3,3,3,4);r('#a03020',3,8,3,2);r('#e8b030',8,8,3,2)}),CAPS=[],KG=[],KW=[],KB=[],RD=[],BC={};let PB={c1:'#2a5aa8',c2:'#e8b94a',em:1},RP={p:[],i:0},nKW=0;
const KN=['Valdoria','Karthen','Ostmark','Brynhold','Zephyra','Ironvale','Mirrowyn','Drakmoor'],STN=[['#bda07c','#d8c29e','#8a6e50'],['#8a8a98','#a8a8b8','#5a5a6a'],['#a8806a','#c8a088','#7a5444'],['#9a9a7a','#bcbc9a','#6a6a52']];
function banner(g,x,y,b,w,h){if(b.em==4){nepal(g,x,y,w,h,b);return}g.fillStyle=b.c1;g.fillRect(x,y,w,h);g.fillStyle=b.c2;const m=(w/2)|0,q=(h/2)|0;
 if(b.em==0)g.fillRect(x,y+q-1,w,2);else if(b.em==1){g.fillRect(x+m-1,y,2,h);g.fillRect(x,y+q-1,w,2)}else if(b.em==2){g.fillRect(x+m-2,y+q-1,4,2);g.fillRect(x+m-1,y+q-2,2,4)}else for(let i=0;i<w;i++)g.fillRect(x+i,y+Math.min(h-2,Math.abs(i-m)*h/w|0),1,2)}
function bcv(b){const k=b.c1+b.c2+b.em;if(!BC[k]){const np=b.em==4,e=document.createElement('canvas');e.width=np?22:10;e.height=np?27:7;banner(e.getContext('2d'),0,0,b,e.width,e.height);BC[k]=e}return BC[k]}
function flag(x,yb,b,s){const np=b.em==4,h=Math.round(14*s),t=Znow(),w=Math.max(3,Math.round(9*s*.9*(np?.8:1))),hh=Math.max(3,Math.round(6*s*.9*(np?1.6:1))),e=bcv(b),W=e.width,Hh=e.height;Z.fillStyle='#4a3020';Z.fillRect(x,yb-h,1,h);for(let i=0;i<w;i++)c.drawImage(e,(i/w*W)|0,0,1,Hh,x+1+i,yb-h+Math.round(Math.sin(t*7+i*.8)*.8),1,hh)}
const kcas=k=>mk(48,40,r=>{const[M,L,D]=k.st,K='#1a1210',rf=k.c1,v=k.v,t=v==2?-4:0;
 r(M,8,18,32,22);r(L,8,18,32,2);r(D,8,38,32,2);for(let y=22;y<38;y+=4)r(D,9,y,30,1);for(let i=0;i<6;i++)r(L,9+i*5,16,3,2);
 r(M,17,7+t,14,12-t);r(L,17,7+t,2,12-t);r(D,29,7+t,2,12-t);if(v==1){for(let i=0;i<4;i++)r(L,17+i*4,4,3,3)}else for(let i=0;i<7;i++)r(rf,23-i,i+t,2+i*2,1);
 const tw=(x,top,h)=>{r(M,x-4,top+6,8,h);r(L,x-4,top+6,2,h);r(D,x+2,top+6,2,h);if(v==1){for(let i=0;i<3;i++)r(L,x-4+i*3,top+3,2,3)}else for(let i=0;i<6;i++)r(rf,x-1-i,top+i,2+i*2,1);r(K,x-1,top+12,2,3)};
 tw(6,6,28);tw(41,v==2?-2:0,v==2?36:34);r(K,20,28,8,12);r('#5a3a22',21,29,6,11);r(K,23,29,1,11);r(K,25,29,1,11)});
const kwall=k=>mk(14,16,r=>{r(k.st[2],0,3,14,13);r(k.st[0],1,4,12,11);r(k.st[1],1,4,12,2);for(let i=0;i<3;i++)r(k.st[0],i*5,0,4,4);r(k.st[2],1,10,12,1);r(k.c1,5,6,4,3)});
function mkRoad(fx,fy,tx,ty){const L=Math.hypot(tx-fx,ty-fy),n=Math.max(2,L/6|0),px=-(ty-fy)/L,py=(tx-fx)/L,ph=rnd()*6,s=new Set,o=[];for(let i=0;i<=n;i++){const w=Math.sin(i*.05+ph)*18*Math.sin(Math.PI*i/n),x=Math.round((fx+(tx-fx)*i/n+px*w)/8)*8,y=Math.round((fy+(ty-fy)*i/n+py*w)/8)*8,q=x+','+y;if(!s.has(q)){s.add(q);o.push([x,y])}}return{p:o,i:0}}
function kgMask(k){const nm=k.name;Object.defineProperty(k,'name',{get(){return(k.known||k.owned||window.NOFOG)?k._nm:'Unknown Kingdom '+(KG.indexOf(k)+1)},set(v){k._nm=v},enumerable:true,configurable:true});k._nm=nm}
function pvMask(P){let n=P.n,kn=P.kn;const ix=()=>(P.s|0)+1,ok=()=>P.known||window.NOFOG||P.tm===ME.tm;Object.defineProperty(P,'n',{get(){return ok()?n:'Unknown Lord '+ix()},set(v){if(!/^Unknown /.test(String(v)))n=v},enumerable:true,configurable:true});Object.defineProperty(P,'kn',{get(){return ok()?kn:'Unknown Realm '+ix()},set(v){if(!/^Unknown /.test(String(v)))kn=v},enumerable:true,configurable:true})}
function mkKG(x,y){for(let i=objs.length;i--;){const o=objs[i];if((o.k=='tree'||o.k=='rock'||o.k=='village'||o.k=='den')&&Math.hypot(o.x-x,o.y-y)<170)objs.splice(i,1)}
 const h=rnd()*360,k={name:KN.splice(Math.floor(rnd()*KN.length),1)[0],x,y,rel:0,owned:0,c1:`hsl(${h|0},60%,38%)`,c2:`hsl(${(h+150+rnd()*60)%360|0},70%,62%)`,em:Math.floor(rnd()*4),v:Math.floor(rnd()*3),st:STN[Math.floor(rnd()*4)],r:{wood:60,stone:40,gold:80,food:50},tt:4,wp:90+rnd()*60,inc:0,cool:0,n:0,cu:CU[Math.floor(rnd()*CU.length)],fe:0};
 const o=add('capital',kcas(k),x,y,96,80);o.hp=o.mhp=500+Math.floor(rnd()*300);o.kg=k;k.cast=o;CAPS.push(o);KG.push(k);kgMask(k);k.wt=kwall(k);
 const ang=Math.atan2(CX-(y-20),CX-x),N=62;k.gx=x+Math.cos(ang)*100;k.gy=y-20+Math.sin(ang)*72;
 for(let i=0;i<N;i++){const a=i/N*6.283;if(Math.abs(Math.atan2(Math.sin(a-ang),Math.cos(a-ang)))<.22)continue;const w={x:x+Math.cos(a)*100,y:y-20+Math.sin(a)*72,hp:60,mhp:60,kg:k};w.o={k:'wall',img:k.wt,x:w.x,y:w.y,w:14,h:16,dead:0,done:0};objs.push(w.o);KW.push(w)}
 
 [-48,0,48].forEach(d=>{const f=FN[Math.floor(rnd()*5)],g=[...GN].sort(()=>Math.random()-.5),fm={};['villager','villager','child'].forEach((ty,i)=>{const dd=UT[ty];CT.push({type:ty,x:x+d+i*6,y:y+16,hx:x+d,hy:y+14,hp:dd.hp,mhp:dd.hp,face:1,atk:0,hit:0,ph:0,wt:Math.random()*3,cd:Math.random()*6,bt:0,bub:'',cv:null,fm,kg:k,nm:g[i]+' '+f})})});
 ['pike','sword','bow','cguard','cav','bow'].forEach((t,i)=>{const a=i*1.05;mku(1,t,x+Math.cos(a)*55,y-10+Math.sin(a)*36,{kg:k})});
 [-.28,.28].forEach(d=>objs.push({k:'tower',img:TX.tower,x:x+Math.cos(ang+d)*100,y:y-20+Math.sin(ang+d)*72,w:16,h:36,dead:0,done:0,gt:1,kg:k}));k.bl={type:'builder',x:k.gx,y:k.gy,hit:0,atk:0,ph:0,face:1,t:0,kg:k};KB.push(k.bl)}

if(!MPI){const NK=3+Math.floor(rnd()*3);for(let n=0,t=0;n<NK&&t<500;t++){const x=300+rnd()*(WD-600),y=300+rnd()*(WD-600);if(Math.hypot(x-CX,y-CX)<1100||KG.some(q=>Math.hypot(q.x-x,q.y-y)<1000))continue;n++;mkKG(x,y)}
 KG.forEach(k=>{const o=KG.filter(q=>q!==k).sort((a,b)=>Math.hypot(a.x-k.x,a.y-k.y)-Math.hypot(b.x-k.x,b.y-k.y))[0];if(o)k.rp=mkRoad(k.gx,k.gy,o.gx,o.gy)});
 const k0=KG.slice().sort((a,b)=>Math.hypot(a.x-CX,a.y-CX)-Math.hypot(b.x-CX,b.y-CX))[0];RP=mkRoad(CX+485,CX,k0.gx,k0.gy)}
bld(K1);const PC=K1.o;PC.hp=PC.mhp=MPI?3000:900;
SLOTS.filter(q=>q.ring).forEach(bld);
mkw('builder',CX-20,CX+30);mkw('builder',CX+20,CX+30);mkw('farmer',CX-10,CX+36);
for(let i=0;i<4;i++)mku(0,'cguard',CX+i*6,CX+10);
function brk(w){w.built=0;w.cl=0;const i=WALLS.indexOf(w);if(i>=0)WALLS.splice(i,1);const j=objs.indexOf(w.o);if(j>=0)objs.splice(j,1);sfx('hit',w.x,w.y)}
function kbrk(w){const i=KW.indexOf(w);if(i>=0)KW.splice(i,1);const j=objs.indexOf(w.o);if(j>=0)objs.splice(j,1);sfx('hit',w.x,w.y)}
function callAllies(){KG.forEach(k=>{if(k.rel==1&&!k.owned){for(let i=0;i<3;i++){const a=rnd()*6.283,u=mku(0,['sword','bow','pike'][i],CX+Math.cos(a)*255,CX+Math.sin(a)*210);u.gd=1;u.hx=u.x;u.hy=u.y;u.kg=k;u.ttl=Znow()+150}toast(k.name+' sends reinforcements!')}})}
function kAI(dt){if(MPI){if(PC.hp>0)PC.hp=Math.min(PC.mhp,PC.hp+1.5*dt);for(const r in TS)TS[r]=Math.min(1,TS[r]+.01*dt);return}const t=Znow();if(!window.FALLEN)PC.hp=Math.min(PC.mhp,PC.hp+1.5*dt);for(const r in TS)TS[r]=Math.min(1,TS[r]+.01*dt);
 KG.forEach(k=>{k.n=0;if(!k.owned){for(const a in k.r)k.r[a]=Math.min(RESMAX,k.r[a]+dt*(a=='gold'?.7:.6))}
  if(k.fe>t&&k.rel>=0&&k.gf!==k.fe&&Math.hypot(H.x-k.x,H.y-k.y)<150){k.gf=k.fe;H.gold+=20;H.food+=10;toast('Festival gifts: '+k.cu.f+'!')}if(t>k.inc){k.inc=t+15;if(k.owned){H.gold+=12;H.wood+=8;H.stone+=6;H.food+=8}else if(k.rel==1){H.gold+=6;H.food+=4}}
  if(k.owned)return;k.tt-=dt;k.wp-=dt;const al=USK(k);k.n=al.length;
  if(k.tt<=0){k.tt=9+rnd()*8;const ty=['pike','sword','bow','cguard','cav'][Math.floor(rnd()*5)],d=UT[ty];if(al.length<50&&Object.entries(d.cost).every(([a,v])=>k.r[a]>=v)){for(const a in d.cost)k.r[a]-=d.cost[a];const a=rnd()*6.283;mku(1,ty,k.x+Math.cos(a)*50,k.y-10+Math.sin(a)*34,{kg:k})}}
  if(k.rel==-1&&k.wp<=0&&al.length>=8){k.wp=100+rnd()*60;al.filter(u=>!u.raid).slice(0,Math.ceil(al.length*.6)).forEach(u=>u.raid=1);toast(k.name+' marches on your castle!');sfx('horn');say(k.name+' marches upon us!')}
  const b=k.bl,p=k.rp,q=p&&p.p[p.i];if(q){const dx=q[0]-b.x,dy=q[1]+4-b.y,d=Math.hypot(dx,dy);if(d>3){b.x+=dx/d*30*dt;b.y+=dy/d*30*dt;b.ph+=dt*10;b.face=dx>0?1:-1}else{b.t+=dt;if(b.t>4){b.t=0;RD.push({x:q[0],y:q[1]});p.i++}}}});
 if(t>nFest){nFest=t+70+rnd()*60;const k=KG[Math.floor(rnd()*KG.length)];k.fe=t+40;feed(k.name+' holds the '+k.cu.f+'!');if(Math.hypot(H.x-k.x,H.y-k.y)<900)toast('Music drifts from '+k.name)}if(t>nKW){nKW=t+60+rnd()*60;const L2=KG.filter(k=>!k.owned);if(L2.length>1){const a=L2[Math.floor(rnd()*L2.length)];let b;do{b=L2[Math.floor(rnd()*L2.length)]}while(b===a);[[a,3],[b,4]].forEach(([k,n])=>US.filter(u=>u.kg===k&&!u.dead&&u.team).slice(0,n).forEach(u=>u.dead=t));b.cast.hp=Math.max(40,b.cast.hp-rnd()*40);feed(a.name+' raided '+b.name)}}}
// ===== UI: banner + diplomacy =====
function ovx(){const o=$('ov');o.style.display='none';o.innerHTML='';delete o.dataset.tg;if(typeof MER!='undefined')MER.sh=0;if($('pz').style.display!='flex')paused=0}
$('ov').addEventListener('pointerdown',e=>{if(e.target===$('ov')&&!won)ovx()});addEventListener('keydown',e=>{if(e.key=='Escape'&&$('ov').style.display=='flex'&&!won){e.stopImmediatePropagation();ovx()}},true);
function bpv(){const g=$('bpc').getContext('2d');g.clearRect(0,0,60,42);banner(g,0,0,PB,60,42)}
$('bn').addEventListener('pointerdown',e=>{e.preventDefault();bnUI()});
function dipUI(){if(window.xm&&xm.open)xm.open()}
function dip(i,a){const k=KG[i],t=Znow();
 if(a=='w'){if(k.rel<0){if(k.cast.hp<k.cast.mhp*.7||k.n<8||rnd()<.25){k.rel=0;toast(k.name+' accepts peace')}else toast(k.name+' refuses peace')}else{k.rel=-1;toast('War with '+k.name+'!')}}
 else{if(k.rel>0){k.rel=0;toast('Pact with '+k.name+' broken')}else if(t<k.cool)toast(k.name+' will not talk yet');else if(k.rel<0&&k.cast.hp>=k.cast.mhp*.6){toast(k.name+' spits on your offer');k.cool=t+40}else if(rnd()<.7){k.rel=1;toast(k.name+' is now your ally!');sfx('recruit')}else{toast(k.name+' declines');k.cool=t+40}}
 dipUI()}
$('tr').addEventListener('pointerdown',e=>{e.preventDefault();tradeUI()});$('kn').addEventListener('keydown',e=>e.stopPropagation());$('dp').addEventListener('pointerdown',e=>{e.preventDefault();dipUI()});

let paused=1,voiceOn=1,sq=0,lastSay=0,inGame=0;
let VC=null,VM=0;function pv(){const v=speechSynthesis.getVoices();if(!v.length)return;const en=v.filter(x=>/^en/i.test(x.lang));
 /* Old wise king: prefer deep male English voices, penalise anything female / robotic */
 const sc=x=>{const n=x.name+' '+x.lang+' '+(x.voiceURI||'');let q=0;
  if(/natural|neural|online|premium|enhanced|studio/i.test(n))q+=3;
  if(/google uk english male/i.test(n))q+=9;
  if(/\b(arthur|daniel|oliver|george|ryan|thomas|rjs|gbd|fred|alex|lee|rishi|aaron|gordon|bruce|ralph|junior)\b/i.test(n))q+=8;
  if(/\b(james|david|guy|brian|eric|mark|christopher|davis|roger|steffan|liam|male|man|iom|iol|tpd)\b/i.test(n))q+=6;
  if(/en[-_]GB/i.test(n))q+=3;if(/en[-_](AU|IE|ZA|IN)/i.test(n))q+=1;
  if(/female|woman|samantha|zira|susan|hazel|fiona|karen|victoria|moira|tessa|serena|kate|jenny|aria|libby|sonia|emma|amy|joanna|ivy|kendra|kimberly|salli|nicole|olivia|allison|ava|nora|catherine|google us english|google uk english female|gba|gbb|gbc|iob|iog|tpc|tpf|sfg|compact|espeak|novelty|whisper|bad|bells|boing|trinoids|zarvox|cellos|organ|wobble|jester|superstar|bubbles|albert/i.test(n))q-=12;
  return q};
 const s=en.slice().sort((a,b)=>sc(b)-sc(a));VC=s[0]||v[0];VM=VC?sc(VC):-99}
if(window.speechSynthesis){pv();speechSynthesis.onvoiceschanged=pv}
function say(t,f){if(!voiceOn||!window.speechSynthesis)return null;const n=Znow();if(!f&&n-lastSay<5)return null;lastSay=n;const u=new SpeechSynthesisUtterance(t);pv();if(VC){u.voice=VC;u.lang=VC.lang}else u.lang='en-GB';u.pitch=VM>=6?.8:.58;u.rate=.9;u.volume=1;speechSynthesis.cancel();const dl=Math.max(80,(window.__hornT||0)+700-performance.now());setTimeout(()=>{speechSynthesis.resume();speechSynthesis.speak(u)},dl);return u}
const ST=['Long ago the realm of Aldoria shattered, and its crown was lost in blood and fire.','Bandits stalk the roads. Wolves rule the forests. And in the northeast castle, the usurper Malric calls himself king.','You have a campfire, a sword, and the will to rise.','Gather your people. Raise farms. Build walls. Forge an army.','Then break the gates of Malric’s keep, and claim the Crown of Realms.'];
function begin(){setName();inGame=1;try{toast('🗺 Map: '+MAPN[MAPI])}catch(e){}sq++;if(window.speechSynthesis)speechSynthesis.cancel();$('menu').style.display='none';paused=0;nextRaid=Znow()+60;say('Rise, my liege. The kingdom of '+KNAME+' awaits.',1)}
function story(i,k){if(k!=sq)return;if(i>=ST.length)return begin();const p=$('sl'),tx=ST[i];p.textContent='';let j=0;const iv=setInterval(()=>{if(k!=sq){clearInterval(iv);return}p.textContent=tx.slice(0,++j);if(j>=tx.length)clearInterval(iv)},38);let d=0;const adv=()=>{if(d||k!=sq)return;d=1;setTimeout(()=>story(i+1,k),900)};const u=say(tx,1);if(u){u.onstart=()=>u.h=1;u.onend=adv;u.onerror=adv;setTimeout(()=>{if(!u.h&&!window.wn&&k==sq){window.wn=1;$('sk').insertAdjacentHTML('beforebegin','<div style="font-size:12px;color:#7a2a1a">No narrator voice found on this device. Try Chrome or Safari.</div>')}},2500)}setTimeout(adv,tx.length*(u?110:60)+2500)}
$('b1').onclick=()=>{if(window.speechSynthesis){const p=new SpeechSynthesisUtterance(' ');p.volume=0;speechSynthesis.speak(p)}aud();if(ac&&ac.state=='suspended')ac.resume();$('ttl').style.display='none';$('sp').style.display='block';story(0,++sq)};
$('sk').onclick=begin;$('b2').onclick=()=>$('how').style.display='block';$('how').onclick=()=>$('how').style.display='none';
$('b3').onclick=()=>{voiceOn^=1;$('b3').textContent=voiceOn?'🔊 Narrator: On':'🔇 Narrator: Off'};
{const m=$('mbg'),g=m.getContext('2d');m.width=160;m.height=90;const gr=g.createLinearGradient(0,0,0,90);gr.addColorStop(0,'#0e0a24');gr.addColorStop(.6,'#5a2a4a');gr.addColorStop(1,'#c4663a');g.fillStyle=gr;g.fillRect(0,0,160,90);
 for(let i=0;i<50;i++){g.fillStyle='#fff';g.globalAlpha=.3+hs(i,3)*.7;g.fillRect(hs(i,1)*160|0,hs(i,2)*45|0,1,1)}g.globalAlpha=1;g.fillStyle='#f3e9d2';g.fillRect(124,10,7,7);
 g.fillStyle='#2c5a30';for(let x=0;x<160;x++)g.fillRect(x,(68+Math.sin(x*.07)*5+Math.sin(x*.2)*2)|0,1,30);
 g.fillStyle='#0a0710';g.fillRect(58,52,44,24);g.fillRect(72,36,16,20);[[52,40],[100,40]].forEach(([x,y])=>{g.fillRect(x,y,9,36);for(let i=0;i<3;i++)g.fillRect(x+i*4,y-3,2,3)});for(let i=0;i<4;i++)g.fillRect(72+i*5,33,3,3);g.fillRect(79,26,1,10);g.fillStyle='#a8324a';g.fillRect(80,26,5,3);g.fillStyle='#f3a31a';[[56,46],[104,46],[78,42],[78,60]].forEach(([x,y])=>g.fillRect(x,y,2,3));g.fillStyle='#0a0710';g.fillRect(0,76,160,14)}
const SL={};
function tn(f,d,ty,v,f2){if(muted)return;const o=ac.createOscillator(),g=ac.createGain(),n=ac.currentTime;o.type=ty||'sine';o.frequency.setValueAtTime(f,n);if(f2)o.frequency.exponentialRampToValueAtTime(f2,n+d);g.gain.setValueAtTime(v,n);g.gain.exponentialRampToValueAtTime(.001,n+d);o.connect(g);g.connect(sb);o.start(n);o.stop(n+d+.02)}
function ns(d,v,ft,fq,f2){if(muted)return;const s=ac.createBufferSource(),fl=ac.createBiquadFilter(),g=ac.createGain(),n=ac.currentTime;s.buffer=nb;s.loop=true;fl.type=ft;fl.frequency.setValueAtTime(fq,n);if(f2)fl.frequency.exponentialRampToValueAtTime(f2,n+d);g.gain.setValueAtTime(v,n);g.gain.exponentialRampToValueAtTime(.001,n+d);s.connect(fl);fl.connect(g);g.connect(sb);s.start(n);s.stop(n+d+.02)}
function arp(a,ty,v,gap){a.forEach((f,i)=>setTimeout(()=>tn(f,.2,ty,v),i*gap))}
function sfx(k,x,y){if(!ac||!sb||muted)return;let v=1;if(x!==undefined){v=Math.max(0,1-Math.hypot(x-H.x,y-H.y)/380);if(v<.05)return}const n=ac.currentTime;if(SL[k]&&n-SL[k]<.09)return;SL[k]=n;
 const S={swing:()=>ns(.15,.5,'bandpass',500,2200),hit:()=>{tn(150,.12,'triangle',.22*v,55);ns(.07,.25*v,'lowpass',1500)},hurt:()=>{tn(220,.3,'triangle',.3,60);ns(.1,.3,'lowpass',800)},kill:()=>tn(260,.25,'triangle',.2*v,60),arrow:()=>{tn(900,.1,'sine',.12*v,300);ns(.1,.12*v,'highpass',3000)},
 chop:()=>{ns(.08,.5,'lowpass',900);tn(110,.12,'triangle',.3,60)},mine:()=>{tn(1400,.15,'triangle',.25,900);tn(2100,.1,'sine',.12,1500);ns(.04,.3,'highpass',3000)},recruit:()=>arp([392,494,587],'triangle',.12,90),loot:()=>arp([880,1175,1480],'triangle',.15,70),no:()=>tn(120,.2,'triangle',.18,90),
 horn:()=>{window.__hornT=performance.now();tn(147,.4,'triangle',.11,140);tn(220,.4,'triangle',.07,210)},win:()=>arp([392,523,659,784],'triangle',.14,160),
 s_forest:()=>ns(.06,.15,'lowpass',500),s_swamp:()=>{ns(.12,.2,'lowpass',350);tn(80,.08,'sine',.1)},s_desert:()=>ns(.07,.12,'bandpass',1800),s_snow:()=>ns(.06,.15,'highpass',2600),
 a_forest:()=>{tn(2400+Math.random()*400,.08,'sine',.07,3200);setTimeout(()=>tn(3000,.07,'sine',.06,2400),110)},a_swamp:()=>{tn(110,.18,'triangle',.1,70);setTimeout(()=>tn(95,.2,'triangle',.09,60),200)},a_desert:()=>{ns(2.2,.12,'bandpass',400,900);if(Math.random()<.3)tn(1800,.4,'triangle',.04,1100)},a_snow:()=>ns(2.5,.14,'bandpass',900,300)};
 if(S[k])S[k]()}
const mm=$('mm').getContext('2d'),bg=document.createElement('canvas'),fg=document.createElement('canvas');bg.width=bg.height=fg.width=fg.height=110;
{const b=bg.getContext('2d');for(let y=0;y<110;y++)for(let x=0;x<110;x++){const a=BR[bio(x/110*WD,y/110*WD)][0];b.fillStyle=`rgb(${a})`;b.fillRect(x,y,1,1)}}
const fx=fg.getContext('2d',{willReadFrequently:true});fx.fillStyle='#000';fx.fillRect(0,0,110,110);
const mp=v=>v/WD*110,tint=[40,90,60,.1];
// AI
function think(u,dt,EN,TG){const d=UT[u.type],tm=u.team;u.cd-=dt;u.hit-=dt;u.atk-=dt;if(u.type=='ram'){ram(u,dt);return}
 const OP=tm?TG:EN;let tg=null,bd=tm?(u.raid?260:170):125;
 if(!tm&&!(PV.on&&u.gd)&&!u.hold&&Math.hypot(u.x-H.x,u.y-H.y)>250)bd=0;
 const SRC=(tm&&u.kg&&u.kg.rel!=-1&&!u.raid?[]:OP),bd0=bd;let lt=u.lt;if(lt&&(lt.dead||lt.hp<=0))lt=null;const tnw=now();
 if(lt&&tnw<(u.ns||0)){const ld=Math.hypot(lt.x-u.x,lt.y-u.y);if(ld<bd0*1.5&&SRC.length){tg=lt;bd=ld}}
 if(!tg&&tnw>=(u.ns||0)){u.ns=tnw+.2+Math.random()*.2;if(SRC.length&&bd0>0){let b2=bd0*bd0,bb=null;if(SRC.length>48&&window.sgQ){const r=sgQ(SRC,u.x,u.y,bd0);if(r){b2=r.d;bb=r.e}}else for(let k=0;k<SRC.length;k++){const e=SRC[k],ex=e.x-u.x,ey=e.y-u.y;if(ex>bd0||ex<-bd0||ey>bd0||ey<-bd0)continue;const dd=ex*ex+ey*ey;if(dd<b2){b2=dd;bb=e}}if(bb){tg=bb;bd=Math.sqrt(b2)}}}
 u.lt=tg;
 if(!tm&&PV.war&&d.w!='bow'&&d.w!='none'){const s=nearStruct(u.x,u.y,tg?34:70);if(s&&(!tg||bd>d.rng+10)){tg=s.e;bd=s.d}}
 let px,py,stop=2,spd=d.spd;
 if(tg){px=tg.x;py=tg.y;stop=d.rng*.8}else if(tm){if(u.raid){px=CX;py=CX}else{px=u.hx;py=u.hy}}else{px=u.sx;py=u.sy;stop=u.rs?9:3;spd=Math.max(d.spd,Math.min(130,Math.hypot(px-u.x,py-u.y)*3))}
 if(!tm&&(!tg||d.rng<30)){const g=gateWP(u,px,py);if(g){px=g[0];py=g[1];stop=2}}const dx=px-u.x,dy=py-u.y,dist=Math.hypot(dx,dy);if(!tm)u.rs=tg?0:(dist<=stop?1:0);
 if(dist>stop){const s=Math.min(spd*dt,dist-stop+.01);u.x+=dx/dist*s;u.y+=dy/dist*s;u.ph+=dt*10;if(Math.abs(dx)>5)u.face=dx>0?1:-1}
 if(tg&&bd<=d.rng+4&&u.cd<=0){u.cd=d.cd;u.atk=.25;u.face=tg.x>=u.x?1:-1;const dm=d.dmg*(tm?(window.NPCDM||1):1+.15*gear);
  if(d.w=='bow'){const L=Math.hypot(tg.x-u.x,tg.y-u.y)||1;sfx('arrow',u.x,u.y);AR.push({x:u.x,y:u.y-10,vx:(tg.x-u.x)/L*230,vy:(tg.y-u.y)/L*230,team:tm,dmg:dm,l:.9,from:u})}else hurt(tg,dm,u)}}
function drawU(u,x,y){const d=UT[u.type],sc=d.big||1,f=u.face,fl=u.hit>0?1:0,t=now();
 if(u._v===undefined)u._v=Math.random()*6|0;
 const mvn=u._lp!==undefined&&Math.abs(u.ph-u._lp)>1e-4;u._lp=u.ph;if(mvn)u._mt=t+.14;const mv=t<(u._mt||0);
 const dyv=u._ly!==undefined?u.y-u._ly:0;u._ly=u.y;if(mvn&&dyv<-.02)u._up=t+.3;else if(dyv>.02)u._up=0;const up=t<(u._up||0);
 const tq=CR?0:Math.floor(t*3)%3,qa=u.atk>0?(CR?Math.min(6,Math.floor((1-u.atk/.25)*4)*2):Math.min(7,Math.floor((1-u.atk/.25)*8))):-1,rem=qa>=0?.25*(1-(qa+.5)/8):0,pq=mv?(CR?Math.floor(((u.ph%6.2832+6.2832)%6.2832)/6.2832*4)*2:Math.floor(((u.ph%6.2832+6.2832)%6.2832)/6.2832*8)):0,phq=pq/8*6.2832;
 let hb=14;
 if(u.type=='ram'){Zspr('ram|'+f+fl+(mv?1:0)+pq+qa,(ox,oy)=>Zram(ox,oy,f,phq,rem,fl,mv),x,y);hb=26}
 else if(u.type=='wolf'){Zspr('wf|'+d.c+f+fl+(mv?1:0)+pq+(qa>=0?1:0)+tq,(ox,oy)=>Zwolf(ox,oy,f,phq,mv,qa>=0?1:-1,d.c,fl),x,y,tq);hb=15}
 else if(u.type=='treb'){Zspr('tb|'+f+fl+qa,(ox,oy)=>Ztreb(ox,oy,f,rem,fl),x,y);hb=40}
 else{
  let sty=ZMS[u.type]||ZMS.villager,wvv=null;const vil=u.type=='villager';
  let col=u.kg?u.kg.c1:(!u.team&&d.w!='none'?PB.c1:d.c);if(vil&&!u.kg)col=ZVIL[u._v%6];
  let acc=u.kg?u.kg.c2:(!u.team?PB.c2:(d.s||'#c8a050'));
   {const _wu=(!u.team&&!u.kg&&window.WARD&&WARD.u)?WARD.u[u.type]:null;if(_wu&&_wu[0]){col=_wu[0];acc=_wu[1]||acc}}
  if(u.type=='lord'&&u.kg&&u.kg.hs&&window.HS){const hi=HS.indexOf(u.kg.hs);if(hi>=0){sty=ZHERO[hi];wvv=ZHW[hi];col=HS[hi].c1;acc=HS[hi].c2}}
  const wep=(d.w=='none'||d.w=='bite')?null:d.w;let tool=sty.tool||null;
  const working=!!tool&&!mv&&(u.t||0)>.04,wp=working?((t*1.25+u._v*.137)%1):-1,wq=wp>=0?Math.floor(wp*10):-1;
  const carry=(u.type=='builder'&&mv)?'plank':null;if(carry)tool=null;
  const talk=u.bt>0&&!mv,bn=u.team?u.kg:(u.kg||PB);
  if(!d.horse){c.fillStyle='rgba(0,0,0,.3)';c.fillRect(x-Math.round(5*sc),y-1,Math.round(10*sc),3)}
  if(bn&&d.w!='none'&&(u.std||US.length<50))flag(x-f*5,y-(d.horse?9:Math.round(2*sc)),bn,u.std?1.3:.7);
  const key=[u.type,wvv,col,acc,f,fl,mv?1:0,up?1:0,pq,qa,wq,tq,u._v,talk?1:0,carry?1:0].join('|');
  ZU=u;Zspr(key,(ox,oy)=>{
   if(d.horse)Zhorse(ox,oy,f,phq,0,mv,ZCOAT[u.type]||'#6a4326',col);
   Zman({x:d.horse?ox-f:ox,y:oy,f,sc:sc>1.2?sc*.95:sc,t:tq/3,sd:u._v,mv,ph:phq,fl,col,acc,st:sty,up,atk:qa>=0?(qa+.5)/8:-1,wep:sty.xb?'bow':wep,wv:wvv,jp:wvv=='katana',tool,wp:wq>=0?(wq+.5)/10:-1,ride:d.horse?12:0,hb:d.horse&&mv?-Math.round(Math.abs(Math.sin(phq))*1.4):0,carry,talk,hs:u.type=='child'?1.25:1,dress:vil&&(u._v&1),legc:vil?'#4a3a30':(sty.a=='cloth'?Zsh(col,.55):null),cape:acc})},x,y,tq);
  hb=(d.horse?30:Math.round(21*sc))}
 if(u.hp<u.mhp){c.fillStyle='#a8142a';c.fillRect(x-6,y-hb,12,2);c.fillStyle=u.team?'#e84':'#4c4';c.fillRect(x-6,y-hb,Math.max(0,12*u.hp/u.mhp)|0,2)}}
const TCH=new Map();const TCK=new Map();
function tcell(i,j){const px=i*8,py=j*8,tk=j*4096+i;let rc=TCH.get(tk);if(!rc){const bb=bio(px,py),a=BR[bb][(i+j)&1],k=.9+hs(i,j)*.16+(ht(px,py)-ht(px+8,py+8))*.1;rc={c:`rgb(${Math.min(255,a[0]*k)|0},${Math.min(255,a[1]*k)|0},${Math.min(255,a[2]*k)|0})`,g:(bb!='desert'&&hs(i+9,j+4)>.84)?`rgb(${a[0]*.7|0},${a[1]*.75|0},${a[2]*.7|0})`:null};if(TCH.size>24000)TCH.clear();TCH.set(tk,rc)}return rc}
function tchunk(ci,cj){const key=cj*4096+ci;let q=TCK.get(key);if(q){q.u=TCK.n;return q}
 const cvs=document.createElement('canvas');cvs.width=cvs.height=256;const g=cvs.getContext('2d'),gl=[];
 for(let j=0;j<32;j++)for(let i=0;i<32;i++){const ti=ci*32+i,tj=cj*32+j,rc=tcell(ti,tj);g.fillStyle=rc.c;g.fillRect(i*8,j*8,8,8);if(rc.g)gl.push({x:i*8,y:j*8,i:ti,c:rc.g})}
 q={cv:cvs,gl:gl,u:TCK.n};TCK.set(key,q);if(TCK.size>40){const o=[...TCK.entries()].sort((a,b)=>a[1].u-b[1].u);for(let k=0;k<10;k++)TCK.delete(o[k][0])}return q}
const SWT=Array.from({length:64},(_,i)=>Math.round(Math.sin(i/64*6.2832)));
function terr(cx,cy,t){TCK.n=(TCK.n||0)+1;const c0=Math.max(0,cx>>8),c1=(cx+VW)>>8,r0=Math.max(0,cy>>8),r1=(cy+VH)>>8,sw=!window.PERF;
 for(let cj=r0;cj<=r1;cj++)for(let ci=c0;ci<=c1;ci++){const q=tchunk(ci,cj),ox=ci*256-cx,oy=cj*256-cy;c.drawImage(q.cv,ox,oy);
  const gl=q.gl;for(let k=0;k<gl.length;k++){const b=gl[k],x=ox+b.x,y=oy+b.y;if(x<-8||x>VW||y<-8||y>VH)continue;c.fillStyle=b.c;const s=sw?SWT[((t*2+b.i)*10.186|0)&63]:0;c.fillRect(x+3+s,y+2,1,3);c.fillRect(x+5,y+4,1,2)}}}
function loop(){requestAnimationFrame(loop);{const _fn=performance.now();if(_fn-(window.__lf||0)<10)return;window.__lf=_fn}if(window.__pvh&&window.__pvh!==VH){const ow=VW,oh=VH;VH=window.__pvh;size();cam.x+=(ow-VW)/2;cam.y+=(oh-VH)/2}const t=now(),dt=(paused&&!PV.live)?0:Math.min(.05,t-last);last=t;
 PV.war=PV.live&&t>=PV.peaceEnd&&(!won||window.GENM)?1:0;let dx=jx+K.d-K.a,dy=jy+K.s-K.w;const m=Math.hypot(dx,dy);
 if(m>.1){if(m>1){dx/=m;dy/=m}H.x=Math.max(16,Math.min(WD-16,H.x+dx*(H.m?130:72)*dt));H.y=Math.max(30,Math.min(WD-6,H.y+dy*(H.m?130:72)*dt));H.fx=dx/Math.max(m,1);H.fy=dy/Math.max(m,1);if(dx)H.face=dx<0?-1:1;H.ft+=dt;if(H.ft>.17){H.ft=0;H.fr^=1}}
 for(const r of['wood','stone','gold','food'])if(H[r]>RESMAX)H[r]=RESMAX;H.cd-=dt;H.atk-=dt;H.hit-=dt;if(atkHeld)swing();
 const nc=Math.hypot(H.x-CX,H.y-CX)<200;if(nc){H.hp=Math.min(H.mhp,H.hp+10*dt);ARM.forEach(u=>u.hp=Math.min(u.mhp,u.hp+8*dt))}
 const l=hist[0];if(!l||Math.hypot(l.x-H.x,l.y-H.y)>6){hist.unshift({x:H.x,y:H.y});hist.length=Math.min(hist.length,60)}
 // formation
 const order=[...ARM].filter(u=>!u.gd&&!u.hold).sort((a,b)=>CLS.indexOf(a.type)-CLS.indexOf(b.type)),n=order.length,fx_=smx(dt),fy_=FS.y,rx=-FS.y,ry=FS.x;
 const cC=Math.max(4,Math.min(26,Math.ceil(Math.sqrt(n*1.4)))),cW=Math.max(8,Math.min(40,Math.ceil(Math.sqrt(n*4))));
 order.forEach((u,i)=>{let ox,oy;if(form==0){const row=Math.floor(i/cC),col=i%cC-(cC-1)/2;ox=-fx_*(24+row*14)+rx*col*14;oy=-fy_*(24+row*14)+ry*col*14}
  else if(form==1){const row=Math.floor(i/cW),col=i%cW-(cW-1)/2;ox=fx_*(34-row*12)+rx*col*12;oy=fy_*(34-row*12)+ry*col*12}
  else{let k=i,rg=0,cap=10;while(k>=cap){k-=cap;rg++;cap=10+rg*9}const a=k/cap*6.283,r=28+rg*14;ox=Math.cos(a)*r;oy=Math.sin(a)*r}u.sx=H.x+ox;u.sy=H.y+oy});if(form>=3&&window.advForm)advForm(order,fx_,fy_);ARM.forEach(u=>{if(u.gd||u.hold){u.sx=u.hx;u.sy=u.hy}});if(window.armyCmd)armyCmd();
 WK.forEach(w=>wk(w,dt));castle(dt);cits(dt);anim(dt);kAI(dt);wpush();gwalls(dt);mpTick();
 window.__fr=(window.__fr|0)+1;const EN=PV.on?(PV.war?ghostTargets():[]):US.filter(u=>u.team&&!u.dead&&(!u.kg||u.kg.rel<0)&&(u.raid||(Math.abs(u.x-H.x)<520&&Math.abs(u.y-H.y)<420))),TG=PV.on?[]:ARM.concat([H]);
 turr(dt,EN);const _TS=(EN.length+ARM.length)>[450,300,200,120][window.__Q|0],_th=(u,i)=>{if(_TS){if((i+window.__fr)&1)return;think(u,dt*2,EN,TG)}else think(u,dt,EN,TG)};if(!PV.on)EN.forEach(_th);ARM.slice().forEach(_th);EN.forEach(u=>{if(u.raid&&u.cd<=0&&PC.hp>0&&Math.hypot(u.x-PC.x,u.y-PC.y)<UT[u.type].rng+60){u.cd=UT[u.type].cd;u.atk=.25;window.LK=u.kg||window.LK;hitPC(UT[u.type].dmg)}});ARM.slice().forEach(u=>{if(u.ttl&&t>u.ttl){u.dead=t;ARM.splice(ARM.indexOf(u),1)}});
 const AL=(PV.on?[]:EN).concat(ARM);{const G=new Map();AL.forEach(u=>{const k=(u.x>>3)*700+(u.y>>3);let l=G.get(k);if(!l){l=[];G.set(k,l)}l.push(u)});
 const SK=AL.length>250;AL.forEach(u=>{if(SK&&(((u.uid|0)+window.__fr)&1))return;const gx=u.x>>3,gy=u.y>>3;for(let ax=-1;ax<=1;ax++)for(let ay=-1;ay<=1;ay++){const l=G.get((gx+ax)*700+gy+ay);if(!l)continue;for(let k=0;k<l.length;k++){const o=l[k];if(o===u)continue;const ex=u.x-o.x,ey=u.y-o.y,d2=ex*ex+ey*ey;if(d2<64&&d2>.01){const d=Math.sqrt(d2);u.x+=ex/d*(SK?48:24)*dt;u.y+=ey/d*(SK?48:24)*dt}}}})};{const WS=WALLS.slice();let _x0=1e9,_x1=-1e9,_y0=1e9,_y1=-1e9;WS.forEach(w=>{if(w.x<_x0)_x0=w.x;if(w.x>_x1)_x1=w.x;if(w.y<_y0)_y0=w.y;if(w.y>_y1)_y1=w.y});(PV.on||!WS.length?[]:EN.filter(u=>u.x>_x0-24&&u.x<_x1+24&&u.y>_y0-24&&u.y<_y1+24)).forEach(u=>WS.forEach(w=>{if(w.hp<=0)return;const ex=u.x-w.x,ey=u.y-w.y;if(ex>20||ex<-20||ey>20||ey<-20)return;const d=Math.hypot(ex,ey);if(d<9&&d>.1){u.x+=ex/d*(9-d);u.y+=ey/d*(9-d)}if(u.raid&&d<16&&UT[u.type].rng<30){w.hp-=UT[u.type].dmg*dt*1.2;if(w.hp<=0)brk(w)}}))};ARM.concat([H]).forEach(u=>kwN(u.x,u.y).forEach(w=>{if(w.kg.rel>=1||w.kg.owned||Math.abs(u.x-w.x)>20||Math.abs(u.y-w.y)>20)return;const ex=u.x-w.x,ey=u.y-w.y,d=Math.hypot(ex,ey);if(d<9&&d>.1){u.x+=ex/d*(9-d);u.y+=ey/d*(9-d)}if(u.type=='ram'&&d<16&&!(window.peaceOn&&peaceOn())){w.hp-=45*dt;if(w.hp<=0)kbrk(w)}}));
 for(let i=AR.length-1;i>=0;i--){const a=AR[i];a.x+=a.vx*dt;a.y+=a.vy*dt;a.l-=dt;let hit=0;const OP=a.vis?[]:a.team?TG:EN;for(const e of OP){if(!e.dead&&Math.abs(e.x-a.x)<9&&Math.abs(e.y-8-a.y)<9&&Math.hypot(e.x-a.x,e.y-8-a.y)<9){hurt(e,a.dmg,a.from);hit=1;break}}if(hit||a.l<=0)AR.splice(i,1)}
 for(let i=PS.length-1;i>=0;i--){const p=PS[i];p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=90*dt;p.l-=dt;if(p.l<=0)PS.splice(i,1)}
 if(PS.length>500)PS.splice(0,PS.length-500);if(FX.length>70)FX.splice(0,FX.length-70);
 for(let i=FX.length-1;i>=0;i--){FX[i].y-=14*dt;FX[i].l-=dt;if(FX[i].l<=0)FX.splice(i,1)}
 if(t-lastFeed>6&&FEED.length){FEED.length=0;$('feed').innerHTML=''}
 // respawn / raids / cleanup
 PK.forEach(p=>{if(p.w&&p.l.every(u=>u.dead)){if(!p.rt)p.rt=t+110;else if(t>p.rt){p.rt=0;spawn(p)}}});
 for(let i=US.length-1;i>=0;i--)if(US[i].dead&&t-US[i].dead>8)US.splice(i,1);
 if(!MPI&&t>nextRaid){nextRaid=t+75;if(US.filter(u=>u.raid&&!u.kg&&!u.dead).length<6){const a=Math.random()*6.28,k=2+Math.min(40,Math.floor(ARM.length/6)+Math.floor(t/200));for(let i=0;i<k;i++)mku(1,i==k-1?'archer':'bandit',CX+Math.cos(a)*500+i*10,CX+Math.sin(a)*500,{raid:1});toast('Bandits are raiding your camp!');callAllies();sfx('horn');say('Bandits are raiding the camp! To arms!')}}
 if(!MPI&&!won&&!window.WON2&&KG.every(k=>k.owned)){won=1;sfx('win');say('The castle has fallen. The Crown of Realms is yours, my liege. Long may you reign.',1);$('ov').innerHTML='<div><h3>👑 Sole ruler of the continent</h3><p>The rival banner falls. Crown of Realms is yours.</p><button class="g" onclick="window.WON2=1;won=0;ovx()">Keep ruling</button> <button onclick="reloadToMenu()">Main menu</button></div>';$('ov').style.display='flex'}
 // camera
 {const _s=window.SPEC&&window.SPECT?window.SPECT():null,_ck=_s?0:(window.CINK||0),_x=(_s?_s.x:H.x),_y=(_s?_s.y:H.y);const _k=_s?.12:1;cam.x+=(_x-VW/2-cam.x)*_k;cam.y+=(_y-VH/2-cam.y)*_k}cam.x=Math.max(0,Math.min(WD-VW,cam.x));cam.y=Math.max(0,Math.min(WD-VH,cam.y));
 const cx=Math.round(cam.x),cy=Math.round(cam.y),b=bio(H.x,H.y);if(b!=cb)snd(b);if(m>.1){H.sd=(H.sd||0)+dt;if(H.sd>.32){H.sd=0;sfx('s_'+b)}}if(t>(H.am||0)){H.am=t+2+Math.random()*3;sfx('a_'+b)}
 music(t);const dn=Math.sin(t*.05)*.5+.5;c.setTransform(GS,0,0,GS,0,0);c.imageSmoothingEnabled=GQ=='hd';c.imageSmoothingQuality='high';
 const ST_=VH>760?4:VH>420?2:1,i0=Math.floor(cx/8/ST_)*ST_,j0=Math.floor(cy/8/ST_)*ST_;const gw=Math.ceil(VW/8)+3+ST_,gh=Math.ceil(VH/8)+3+ST_;if(GQ=='hd'){if(gc.width!=gw||gc.height!=gh){gc.width=gw;gc.height=gh}c.clearRect(0,0,VW,VH)}
 if(GQ!='hd'&&ST_==1)terr(cx,cy,t);else for(let j=j0;j<=j0+VH/8+ST_;j+=ST_)for(let i=i0;i<=i0+VW/8+ST_;i+=ST_){const px=i*8,py=j*8,tk=j*4096+i;let rc=TCH.get(tk);if(!rc){const bb=bio(px,py),a=BR[bb][(i+j)&1],k=.9+hs(i,j)*.16+(ht(px,py)-ht(px+8,py+8))*.1;rc={c:`rgb(${Math.min(255,a[0]*k)|0},${Math.min(255,a[1]*k)|0},${Math.min(255,a[2]*k)|0})`,g:(bb!='desert'&&hs(i+9,j+4)>.84)?`rgb(${a[0]*.7|0},${a[1]*.75|0},${a[2]*.7|0})`:null};if(TCH.size>24000)TCH.clear();TCH.set(tk,rc)}
  const _cl=rc.c;if(GQ=='hd'){gx.fillStyle=_cl;gx.fillRect(i-i0,j-j0,ST_,ST_)}else{c.fillStyle=_cl;c.fillRect(px-cx,py-cy,8*ST_,8*ST_)}
  if(ST_==1&&rc.g){c.fillStyle=rc.g;const s=Math.round(Math.sin(t*2+i));c.fillRect(px-cx+3+s,py-cy+2,1,3);c.fillRect(px-cx+5,py-cy+4,1,2)}}
 if(GQ=='hd'){c.globalCompositeOperation='destination-over';c.imageSmoothingEnabled=true;c.drawImage(gc,0,0,gw,gh,i0*8-cx,j0*8-cy,gw*8,gh*8);c.globalCompositeOperation='source-over'}RD.forEach(r=>{if(r.x>cx-8&&r.x<cx+VW&&r.y>cy-8&&r.y<cy+VH){c.fillStyle=((r.x+r.y)>>3)&1?(RDP[(window.AGE_?AGE_():0)]||RDP[0])[0]:(RDP[(window.AGE_?AGE_():0)]||RDP[0])[1];c.fillRect(r.x-cx,r.y-cy,8,8);c.fillStyle='#7a6440';c.fillRect(r.x-cx+((r.x*7)&5),r.y-cy+((r.y*3)&5),1,1)}});ground(cx,cy,t);US.forEach(u=>{if(u.dead){const x=Math.round(u.x-cx),y=Math.round(u.y-cy);if(x>-20&&x<VW+20&&y>-20&&y<VH+20){{const al=Math.max(0,1-(t-u.dead)/8)*.85,dt_=UT[u.type];if(u.type=='wolf'||u.type=='ram'||u.type=='treb'){c.globalAlpha=al;c.fillStyle=dt_.c;c.fillRect(x-6,y-3,12,4);c.fillStyle='#a8142a';c.fillRect(x-2,y-1,5,2);c.globalAlpha=1}else{const dc=(u.kg?u.kg.c1:(!u.team&&dt_.w!='none'?PB.c1:dt_.c)),ds=(u._v||u.uid||3)%6,df=u.face||1;c.globalAlpha=al;Zspr(['D',dc,dt_.s,df,ds].join('|'),(ox,oy)=>Zdead(ox,oy,df,dc,dt_.s,ds,1),x,y);c.globalAlpha=1}}}}});
 ZF++;ZB=0;ZBMAX=Math.min(US.length>1200?3:US.length>600?5:US.length>300?8:12,[12,8,4,2][window.__Q|0]);CR=US.length>150?1:0;const L=[];{const _x0=cx-60,_x1=cx+VW+60,_y1=cy+VH+90;for(let _i=0,_n=objs.length;_i<_n;_i++){const o=objs[_i];if(o.dead){if(t-o.dead>(o.k=='tree'||o.k=='rock'?10:60))o.dead=0;else continue}if(o.x>_x0&&o.x<_x1&&o.y>cy&&o.y<_y1)L.push(o)}}
 if(!window.SPEC)L.push({k:'hero',x:H.x,y:H.y});MP.peers.forEach(r=>{if(r.out)return;L.push({k:'rp',r,x:r.x,y:r.y});r.gu.forEach(g=>{if(g.hp>0&&g.x>cx-30&&g.x<cx+VW+30&&g.y>cy&&g.y<cy+VH+40)L.push({k:'unit',u:g,x:g.x,y:g.y})})});WK.forEach(u=>L.push({k:'unit',u,x:u.x,y:u.y}));CT.concat(KB).forEach(u=>{if(u.x>cx-30&&u.x<cx+VW+30&&u.y>cy&&u.y<cy+VH+40)L.push({k:'unit',u,x:u.x,y:u.y})});if(HR.on)L.push({k:'horse',x:HR.x,y:HR.y});AN.forEach(a=>{if(!a.d)L.push({k:'an',a,x:a.x,y:a.y})});US.forEach(u=>{if(!u.dead&&u.x>cx-30&&u.x<cx+VW+30&&u.y>cy&&u.y<cy+VH+40)L.push({k:'unit',u,x:u.x,y:u.y})});
 if(window.PRL)window.PRL(L,cx,cy);
 L.sort((p,q)=>((p.sy!==undefined?p.sy:p.y)-(q.sy!==undefined?q.sy:q.y))||(p.x-q.x));
 if((window.__nf=(window.__nf||0)+1)%3==0){near=null;let nd=30;for(let _i=0,_n=objs.length;_i<_n;_i++){const o=objs[_i],_dx=o.x-H.x,_dy=o.y-8-H.y;if(_dx>44||_dx<-44||_dy>44||_dy<-44)continue;if(o.dead||o.done||o.gh||o.dec||o.k=='capital'||o.k=='wall'||o.k=='farm'||o.k=='home'||o.k=='keep'||o.k=='tower'||(o.grp&&!o.grp.l.every(u=>u.dead)))continue;const dd=Math.hypot(_dx,_dy)-(o.w>30?14:0);if(dd<nd){nd=dd;near=o}}}
 window.__lodN=0;for(let _i=0;_i<L.length;_i++)if(L[_i].k=='unit')window.__lodN++;
 L.forEach(o=>{const x=Math.round(o.x-cx),y=Math.round(o.y-cy);
  if(o.k=='unit'){if(window.lodDraw&&lodDraw(o.u,x,y))return;if(GQ=='hd')shd(x,y,12);drawU(o.u,x,y-(o.u.kg&&o.u.kg.fe>t&&!o.u.team&&o.u.type!='builder'?Math.abs(Math.sin(t*8+o.u.ph))*3|0:0));if(o.u.bt>0)bub(o.u,x,y)}else if(o.k=='horse')drawHorse(x,y,HR.face,0,1);else if(o.k=='an')drawAn(o.a,x,y);else if(o.k=='rp')drawRP(o.r,x,y);
  else if(o.k=='pris')window.drawPris(o.p,x,y,t);
  else if(o.k=='hero'){if(GQ=='hd')shd(x,y,H.m?22:13);else{c.fillStyle='rgba(0,0,0,.3)';c.fillRect(x-6,y-1,12,3)}const bob=H.m?8:0,hh_=Zhs(),mvH=m>.1,pqH=mvH?Math.floor(((t*(H.m?14:11))%6.2832)/6.2832*8):0,phH=pqH/8*6.2832,qaH=H.atk>0?Math.min(7,Math.floor((1-H.atk/.25)*8)):-1,tqH=Math.floor(t*3)%3,upH=H.fy<-.45&&mvH;Zspr(['H',Zhi(),hh_.c1,hh_.c2,H.face,H.hit>0?1:0,mvH?1:0,upH?1:0,pqH,qaH,gear,(window.MWBL?MWBL():''),H.m?1:0,tqH].join('|'),(ox,oy)=>{if(H.m)Zhorse(ox,oy,H.face,phH,0,mvH,'#6a4326',hh_.c2);Zman({x:ox-(H.m?H.face:0),y:oy,f:H.face,sc:1.12,t:tqH/3,sd:Zhi()*5+2,mv:mvH,ph:phH,fl:H.hit>0,col:hh_.c1,acc:hh_.c2,st:ZHERO[Zhi()]||ZHERO[0],up:upH,atk:qaH>=0?(qaH+.5)/8:-1,wep:'sword',jp:Zhi()==1,wv:ZHW[Zhi()],gold:gear,bl:(window.MWBL?MWBL():null),ride:H.m?12:0,hb:H.m&&mvH?-Math.round(Math.abs(Math.sin(phH))*1.4):0,cape:hh_.c2,wp:-1,hs:1.05})},x,y,tqH);
   flag(x-H.face*7,y-6-bob,PB,1.5);const hbY=H.m?-46:-35;c.fillStyle='#a8142a';c.fillRect(x-8,y+hbY,16,2);c.fillStyle='#4c4';c.fillRect(x-8,y+hbY,Math.max(0,16*H.hp/H.mhp)|0,2);if(RULER){c.font='bold 6px monospace';c.textAlign='center';c.fillStyle='#000';c.fillText(RULER,x+1,y+hbY-3);c.fillStyle='#ffe9a8';c.fillText(RULER,x,y+hbY-4)}}
  else{if(o.nsh){}else if(GQ=='hd')shd(x,y,o.k=='tree'?o.w*.9:o.w*1.05);else{c.fillStyle='rgba(0,0,0,.25)';c.fillRect(x-o.w/3|0,y-2,o.w*2/3|0,3)}const h2=o.k=='camp'?o.h*(1+Math.sin(t*12)*.08):o.h;if(o.done)c.globalAlpha=.45;
   const sw=o.k=='tree'?Math.round(Math.sin(t*1.5+o.x)*.6):0;c.drawImage(o.img,x-o.w/2+sw,y-h2,o.w,h2);c.globalAlpha=1;if(o.gh&&o.gk=='c'){pname(x,y-o.h-34,o.pl.kn,'Ruler: '+o.pl.n,o.pl.c1);cfx(o,x,y);flag(x,y-o.h+8,o.pl,1.8)}if(o===PC)pname(x,y-o.h-34,KNAME,RULER?'Ruler: '+RULER:'Your realm',PB.c1);if(o.k=='capital')pname(x,y-o.h-34,o.kg.name,o.kg.owned?'Yours':o.kg.rel<0?'At war':o.kg.rel>0?'Allied':'Neutral',o.kg.owned?PB.c1:o.kg.c1);if(o.k=='home'||o.k=='camp')smoke(x,y,o);if(o.gt)flag(x,y-o.h+6,o.kg&&!o.kg.owned?o.kg:PB,1.2);if(o.kg&&o.k=='capital'&&o.kg.fe>t)fest(o,x,y);if(o.k=='capital'||o===PC){cfx(o,x,y);flag(x,y-o.h+(o===PC?8:4),o===PC||o.kg.owned?PB:o.kg,o===PC?1.8:2.4)}if(o===near){c.strokeStyle='#e8b94a';c.strokeRect(x-o.w/2-1,y-o.h-1,o.w+2,o.h+2)}}});
 AR.forEach(a=>{c.strokeStyle='#e8e0c0';c.lineWidth=1;c.beginPath();c.moveTo(a.x-cx,a.y-cy);c.lineTo(a.x-cx-a.vx*.04,a.y-cy-a.vy*.04);c.stroke()});
 PS.forEach(p=>{c.fillStyle=p.c;c.fillRect(Math.round(p.x-cx),Math.round(p.y-cy),2,2)});
 c.font='bold 8px monospace';c.textAlign='center';FX.forEach(f=>{c.fillStyle='#000';c.fillText(f.t,Math.round(f.x-cx)+1,Math.round(f.y-cy)+1);c.fillStyle=f.c;c.fillText(f.t,Math.round(f.x-cx),Math.round(f.y-cy))});
 ambient(dt,cx,cy,b,dn);tint[0]+=(TN[b][0]-tint[0])*.03;tint[1]+=(TN[b][1]-tint[1])*.03;tint[2]+=(TN[b][2]-tint[2])*.03;tint[3]+=(TN[b][3]-tint[3])*.03;
 c.fillStyle=`rgba(${tint[0]|0},${tint[1]|0},${tint[2]|0},${tint[3]})`;c.fillRect(0,0,VW,VH);if(GQ=='hd')post(cx,cy);
 if(dn<.9){if(lc.width!=VW||lc.height!=VH){lc.width=VW;lc.height=VH}else{lx.globalCompositeOperation='source-over';lx.clearRect(0,0,VW,VH)}lx.fillStyle=`rgba(8,10,45,${(.9-dn)*.5})`;lx.fillRect(0,0,VW,VH);lx.globalCompositeOperation='destination-out';
  const lt=(x,y,r,a)=>{if(!isFinite(x+y+r+a))return;const g=lx.createRadialGradient(x,y,2,x,y,r);g.addColorStop(0,`rgba(0,0,0,${a})`);g.addColorStop(1,'rgba(0,0,0,0)');lx.fillStyle=g;lx.fillRect(x-r,y-r,2*r,2*r)};
  lt(H.x-cx,H.y-cy-10,90,.8);lt(camp.x-cx,camp.y-cy-8,70+Math.sin(t*16)*5,.95);lt(PC.x-cx,PC.y-cy-20,70,.8);CAPS.forEach(o=>{if(o.x>cx-90&&o.x<cx+VW+90)lt(o.x-cx,o.y-cy-20,60,.7)});if(window.xNight)xNight(lt,cx,cy);c.drawImage(lc,0,0)}
 const _vk=VW+'x'+VH,vg=(window.__vg&&window.__vg.k==_vk)?window.__vg.g:(window.__vg={k:_vk,g:(()=>{const g=c.createRadialGradient(VW/2,VH/2,VH*.4,VW/2,VH/2,VW*.62);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.5)');return g})()}).g;c.fillStyle=vg;c.fillRect(0,0,VW,VH);
 {const _mo=H.m||Math.hypot(HR.x-H.x,HR.y-H.y)<34?1:.5;if(window.__mo!==_mo){window.__mo=_mo;$('mnt').style.opacity=_mo}}const a=$('act');a.classList.toggle('on',!!near);{const _at=near?{tree:'Chop',rock:'Mine',camp:'Recruit',barr:'Train',brng:'Train',bstb:'Train',bsge:'Train',bplot:'Build',merch:'Shop',village:'Loot',den:'Loot den'}[near.k]:'…';if(a.textContent!==_at)a.textContent=_at}
 mm.drawImage(bg,0,0);fx.globalCompositeOperation='destination-out';fx.beginPath();fx.arc(mp(H.x),mp(H.y),9,0,7);fx.fill();mm.drawImage(fg,0,0);
 __mmList().forEach(o=>{if(1){const px=mp(o.x),py=mp(o.y);if(t>(o._mt||0)){o._mt=t+.8+Math.random()*.4;o._mv=o.k=='camp'||fx.getImageData(px|0,py|0,1,1).data[3]<128}if(o._mv){mm.fillStyle=o.k=='capital'?(o.kg.owned?'#3c6':o.kg.rel>0?'#6cf':'#f33'):o.done?'#777':o.k=='camp'?'#fa3':'#fff';mm.fillRect(px-1,py-1,3,3)}}});
 mm.fillStyle=Math.floor(t*3)%2?'#ff0':'#fa0';mm.fillRect(mp(H.x)-2,mp(H.y)-2,4,4);MP.peers.forEach(r=>{if(r.out)return;mm.fillStyle=r.c1;mm.fillRect(mp(r.lx)-3,mp(r.ly)-3,6,6);mm.fillStyle='#f55';mm.fillRect(mp(r.x)-2,mp(r.y)-2,4,4)})}
// ===== v3 additions =====
const BL=[],AMB=[];let nFest=25;
const zn=(x,y)=>{const a=((x-CX)/284)**2+((y-CX)/243)**2,b=((x-CX)/480)**2+((y-CX)/405)**2;return a<.9?0:b<.9?1:2};
function gateWP(u,px,py){if(u.gp>now())return null;const a=zn(u.x,u.y),b=zn(px,py);if(a==b)return null;const gx=a<b?(a==0?CX+284:CX+482):(a==2?CX+482:CX+284);if(Math.hypot(u.x-gx,u.y-CX)<10){u.gp=now()+1.2;return null}return[gx,CX]}
function wpush(){ARM.concat([H]).forEach(u=>WALLS.forEach(w=>{if(Math.abs(u.x-w.x)>14||Math.abs(u.y-w.y)>14)return;const ex=u.x-w.x,ey=u.y-w.y,d=Math.hypot(ex,ey);if(d<9&&d>.1){u.x+=ex/d*(9-d);u.y+=ey/d*(9-d)}}))}
function gather(w,dt){const k=w.type=='cutter'?'tree':'rock';let o=w.tg;if(o&&o.dead)o=w.tg=null;
 if(!o){let bd=1e9;objs.forEach(q=>{if(q.k==k&&!q.dead&&Math.hypot(q.x-CX,q.y-CX)<750){const d=Math.hypot(q.x-w.x,q.y-w.y);if(d<bd){bd=d;o=q}}});w.tg=o}
 if(!o){wgo(w,CX+WK.indexOf(w)*14-30,CX+26,dt);return}
 if(wgo(w,o.x,o.y+4,dt)<8){w.t+=dt;if(w.t>1){w.t=0;o.dead=now();w.tg=null;const _y=Math.round(8*(window.YM?YM():1));if(k=='tree')H.wood+=_y;else H.stone+=_y;FX.push({x:w.x,y:w.y-20,t:k=='tree'?'+'+_y+' wood':'+'+_y+' stone',l:1,c:k=='tree'?'#d9a45a':'#bbc'});sfx(k=='tree'?'chop':'mine',o.x,o.y)}}}
function splat(u,big){const n=big?7:2,t=now();for(let i=0;i<n;i++)BL.push({x:u.x+(Math.random()-.5)*(big?18:8),y:u.y+(Math.random()-.5)*(big?9:4),s:big?2+(Math.random()*3|0):1+(Math.random()*2|0),t,c:Math.random()<.5?'#7a0f1a':'#9a1424'});if(BL.length>450)BL.splice(0,BL.length-450)}
function ground(cx,cy,t){const i0=Math.floor(cx/8),j0=Math.floor(cy/8);
 for(let j=j0;j<=j0+VH/8+1;j++)for(let i=i0;i<=i0+VW/8+1;i++){const h=hs(i*3.1,j*1.7);if(h>.94&&bio(i*8,j*8)=='forest'){c.fillStyle=['#f4e04a','#f07aa0','#fff','#8ab4ff'][(h*1000|0)%4];c.fillRect(i*8-cx+3,j*8-cy+4,2,2)}}
 for(let i=BL.length-1;i>=0;i--){const b=BL[i],a=1-(t-b.t)/120;if(a<=0){BL.splice(i,1);continue}if(b.x<cx-8||b.x>cx+VW+8||b.y<cy-8||b.y>cy+VH+8)continue;c.globalAlpha=a*.8;c.fillStyle=b.c;c.fillRect(Math.round(b.x-cx),Math.round(b.y-cy),b.s+1,b.s)}c.globalAlpha=1}
function ambient(dt,cx,cy,b,dn){const t=now(),ty={forest:'l',snow:'s',desert:'d',swamp:'w'}[b];
 if(AMB.length<28)AMB.push({x:cx+Math.random()*VW,y:cy+Math.random()*VH,t:dn<.5&&b!='snow'?'f':ty,l:4+Math.random()*5,a:Math.random()*6});
 for(let k=0;k<4;k++){const x=(((t*5+k*173-cx*.3)%(VW+200))+VW+200)%(VW+200)-100,y=(((k*97-cy*.3)%(VH+100))+VH+100)%(VH+100);c.globalAlpha=.06;c.fillStyle='#000';c.fillRect(x,y,70,24);c.fillRect(x+10,y-8,45,40)}
 for(let i=AMB.length-1;i>=0;i--){const p=AMB[i];p.l-=dt;p.a+=dt;if(p.t=='f'){p.x+=Math.cos(p.a)*10*dt;p.y+=Math.sin(p.a*1.3)*8*dt}else if(p.t=='s'){p.x+=Math.sin(p.a)*8*dt;p.y+=22*dt}else if(p.t=='d'){p.x+=40*dt;p.y+=Math.sin(p.a)*4*dt}else if(p.t=='w'){p.y-=8*dt;p.x+=Math.sin(p.a)*5*dt}else{p.x+=14*dt;p.y+=16*dt}
  if(p.l<=0||p.x<cx-20||p.x>cx+VW+20||p.y>cy+VH+20||p.y<cy-20){AMB.splice(i,1);continue}
  c.globalAlpha=Math.min(1,p.l)*(p.t=='f'?.6+.4*Math.sin(t*6+p.a*3):.85);c.fillStyle=p.t=='f'?'#d8ff70':p.t=='s'?'#fff':p.t=='d'?'#e8c888':p.t=='w'?'#9ac060':(p.a*10|0)%2?'#d8b040':'#6cae48';c.fillRect(Math.round(p.x-cx),Math.round(p.y-cy),p.t=='f'?2:1,p.t=='f'?2:1)}c.globalAlpha=1}
function smoke(x,y,o){const t=now(),sx=x+(o.k=='home'?6:0),sy=y-o.h+(o.k=='home'?2:4);for(let i=0;i<3;i++){const p=(t*.6+i/3+o.x*.013)%1;c.globalAlpha=(1-p)*.5;c.fillStyle='#d8d4cc';const s=2+(p*2|0);c.fillRect(Math.round(sx+Math.sin(t+i)*2+p*4),Math.round(sy-p*16),s,s)}c.globalAlpha=1}
function fest(o,x,y){const k=o.kg,cl=[k.cu.col,k.c2,'#fff'];for(let i=0;i<12;i++){const bx=x-48+i*8,by=y-o.h+14+Math.round(Math.abs(Math.sin(i*.9))*3);c.fillStyle='#3a2a1a';c.fillRect(bx,by,8,1);c.fillStyle=cl[i%3];c.fillRect(bx+2,by+1,4,4)}
 if(Math.random()<.5)PS.push({x:o.x+(Math.random()-.5)*90,y:o.y-30,vx:(Math.random()-.5)*20,vy:-30-Math.random()*30,l:1.2,c:cl[Math.floor(Math.random()*3)]});
 c.fillStyle='#fff';c.font='6px monospace';c.textAlign='center';c.fillText('✦ '+k.cu.f+' ✦',x,y-o.h-46)}
// our castle gate: towers either side + paved passage
[[CX+283,CX-24],[CX+283,CX+26],[CX+479,CX-24],[CX+479,CX+26]].forEach(([x,y])=>objs.push({k:'tower',img:TX.tower,x,y,w:16,h:36,dead:0,done:0,gt:1}));
for(let x=CX+255;x<=CX+510;x+=8)[-8,0,8].forEach(d=>RD.push({x:Math.round(x/8)*8,y:Math.round((CX+d)/8)*8}));
mkw('cutter',CX-14,CX+34);mkw('miner',CX+14,CX+34);


// ===== v4: music, trade, name =====
let KNAME='Aldoria',RULER='',nMus=0,mi=2,mc=0;const DN=['Aldoria','Eldmark','Valenor','Stormhaven','Ravenmoor','Goldcrest'];
const SC={forest:[262,294,330,392,440,523,588],swamp:[196,220,262,294,330,392],desert:[294,311,370,392,440,466],snow:[392,440,523,587,659,784]};
function music(t){if(!ac||!sb||muted||t<nMus||window.BTON)return;const s=SC[cb||'forest'];mi=Math.max(0,Math.min(s.length-1,mi+[-2,-1,-1,0,1,1,2][Math.floor(Math.random()*7)]));
 if(Math.random()<.8){tn(s[mi],2.2,'sine',.10);tn(s[mi]*2,1.2,'sine',.025)}if(mc++%6==0){tn(s[0]/2,4,'sine',.09);tn(s[2]/2,4,'sine',.05)}
 nMus=t+(.8+Math.random()*1.8)*(cb=='swamp'?1.6:1)}
function setName(){RULER=(($('rl').value||'').replace(/[<>&"']/g,'').trim().slice(0,14));H.nm=RULER||'You';KNAME=(($('kn').value||'').replace(/[<>&"']/g,'').trim().slice(0,18))||DN[Math.floor(Math.random()*DN.length)]}
function rn(v){KNAME=v.replace(/[<>&"']/g,'').slice(0,18)}
function pname(x,y,s,sub,col){c.textAlign='center';c.font='bold 8px monospace';let w=c.measureText(s).width;if(sub){c.font='6px monospace';w=Math.max(w,c.measureText(sub).width)}
 w=Math.ceil(w)+12;const h=sub?21:13,px=Math.round(Math.max(w/2+2,Math.min(VW-w/2-2,x))),y0=Math.round(Math.max(38,y-h)),x0=px-(w>>1);
 c.fillStyle='#000';c.fillRect(x0-1,y0-1,w+2,h+2);c.fillStyle='#4a3020';c.fillRect(x0,y0,w,h);c.fillStyle=col||'#e8b94a';c.fillRect(x0,y0,w,2);
 c.font='bold 8px monospace';c.fillStyle='#000';c.fillText(s,px+1,y0+11);c.fillStyle='#ffe9a8';c.fillText(s,px,y0+10);
 if(sub){c.font='6px monospace';c.fillStyle='#d8c8a0';c.fillText(sub,px,y0+18)}}
const TB={wood:4,stone:7,food:3},TS={wood:1,stone:1,food:1};
function tNear(){let r=Math.hypot(H.x-CX,H.y-CX)<340?{mul:MPI?1.5:1,n:'your castle market'}:null;KG.forEach(k=>{if(k.rel>=0&&Math.hypot(H.x-k.x,H.y-k.y)<170){const m=1.15+(k.cu.n=='Sun Merchants'?.25:0);if(!r||m>r.mul)r={mul:m,n:k.name}}});return r}
const tsp=(r,n)=>Math.max(1,Math.round(25*TB[r]*.65*n.mul*TS[r])),tbp=r=>Math.max(2,Math.round(25*TB[r]*1.3));
const tsum=(r,n,k)=>{let s=0,q=TS[r];for(let i=0;i<k;i++){s+=Math.max(1,Math.round(25*TB[r]*.65*n.mul*q));q=Math.max(.4,q*.93)}return s};
function tradeUI(){const e=$('ov'),n=tNear();paused=1;e.style.display='flex';
 if(!n){e.innerHTML='<div><h3>Trade</h3><p>Go to your castle or a friendly kingdom to trade.</p><button onclick="ovx()">Close</button></div>';return}
 e.innerHTML='<div style="width:min(94vw,440px)"><h3>Market · '+n.n+'</h3><p>Gold: '+(H.gold|0)+' / '+RESMAX+'</p>'+['wood','stone','food'].map(r=>`<p style="margin:6px 0">${r} (${H[r]|0})<br>`+[1,5,20].map(k=>`<button onclick="trade('${r}',1,${k})">Sell ${50*k} · +${tsum(r,n,k)}g</button>`).join(' ')+'<br>'+[1,5,20].map(k=>`<button onclick="trade('${r}',0,${k})">Buy ${50*k} · -${tbp(r)*k}g</button>`).join(' ')+'</p>').join('')+'<p style="font-size:8px">Prices fall as you sell and recover in about a minute. Gold and each resource cap at '+RESMAX+'.</p><button onclick="ovx()">Close</button></div>'}
function trade(r,sell,k){k=k||1;const n=tNear();if(!n)return tradeUI();let done=0,why='';
 for(let i=0;i<k;i++){
  if(sell){if(H[r]<50){why='Not enough '+r;break}const g=tsp(r,n);if(H.gold+g>RESMAX){why='Gold storage full';break}H[r]-=50;H.gold+=g;TS[r]=Math.max(.4,TS[r]*.93);done++}
  else{const p=tbp(r);if(H.gold<p){why='Not enough gold';break}if(H[r]+50>RESMAX){why='Storage full';break}H.gold-=p;H[r]+=50;done++}}
 if(!done)toast(why);else{sfx(sell?'loot':'recruit');if(done<k)toast('Traded '+done*50+' · '+why)}
 hud();tradeUI()}

// ===== v5: pause menu, save/load, mute, ruler name, Nepal flag =====
const esc=s=>String(s==null?'':s).replace(/[<>&"']/g,'');
const SK='cor_save_',MK='cor_meta_',stg={g:k=>{try{return localStorage.getItem(k)}catch(e){return null}},s:(k,v)=>{try{localStorage.setItem(k,v);return 1}catch(e){return 0}}};
let pzT=0;
function nepal(g,x,y,w,h,b){const fw=Math.min(w,h/1.22),fh=fw*1.22,ox=x+(w-fw)/2,oy=y+(h-fh)/2,P=p=>[ox+p[0]*fw,oy+p[1]*fh];
 g.save();g.beginPath();[[0,0],[.66,.42],[.3,.42],[1,1],[0,1]].forEach((p,i)=>{const q=P(p);i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1])});g.closePath();
 g.fillStyle=b.c1;g.fill();g.clip();g.strokeStyle=b.c2;g.lineWidth=Math.max(1,fw*.14);g.lineJoin='miter';g.stroke();g.restore();
 const m=P([.2,.25]),q=P([.25,.72]),r=fw,TP=6.283;
 g.fillStyle='#fff';g.beginPath();g.arc(m[0],m[1],r*.085,0,TP);g.fill();
 g.fillStyle=b.c1;g.beginPath();g.arc(m[0],m[1]-r*.045,r*.075,0,TP);g.fill();
 g.fillStyle='#fff';g.beginPath();g.arc(m[0],m[1]-r*.03,r*.022,0,TP);g.fill();
 g.beginPath();g.arc(q[0],q[1],r*.075,0,TP);g.fill();
 g.strokeStyle='#fff';g.lineWidth=Math.max(.8,r*.035);g.beginPath();for(let k=0;k<12;k++){const a=k*.5236;g.moveTo(q[0]+Math.cos(a)*r*.1,q[1]+Math.sin(a)*r*.1);g.lineTo(q[0]+Math.cos(a)*r*.155,q[1]+Math.sin(a)*r*.155)}g.stroke()}
function nepalSet(){PB.c1='#dc143c';PB.c2='#003893';PB.em=4;const a=$('pc1'),b=$('pc2');if(a)a.value=PB.c1;if(b)b.value=PB.c2;bpv()}
function rr(v){RULER=esc(v).slice(0,14);H.nm=RULER||'You'}
function bnUI(){paused=1;const o=$('ov'),ks='onkeydown="event.stopPropagation()" style="user-select:text;-webkit-user-select:text;font:inherit;width:150px"';o.style.display='flex';
 o.innerHTML='<div><h3>Your Banner</h3><p>Realm <input maxlength="18" value="'+esc(KNAME)+'" oninput="rn(this.value)" '+ks+'></p><p>Ruler <input maxlength="14" value="'+esc(RULER)+'" oninput="rr(this.value)" '+ks+'></p><canvas id="bpc" width="60" height="42"></canvas><p>Colour 1 <input id="pc1" type="color" value="'+PB.c1+'" oninput="PB.c1=this.value;bpv()"> Colour 2 <input id="pc2" type="color" value="'+PB.c2+'" oninput="PB.c2=this.value;bpv()"></p><p>'+['Stripe','Cross','Diamond','Chevron'].map((n,i)=>'<button onclick="PB.em='+i+';bpv()">'+n+'</button>').join(' ')+' <button onclick="nepalSet()">Nepal</button></p><button onclick="ovx()">Done</button></div>';bpv()}

// --- pause / mute ---
function pzShow(h){const p=$('pz');p.innerHTML=h;p.style.display='flex'}
function pzx(){$('pz').style.display='none';if(!pzT)paused=0}
function pzMenu(){pzShow('<div class="pn"><h3>Paused</h3><button class="g" onclick="pzx()">▶ Resume</button>'+(MP.on?'':'<button onclick="slotUI(1)">💾 Save Game</button><button onclick="slotUI(0)">📂 Load Game</button>')+'<button onclick="tVoice(this)">'+(voiceOn?'🔊 Narrator: On':'🔇 Narrator: Off')+'</button><button onclick="tMute(this)">'+(muted?'🔇 Sound: Off':'🔊 Sound: On')+'</button><button onclick="mpUI()">🌐 PvP Lobby</button><button onclick="quitUI(this)">🏠 Quit to Title</button></div>')}
function pauseUI(){if(!inGame||won||$('ov').style.display=='flex'||$('pz').style.display=='flex')return;paused=1;pzT=0;pzMenu()}
function setVoice(v){voiceOn=v?1:0;if(!voiceOn&&window.speechSynthesis)speechSynthesis.cancel();$('b3').textContent=voiceOn?'🔊 Narrator: On':'🔇 Narrator: Off';$('nv').textContent=voiceOn?'🔊':'🔇'}
function tVoice(b){setVoice(!voiceOn);if(b)b.textContent=voiceOn?'🔊 Narrator: On':'🔇 Narrator: Off'}
function tMute(b){muted^=1;if(ac){try{muted?ac.suspend():ac.resume()}catch(e){}}if(b)b.textContent=muted?'🔇 Sound: Off':'🔊 Sound: On'}
function quitUI(b){if(b.dataset.s){if(MP.on)mpLeave();else reloadToMenu()}else{b.dataset.s=1;b.textContent='Tap again: progress will be lost'}}
$('pb').addEventListener('pointerdown',e=>{e.preventDefault();pauseUI()});
$('nv').addEventListener('pointerdown',e=>{e.preventDefault();setVoice(!voiceOn);toast(voiceOn?'Narrator on':'Narrator muted')});
$('b3').onclick=()=>setVoice(!voiceOn);
$('rl').addEventListener('keydown',e=>e.stopPropagation());
addEventListener('keydown',e=>{if(e.target&&e.target.tagName=='INPUT')return;if(e.key=='Escape'||e.key=='p'||e.key=='P'){if($('pz').style.display=='flex'){if(!pzT)pzx()}else pauseUI()}});
document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseUI()});

// --- save / load ---
function snap(){const t=now(),pr=u=>[u.type,Math.round(u.x),Math.round(u.y),Math.round(u.hp)];
 return{v:1,seed:SEED,map:MAPI,kn:KNAME,rn:RULER,pb:PB,gear,cls,form,sieged,
  H:{x:H.x,y:H.y,hp:H.hp,wood:H.wood,stone:H.stone,gold:H.gold,food:H.food,m:H.m,face:H.face},
  HR:{x:HR.x,y:HR.y,on:HR.on,face:HR.face},pc:PC.hp,raid:Math.max(10,nextRaid-t),ts:TS,
  sl:SLOTS.map(q=>q.built?[1,Math.round(q.hp||0)]:0),
  arm:ARM.filter(u=>!u.kg&&!u.ttl).map(pr),wk:WK.map(pr),
  kg:KG.map(k=>({kd:k.known?1:0,rel:k.rel,o:k.owned?1:0,r:k.r,hp:Math.round(k.cast.hp),cool:Math.max(0,(k.cool||0)-t),wp:k.wp,ri:k.rp?k.rp.i:0,
   u:US.filter(u=>u.kg===k&&u.team&&!u.dead).map(pr)})),
  kw:KW.map(w=>[Math.round(w.x),Math.round(w.y),Math.round(w.hp)]),ri:RP.i,
  pk:PK.map(p=>p.l.map(u=>u.dead?0:Math.max(1,Math.round(u.hp)))),pkrt:PK.map(p=>p.rt?Math.max(1,p.rt-t):0),
  dn:objs.filter(o=>(o.k=='village'||o.k=='den')&&o.done).map(o=>Math.round(o.x)+','+Math.round(o.y)),
  fog:fg.toDataURL()}}
function applySave(S){const t=now();
 KNAME=S.kn||KNAME;RULER=S.rn||'';H.nm=RULER||'You';PB=Object.assign({c1:'#2a5aa8',c2:'#e8b94a',em:1},S.pb);
 gear=S.gear|0;cls=S.cls|0;form=S.form|0;sieged=S.sieged|0;
 Object.assign(H,S.H);Object.assign(HR,S.HR);PC.hp=S.pc;Object.assign(TS,S.ts);
 nextRaid=t+S.raid;nFest=t+60;nKW=t+90;
 SLOTS.forEach((q,i)=>{const z=S.sl[i];q.cl=0;if(z){if(!q.built)bld(q);if(z[1])q.hp=z[1]}else if(q.built&&q.k=='wall')brk(q)});
 WK.length=0;S.wk.forEach(a=>{const w=mkw(a[0],a[1],a[2]);w.hp=a[3]});
 ARM.slice().forEach(u=>{const j=US.indexOf(u);if(j>=0)US.splice(j,1)});ARM.length=0;S.arm.forEach(a=>{const u=mku(0,a[0],a[1],a[2]);u.hp=Math.min(u.mhp,a[3])});
 KG.forEach((k,i)=>{const z=S.kg[i];if(!z)return;k.rel=z.rel;k.known=(z.kd||z.rel!=0||z.o)?1:0;k.r=z.r;k.cool=t+z.cool;k.wp=z.wp;k.inc=t+15;k.fe=0;
  for(let j=US.length-1;j>=0;j--)if(US[j].kg===k)US.splice(j,1);
  if(z.o){k.owned=1;k.rel=1;k.cast.hp=k.cast.mhp}else{k.owned=0;k.cast.hp=z.hp;z.u.forEach(a=>{const u=mku(1,a[0],a[1],a[2],{kg:k});u.hp=Math.min(u.mhp,a[3])})}
  if(k.rp){k.rp.i=z.ri|0;for(let j=0;j<k.rp.i&&j<k.rp.p.length;j++)RD.push({x:k.rp.p[j][0],y:k.rp.p[j][1]})}});
 const km=new Map(S.kw.map(a=>[a[0]+','+a[1],a[2]]));KW.slice().forEach(w=>{const key=Math.round(w.x)+','+Math.round(w.y);if(km.has(key))w.hp=km.get(key);else kbrk(w)});
 RP.i=S.ri|0;for(let j=0;j<RP.i&&j<RP.p.length;j++)RD.push({x:RP.p[j][0],y:RP.p[j][1]});
 PK.forEach((p,i)=>{const a=S.pk[i];if(!a)return;p.l.forEach((u,j)=>{if(a[j])u.hp=Math.min(u.mhp,a[j]);else u.dead=-1e6});p.rt=S.pkrt[i]?t+S.pkrt[i]:0});
 const dn=new Set(S.dn);objs.forEach(o=>{if((o.k=='village'||o.k=='den')&&dn.has(Math.round(o.x)+','+Math.round(o.y)))o.done=1});
 const im=new Image();im.onload=()=>{fx.globalCompositeOperation='source-over';fx.clearRect(0,0,110,110);fx.drawImage(im,0,0)};im.src=S.fog;
 cam.x=H.x-VW/2;cam.y=H.y-VH/2;$('mnt').textContent=H.m?'Dismount':'Mount'}
function slotUI(sv,msg){let h='<div class="pn"><h3>'+(sv?'Save Game':'Load Game')+'</h3>';
 for(let i=1;i<=3;i++){let m=null;try{m=JSON.parse(stg.g(MK+i))}catch(e){}
  h+='<button'+(!sv&&!m?' disabled':'')+' onclick="'+(sv?'doSave':'doLoad')+'('+i+')">Slot '+i+(m?'<br>'+esc(m.n)+' · 👑'+esc(m.c)+'<br>'+esc(m.d):'<br>Empty')+'</button>'}
 h+=(msg?'<p>'+esc(msg)+'</p>':'')+'<button onclick="'+(pzT?'pzx()':'pzMenu()')+'">◀ Back</button></div>';pzShow(h)}
function doSave(i){let msg;try{const d=new Date(),meta={n:KNAME,c:KG.filter(k=>k.owned).length+'/'+KG.length,d:d.toLocaleDateString(undefined,{month:'short',day:'numeric'})+' '+d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})};
 if(stg.s(SK+i,JSON.stringify(snap()))&&stg.s(MK+i,JSON.stringify(meta))){msg='Saved to slot '+i;sfx('recruit')}else msg='Save failed: this browser blocks storage'}catch(e){msg='Save failed'}slotUI(1,msg)}
function doLoad(i){if(!stg.g(SK+i))return slotUI(0,'That slot is empty');if(stg.s('cor_pend',String(i)))reloadToMenu();else slotUI(0,'Load failed: this browser blocks storage')}
function cont(){if(window.speechSynthesis){const p=new SpeechSynthesisUtterance(' ');p.volume=0;speechSynthesis.speak(p)}aud();pzT=0;$('pz').style.display='none';inGame=1;sq++;paused=0;say('Welcome back, my liege.',1)}
$('b4').onclick=()=>{pzT=1;slotUI(0)};
if(PEND){try{applySave(PEND)}catch(e){setTimeout(()=>{throw e},0)}$('menu').style.display='none';pzT=1;pzShow('<div class="pn"><h3>Reign Restored</h3><p>'+esc(KNAME)+' awaits your return, my liege.</p><button class="g" onclick="cont()">▶ Continue</button></div>')}

// ===== v7/v8: PvP lobby (2-6 seats, bots, teams, merchants, 3 min peace) =====
const MP={on:0,code:'',host:0,id:Math.random().toString(36).slice(2,8),conns:[],peers:new Map(),st:'',up:0,tS:0,tA:0,tB:0,tD:0,tB2:0};
const CODEC='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',TYS=Object.keys(UT),LBP=[],nz=(v,d)=>(v!==null&&v!==''&&isFinite(+v))?+v:d;
let mpL=now(),lastWarn=0;
const peace=()=>PV.live&&now()<PV.peaceEnd;
function mpSend(m,ex){MP.conns.forEach(q=>{try{if(q!==ex&&q.open&&(!m.to||!MP.host||q.pid===m.to))q.send(m)}catch(e){}})}
function mpClean(v,d){return /^#[0-9a-fA-F]{6}$/.test(v)?v:d}


// ===== v8: bots (host simulates them; everyone sees ordinary rival peers) =====
const BOT={},BKI=SLOTS.indexOf(K1),BRI=[];SLOTS.forEach((q,i)=>{if(q.k=='wall'&&q.ring)BRI.push(i)});
const RM=new Map(BRI.map((s,j)=>[s,j])),BOTTY=['pike','sword','bow','sword','cav','bow','pike','ram'];
function botMk(P){BOT[P.id]={id:P.id,P,tm:P.tm,nm:P.n,hp:3000,mhp:3000,hh:100,gold:70,x:P.lx,y:P.ly+40,u:[],n:0,tr:8,at:0,tg:null,wl:BRI.map(()=>100),dq:{},tq:0,ts:0,tb:0,en:[],te:0,inc:.8}}
function botFoes(b){const L=[];MP.peers.forEach(Q=>{if(!Q.out&&Q!==b.P&&Q.tm!==b.tm)L.push({x:Q.lx,y:Q.ly})});if(PC.hp>0&&!won&&ME.tm!==b.tm)L.push({x:CX,y:CX});return L}
function botEnts(b){const L=[];
 MP.peers.forEach(Q=>{if(Q.out||Q===b.P||Q.tm===b.tm)return;
  if(Q.hp>0)L.push({x:Q.x,y:Q.y,k:'h',i:0,Q});
  Q.gu.forEach(g=>{if(g.hp>0)L.push({x:g.x,y:g.y,k:'u',i:g.gi,Q})});
  Q.gw.forEach(w=>{if(w.hp>0)L.push({x:w.x,y:w.y,k:'w',i:w.gi,Q,s:1})});
  if(Q.ck&&Q.ck.hp>0)L.push({x:Q.ck.x,y:Q.ck.y+6,k:'c',i:0,Q,s:1})});
 if(PC.hp>0&&!won&&ME.tm!==b.tm){if(H.hp>0)L.push({x:H.x,y:H.y,k:'h',i:0,host:1});
  ARM.forEach(u=>{if(!u.dead)L.push({x:u.x,y:u.y,k:'u',i:u.uid,host:1})});
  WALLS.forEach(w=>{if(w.hp>0)L.push({x:w.x,y:w.y,k:'w',i:w.cust?1000+w.ci:SLOTS.indexOf(w),host:1,s:1})});
  L.push({x:PC.x,y:PC.y+6,k:'c',i:0,host:1,s:1})}
 return L}
function botHit(b,u,d,e){let dm=u.type=='ram'?(e.s?45:0):d.dmg;if(!dm)return;if(e.s&&u.type!='ram')dm*=.45;
 const Q=e.host?'H':e.Q.id,key=e.k+':'+e.i;(b.dq[Q]=b.dq[Q]||{})[key]=(b.dq[Q][key]||0)+dm}
function botTick(dt,t){for(const id in BOT){const b=BOT[id],P=b.P;if(P.out){delete BOT[id];continue}
 b.hp=Math.min(b.mhp,b.hp+1.5*dt);let fa=0;if(ME.tm!==b.tm)fa+=ARM.length;MP.peers.forEach(Q=>{if(!Q.out&&Q.tm!==b.tm)fa+=Q.gu.length});const bs=1+Math.min(1,fa/200);b.gold+=b.inc*bs*dt;b.tr-=dt*bs;
 if(b.tr<=0){b.tr=11+Math.random()*7;if(b.u.length<Math.min(260,6+(((window.GT_?GT_():0)/60*2.5)|0)+(fa*.6|0))){const ty=BOTTY[Math.floor(Math.random()*BOTTY.length)],c=UT[ty].cost||{},cost=((c.gold||0)+(c.wood||0)*.4+(c.stone||0)*.5+(c.food||0)*.5)||20;
  if(b.gold>=cost){b.gold-=cost;const a=Math.random()*6.283;b.u.push({uid:++b.n,type:ty,x:b.x+Math.cos(a)*30,y:b.y+Math.sin(a)*24,hp:UT[ty].hp,mhp:UT[ty].hp,cd:0,atk:0,face:1})}}}
 const pe=peace();if(!pe){if(!b.at&&b.u.length>=10)b.at=1;if(b.at&&b.u.length<3)b.at=0}else b.at=0;
 if(t>b.te){b.te=t+3;b.en=botEnts(b);let best=null,bd=1e9;botFoes(b).forEach(f=>{const d=Math.hypot(f.x-b.x,f.y-b.y);if(d<bd){bd=d;best=f}});b.tg=best}
 b.u.forEach(u=>{const d=UT[u.type];u.cd-=dt;u.atk-=dt;let tg=null,bd=1e9;
  if(!pe)for(const e of b.en){if(u.type=='ram'&&!e.s)continue;const dd=Math.hypot(e.x-u.x,e.y-u.y)+(e.s?26:0);if(dd<bd){bd=dd;tg=e}}
  let goal,isT=0;if(tg&&bd<(b.at?420:150)){goal=tg;isT=1}else if(b.help&&t<b.helpT)goal={x:b.help.x+((u.uid*37)%60)-30,y:b.help.y+((u.uid*53)%50)-10};else if(b.at&&b.tg)goal=b.tg;else goal={x:b.x+((u.uid*37)%60)-30,y:b.y+((u.uid*53)%50)-10};
  const dx=goal.x-u.x,dy=goal.y-u.y,L=Math.hypot(dx,dy),rg=(d.rng||15)+4;
  if(isT&&L<=rg){u.face=dx>=0?1:-1;if(u.cd<=0){u.cd=d.cd||1;u.atk=.25;botHit(b,u,d,tg)}}
  else if(L>3){const s=Math.min((d.spd||50)*dt,L);u.x+=dx/L*s;u.y+=dy/L*s;if(Math.abs(dx)>1)u.face=dx>0?1:-1}});
 if(t>b.tq){b.tq=t+.3;for(const Q in b.dq){const a=Object.keys(b.dq[Q]).slice(0,40).map(k=>{const z=k.split(':');return[z[0],+z[1],Math.round(b.dq[Q][k])]}).filter(x=>x[2]>0);b.dq[Q]={};if(!a.length)continue;
  const m={t:'d',id:b.id,to:Q==='H'?MP.id:Q,n:b.nm,a};if(Q==='H')applyD(m);else if(BOT[Q])botD(m);else mpSend(m)}}
 if(t>b.ts){b.ts=t+.25;const s=toSh(b.x,b.y),u=[];
  mpRecv({t:'s',id:b.id,x:Math.round(s[0]*10)/10,y:Math.round(s[1]*10)/10,f:1,m:0,hp:Math.round(b.hh),mhp:100,ar:[]},null);
  b.u.forEach(a=>{const q=toSh(a.x,a.y);u.push(a.uid,TYS.indexOf(a.type),Math.round(q[0]),Math.round(q[1]),Math.round(a.hp),a.face>0?1:0,a.atk>0?1:0)});
  mpRecv({t:'a',id:b.id,u},null)}
 if(t>b.tb){b.tb=t+1.2;mpRecv({t:'b',id:b.id,hp:Math.round(b.hp),mh:b.mhp,sl:SLOTS.map((q,i)=>i===BKI?1:(RM.has(i)&&b.wl[RM.get(i)]>0?Math.round(b.wl[RM.get(i)]):0)),c1:P.c1,c2:P.c2,em:P.em,p:P.p,s:P.s,c3:P.c3,n:b.nm,kn:P.kn},null)}}}
function botD(m){
 if(m.t=='g'){const b=BOT[m.to];if(b)b.gold+=(m.r=='gold'?1:.5)*Math.max(0,Math.min(100,m.n|0));return}
 if(m.t=='q'){const b=BOT[m.to],Q=m.id===MP.id?null:MP.peers.get(m.id);if(!b||b.P.out)return;if((Q?Q.tm:ME.tm)!==b.tm)return;b.help=Q?{x:Q.lx,y:Q.ly+30}:{x:CX,y:CX+30};b.helpT=now()+100;if(!Q)toast(b.nm+' sends troops to defend you');return}
 const b=BOT[m.to];if(!b||b.P.out||peace())return;const A=MP.peers.get(m.id),at=m.id===MP.id?ME.tm:A&&A.tm;if(at===b.tm)return;
 (Array.isArray(m.a)?m.a.slice(0,40):[]).forEach(e=>{if(!Array.isArray(e))return;const k=e[0],i=+e[1],d=Math.min(400,+e[2]||0);if(!(d>0))return;
  if(k=='u'){const j=b.u.findIndex(x=>x.uid===i);if(j>=0&&(b.u[j].hp-=d)<=0)b.u.splice(j,1)}
  else if(k=='h'){b.hh-=d;if(b.hh<=0)b.hh=100}
  else if(k=='c'){b.hp-=d;if(b.hp<=0){b.u=[];mpRecv({t:'e',id:b.id},null)}}
  else if(k=='w'){const j=RM.get(i);if(j!==undefined&&b.wl[j]>0)b.wl[j]=Math.max(0,b.wl[j]-d)}})}

// ===== v8: travelling merchant (weapons for the hero, balanced for a low-gold economy) =====
const MER={on:0,until:0,next:0,stock:[],o:null,sh:0,img:null},MWPN=[
{t:1,r:'Good',c:'#9c6',b:.15,p:90,w:45,n:['Iron Blade','Hunter’s Saber']},
{t:2,r:'Fine',c:'#6cf',b:.3,p:180,w:30,n:['Steel Warblade','Duelist’s Edge']},
{t:3,r:'Rare',c:'#c8f',b:.5,p:330,w:16,n:['Knight’s Greatsword','Wolfbane']},
{t:4,r:'Epic',c:'#fa4',b:.8,p:540,w:7,n:['Flamebrand','Stormcaller']},
{t:5,r:'Power',c:'#f55',b:1.2,p:850,w:3,n:['Crown-Breaker','Dragonfang']}];
function merRoll(){const ts=[],pool=MWPN.slice();
 while(ts.length<3){const tot=pool.reduce((s,x)=>s+x.w,0);let r=Math.random()*tot,i=0;for(;i<pool.length-1;i++){r-=pool[i].w;if(r<0)break}ts.push(pool.splice(i,1)[0])}
 if(!ts.some(x=>x.t<=2))ts[2]=MWPN[Math.random()<.5?0:1];
 return ts.sort((a,b)=>a.t-b.t).map(x=>{const sale=Math.random()<.35?.8+Math.random()*.1:1;return{t:x.t,r:x.r,c:x.c,b:x.b,n:x.n[Math.floor(Math.random()*2)],base:x.p,price:Math.round(x.p*sale/5)*5,sold:0}})}
function merTick(t){if(!MER.next)MER.next=t+70+Math.random()*50;
 if(!MER.on&&t>MER.next){MER.on=1;MER.until=t+75;MER.stock=merRoll();MER.img=MER.img||stall('#e8b030');MER.o={k:'merch',img:MER.img,x:CX+40,y:CX+34,w:18,h:14,dead:0,done:0};objs.push(MER.o);$('mer').style.display='block';toast('🛒 A travelling merchant has set up at your camp!');sfx('loot')}
 else if(MER.on&&t>MER.until){MER.on=0;MER.next=t+110+Math.random()*90;const j=objs.indexOf(MER.o);if(j>=0)objs.splice(j,1);MER.o=null;$('mer').style.display='none';if(MER.sh){MER.sh=0;ovx()}toast('The merchant packs up and leaves')}
 if(MER.on)$('mer').textContent='🛒 Merchant '+Math.ceil(MER.until-t)+'s'}
function merUI(){if(!MER.on)return;if(Math.hypot(H.x-CX,H.y-CX)>240){toast('The merchant is at your camp');return}
 MER.sh=1;const e=$('ov'),ti=H.wt?Math.round((H.wbase||0)*.5):0;paused=1;e.style.display='flex';
 e.innerHTML='<div style="width:min(94vw,440px)"><h3>🛒 Travelling Merchant</h3><p>Gold: '+(H.gold|0)+' · Weapon: '+(H.wt?esc(H.wn)+' (+'+Math.round(H.wb*100)+'%)':'none')+'<br>Your old weapon trades in for '+ti+'g</p>'
 +MER.stock.map((s,i)=>{const net=Math.max(0,s.price-ti);return '<p style="margin:6px 0"><b style="color:'+s.c+'">'+s.r+'</b> '+esc(s.n)+' · +'+Math.round(s.b*100)+'% hero damage<br>'+(s.sold?'Sold':s.t<=(H.wt|0)?'Not an upgrade':`<button onclick="merBuy(${i})">Buy · ${net}g${s.price<s.base?' (sale)':''}</button>`)+'</p>'}).join('')
 +'<p style="margin:6px 0">Sell to the merchant<br>'+[['wood',22],['stone',38],['food',16]].map(([r,g])=>`<button onclick="merSell('${r}',${g})">10 ${r} → ${g}g</button> <button onclick="merSell('${r}',${g},10)">100 → ${g*10}g</button>`).join('<br>')+'</p><button onclick="MER.sh=0;ovx()">Close</button></div>'}
function merBuy(i){const s=MER.stock[i];if(!MER.on||!s||s.sold||s.t<=(H.wt|0))return;const ti=H.wt?Math.round((H.wbase||0)*.5):0,net=Math.max(0,s.price-ti);
 if(H.gold<net){sfx('no');toast('You need '+net+' gold');return}
 H.gold-=net;H.wt=s.t;H.wb=s.b;H.wn=s.n;H.wbase=s.base;s.sold=1;sfx('recruit');toast('Bought '+s.n+': your hero hits '+Math.round(s.b*100)+'% harder');hud();merUI()}
function merSell(r,g,k){k=k||1;const n=10*k;if(!MER.on||H[r]<n){sfx('no');toast('You need '+n+' '+r);return}if(H.gold+g*k>RESMAX){sfx('no');toast('Gold storage full');return}H[r]-=n;H.gold+=g*k;sfx('loot');hud();merUI()}
$('mer').addEventListener('pointerdown',e=>{e.preventDefault();merUI()});

// ---- lobby ----
function lbMine(){return{n:esc($('rl').value).slice(0,14).trim()||'Player',kn:esc($('kn').value).slice(0,18).trim()}}
function lbRender(){if(!MP.on)return;
 $('lbl').innerHTML=LBP.map((p,i)=>'<div onclick="lbTeam('+i+')"><i style="background:'+PAL[i%6][0]+';border-color:'+PAL[i%6][1]+'"></i>'+(p.bot?'🤖 ':'')+esc(p.n)+' · T'+(p.tm||1)+(i==0?' 👑':'')+(p.id===MP.id?' (you)':'')+'</div>').join('');
 $('lbh').textContent='Lobby '+MP.code+' · '+LBP.length+'/6 seats';
 $('lbm').textContent=MP.up?(MP.host?(LBP.length<2?'Add a bot or wait for a friend… code '+MP.code:'Tap a name to change its team. Same team = allies.'):'Tap your name to change your team. Waiting for the host…'):MP.st;
 $('lbb').innerHTML=MP.host&&MP.up?'<button class="mb" onclick="lbBot(-1)">−</button> 🤖 Bots '+LBP.filter(p=>p.bot).length+' <button class="mb" onclick="lbBot(1)">+</button> <button class="mb" onclick="lbAlly()">🤝 Ally bots</button> <button class="mb" onclick="window.MT&&MT.open(\'fr\')">👥 Invite friends</button>':'';
 $('lbs').style.display=MP.host?'':'none';$('lbs').disabled=LBP.length<2||!MP.up}
const BN=['Aldric','Brenna','Cedric','Dagna','Eadric','Fenna'];
function ftm(){let k=1;while(LBP.some(p=>(p.tm||1)===k))k++;return Math.min(k,6)}
function lbFix(){if(!MP.host)return;const want=Math.max(0,Math.min(MP.nb|0,6-LBP.filter(p=>!p.bot).length)),bs=LBP.filter(p=>p.bot);while(bs.length>want)LBP.splice(LBP.indexOf(bs.pop()),1);
 for(let i=bs.length;i<want;i++){let k=1;while(LBP.some(p=>p.id==='bot'+k))k++;LBP.push({id:'bot'+k,n:'Bot '+BN[(k-1)%6],kn:'',bot:1,tm:ftm()})}}
function lbBot(d){if(!MP.host||PV.live)return;const hu=LBP.filter(p=>!p.bot).length;MP.nb=Math.max(0,Math.min(6-hu,LBP.filter(p=>p.bot).length+d));lbFix();lbBroadcast()}
function lbAlly(){if(!MP.host)return;const me=LBP.find(p=>p.id===MP.id);LBP.forEach(p=>{if(p.bot)p.tm=me.tm||1});lbBroadcast()}
function lbTeam(i){const p=LBP[i];if(!p||PV.live)return;
 if(MP.host){if(!p.bot&&p.id!==MP.id)return;p.tm=(p.tm||1)%6+1;lbBroadcast()}
 else if(p.id===MP.id&&MP.up){p.tm=(p.tm||1)%6+1;lbRender();mpSend({t:'nm',id:MP.id,n:p.n,kn:p.kn,tm:p.tm})}}
function lbBroadcast(){lbRender();mpSend({t:'lb',id:MP.id,p:LBP})}
function lbJoin(m,q){
 if(PV.live){try{q.send({t:'no',id:MP.id,to:m.id,r:'Game already started'});setTimeout(()=>q.close(),400)}catch(e){}return}
 if(!LBP.some(p=>p.id===m.id)){
  if(LBP.filter(p=>!p.bot).length>=6){try{q.send({t:'no',id:MP.id,to:m.id,r:'Lobby is full (6/6)'});setTimeout(()=>q.close(),400)}catch(e){}return}
  LBP.push({id:String(m.id).slice(0,8),n:esc(m.n||'Player').slice(0,14).trim()||'Player',kn:esc(m.kn||'').slice(0,18),tm:ftm()});lbFix()}
 q.pid=m.id;lbBroadcast()}
function lbEdit(){if(!MP.on||PV.live)return;const o=lbMine();
 if(MP.host){const me=LBP.find(p=>p.id===MP.id);if(me){me.n=o.n;me.kn=o.kn;lbBroadcast()}}
 else if(MP.up)mpSend({t:'nm',id:MP.id,n:o.n,kn:o.kn})}
function lbStart(){if(!MP.host||LBP.length<2||LBP.length>6||PV.live)return;
 if(new Set(LBP.map(p=>p.tm||1)).size<2){$('lbm').textContent='Need at least two different teams to fight';return}
 const p=LBP.map((x,i)=>({id:x.id,n:x.n,kn:x.kn,s:i,tm:x.tm||1,bot:x.bot?1:0}));mpSend({t:'go',id:MP.id,p});pvStart(p)}

// ---- game start ----
function mkPeer(p){const lx=p.bx-ME.bx+CX,ly=p.by-ME.by+CX,
 P={id:p.id,n:p.n,kn:p.kn,s:p.s,tm:p.tm,bot:p.bot,bx:p.bx,by:p.by,lx,ly,x:lx,y:ly+40,tx:lx,ty:ly+40,f:1,m:0,mv:0,fr:0,ft:0,hp:100,mhp:100,c1:PAL[p.s][0],c2:PAL[p.s][1],em:PAL[p.s][2],seen:now(),out:0,gu:new Map(),sl:[],gw:[],dq:{},ck:null,gh:1,gk:'h',gi:0};
 P.pl=P;pvMask(P);MP.peers.set(p.id,P);
 for(let i=objs.length;i--;){const o=objs[i];if((o.k=='tree'||o.k=='rock'||o.k=='village'||o.k=='den')&&Math.hypot(o.x-lx,o.y-ly)<345)objs.splice(i,1)}
 const ad=(k,img,x,y,w,h,e)=>{objs.push(Object.assign({k,img,x,y,w,h,dead:0,done:0,gh:1,pl:P},e||{}))};
 [[188,-24],[188,26],[319,-24],[319,26]].forEach(d=>ad('tower',TX.tower,lx+d[0],ly+d[1],16,36,{gt:1,kg:P}));
 ad('fire',TX.fire,lx,ly,16,20);
 for(let x=170;x<=340;x+=8)[-8,0,8].forEach(d=>RD.push({x:Math.round((lx+x)/8)*8,y:Math.round((ly+d)/8)*8}))}
function pvStart(list){
 if(PV.live||!Array.isArray(list)||list.length<2||list.length>6)return;
 const L=list.map((p,i)=>({id:String(p.id).slice(0,8),n:esc(p.n).slice(0,14)||'Player',kn:esc(p.kn).slice(0,18)||DN[i%DN.length],s:i,tm:Math.max(1,Math.min(6,(p.tm|0)||1)),bot:p.bot?1:0})),me=L.find(p=>p.id===MP.id);
 if(!me)return;
 const n=L.length,R=n==2?900:1000;
 L.forEach(p=>{const a=-Math.PI/2+p.s*6.2832/n;p.bx=CX+Math.cos(a)*R;p.by=CX+Math.sin(a)*R});
 ME.bx=me.bx;ME.by=me.by;ME.s=me.s;ME.tm=me.tm;PV.n=n;PV.on=1;
 RULER=me.n;H.nm=RULER;KNAME=me.kn;PB=(window.bnCustom&&bnCustom())||{c1:PAL[me.s][0],c2:PAL[me.s][1],em:PAL[me.s][2]};
 L.forEach(p=>{if(p!==me)mkPeer(p)});
 if(window.speechSynthesis)speechSynthesis.cancel();
 $('menu').style.display='none';$('dp').style.display='none';
 PV.live=1;PV.peaceEnd=now()+420;if(MP.host)MP.peers.forEach(P=>{if(P.bot)botMk(P)});PV.ann=0;PV.a30=0;inGame=1;paused=0;sq++;
 toast('☮ 7 minutes of peace. Build your economy and army!');
 say('Rise, my liege. Seven minutes of peace begin now. Prepare for war.',1)}

// ---- scoring / elimination ----
function pOut(P,why){if(P.out)return;P.out=1;P.gu.clear();P.dq={};
 for(let i=objs.length;i--;)if(objs[i].pl===P)objs.splice(i,1);
 P.sl=[];P.gw=[];P.ck=null;
 if(why.indexOf('eliminated')>=0)objs.push({k:'ruin',img:TX.ruin,x:P.lx,y:P.ly-30,w:48,h:40,dead:0,done:0,gh:1});
 feed(P.n+why);toast(P.n+why);sfx('horn');pvCheck()}
function pvCheck(){if(!PV.live||won||!MP.up)return;let a=0;MP.peers.forEach(P=>{if(!P.out&&P.tm!==ME.tm)a++});
 if(!a){won=1;sfx('win');say('Every rival has fallen. The Crown of Realms is yours, my liege.',1);
  $('ov').innerHTML='<div><h3>👑 Last crown standing!</h3><p>Every rival kingdom has fallen. You rule the realm.</p><button onclick="ovx()">Continue</button> <button onclick="mpLeave()">Leave</button></div>';$('ov').style.display='flex'}}
function pvTxt(){if(!PV.on)return'';let a=PC.hp>0?1:0;MP.peers.forEach(P=>{if(!P.out)a++});
 const r=PV.peaceEnd-now(),pc=$('pcd');
 if(PV.live&&r>0){const s=Math.ceil(r);pc.style.display='block';pc.textContent='☮ PEACE '+((s/60)|0)+':'+('0'+s%60).slice(-2);return'👥'+a+'/'+PV.n+' ☮'}
 pc.style.display='none';return'👥'+a+'/'+PV.n+' ⚔'}

// ---- ghosts: enemy bases, armies and combat ----
function syncBase(P,m){const sl=m.sl;if(!Array.isArray(sl))return;
 for(let i=0;i<NB&&i<sl.length;i++){const q=SLOTS[i],v=+sl[i]||0,o=P.sl[i];
  if(v>0){if(!o){const z={wall:[14,16],farm:[18,10],home:[28,24],keep:[56,48],tower:[16,36]}[q.k];if(!z)continue;
    const n={k:q.k,img:TX[q.k],x:P.lx+q.x-CX,y:P.ly+q.y-CX,w:z[0],h:z[1],dead:0,done:0,gh:1,pl:P,gk:q.k=='wall'?'w':'x',gi:i,hp:v,mhp:q.k=='wall'?100:200};
    if(q.k=='tower')n.kg=P;P.sl[i]=n;objs.push(n);if(q.k=='keep')P.ck=n}
   else if(q.k=='wall')o.hp=v}
  else if(o){const j=objs.indexOf(o);if(j>=0)objs.splice(j,1);P.sl[i]=null;if(P.ck===o)P.ck=null}}
 P.gw=P.sl.filter(o=>o&&o.gk=='w');
 if(P.ck){P.ck.hp=nz(m.hp,P.ck.hp);P.ck.mhp=Math.max(1,nz(m.mh,3000));P.ck.gk='c';P.ck.gi=0}}
function ghostTargets(){const L=[];MP.peers.forEach(P=>{if(P.out||P.tm===ME.tm)return;if(P.hp>0)L.push(P);P.gu.forEach(g=>{if(g.hp>0)L.push(g)})});return L}
function nearStruct(x,y,r){let b=null,bd=r;
 MP.peers.forEach(P=>{if(P.out||P.tm===ME.tm||Math.abs(x-P.lx)>320||Math.abs(y-P.ly)>280)return;
  P.gw.forEach(w=>{if(w.hp<=0)return;const d=Math.hypot(w.x-x,w.y-y);if(d<bd){bd=d;b=w}});
  if(P.ck&&P.ck.hp>0){const d=Math.hypot(P.ck.x-x,P.ck.y-14-y)-20;if(d<bd){bd=d;b=P.ck}}});
 return b?{e:b,d:bd}:null}
function sendD(P,k,i,d){if(!P||P.out||!(d>0))return;const key=k+':'+i;P.dq[key]=(P.dq[key]||0)+d}
function flushD(){MP.peers.forEach(P=>{const ks=Object.keys(P.dq);if(!ks.length)return;
 const a=ks.slice(0,40).map(key=>{const z=key.split(':');return[z[0],+z[1],Math.round(P.dq[key])]}).filter(x=>x[2]>0);P.dq={};
 if(a.length){const m={t:'d',id:MP.id,to:P.id,n:RULER||'Rival',a};if(P.bot&&MP.host)botD(m);else mpSend(m)}})}
function gdmg(g,dmg){if(g.gk=='w'||g.gk=='c')dmg*=.5;dmg=Math.max(1,Math.round(dmg));
 sendD(g.pl,g.gk,g.gi,dmg);g.hp=Math.max(0,g.hp-dmg);g.hit=.15;sfx('hit',g.x,g.y);
 FX.push({x:g.x,y:g.y-(g.gk=='w'?14:22),t:'-'+dmg,l:.7,c:'#fff'});
 for(let i=0;i<3;i++)PS.push({x:g.x,y:g.y-8,vx:(Math.random()-.5)*60,vy:-Math.random()*40,l:.45,c:(g.gk=='w'||g.gk=='c')?'#8a8a98':'#a8142a'});
 if(g.gk=='u'||g.gk=='h')splat(g,g.hp<=0)}
function gswing(dm){if(!PV.war)return;MP.peers.forEach(P=>{if(P.out||P.tm===ME.tm)return;
 const hit=e=>{const dx=e.x-H.x,dy=e.y-H.y;return Math.hypot(dx,dy)<36&&(dx*H.fx+dy*H.fy>-5)};
 if(P.hp>0&&hit(P))hurt(P,dm,H);P.gu.forEach(g=>{if(g.hp>0&&hit(g))hurt(g,dm,H)});
 if(Math.abs(P.lx-H.x)<320&&Math.abs(P.ly-H.y)<280)P.gw.forEach(w=>{if(w.hp>0&&Math.hypot(w.x-H.x,w.y-H.y)<24)hurt(w,dm,H)})})}
function gwalls(dt){if(!PV.live)return;const U=[H].concat(ARM);
 MP.peers.forEach(P=>{if(P.out||!P.gw.length||P.tm===ME.tm)return;
  U.forEach(u=>{if(Math.abs(u.x-P.lx)>320||Math.abs(u.y-P.ly)>280)return;
   P.gw.forEach(w=>{if(w.hp<=0||Math.abs(u.x-w.x)>16||Math.abs(u.y-w.y)>16)return;
    const ex=u.x-w.x,ey=u.y-w.y,d=Math.hypot(ex,ey);
    if(d<9&&d>.1){u.x+=ex/d*(9-d);u.y+=ey/d*(9-d)}
    if(PV.war&&P.tm!==ME.tm&&u.type=='ram'&&d<16){sendD(P,'w',w.gi,45*dt);w.hp-=45*dt}})})})}
function applyD(m){if(!PV.live||peace()||(won&&!window.GENM))return;window.LAT=m.id;{const A=MP.peers.get(m.id);if(A&&A.tm===ME.tm)return;if(A&&!A.known&&window.discP)discP(A)}const nm=esc(m.n).slice(0,14)||'Rival';let warn=0;
 (Array.isArray(m.a)?m.a.slice(0,40):[]).forEach(e=>{if(!Array.isArray(e))return;const k=e[0],i=+e[1],d=Math.min(400,+e[2]||0);if(!(d>0))return;
  if(k=='u'){const u=ARM.find(x=>x.uid===i);if(u&&!u.dead)hurt(u,d,{nm})}
  else if(k=='h')hurt(H,d,{nm});
  else if(k=='c'){hitPC(d);warn=1}
  else if(k=='w'){if(i>=1000){const q=CW[i-1000];if(q){q.hp-=d;if(q.hp<=0)cwBreak(q);warn=1}}else{const q=SLOTS[i];if(q&&q.built&&q.k=='wall'){q.hp-=d;if(q.hp<=0)brk(q);warn=1}}}});
 if(warn&&now()-lastWarn>8){lastWarn=now();toast(nm+' is attacking your castle!');sfx('horn')}}

// ---- networking ----
function mpRecv(m,from){if(!m||typeof m.id!='string'||m.id===MP.id)return;
 if(from)from.pid=m.id;
 if(MP.host&&m.t!='hi'&&m.t!='nm')mpSend(m,from);
 if(MP.host&&m.to&&BOT[m.to]){botD(m);return}
 if(m.to&&m.to!==MP.id)return;
 const P=MP.peers.get(m.id);
 switch(m.t){
  case 'hi':if(MP.host)lbJoin(m,from);break;
  case 'nm':if(MP.host){const p=LBP.find(x=>x.id===m.id);if(p){p.n=esc(m.n).slice(0,14).trim()||'Player';p.kn=esc(m.kn).slice(0,18);if(m.tm)p.tm=Math.max(1,Math.min(6,m.tm|0));lbBroadcast()}}break;
  case 'lb':if(!MP.host&&!PV.live&&Array.isArray(m.p)){LBP.length=0;m.p.slice(0,6).forEach(p=>LBP.push({id:String(p.id).slice(0,8),n:esc(p.n).slice(0,14),kn:esc(p.kn).slice(0,18),tm:Math.max(1,Math.min(6,p.tm|0||1)),bot:p.bot?1:0}));lbRender()}break;
  case 'no':MP.st=esc(m.r);MP.up=0;lbRender();break;
  case 'go':if(!MP.host)pvStart(m.p);break;
  case 'bye':if(PV.live&&P)pOut(P,' left the realm');break;
  case 'e':if(P){P.by=String(m.by||'').slice(0,8);P.hi=m.hi|0;pOut(P,' has been eliminated!')}break;
  case 'd':applyD(m);break;
  case 'g':if(PV.live&&P&&P.tm===ME.tm&&['wood','stone','food','gold'].includes(m.r)){const n=Math.max(0,Math.min(100,m.n|0));H[m.r]=Math.min(RESMAX,H[m.r]+n);toast(P.n+' sent you '+n+' '+m.r);sfx('loot');hud()}break;
  case 'q':if(PV.live&&P&&P.tm===ME.tm){if(!AL.req.some(r=>r.id===P.id))AL.req.push({id:P.id,n:P.n});toast('📣 '+P.n+' asks for troops! Open Allies');sfx('horn')}break;
  case 's':{if(!P||P.out)break;const x=nz(m.x,NaN),y=nz(m.y,NaN);if(!isFinite(x)||!isFinite(y))break;
   const q=toLo(x,y);P.tx=q[0];P.ty=q[1];P.f=m.f<0?-1:1;P.m=m.m?1:0;P.hp=Math.max(0,nz(m.hp,100));P.mhp=Math.max(1,nz(m.mhp,100));P.seen=now();
   if(Array.isArray(m.ar))for(let i=0;i+3<m.ar.length&&i<160;i+=4){const a=toLo(+m.ar[i],+m.ar[i+1]);if(isFinite(a[0])&&isFinite(a[1]))AR.push({x:a[0],y:a[1],vx:+m.ar[i+2]||0,vy:+m.ar[i+3]||0,team:2,vis:1,dmg:0,l:.6,from:null})}
   break}
  case 'a':{if(!P||P.out||!Array.isArray(m.u))break;P.seen=now();const u=m.u,seen=new Set();
   for(let i=0;i+6<u.length&&i<3600;i+=7){const uid=u[i]|0,ty=TYS[u[i+1]|0];if(!ty)continue;const q=toLo(+u[i+2],+u[i+3]);if(!isFinite(q[0])||!isFinite(q[1]))continue;
    seen.add(uid);let g=P.gu.get(uid);
    if(!g){g={uid,type:ty,x:q[0],y:q[1],ph:0,hit:0,atk:0,dead:0,team:1,gh:1,gk:'u',gi:uid,pl:P,kg:P,nm:UT[ty].n,mhp:UT[ty].hp,face:1,hp:UT[ty].hp};P.gu.set(uid,g)}
    g.tx=q[0];g.ty=q[1];g.hp=Math.max(0,+u[i+4]||0);g.face=u[i+5]?1:-1;if(u[i+6])g.atk=.3}
   P.gu.forEach((g,k)=>{if(!seen.has(k))P.gu.delete(k)});break}
  case 'b':{if(!P||P.out)break;P.seen=now();P.c1=mpClean(m.c1,P.c1);P.c2=mpClean(m.c2,P.c2);P.em=Math.max(0,Math.min(4,m.em|0));if(m.bx){P.p=Math.max(0,Math.min(10,m.bp|0));P.s=Math.max(0,Math.min(10,m.bs|0));P.c3=mpClean(m.bc,'#f3ecd8')}else{P.p=P.s=P.c3=undefined}if(m.hi!==undefined)P.hi=m.hi|0;
   P.n=esc(m.n||P.n).slice(0,14)||P.n;P.kn=esc(m.kn||P.kn).slice(0,18)||P.kn;syncBase(P,m);syncCW(P,m.cw);if(window.syncCP)syncCP(P,m.cp);if(window.syncDG&&m.dg)syncDG(P,m.dg.dc,m.dg.cg);break}
 }}
function mpInit(){if(!MPI)return;$('dp').style.display='none';MP.on=1;MP.code=MPI.code;MP.host=MPI.host?1:0;MP.st='Connecting…';
 $('rp').style.display='none';$('ttl').style.animation='none';$('ttl').classList.add('lob');$('mb').style.display='none';$('cr').style.display='none';$('lb').style.display='block';
 if(MPI.n)$('rl').value=MPI.n;if(MPI.kn)$('kn').value=MPI.kn;lbRender();
 const sc=document.createElement('script');sc.src='https://cdn.jsdelivr.net/npm/peerjs@1.5.4/dist/peerjs.min.js';sc.onload=mpPeer;sc.onerror=()=>{MP.st='Cannot reach multiplayer service';lbRender()};document.head.appendChild(sc)}
function mpPeer(){try{const pid='corr-'+MP.code,P=MP.host?new Peer(pid):new Peer();MP.peer=P;
 P.on('disconnected',()=>{if(MP.peer===P&&!P.destroyed&&!document.hidden&&MP.on&&!PV.live){MP.st='Reconnecting…';lbRender();try{P.reconnect()}catch(e){}}});
 P.on('open',()=>{if(MP.host){MP.up=1;MP.st='Hosting';const o=lbMine();LBP.length=0;LBP.push({id:MP.id,n:o.n,kn:o.kn,tm:1});lbRender()}
  else{const q=P.connect(pid,{serialization:'json'});
   q.on('open',()=>{MP.conns=[q];MP.up=1;MP.st='Connected';const o=lbMine();q.send({t:'hi',id:MP.id,n:o.n,kn:o.kn});lbRender()});
   q.on('data',d=>mpRecv(d,q));
   q.on('close',()=>{const was=MP.up;MP.up=0;if(MP.st!='Lobby is full (6/6)'&&MP.st!='Game already started')MP.st='Host left the room';if(PV.live&&was)toast('Host left the room. Connection lost.');lbRender()})}});
 P.on('connection',q=>{q.on('open',()=>MP.conns.push(q));q.on('data',d=>mpRecv(d,q));
  q.on('close',()=>{const i=MP.conns.indexOf(q);if(i>=0)MP.conns.splice(i,1);if(!q.pid)return;
   if(PV.live){const r=MP.peers.get(q.pid);if(r)pOut(r,' left the realm');mpSend({t:'bye',id:q.pid})}
   else{const j=LBP.findIndex(p=>p.id===q.pid);if(j>0){LBP.splice(j,1);lbFix();lbBroadcast()}}})});
 P.on('error',e=>{MP.up=0;if(MP.rv>0&&MP.on&&!PV.live&&(e.type=='unavailable-id'||e.type=='network'||e.type=='server-error'||e.type=='socket-error'||e.type=='socket-closed')){MP.rv--;MP.st='Reconnecting…';lbRender();try{P.destroy()}catch(x){}setTimeout(()=>{if(MP.on&&!PV.live&&!MP.up)mpPeer()},2200);return}MP.st=e.type=='unavailable-id'?'Code already in use':e.type=='peer-unavailable'?'Room not found':'Network error ('+e.type+')';lbRender()})}catch(e){MP.st='Multiplayer failed';lbRender()}}
function mpRevive(){if(!MP.on||PV.live||document.hidden||MP.busyRv)return;const P=MP.peer;
 if(P&&!P.destroyed&&P.disconnected){MP.st='Reconnecting…';lbRender();try{P.reconnect()}catch(e){}return}
 if(P&&!P.destroyed&&!P.disconnected&&MP.up)return;
 if(!window.Peer||MP.st=='Lobby is full (6/6)'||MP.st=='Game already started')return;
 MP.busyRv=1;MP.rv=5;MP.st='Reconnecting…';lbRender();try{P&&P.destroy()}catch(e){}MP.conns=[];MP.up=0;
 setTimeout(()=>{MP.busyRv=0;if(MP.on&&!PV.live)mpPeer()},700)}
document.addEventListener('visibilitychange',()=>{if(!document.hidden)setTimeout(mpRevive,500)});
addEventListener('online',()=>setTimeout(mpRevive,500));
addEventListener('pageshow',e=>{if(e.persisted)setTimeout(mpRevive,500)});
function mpTick(){if(!MP.on)return;const t=now(),raw=t-mpL,dt=Math.min(.1,raw);mpL=t;
 if(raw>1.5)MP.peers.forEach(r=>r.seen=t);
 if(PV.live){
  if(!PV.ann&&t>=PV.peaceEnd){PV.ann=1;toast('⚔ Peace has ended! War begins!');sfx('horn');say('The peace has ended. To war!',1)}
  else if(!PV.a30&&t<PV.peaceEnd&&PV.peaceEnd-t<30){PV.a30=1;toast('30 seconds of peace left!')}
  MP.peers.forEach(r=>{if(r.out)return;if(MP.up&&t-r.seen>10){pOut(r,' lost connection');return}
   const dx=r.tx-r.x,dy=r.ty-r.y,dd=Math.hypot(dx,dy);r.mv=dd>.6;
   if(dd>300){r.x=r.tx;r.y=r.ty}else{const k=Math.min(1,dt*10);r.x+=dx*k;r.y+=dy*k}
   if(r.mv){r.ft+=dt;if(r.ft>.17){r.ft=0;r.fr^=1}}
   r.gu.forEach(g=>{const ex=g.tx-g.x,ey=g.ty-g.y,e=Math.hypot(ex,ey);
    if(e>200){g.x=g.tx;g.y=g.ty}else{const k=Math.min(1,dt*7);g.x+=ex*k;g.y+=ey*k;if(e>.8)g.ph+=dt*10}
    g.atk-=dt;g.hit-=dt})});
  if(MP.host&&MP.up)botTick(dt,t);if(!won)merTick(t);alTick();
  const alive=!(won&&PC.hp<=0)||window.GENM;
  if(MP.up&&alive){
   if(t>MP.tS){MP.tS=t+.125;const s=toSh(H.x,H.y),ar=[];
    AR.forEach(a=>{if(a.team===0&&!a.vis&&!a.sent){a.sent=1;const q=toSh(a.x,a.y);ar.push(Math.round(q[0]),Math.round(q[1]),Math.round(a.vx),Math.round(a.vy))}});
    mpSend({t:'s',id:MP.id,x:Math.round(s[0]*10)/10,y:Math.round(s[1]*10)/10,f:H.face,m:H.m,hp:Math.round(H.hp),mhp:H.mhp,ar:ar.slice(0,40)})}
   if(t>MP.tA){MP.tA=t+(ARM.length>150?.4:.25);const u=[];
    ARM.forEach(a=>{if(a.dead)return;const q=toSh(a.x,a.y);u.push(a.uid|0,TYS.indexOf(a.type),Math.round(q[0]),Math.round(q[1]),Math.round(a.hp),a.face>0?1:0,a.atk>0?1:0)});
    mpSend({t:'a',id:MP.id,u})}
   if(t>MP.tB){MP.tB=t+1.2;
    mpSend({t:'b',id:MP.id,hp:Math.round(PC.hp),mh:PC.mhp,sl:SLOTS.slice(0,NB).map(q=>q.built?Math.max(1,q.hp|0):0),c1:PB.c1,c2:PB.c2,em:PB.em,bx:(PB.p===undefined&&PB.s===undefined)?0:1,bp:PB.p|0,bs:PB.s|0,bc:PB.c3||'#f3ecd8',hi:window.HI|0,n:RULER||'Player',kn:KNAME,cw:cwOut(),cp:window.cpOut?cpOut(1):[],dg:window.dgOut?dgOut():0})}
   if(t>MP.tD){MP.tD=t+.15;flushD()}}}
 if(t>MP.tB2){MP.tB2=t+1;$('mpb').textContent=MP.up?'🌐 '+MP.code+' · '+(PV.live?'in game':LBP.length+' in lobby'):'🌐 '+MP.code+' · '+MP.st}}
function drawRP(r,x,y){const t=now();c.fillStyle='rgba(0,0,0,.3)';c.fillRect(x-6,y-1,12,3);
 const bob=r.m?8:0,pqR=r.mv?Math.floor(((t*(r.m?14:11))%6.2832)/6.2832*8):0,phR=pqR/8*6.2832,tqR=Math.floor(t*3)%3,mvR=!!r.mv;Zspr(['R',r.s|0,r.c1,r.c2,r.f,r.hit>0?1:0,mvR?1:0,pqR,r.m?1:0,tqR].join('|'),(ox,oy)=>{if(r.m)Zhorse(ox,oy,r.f,phR,0,mvR,'#6a4326',r.c2);Zman({x:ox-(r.m?r.f:0),y:oy,f:r.f,sc:1.12,t:tqR/3,sd:(r.s|0)*5+2,mv:mvR,ph:phR,fl:r.hit>0,col:r.c1,acc:r.c2,st:ZHERO[(r.s|0)%4]||ZHERO[0],up:false,atk:-1,wep:'sword',jp:((r.s|0)%4)==1,wv:ZHW[(r.s|0)%4],ride:r.m?12:0,hb:r.m&&mvR?-Math.round(Math.abs(Math.sin(phR))*1.4):0,cape:r.c2,wp:-1,hs:1.05})},x,y,tqR);
 flag(x-r.f*7,y-6-bob,r,1.5);const hbR=r.m?-46:-35;c.fillStyle='#a8142a';c.fillRect(x-8,y+hbR,16,2);c.fillStyle='#e84';c.fillRect(x-8,y+hbR,Math.max(0,16*r.hp/r.mhp)|0,2);
 c.font='bold 6px monospace';c.textAlign='center';c.fillStyle='#000';c.fillText(r.n,x+1,y+hbR-3);c.fillStyle='#f99';c.fillText(r.n,x,y+hbR-4)}
function mpGo(code,host){try{sessionStorage.setItem('cor_mp',JSON.stringify({code,host,n:esc($('rl').value).slice(0,14),kn:esc($('kn').value).slice(0,18)}));try{history.replaceState(null,'',location.pathname+location.search)}catch(e){}reloadToMenu()}catch(e){mpUI('This browser blocks storage; multiplayer needs it')}}
function mpHost(){let q='';for(let i=0;i<4;i++)q+=CODEC[Math.floor(Math.random()*CODEC.length)];q+=MAPLC[MAPI]||'X';mpGo(q,1)}
function mpJoin(){const q=($('mpc').value||'').toUpperCase().replace(/[^A-Z0-9]/g,'');if(q.length<4)return mpUI('Enter the room code your friend shares');mpGo(q,0)}
function mpLeave(){try{if(MP.on)mpSend({t:'bye',id:MP.id});sessionStorage.removeItem('cor_mp');history.replaceState(null,'',location.pathname+location.search)}catch(e){}reloadToMenu()}
function mpUI(msg){const back=pzT?'pzx()':'pzMenu()';let h='<div class="pn"><h3>PvP Lobby</h3>';
 if(MP.on){h+='<p>Room <b style="color:#8ee;font-size:12px">'+MP.code+'</b><br>'+(MP.host?'You are hosting. Keep the game open.':'Joined as guest.')+'<br>'+(PV.live?'Players: '+[esc(RULER||KNAME||'You')].concat([...MP.peers.values()].map(r=>r.n+(r.out?' ✖':''))).join(', '):'In lobby')+'</p><button onclick="mpLeave()">Leave room (restarts game)</button>'}
 else{h+='<p>2 to 6 lords. Empty seats can be filled with bots, and any lords on the same team are allies. Travelling merchants visit at random. Each lord builds their own castle. 7 minutes of peace, then war: the last castle standing wins. Hosting or joining restarts your game.</p><button class="g" onclick="mpHost()">Host a lobby</button><input id="mpc" maxlength="8" placeholder="ROOM CODE" onkeydown="event.stopPropagation()"><button onclick="mpJoin()">Join lobby</button>'}
 h+=(msg?'<p>'+esc(msg)+'</p>':'')+'<button onclick="'+back+'">◀ Back</button></div>';pzShow(h)}
$('lbs').onclick=lbStart;$('lbx').onclick=mpLeave;
$('rl').addEventListener('input',lbEdit);$('kn').addEventListener('input',lbEdit);
$('b5').onclick=()=>{pzT=1;mpUI()};
addEventListener('pointerdown',()=>{try{aud();if(ac&&ac.state=='suspended'&&!muted)ac.resume()}catch(e){}});
addEventListener('pagehide',()=>{if(MP.on)mpSend({t:'bye',id:MP.id})});
mpInit();

let last=now();hud();loop();
