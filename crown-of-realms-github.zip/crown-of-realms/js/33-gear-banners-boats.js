/* ===== v17: visible gear, banners, horse barding, boats + sea maps ===== */
(function(){try{
const G=window.GEAR,B={},ST={};
/* gear on the character */
function vis(){try{const hi=window.HI|0;B.h=B.h||{};if(!B.h[hi])B.h[hi]=Object.assign({},ZHERO[hi]);B.w=B.w||{};if(!B.w[hi])B.w[hi]=ZHW[hi];
 const a=G.eq.a?+G.eq.a.id.slice(1):-1,w=G.eq.w?+G.eq.w.id.slice(1):-1;
 const AT=[{a:'leath',h:'cap'},{a:'mail',h:'nasal',tab:1},{a:'plate',h:'kettle',tab:1,pl:1,sh:'kite'},{a:'plate',h:'great',tab:1,pl:1,cross:1,cape:1,sh:'kite'}];
 ZHERO[hi]=a>=0?Object.assign({},B.h[hi],AT[a],{hv:1}):B.h[hi];ZHW[hi]=w>=0?['gladius','long','sabre','long'][w]:B.w[hi];
 const u=G.eq.ua?+G.eq.ua.id.slice(2):-1;['pike','sword','bow','xbow','cav','jave'].forEach(t=>{if(!ZMS[t])return;B.u=B.u||{};if(!B.u[t])B.u[t]=Object.assign({},ZMS[t]);ZMS[t]=u>=0?Object.assign({},B.u[t],{a:['leath','mail','plate'][u],tab:1}):B.u[t]});
 ZC.clear()}catch(e){console.error(e)}}
const _m=window.MWBL;window.MWBL=function(){return G.eq.w&&G.eq.w.id=='w3'?'#ff7a2a':(_m?_m():'')};
const _ab=window.armBuy;window.armBuy=function(t,i){_ab(t,i);vis()};
/* horse barding drawn over the horse */
const _zh=Zhorse;Zhorse=function(X,Y,f,ph,sad,mv,coat,capc){_zh(X,Y,f,ph,sad,mv,coat,capc);try{const e=G.eq.ha;if(!e||coat!='#6a4326')return;const t=+e.id.slice(2),R=Zpen(X,Y,f,0).R,col=['#b8332b','#9aa0aa','#c9ced8'][t];
 R(col,-6,-13,12,6);R(Zsh(col,.7),-6,-8,12,1);R('#d8b040',-6,-13,12,1);if(t>0){R(col,f*8-1,-17,3,5);R('#d8b040',f*9,-16,1,1)}if(t>1)R(Zsh(col,.8),-5,-11,10,1)}catch(e){}};
/* banners planted in camp, drawn in the world */
function dBan(c0,x,y,sz,t){const b=(window.getPB&&getPB())||{c1:'#b01c1c',c2:'#e8b94a',em:1},ph=sz*7+10,w=[0,7,11,16,22][sz],h=[0,10,16,24,32][sz];
 c0.fillStyle='#3a2410';c0.fillRect(x-1,y-ph-h-2,2,ph+h+2);c0.fillStyle='#d8b060';c0.fillRect(x-2,y-ph-h-3,4,2);
 let e=null;try{e=bcv(b)}catch(_){}
 for(let i=0;i<w;i++){const wv=Math.sin(t*3+i*.5)*1.4*(i/w),sw=sz==1||sz==4?Math.round(i/w*h*.35):0,top=Math.round(y-ph-h+wv),hh=h-(sz==1?sw:0)-(sz==4&&i%5==4?4:0);
  if(e)c0.drawImage(e,(i/w*e.width)|0,0,1,e.height,x+1+i,top,1,hh);else{c0.fillStyle=b.c1;c0.fillRect(x+1+i,top,1,hh)}}
 c0.fillStyle='#1a0e06';c0.fillRect(x-3,y,6,2)}
const _p=window.PRL;window.PRL=function(L,cx,cy){if(_p)_p(L,cx,cy);if(!G.eq.b)return;const sz=G.eq.b.d,sp=[[CX-28,CX+112],[CX+28,CX+112],[CX-84,CX+108],[CX+84,CX+108]];sp.slice(0,sz).forEach(q=>{if(q[0]>cx-40&&q[0]<cx+VW+40&&q[1]>cy&&q[1]<cy+VH+50)L.push({k:'pris',p:{ban:sz,init:1},x:q[0],y:q[1]})})};
const _dp=window.drawPris;window.drawPris=function(p,x,y,t){if(p.ban)return dBan(c,x,y,p.ban,t);return _dp(p,x,y,t)};
/* face + crest detail for lords */
/* boats and sea maps */
const MAPS=[{n:'Emerald Archipelago',sea:'#1f6f8f',sea2:'#2b8aa8',land:'#4f8a3a',loot:{food:25,wood:30},pir:0,rocks:6},{n:'Frozen Fjords',sea:'#2a4a6a',sea2:'#3c6a8c',land:'#dfe9f0',loot:{stone:30,gold:25},pir:0,rocks:14},{n:'Pirate Straits',sea:'#1a3a4a',sea2:'#264f62',land:'#a89060',loot:{gold:60,wood:20},pir:3,rocks:8}];
let hasBoat=false,V=null;
window.sailUI=function(){if(!inGame)return;const e=$('ov');e.style.display='flex';let h='<div style="width:min(94vw,480px)"><div class="xh"><h3>⛵ Harbour</h3><button onclick="ovx()">✕ Close</button></div>';
 if(!hasBoat)h+='<p style="font-size:9px">You need a ship to cross the seas.</p><button onclick="buyBoat()">Build a longship (40 wood, 20 gold)</button>';
 else{h+='<p style="font-size:9px">Choose a sea. Plunder islands, then sail back to your dock to bring the loot home.</p>'+MAPS.map((m,i)=>'<p><button onclick="voyage('+i+')">⛵ '+m.n+'</button></p>').join('')}
 e.innerHTML=h+'</div>'};
window.buyBoat=function(){if(H.wood<40||H.gold<20){sfx('no');return toast('Needs 40 wood and 20 gold')}H.wood-=40;H.gold-=20;hasBoat=true;sfx('recruit');toast('Your longship is launched');sailUI()};
window.voyage=function(mi){ovx();const m=MAPS[mi],W=1800,Ht=1200,cv=document.createElement('canvas');cv.style.cssText='position:fixed;inset:0;width:100vw;height:100vh;z-index:9999;touch-action:none;background:'+m.sea;cv.width=innerWidth;cv.height=innerHeight;document.body.appendChild(cv);const g=cv.getContext('2d');
 let seed=mi*977+Math.floor(Math.random()*1e4);const rn=()=>(seed=(seed*16807)%2147483647)/2147483647;
 const isl=[];for(let i=0;i<7;i++)isl.push({x:350+rn()*1350,y:100+rn()*1000,r:50+rn()*45,tk:0,sd:rn()*6});
 const rocks=[];for(let i=0;i<m.rocks;i++)rocks.push({x:300+rn()*1450,y:60+rn()*1080,r:12+rn()*8});
 const pir=[];for(let i=0;i<m.pir;i++)pir.push({x:900+rn()*800,y:100+rn()*1000,a:0});
 V={x:110,y:Ht/2,a:0,hp:100,loot:{},tx:null,ty:null,keys:{},done:0};const dock={x:60,y:Ht/2};
 const kd=e=>{V.keys[e.key.toLowerCase()]=1},ku=e=>{V.keys[e.key.toLowerCase()]=0};addEventListener('keydown',kd);addEventListener('keyup',ku);
 const cam=()=>({x:Math.max(0,Math.min(W-cv.width,V.x-cv.width/2)),y:Math.max(0,Math.min(Ht-cv.height,V.y-cv.height/2))});
 cv.addEventListener('pointerdown',e=>{const c2=cam();V.tx=e.clientX+c2.x;V.ty=e.clientY+c2.y});cv.addEventListener('pointermove',e=>{if(e.buttons){const c2=cam();V.tx=e.clientX+c2.x;V.ty=e.clientY+c2.y}});
 const leave=ok=>{V.done=1;cancelAnimationFrame(raf);removeEventListener('keydown',kd);removeEventListener('keyup',ku);cv.remove();if(ok){for(const k in V.loot)H[k]=(H[k]||0)+V.loot[k];toast('⛵ Home with '+Object.entries(V.loot).map(([k,v])=>v+' '+k).join(', '));sfx('loot')}else toast('Your voyage ends');hud()};
 let raf,last=performance.now();
 const lp=n=>{raf=requestAnimationFrame(lp);const dt=Math.min(.05,(n-last)/1000);last=n;let dx=0,dy=0;const K=V.keys;if(K.a||K.arrowleft)dx--;if(K.d||K.arrowright)dx++;if(K.w||K.arrowup)dy--;if(K.s||K.arrowdown)dy++;if(V.tx!=null){dx=V.tx-V.x;dy=V.ty-V.y;const d=Math.hypot(dx,dy);if(d<10){dx=dy=0;V.tx=null}else{dx/=d;dy/=d}}
  const l=Math.hypot(dx,dy)||1;if(dx||dy){let ta=Math.atan2(dy,dx),da=ta-V.a;da=Math.atan2(Math.sin(da),Math.cos(da));V.a+=da*Math.min(1,dt*6);dx=Math.cos(V.a)*l;dy=Math.sin(V.a)*l;(V.wk=V.wk||[]).push({x:V.x-Math.cos(V.a)*14,y:V.y-Math.sin(V.a)*14,l:1});const nx=V.x+dx/l*95*dt,ny=V.y+dy/l*95*dt;let blk=0;isl.forEach(s=>{if(Math.hypot(nx-s.x,ny-s.y)<s.r*.82)blk=1});if(!blk){V.x=Math.max(20,Math.min(W-20,nx));V.y=Math.max(20,Math.min(Ht-20,ny))}}
  isl.forEach(s=>{if(!s.tk&&Math.hypot(V.x-s.x,V.y-s.y)<s.r+22){s.tk=1;for(const k in m.loot)V.loot[k]=(V.loot[k]||0)+Math.round(m.loot[k]*(.6+rn()*.8));toast('🏝 You plunder the island')}});
  rocks.forEach(r=>{if(Math.hypot(V.x-r.x,V.y-r.y)<r.r+8){V.hp-=25*dt}});pir.forEach(p=>{const a=Math.atan2(V.y-p.y,V.x-p.x),d=Math.hypot(V.x-p.x,V.y-p.y);p.a=a;if(d>20){p.x+=Math.cos(a)*55*dt;p.y+=Math.sin(a)*55*dt}if(d<40)V.hp-=14*dt});
  if(V.hp<=0){toast('💥 Your ship sinks! Loot lost.');return leave(0)}
  if(Math.hypot(V.x-dock.x,V.y-dock.y)<60&&Object.keys(V.loot).length)return leave(1);
  const c2=cam(),t=n/1000;g.fillStyle=m.sea;g.fillRect(0,0,cv.width,cv.height);g.strokeStyle=m.sea2;g.lineWidth=2;for(let i=0;i<60;i++){const wx=(i*173%W)-c2.x,wy=(i*97%Ht)-c2.y+Math.sin(t+i)*3;g.beginPath();g.moveTo(wx,wy);g.quadraticCurveTo(wx+10,wy-5,wx+20,wy);g.stroke()}
  g.save();g.translate(-c2.x,-c2.y);isl.forEach(s=>{g.fillStyle=m.land;g.globalAlpha=s.tk?.6:1;g.beginPath();for(let i=0;i<14;i++){const a=i/14*6.283,r=s.r*(.85+Math.sin(a*3+s.sd)*.15);g.lineTo(s.x+Math.cos(a)*r,s.y+Math.sin(a)*r)}g.fill();g.globalAlpha=1;g.fillStyle='#2e5a22';if(mi==0)for(let i=0;i<5;i++)g.fillRect(s.x-20+i*10,s.y-8+(i%2)*10,5,5)});
  g.fillStyle='#5a5a62';rocks.forEach(r=>{g.beginPath();g.arc(r.x,r.y,r.r,0,6.283);g.fill()});g.fillStyle='#6a4a2a';g.fillRect(dock.x-30,dock.y-18,50,36);g.fillStyle='#e8d070';g.font='10px sans-serif';g.fillText('DOCK',dock.x-22,dock.y+3);
  pir.forEach(p=>{g.save();g.translate(p.x,p.y);g.rotate(p.a);g.fillStyle='#2a2a2a';g.fillRect(-14,-6,28,12);g.fillStyle='#e8e8e8';g.fillRect(-2,-9,3,18);g.restore()});
  (V.wk||[]).forEach(w=>{w.l-=dt*1.2;g.fillStyle='rgba(255,255,255,'+Math.max(0,w.l*.5)+')';g.fillRect(w.x-1.5,w.y-1.5,3,3)});V.wk=(V.wk||[]).filter(w=>w.l>0);g.save();g.translate(V.x,V.y+Math.sin(t*3)*1.5);g.rotate(V.a);g.fillStyle='#7a4a22';g.beginPath();g.moveTo(18,0);g.lineTo(-14,-9);g.lineTo(-14,9);g.fill();g.fillStyle=(window.PB&&PB.c1)||'#b01c1c';g.fillRect(-2,-7,3,14);g.restore();g.restore();
  [...isl.filter(s=>!s.tk).map(s=>[s.x,s.y,'#ffd54a']),[dock.x,dock.y,'#ff7a5a']].forEach(q=>{const sx=q[0]-c2.x,sy=q[1]-c2.y;if(sx>0&&sx<cv.width&&sy>0&&sy<cv.height)return;const ax=Math.max(14,Math.min(cv.width-14,sx)),ay=Math.max(60,Math.min(cv.height-14,sy)),an=Math.atan2(sy-cv.height/2,sx-cv.width/2);g.save();g.translate(ax,ay);g.rotate(an);g.fillStyle=q[2];g.beginPath();g.moveTo(10,0);g.lineTo(-6,-6);g.lineTo(-6,6);g.fill();g.restore()});g.fillStyle='#fff';g.font='14px sans-serif';g.fillText(MAPS[mi].n+' · Hull '+Math.max(0,V.hp|0)+' · Loot '+(Object.entries(V.loot).map(([k,v])=>v+' '+k).join(', ')||'none')+' · Sail back to the DOCK',12,22);g.fillText('✕ tap here to abandon',12,44)};
 cv.addEventListener('click',e=>{if(e.clientY<52&&e.clientX<260)leave(0)});raf=requestAnimationFrame(lp)};
[['sail','⛵ Sail',()=>sailUI()]].forEach(([id,tx,fn])=>{const b=document.createElement('button');b.className='b';b.id=id;b.textContent=tx;b.addEventListener('pointerdown',ev=>{ev.preventDefault();fn()});$('brow').appendChild(b)});
}catch(e){console.error('v17 patch',e)}})();
